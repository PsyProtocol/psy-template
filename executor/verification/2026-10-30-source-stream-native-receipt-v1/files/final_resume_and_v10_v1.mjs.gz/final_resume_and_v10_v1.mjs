// Final-source reuse plus actual v10 native planning. No financial capability.
import{readFile,writeFile}from'node:fs/promises';import{join,resolve}from'node:path';import assert from'node:assert/strict';
import{prepareSealedMinimumSourceStream,prepareRandomSourceStream}from'<application-root>/executor/randomSourceStream.mjs';
import{parseLosslessJson,losslessJson}from'<application-root>/amm/u124/client.mjs';
import{sha256}from'<application-root>/executor/requestBinding.mjs';
const c=resolve(process.argv[2]),old=resolve(process.argv[3]),rows=[];
for(const market of ['amm','bondingcurve']){
 const o=JSON.parse(await readFile(join(c,'native-integration-v1',market,'options.json'),'utf8'));
 const r=await prepareSealedMinimumSourceStream(o,{runNative:async()=>{throw Error('unexpected duplicate native preparation');}});rows.push({market,status:await r.status(),newNativeRuns:0});
}
const d=join(old,'native-planner-v1'),source=parseLosslessJson(await readFile(join(d,'source.json'),'utf8')),driver=join(c,'bin-v2/random_stream_plan');
const o={historyRoot:source.history.checkpoint_path.root,wallet:driver,walletSha256:sha256(await readFile(driver)),runtimeDirectory:join(c,'v10-runtime-v1')};
for(const[n,file]of Object.entries({review:'review.json',snapshot:'source.json',draw:'draw.json',policy:'policy.json'})){o[n]=join(d,file);o[n+'Sha256']=sha256(await readFile(o[n]));}
const route=await prepareRandomSourceStream(o),p=await route.plan();assert.equal(p.status.members,5);assert.equal(p.status.canSign,false);assert.throws(()=>route.authorizeSettlement(),/cannot enable writes/);
const again=await prepareRandomSourceStream(o,{runNative:async()=>{throw Error('unexpected duplicate v10 native preparation');}});assert.deepEqual((await again.plan()).plan,p.plan);
await writeFile(join(c,'public/FINAL-REUSE-AND-V10-v1.json'),losslessJson({schema:1,scope:'actual native finite-source planning; archived synthetic inputs, no full UPS or live execution',rows,v10:{status:p.status,outputs:p.outputs,driverSha256:o.walletSha256,exactRestart:true},additionalNativePlanningRuns:1,totalNativePlanningRuns:6,financialOperations:0,proofsGenerated:0,rpcRequests:0,canBroadcast:false})+'\n',{flag:'wx'});console.log('Final v13 reuse and real v10 native planning passed; no broadcast capability');
