from pathlib import Path
import subprocess,json,os,hashlib
case=Path(__file__).resolve().parent
sdk=case.parent/'sdk-mainnet-beta-20261027-v1'
app=case.parent.parent/'psy-template-security-20261016'
out=case/'compatibility-v1';out.mkdir()
old_seal=case.parent/'market-seal-inclusion-20261028-v1/component-proof-v1'
old_order=case.parent/'market-random-order-20261028-v1'
seal=json.loads((old_seal/'REPORT.json').read_text())
def run(label,cmd):
 r=subprocess.run([str(x)for x in cmd],capture_output=True,timeout=120)
 (out/(label+'.log')).write_bytes(r.stdout+r.stderr)
 assert r.returncode==0,label
run('legacy-seal',[sdk/'target/release/verify_seal_component',old_seal/'statement.json',old_seal/'layout.json',seal['checkpointRoot'],seal['sealCheckpoint'],old_seal/'proof.bin',out/'legacy-seal.json'])
run('legacy-order',[sdk/'target/release/verify_random_order_component',old_order/'public/client-statement-v1.json',old_order/'component-proofs-v1/permutation-proof.bin',out/'legacy-order.json'])
node=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
run('client-encoding',[node,case/'interop.mjs',app/'batching/random-order/scope.mjs',case/'component-proofs-v1',case/'client-roundtrip-v1'])
summary=json.loads((case/'component-proofs-v1/REPORT.json').read_text())
for market in ['amm','curve']:
 run('client-'+market,[sdk/'target/release/verify_scoped_order',case/'client-roundtrip-v1'/(market+'-input.json'),case/'component-proofs-v1/layout.json',summary[market+'CheckpointRoot'],summary['sealCheckpoint'],case/'component-proofs-v1'/(market+'-proof.bin'),out/('client-'+market+'.json')])
args=[str(x)for x in [sdk/'target/release/verify_scoped_order',case/'component-proofs-v1/amm-input.json',case/'component-proofs-v1/layout.json',summary['ammCheckpointRoot'],summary['sealCheckpoint'],case/'component-proofs-v1/amm-proof.bin',out/'wrong-domain.json']]
env=os.environ.copy();env['PSY_MARKET_TESTNET_PROFILE']='sepolia-config-v1'
r=subprocess.run(args,env=env,capture_output=True,timeout=120)
(out/'wrong-domain.log').write_bytes(r.stdout+r.stderr)
report=json.loads((out/'wrong-domain.json').read_text());assert r.returncode==1 and report['stage']=='domain' and report['failureKind']=='rejected'
(out/'RESULT.json').write_text(json.dumps({'schema':2,'legacySavedComponentsVerified':2,'clientNativeProofReplays':2,'wrongDomainNotClassifiedAsEndpointRejection':True,'wrongDomainStage':report['stage'],'financialOperations':0,'proofsGenerated':0,'randomAuthorization':False},indent=2)+'\n')
