// Application protocol tests. These do not claim browser/native UPS acceptance.
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { createPrepareOnlyMarketService, createMarketWalletService } from "../market-preparation/market-client/wallet/prepareService.mjs";
import bundle from "../market-preparation/bundle.json";
import source from "../market-preparation/SOURCE.json";
const sha = (x: string | Uint8Array) =>
  createHash("sha256").update(x).digest("hex");
function service(fetcher?: typeof fetch) {
  return createPrepareOnlyMarketService({
    bundle,
    store: { get: async () => undefined, set: async () => {} },
    provider: {},
    ...(fetcher ? { fetcher } : {}),
    prepareTrace: async () => {
      throw Error("must not prove unreviewed record");
    },
    parse: JSON.parse,
    stringify: JSON.stringify,
  });
}
describe("wallet-owned prepare-only market integration", () => {
  it("reports the native verifier/dependency boundary and exposes no broadcast method", () => {
    const s = service();
    expect(s.capabilities()).toMatchObject({
      prepareOnly: true,
      broadcast: false,
      nativeFullCallVerifier: false,
      financialAuthorization: false,
    });
    expect("broadcast" in s).toBe(false);
    expect("installNativeVerifier" in s).toBe(false);
  });
  it("accepts only reviewed actual network endpoints/domain", async () => {
    const s = service();
    await expect(
      s.assertNetwork(bundle.networkConfig),
    ).resolves.toBeUndefined();
    for (const mutate of [
      (c: any) => (c.magic = "2"),
      (c: any) => (c.realm_configs[0].rpc_url = ["https://other.example"]),
      (c: any) =>
        (c.coordinator_configs[0].rpc_url = ["https://other.example"]),
      (c: any) => c.users_per_realm++,
    ]) {
      const c = structuredClone(bundle.networkConfig);
      mutate(c);
      await expect(s.assertNetwork(c)).rejects.toThrow();
    }
  });
  it("checks the real chain namespace afresh without enabling market writes", async () => {
    let calls = 0;
    let root = bundle.registry.network.chainRootAt1;
    const s = service((async () => {
      calls++;
      return new Response(JSON.stringify({jsonrpc: "2.0", id: 1, result: {global_chain_root: root}}));
    }) as typeof fetch);
    await expect(s.assertChain()).resolves.toMatchObject({chainRootAt1: root});
    root = "b".repeat(64);
    await expect(s.assertChain()).rejects.toThrow("chain instance changed");
    expect(calls).toBe(2);
    expect(s.capabilities().broadcast).toBe(false);
  });
  it("vendors application modules exactly without changing the SDK", () => {
    for (const file of source.files) {
      const bytes = readFileSync(
        new URL("../market-preparation/" + file.file, import.meta.url),
      );
      expect(sha(bytes)).toBe(file.sha256);
    }
    expect(
      sha(
        readFileSync(
          new URL("../market-preparation/bundle.json", import.meta.url),
        ),
      ),
    ).toBe(source.bundleSha256);
    expect(source.requiredSdkManifestSha256).toBe(
      bundle.registry.sdkManifestSha256,
    );
  });
  it("keeps execution adapters wallet-owned and guards queue enqueue and execution", () => {
    const core = readFileSync(
      new URL("./psy-wallet-ext-core.ts", import.meta.url),
      "utf8",
    );
    const messages = readFileSync(
      new URL("../message.ts", import.meta.url),
      "utf8",
    );
    expect(core).toContain("txQueue.runExclusive(async () =>");
    expect(core).toContain("txQueue.assertReadyForMarket(address)");
    expect(core).toContain(".assertNoPending(");
    expect(messages).not.toContain('"psy_confirmPreparedMarket"');
    expect(core).toContain("installedMarketOptions(marketPreparationBundle)");
    expect(core).toContain("this.marketExecution().broadcast(context, intentId, preparedHash)");
  });
});

describe("fixed market verifier boundary",()=>{
 it("refuses an internal exact service without wallet-owned native resources and approval",()=>{
  const base={bundle,store:{get:async()=>undefined,set:async()=>{}},provider:{},prepareTrace:async()=>{throw Error("forbidden");},parse:JSON.parse,stringify:JSON.stringify};
  expect(()=>createMarketWalletService(base as any)).toThrow();
  expect(()=>createMarketWalletService({...base,native:{identity:async()=>"{}",identify:async()=>"{}",verify:async()=>"{}"},expectedVerifierPackSha256:"a".repeat(64)} as any)).toThrow();
 });
 it("keeps AMM and other markets under the identical reviewed network",()=>{
  expect(bundle.amm.registry.markets[0].kind).toBe("amm");
  expect(bundle.amm.registry.markets[0].marketId).toBe(9);
  expect(bundle.amm.networkConfig).toEqual(bundle.networkConfig);
  expect(bundle.amm.registry.sdkManifestSha256).toBe(source.requiredSdkManifestSha256);
 });
});
