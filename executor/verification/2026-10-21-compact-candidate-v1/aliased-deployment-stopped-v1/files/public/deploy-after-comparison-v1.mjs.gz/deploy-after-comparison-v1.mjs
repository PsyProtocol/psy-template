// Owned staging QA: wait for completed whole-UPS comparison, then fresh deployment only.
import assert from 'node:assert/strict';
import{existsSync}from'node:fs';
import{read,run,save}from'/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016/batching/admission/liveSupport.mjs';
const base='/tmp/psy-market-candidate-bulk-live-20261021-v1',comparison='/tmp/psy-market-profile-comparison-20261021-v1/COMPARISON.json';
console.log('Waiting for complete fixed40/compact full-UPS comparison; no financial RPC before it.');
while(!existsSync(comparison))await new Promise(r=>setTimeout(r,5000));
const c=read(comparison);assert.equal(c.broadcast,false);assert.equal(c.productionReady,false);assert.equal(c.methodology.chainTps,null);assert.equal(c.comparisons.length,4);assert.deepEqual(c.comparisons.map(r=>r.market).sort(),['amm','bondingcurve','nftmarket','orderbook']);for(const r of c.comparisons)assert.equal(r.sameContractStateAndFees,true);
console.log(new Date().toISOString(),'Comparison complete; starting pinned fresh-only deployment.');
const timing=await run(process.execPath,['executor/acceptance/candidateDeploy.mjs',base,'/tmp/psy-market-isolated-live-20261020-v1','/tmp/psy-ordinary-diagnostics-binaries-20261021-v14/isolated_wallet','/tmp/psy-executor-resident-binaries-20261021-v3/compact_market_wallet','all-four-v1'],base+'/deployments-v1.log',{PSY_CANDIDATE_RELEASE_FILE:'candidate-release-v4.json'});
save(base+'/public/deployment-after-comparison-complete-v1.json',{completedAt:new Date().toISOString(),comparison,timing,scope:'fresh deployment and registration only; bootstrap and economic acceptance still required'});
