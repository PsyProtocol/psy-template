//! Deterministic v14 continuous settlement, separate from fresh bootstrap.
//! Initial pool/user actions and final claims are actual VM prerequisites only.
use super::*;
use super::funded_bootstrap_full_ups::{registered, OWNER, CAP};
use super::minimum_stream_full_ups::{native_total, conservation};

fn bound(mut request: Request, key: [u64;4]) -> Request {
    request.registered_key=Some(key);request
}

#[tokio::test]
#[ignore="bounded v14 complete UPS continuation; no financial or RPC authority"]
async fn deterministic_funded_stream_complete_ups_continuation()->Result<()> {
    let out=std::env::var("FUNDED_STREAM_OUT")?;fs::create_dir(&out)?;
    for kind in ["amm","bondingcurve"] {
        // No legacy sponsor or pre-populated fee cap is used. Pool setup is
        // intentionally independent of the separately accepted first-use UPS.
        let mut w=setup_with_sponsor(kind,false)?;
        ensure!(w.val(V,"fee_cap",0)==0&&w.val(V,"fee_used",0)==0,"no implicit authorization");
        w.set(OWNER,0,0,CAP+ESCROW);
        let totals=[asset_total(&w,A)?,asset_total(&w,B)?];let native=native_total(&w)?;
        let mut chain=StreamChain::new(&w).await?;
        ensure!(chain.spec["version"]==14&&chain.spec["fee_owner"]==OWNER,"exact deterministic owner/profile");
        let key=registered(&chain);
        w.run(OWNER,M,"authorize_fee_budget",&[vec![V,1,CAP],key.to_vec()].concat())?;
        w.run(OWNER,0,"transfer",&[V,CAP])?;
        let (_,inactive)=SourcePage::inactive_maintenance(&chain.review,&chain.source)?;
        let mut grant=bound(basic(13,&inactive,&w),key);
        grant.fields[21]=1;grant.fields[22]=CAP;grant.fields[23]=1;
        chain.prove(&mut w,grant,&out,"funding-grant").await?;
        conservation(&w,totals,native)?;

        let snapshot=chain.source.clone();
        let source=stream_source::prepare(&chain.review,&snapshot,snapshot.history.checkpoint_path.root)?;
        let queue=stream_source::priority(&chain.review,&snapshot,snapshot.history.checkpoint_path.root)?;
        ensure!(source.len()==2&&queue.members.len()==5,"bounded two-source-page five-order workload");
        let open=bound(basic(OPEN,&source[0],&w),key);
        chain.prove(&mut w,open,&out,"open").await?;
        let after_open=w.clone();let open_leaf=chain.base.last_leaf;
        w.run(203,M,"request_cancel",&[])?;
        for(i,page)in source.iter().enumerate(){
            let request=bound(basic(COVER,page,&w),key);
            chain.prove(&mut w,request,&out,&format!("source-{i}")).await?;
            conservation(&w,totals,native)?;
        }
        ensure!(w.val(V,"stream_phase",0)==3,"complete frozen source before settlement");
        let first=bound(settle_request(&w,&chain.review,&snapshot,&source[0],&queue,0)?,key);
        chain.prove(&mut w,first,&out,"settle-0").await?;
        let before_tail=w.clone();let tail_leaf=chain.base.last_leaf;
        let tail=bound(settle_request(&w,&chain.review,&snapshot,&source[0],&queue,4)?,key);
        chain.prove(&mut w,tail,&out,"settle-tail").await?;
        ensure!(w.val(V,"stream_phase",0)==7&&w.val(V,"stream_settled",0)==5,"all 4+1 members terminal");
        let ordinary_claims=claim_all(&mut w)?;conservation(&w,totals,native)?;
        let normal_fee=w.val(V,"fee_used",0);

        let mut timed=before_tail;timed.checkpoint=snapshot.fields[7]+1;
        chain.base.last_leaf=tail_leaf;
        let request=bound(settle_request(&timed,&chain.review,&snapshot,&source[0],&queue,4)?,key);
        chain.prove(&mut timed,request,&out,"timeout-tail").await?;
        ensure!(timed.val(V,"stream_phase",0)==7&&timed.val(V,"consumed",204)==1,"original tail timeout refund");
        claim_all(&mut timed)?;conservation(&timed,totals,native)?;

        let mut abandoned=after_open;abandoned.checkpoint=snapshot.fields[7]+1;
        chain.base.last_leaf=open_leaf;
        let request=bound(basic(ABORT_SOURCE,&source[0],&abandoned),key);
        chain.prove(&mut abandoned,request,&out,"abort-source").await?;
        ensure!(abandoned.val(V,"stream_phase",0)==7&&abandoned.val(V,"stream_aborted",0)==1
            &&(200..205).all(|u|abandoned.val(V,"consumed",u)==0),"unaccepted source abort cannot consume funding");
        conservation(&abandoned,totals,native)?;
        fs::write(format!("{out}/{kind}-REPORT.json"),serde_json::to_vec_pretty(&json!({
            "scope":"New v14 continuous deterministic complete UPSs on synthetic checkpoints; VM pool/setup/ordinary claims are not signed ordinary UPSs or network acceptance",
            "profile":chain.spec["profile"],"completeUps":8,"members":5,"sourcePages":2,"settlementPages":[4,1],
            "actualSyntheticFills":3,"cancelledRefund":true,"slippageRefund":true,"timeoutTailRefund":true,
            "unacceptedSourceAbort":true,"assetConservation":true,"nativeConservationIncludingFees":true,
            "normalFeeUsed":normal_fee,"lifetimeCap":CAP,"legacySponsor":false,"randomMode":false,
            "keyFingerprint":chain.key.g.get_fingerprint(),"ordinaryClaimBytecode":ordinary_claims,
            "measurements":chain.measurements,"ordinaryWalletUps":false,"fullUpsVerified":true,
            "broadcast":false,"financialOperations":0
        }))?)?;
    }
    Ok(())
}
