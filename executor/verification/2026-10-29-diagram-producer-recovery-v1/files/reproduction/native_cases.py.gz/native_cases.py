# Offline public proposals and preserved proofs only. No session/RPC/broadcast.
from pathlib import Path
import subprocess,time,json,hashlib,re,platform
case=Path(__file__).resolve().parent
old=case.parent/'market-previous-checkpoint-20261028-v1'
out=case/'public/native-comparison-v1';out.mkdir()
baseline=case/'bin-v1/baseline-wallet'
candidate=case/'bin-v1/candidate-wallet'
verifier=case/'bin-v1/verify-saved-ups'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(label,args,limit=120):
 start=time.perf_counter()
 v=subprocess.run(['/usr/bin/time','-l',*map(str,args)],text=True,capture_output=True,timeout=limit)
 elapsed=time.perf_counter()-start
 (out/(label+'.stdout.log')).write_text(v.stdout)
 (out/(label+'.stderr.log')).write_text(v.stderr)
 match=re.search(r'(\d+)\s+maximum resident set size',v.stderr)
 report={'label':label,'exitCode':v.returncode,'wallSeconds':elapsed,'kernelMaxResidentBytes':int(match.group(1)) if match else None,'memoryScope':'macOS child rusage maximum resident set size, not physical footprint; parent observer samples are separate'}
 save(out/(label+'-timing.json'),report)
 if v.returncode:raise RuntimeError(label+' failed: '+v.stderr)
 return report
rows=[]
for turn in range(2):
 for market in ['amm','bondingcurve']:
  policy=old/'fixtures-v1'/market/'policy.json'
  inp=out/(market+'-input.json')
  if not inp.exists():inp.write_bytes((old/'public'/(market+'-rank-input.json')).read_bytes())
  expected=json.loads((old/'public'/(market+'-rank.json')).read_text())['rank']
  versions=[('baseline',baseline),('candidate',candidate)]
  if turn==1:versions.reverse()
  for version,binary in versions:
   label=f'{market}-{version}-{turn+1}';result=out/(label+'.json')
   report=run(label,[binary,'producer-order',policy,inp,result])
   data=json.loads(result.read_text());assert data['rank']==expected and not data['qualifiedRandomness'] and not data['broadcast']
   if version=='candidate':assert data['proofVerified'] is False
   rows.append({**report,'market':market,'version':version,'sample':turn+1,'rankMatchedPriorCompleteUps':True,'binarySha256':sha(binary),'policySha256':sha(policy),'inputSha256':sha(inp)})
identities=[]
for market in ['amm','bondingcurve']:
 report=run(market+'-candidate-identity',[candidate,'identity',old/'fixtures-v1'/market/'policy.json'])
 data=json.loads((out/(market+'-candidate-identity.stdout.log')).read_text().splitlines()[-1])
 expected=json.loads((old/'public'/(market+'-native-identity.json')).read_text());assert data==expected
 identities.append({'market':market,'identity':data,'unchangedFromPriorFourUps':True})
proofs=[]
for request in sorted((old/'full-ups-v1').glob('*-request.json')):
 path=out/(request.stem+'-verified.json');run(request.stem+'-verify',[verifier,request,path],90)
 data=json.loads(path.read_text());assert data['fullProofVerifiedAgainstPinnedNodeKeyAndCommon'] and not data['broadcast']
 proofs.append(data)
report={'schema':1,'scope':'fresh-process public rank proposal; no cold/warm full-settlement, RPC, fee, claim or confirmation comparison','platform':platform.platform(),'threads':2,'sdkCommit':'c92880c8b6e2c8d392f19368bc8801a2584fd427','schedule':'AB then BA per market, sequential, same policy/input, same locked release toolchain','samples':rows,'identities':identities,'preservedEndcaps':proofs,'newProofsGenerated':0,'financialOperations':0,'rpcCalls':0,'networkAcceptance':False,'reliableP95':False,'physicalPeakMeasured':False}
save(out/'SUMMARY.json',report)
print(json.dumps({'rankSamples':len(rows),'unchangedKeys':len(identities),'preservedEndcapsVerified':len(proofs),'financialOperations':0}))
