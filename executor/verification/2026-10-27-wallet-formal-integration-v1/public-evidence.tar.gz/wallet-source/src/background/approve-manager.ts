import { type ClaimBatchItem, PsyJSON } from "@psy-protocol/psy-sdk";
import browser from "webextension-polyfill";
import { marketConfirmation } from "../market-native/confirmation";
import accountsApproved from "@/background/accounts-approved";
import type PsyWalletExtCore from "@/background/psy-wallet-ext-core";
import { APPROVE_POPUP_ID_PARAM } from "@/lib/approve-surface";
import {
  externalProofParamsToPrivateTransferClaimRaw,
  shieldDepositParamsToClaimBatchItem,
} from "@/lib/claimables";
import { getOriginFromUrl, includesAddress } from "@/lib/utils.ts";
import { psyApproveMsgDispatch } from "@/message";
import type { ApproveMsg, IWalletInfo } from "@/types";

const pendingResponses: Record<string, (value: any) => void> = {};

const APPROVE_POPUP_WIDTH = 380;
// Outer window height — `windows.create` includes the OS title bar / window
// chrome, so the page viewport is shorter than this. Sized so the tallest
// approval (connect: hero + origin + account + trust cards + footer note +
// actions) clears the chrome with room to spare; the ApproveShell scrolls
// internally if a screen ever exceeds it, and its footer stays pinned.
const APPROVE_POPUP_HEIGHT = 720;
const APPROVE_PROMPT_TIMEOUT_MS = 5 * 60_000;

// Upper bound on the pre-popup wallet claim scan (see receiveApproveMsg).
// Folding runs before the approval window opens, so a slow rollup / RPC must
// never leave the dApp hanging — on timeout we fall back to the un-folded
// request and open the popup with just the dApp's own items.
const FOLD_PENDING_CLAIMS_TIMEOUT_MS = 15_000;

function isBoundsError(error: unknown): boolean {
  return String(error).includes("Invalid value for bounds");
}

function noteProofRawFromPrivateTransferResult(result: {
  noteProofRaw?: string | null;
  backupPayload?: string | null;
}): string | null {
  if (typeof result.noteProofRaw === "string") return result.noteProofRaw;
  if (!result.backupPayload) return null;
  try {
    const parsed = JSON.parse(result.backupPayload) as {
      noteProofRaw?: unknown;
    };
    return typeof parsed.noteProofRaw === "string" ? parsed.noteProofRaw : null;
  } catch {
    return null;
  }
}

// One approval is in flight at any time. A second psy_sendTransaction
// while the first is open used to overwrite `approveState` and silently
// drop the first request (the popup still shows the *new* tx). Now we
// queue: subsequent requests await their turn behind earlier ones, the
// popup only ever sees the head, and the dapp gets a clear ordering.
interface QueuedApproveRequest {
  msg: ApproveMsg;
  sender: browser.Runtime.MessageSender;
  currentWallet?: string;
  resolve: (value: any) => void;
  /** Live core for head-of-queue work (the pre-prompt claim fold). */
  core?: PsyWalletExtCore;
  /**
   * Duplicate connect requests (same action + origin + currentWallet) that
   * arrived while this one was queued or prompting. They piggyback on this
   * request's outcome instead of opening their own popup — resolved with the
   * same result (approve, reject, OR timeout), only the JSON-RPC id swapped
   * for their own. See receiveApproveMsg's coalescing block.
   */
  followers?: Array<{ id: string; resolve: (value: any) => void }>;
}

const CONNECT_ACTIONS = ["psy_requestAccounts", "psy_requestPermissions"];

function sameWallet(a?: string, b?: string): boolean {
  return (a ?? "").toLowerCase() === (b ?? "").toLowerCase();
}
class ApproveManager {
  private _approveState?: ApproveMsg;
  private queue: QueuedApproveRequest[] = [];
  private processing = false;

  private set approveState(value: ApproveMsg | undefined) {
    this._approveState = value;
    psyApproveMsgDispatch(value);
  }

  public refreshApproveState() {
    psyApproveMsgDispatch(this._approveState);
  }

  public async confirmPreparedMarket(input: unknown): Promise<{approved: boolean; approvalSha256?: string}> {
    const {terms, approvalSha256} = await marketConfirmation(input);
    // Never wait behind an approval whose execution may already be waiting for
    // the wallet transaction queue held by this exact broadcast operation.
    if (this.processing || this.queue.length || this._approveState)
      throw Error("Another wallet approval is pending; preserve the exact prepared market request");
    const id = `market-${crypto.randomUUID()}`;
    const msg: ApproveMsg = {id, isPsy: true, action: "psy_confirmPreparedMarket",
      origin: terms.context.origin, params: [terms.context.account, terms, approvalSha256]};
    const response = await new Promise<any>(resolve => {
      this.queue.push({msg, sender: {}, currentWallet: terms.context.account, resolve});
      void this.processQueue();
    });
    if (response?.error) return {approved: false};
    const result = typeof response?.result === "string" ? PsyJSON.parse(response.result) : response?.result;
    if (result?.approved !== true || result.approvalSha256 !== approvalSha256)
      throw Error("Exact wallet approval result changed");
    return {approved: true, approvalSha256};
  }

  public async receiveApproveMsg(
    msg: ApproveMsg,
    data: {
      sender: browser.Runtime.MessageSender;
      currentWallet?: string;
      core: PsyWalletExtCore;
      walletSnapshot: {
        currentWallet?: IWalletInfo;
        wallets: IWalletInfo[];
      };
    },
  ) {
    if (msg.action === "psy_confirmPreparedMarket")
      throw Error("Exact market confirmation cannot be initiated by a page message");
    // Execution semantics are wallet-authored. A page may include arbitrary
    // top-level JSON-RPC fields, so never trust an incoming marker; only the
    // exact fold validation below is allowed to grant it.
    if (msg.action === "psy_execClaimBatch") delete msg.exactFoldExecution;
    // const params = PsyJSON.parse(msg.params as any) as ApproveMsg['params']
    const origin =
      (data.sender as any).origin ||
      (data.sender.url && getOriginFromUrl(data.sender.url));
    if (!origin) throw new Error("Empty tab url");
    const avatar = data.sender?.tab?.favIconUrl;

    // The wallet's OWN UI (popup / its pages) is trusted — it initiates claims
    // and private transfers directly, with no dapp-connection to approve. A
    // dapp can't spoof this: sender.id is set by the browser to the extension
    // id only for the extension's own contexts. External dapps still go
    // through the normal approved-origin gate below.
    const selfOrigin = `chrome-extension://${browser.runtime.id}`;
    const isInternal =
      data.sender.id === browser.runtime.id &&
      ((data.sender.url ?? "").startsWith(selfOrigin) || origin === selfOrigin);

    const approves = accountsApproved._approvedMap[origin];
    let approveAccount = "";
    try {
      const parsedParams =
        typeof msg.params === "string" ? PsyJSON.parse(msg.params) : msg.params;
      approveAccount = parsedParams?.[0] || "";
    } catch (_) {}
    const currentWallet = data.currentWallet;

    if (
      msg.action === "psy_requestAccounts" ||
      msg.action === "psy_requestPermissions"
    ) {
      // @ts-expect-error
      msg.params = PsyJSON.stringify({
        origin,
        avatar,
        approvedAccounts: accountsApproved.getApprovedAccountsForOrigin(origin),
        ...data.walletSnapshot,
      });
      if (
        msg.action === "psy_requestAccounts" &&
        currentWallet &&
        includesAddress(approves, currentWallet)
      ) {
        return {
          id: msg.id,
          result: PsyJSON.stringify(
            accountsApproved.getAccountsForOrigin(origin, currentWallet),
          ),
          error: null,
        };
      }
    } else if (
      !isInternal &&
      !(approves && approveAccount && includesAddress(approves, approveAccount))
    ) {
      return {
        id: msg.id,
        result: null,
        error: "Wallet not load or not connect approved",
      };
    }

    // The wallet's own UI already confirmed this action by initiating it
    // (the user clicked Claim / Send in the popup). So for internal,
    // non-connection actions we run them directly against the live core
    // instead of spawning a second confirm window. That window boots a whole
    // new core ("Connecting to network…") and is the usual source of claim
    // failures — skipping it removes both the redundant tap and the hang.
    // External dapps still go through the prompt below.
    if (
      isInternal &&
      msg.action !== "psy_requestAccounts" &&
      msg.action !== "psy_requestPermissions"
    ) {
      return this.executeApprovedAction(msg, data.core);
    }

    // Wallet-side claim bundling (psy_execClaimBatch with a
    // `foldPendingClaims: { contractId }` opts param). BEFORE the prompt is
    // shown, enumerate this wallet's own ready claimables for the requested
    // contract and PREPEND them to the dApp's batch (see
    // core.buildFoldPendingClaims). Pre-prompt on purpose: the bundled items
    // render as ordinary batch rows in the approval popup
    // (claimBatchItemToDisplayArg) and count into the confirm button, and
    // `msg.foldedClaims` adds the "also claiming N…" summary — so the user
    // consents to exactly what will be proved. Secrets never cross to the
    // page: only the rewritten background-side params carry the items.
    // Best-effort: when opts is absent or anything fails, the request stays
    // byte-identical to today's behavior.
    // The wallet bundle now runs at HEAD-OF-QUEUE time (processQueue), not
    // here: prompts serialize, so a bundle computed at enqueue could wait
    // behind the head indefinitely - two queued bundles included the same
    // claimables and the second consent screen showed amounts the prove-time
    // stale-drop then silently removed (ghost consent).

    // Attach the requesting site to the msg the popup will render. Set as
    // top-level fields (not inside `params`) so executeApprovedAction's
    // by-position params parsing is untouched — the execution path never
    // reads these. Lets fund-moving approvals (psy_sendTransaction,
    // psy_execClaimBatch*) show "Requested by …" the same as the connect
    // screen, closing a transaction-phishing gap. The connect actions carry
    // origin in `params` already (rewritten above) and the internal
    // fast-path never reaches here, so this only affects external prompts.
    msg.origin = origin;
    msg.avatar = avatar;

    // Serialize prompts. If another approval is already in flight (popup
    // open + pendingResponses entry waiting), park this one and process
    // it after the head resolves.
    return new Promise((resolve) => {
      // Coalesce duplicate CONNECT requests: a dapp that fires
      // psy_requestAccounts twice in a row (React double-mount, a
      // wallet-ready retry racing a click handler, …) must get ONE popup.
      // If an identical connect (same action + origin + wallet) is already
      // queued or in flight (the in-flight head stays at queue[0] until it
      // settles), piggyback on it: the newcomer resolves with the same
      // outcome — approve, reject, or timeout — under its own id. Only
      // identical actions coalesce: psy_requestPermissions REPLACES the
      // approved set (account re-selection) while psy_requestAccounts adds
      // to it, so cross-action requests keep their own prompts.
      if (CONNECT_ACTIONS.includes(msg.action)) {
        const duplicate = this.queue.find(
          (queued) =>
            queued.msg.action === msg.action &&
            queued.msg.origin === origin &&
            sameWallet(queued.currentWallet, data.currentWallet),
        );
        if (duplicate) {
          (duplicate.followers ??= []).push({ id: msg.id, resolve });
          return;
        }
      }
      this.queue.push({
        msg,
        sender: data.sender,
        currentWallet: data.currentWallet,
        resolve,
        core: data.core,
      });
      void this.processQueue();
    });
  }

  /**
   * Settle a queued request AND any coalesced duplicates riding on it.
   * Followers get the same outcome (approve, reject, or timeout) with the
   * JSON-RPC id swapped for their own, so no waiter is ever leaked.
   */
  private settleQueuedRequest(head: QueuedApproveRequest, result: any): void {
    head.resolve(result);
    for (const follower of head.followers ?? []) {
      try {
        follower.resolve(
          result && typeof result === "object"
            ? { ...result, id: follower.id }
            : result,
        );
      } catch {
        // resolver must never throw
      }
    }
    head.followers = undefined;
  }

  /**
   * Head-of-queue re-check for psy_requestAccounts: the enqueue-time
   * short-circuit (receiveApproveMsg) only sees approvals as of ARRIVAL. A
   * connect that queued behind an open prompt may be approved by the time it
   * reaches the head (the user just approved the same origin) — prompting
   * again would double-ask. Returns the same shape as the enqueue-time
   * short-circuit when the origin + wallet is now approved, else null.
   *
   * Deliberately NOT applied to psy_requestPermissions: its grant REPLACES
   * the origin's approved set with the popup's account selection (see
   * handleApproveMsg), so it must keep prompting even when already approved —
   * mirroring the enqueue path, which never short-circuits it either.
   */
  private connectAlreadyApprovedResult(
    head: QueuedApproveRequest,
  ): { id: string; result: string; error: null } | null {
    if (head.msg.action !== "psy_requestAccounts") return null;
    const origin = head.msg.origin;
    const currentWallet = head.currentWallet;
    if (!origin || !currentWallet) return null;
    const approves = accountsApproved._approvedMap[origin];
    if (!includesAddress(approves, currentWallet)) return null;
    return {
      id: head.msg.id,
      result: PsyJSON.stringify(
        accountsApproved.getAccountsForOrigin(origin, currentWallet),
      ),
      error: null,
    };
  }

  // Runs an approved action against the live core and returns the JSON-RPC
  // shaped result. Shared by the internal direct-execute path (above) and the
  // external prompt path (handleApproveMsg, after the user confirms). Only
  // covers actions whose inputs come entirely from the original request —
  // connection/permission grants still need the prompt's account selection.
  private async executeApprovedAction(
    approveState: ApproveMsg,
    core: PsyWalletExtCore,
  ): Promise<{ id: any; result: any; error: any }> {
    const { id } = approveState;
    const params =
      typeof approveState.params === "string"
        ? PsyJSON.parse(approveState.params as any)
        : (approveState.params as any);
    try {
      switch (approveState.action) {
        case "psy_sendTransaction": {
          const result = await core.execContractCall(params[0], params[1]);
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_execClaimBatch": {
          // Unified UPS: a heterogeneous ClaimBatchItem[] (public
          // simple_claim / simple_transfer, private-note claims, and
          // shield-deposit claims) folded into ONE recursive proof via
          // `core.execClaimBatch` → tx_queue → generateBatchClaimTxTrace +
          // prove-step.
          //
          // Activity rows for ALL item types now come from the durable
          // tx_queue projection. Synthesising rows here would create a second
          // local source and make pending holds diverge from queue state.
          const result = approveState.exactFoldExecution
            ? await core.execClaimBatch(params[0], params[1], {
                exactFoldExecution: true,
              })
            : await core.execClaimBatch(params[0], params[1]);
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_execClaimBatchAndPrivateTransfer": {
          // One approval popup, ONE fused UPS proof: the claims and the
          // private send are folded into a single claim-batch transaction.
          // `core.executePrivateTransfer(…, claims)` enqueues the durable
          // private-transfer job; the queue worker appends the send as a
          // generic `{type:"public"}` item after the claims and projects the
          // Activity rows/holds from that queue entry.
          //
          // Failure semantics (the fused UPS is atomic):
          //   - Fused batch fails → nothing landed; `claimsTxHash` is null
          //     and recoveryHint says nothing was submitted.
          //   - The lib falls back to the legacy two-stage sequence by
          //     itself if the fused shape is ever rejected; in that mode
          //     `preClaimTxHash` reports the claims-only hash so a
          //     claims-landed-but-send-failed outcome is still surfaced
          //     as "retry the send only".
          const [address, claims, privateReq] = params as [
            string,
            Array<{ type: string; data: any }>,
            {
              contract_id: string;
              recipient_shield_address: string;
              recipient_nostr_pubkey: string;
              amount: string;
              sender_label?: string;
              token_symbol?: string;
              decimals?: number;
            },
          ];

          // Delegate to the wallet's private-transfer service — the same
          // code path the wallet's PrivateTransferProcessingModal runs. It
          // returns a structured result (success / error / txHash /
          // noteProofRaw) rather than throwing on send failures, so we
          // forward both shapes verbatim and let the caller (bridge)
          // decide how to recover. The pre-commit backup persistence is
          // built into the lib helper (privateTransfer.ts :260+) so
          // recovery survives a popup death anywhere downstream.
          let sendResult: Awaited<
            ReturnType<typeof core.executePrivateTransfer>
          >;
          try {
            sendResult = await core.executePrivateTransfer(
              address,
              privateReq,
              claims as any,
            );
          } catch (sendError: any) {
            // Hard throw (e.g. wallet not found) happens before anything
            // is submitted — the fused UPS never started.
            const message = sendError?.message || PsyJSON.stringify(sendError);
            return {
              id,
              result: PsyJSON.stringify({
                claimsTxHash: null,
                sendError: message,
                recoveryHint: "Nothing has been submitted to chain yet.",
              }),
              error: null,
            };
          }
          // Fused mode: the single tx hash covers the claims too. Fallback
          // (two-stage) mode: preClaimTxHash is the claims-only hash.
          const claimsTxHash: unknown =
            sendResult.preClaimTxHash ??
            (claims.length > 0 ? sendResult.txHash : null);
          const noteProofRaw =
            noteProofRawFromPrivateTransferResult(sendResult);
          if (sendResult.success) {
            return {
              id,
              result: PsyJSON.stringify({
                claimsTxHash,
                sendTxHash: sendResult.txHash,
                noteProofRaw,
                sendOutcome: sendResult.outcome,
                postCommitFailureStage: sendResult.postCommitFailureStage,
                nostrDelivered: sendResult.nostrDelivered,
                backupPayload: sendResult.backupPayload,
              }),
              error: null,
            };
          }
          return {
            id,
            result: PsyJSON.stringify({
              claimsTxHash,
              sendTxHash: sendResult.txHash,
              noteProofRaw,
              sendOutcome: sendResult.outcome,
              postCommitFailureStage: sendResult.postCommitFailureStage,
              nostrDelivered: sendResult.nostrDelivered,
              sendError: sendResult.error,
              backupPayload: sendResult.backupPayload,
              // ORDER MATTERS: when the send itself committed (fused tx
              // hash present), "retry the send" would DOUBLE-SEND — the
              // Saved-Backups hint must win over the pre-claim hint.
              recoveryHint:
                sendResult.txHash != null
                  ? "Chain committed but downstream failed; check Saved Backups."
                  : sendResult.preClaimTxHash != null
                    ? "Pre-claim landed; retry the private send only."
                    : "Nothing has been submitted to chain yet.",
            }),
            error: null,
          };
        }
        case "psy_deployContract": {
          console.warn("[deploy-contract] approve:start", {
            address: params[0],
            circuitCount: Array.isArray(params[1]) ? params[1].length : null,
          });
          const result = await core.deployContract(
            params[0],
            params[1],
            params[2],
            params[3],
            params[4],
          );
          console.warn("[deploy-contract] approve:done", {
            address: params[0],
            result,
          });
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_listShieldReceiveAddresses": {
          const result = await core.listShieldReceiveAddresses(params[0]);
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_deriveShieldAddress": {
          const result = await core.createShieldReceiveAddress(
            params[0],
            params[1],
          );
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_claimShieldDeposit": {
          const item = shieldDepositParamsToClaimBatchItem({
            tokenAddressU32x8Json: params[1],
            l2TokenContractIdJson: params[2],
            amountU32x8Json: params[3],
            sourceChainIndex: params[4],
            depositIndex: params[5],
            depositRootJson: params[6],
            nullifierHashJson: params[7],
            noteCommitmentJson: params[8],
            depositProofBincodeB64: params[9],
            shieldAddress: params[10],
            contractId: params[11],
            depositProofFingerprintJson: params[12],
          });
          const claimStartIndexRaw = params[13];
          const claimStartIndex =
            claimStartIndexRaw != null && claimStartIndexRaw !== ""
              ? Number(claimStartIndexRaw)
              : undefined;
          if (Number.isFinite(claimStartIndex)) {
            (item.data as { shield_start_index?: string }).shield_start_index =
              String(claimStartIndex);
          }
          const result = await core.execClaimBatch(params[0], [item]);
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        case "psy_claimWithExternalProof": {
          const [
            address,
            noteProofRaw,
            nullifierJson,
            ownerJson,
            amount,
            userTreeRootJson,
            checkpointId,
            noteRootSlot,
            contractId,
            shieldAddress,
            noteProofFingerprintJson,
            noteVerifierDataJson,
          ] = params;
          const noteProof =
            noteProofRaw instanceof Uint8Array
              ? noteProofRaw
              : Uint8Array.from(Object.values(noteProofRaw ?? {}));
          // Route private-note claims through the unified claim-batch surface so
          // the prover emits TraceStep::ExternalProof before the private_claim
          // contract call. The old execClaimWithExternalProof path uses a
          // one-shot prove API that cannot build the external-proof trace step.
          const claim = externalProofParamsToPrivateTransferClaimRaw({
            noteProof,
            nullifierJson,
            ownerJson,
            amount,
            userTreeRootJson,
            checkpointId,
            noteRootSlot,
            shieldAddress,
            noteProofFingerprintJson,
            noteVerifierDataJson,
            tokenContractId: contractId,
          });
          const item: ClaimBatchItem = {
            type: "private_transfer",
            data: { contract_id: String(contractId), claim },
          };
          // execClaimBatch writes its own Activity rows (the single choke point
          // for all batch callers) and injects r0/r1 from the shield address.
          const result = await core.execClaimBatch(address, [item]);
          return { id, result: PsyJSON.stringify(result), error: null };
        }
        default:
          console.warn(
            "[psy-wallet][approve] handler not found:",
            approveState.action,
          );
          return { id, result: null, error: "Not Support" };
      }
    } catch (error: any) {
      // Preserve the per-action error prefixes the inline handlers used.
      const prefix =
        approveState.action === "psy_claimShieldDeposit"
          ? "[wallet-bg-shield] "
          : approveState.action === "psy_claimWithExternalProof"
            ? "[wallet-bg-external-proof] "
            : "";
      return {
        id,
        result: null,
        error: `${prefix}${error?.message || PsyJSON.stringify(error)}`,
      };
    }
  }

  /**
   * Rewrite a psy_execClaimBatch message at head-of-queue. Legacy
   * `{ contractId }` opts remain best-effort. Supplying snapshotToken/expected
   * activates the exact contract: any timeout, incomplete source, snapshot
   * drift, unresolved row, or fold mismatch rejects before a popup opens.
   */
  private async foldPendingClaimsIntoMsg(
    msg: ApproveMsg,
    core: PsyWalletExtCore,
  ): Promise<void> {
    if (msg.action !== "psy_execClaimBatch") return;
    const parsed =
      typeof msg.params === "string"
        ? PsyJSON.parse(msg.params as string)
        : (msg.params as unknown[]);
    const opts = parsed?.[2];
    const fold =
      opts &&
      typeof opts === "object" &&
      "foldPendingClaims" in opts &&
      opts.foldPendingClaims &&
      typeof opts.foldPendingClaims === "object"
        ? opts.foldPendingClaims
        : undefined;
    if (!fold || !("contractId" in fold) || fold.contractId == null) return;
    if (!Array.isArray(parsed?.[1])) {
      throw new Error("foldPendingClaims requires a claim batch array");
    }

    const hasSnapshotToken =
      "snapshotToken" in fold && typeof fold.snapshotToken === "string";
    const hasExpected = "expected" in fold && Array.isArray(fold.expected);
    const exact = hasSnapshotToken || hasExpected;
    if (exact && (!hasSnapshotToken || !hasExpected)) {
      throw new Error(
        "Exact fold requires both snapshotToken and expected claim rows",
      );
    }

    const buildFold = () =>
      Promise.race([
        core.buildFoldPendingClaims(
          String(parsed[0] ?? ""),
          String(fold.contractId),
          parsed[1] as ClaimBatchItem[],
        ),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new Error("buildFoldPendingClaims timed out")),
            FOLD_PENDING_CLAIMS_TIMEOUT_MS,
          ),
        ),
      ]);

    if (exact) {
      const expected = fold.expected as unknown[];
      const normalizedExpected = expected.map((raw) => {
        if (!raw || typeof raw !== "object") {
          throw new Error("Exact fold expected row is invalid");
        }
        if (!("id" in raw) || typeof raw.id !== "string") {
          throw new Error("Exact fold expected id is invalid");
        }
        if (!("contractId" in raw) || !("amount" in raw)) {
          throw new Error("Exact fold expected row is incomplete");
        }
        const contractId = String(raw.contractId);
        const amount = String(raw.amount);
        if (!/^\d+$/.test(contractId) || !/^\d+$/.test(amount)) {
          throw new Error("Exact fold expected values must be decimal strings");
        }
        return { id: raw.id, contractId, amount };
      });
      const contractId = String(fold.contractId);
      if (normalizedExpected.some((row) => row.contractId !== contractId)) {
        throw new Error("Exact fold expected rows cross contract boundaries");
      }
      const snapshot = await Promise.race([
        core.listClaimablesForDapp(String(parsed[0] ?? "")),
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new Error("listClaimables snapshot timed out")),
            FOLD_PENDING_CLAIMS_TIMEOUT_MS,
          ),
        ),
      ]);
      if (!snapshot.complete) {
        throw new Error("Exact fold snapshot is incomplete; retry later");
      }
      if (snapshot.snapshotToken !== fold.snapshotToken) {
        throw new Error("Exact fold snapshot changed; refresh and try again");
      }
      const current = snapshot.items
        .filter((row) => String(row.contractId) === contractId)
        .map((row) => ({
          id: row.id,
          contractId: String(row.contractId),
          amount: row.amount,
        }));
      if (JSON.stringify(current) !== JSON.stringify(normalizedExpected)) {
        throw new Error("Exact fold expected rows no longer match the wallet");
      }

      const folded = await buildFold();
      const actual = folded.itemIds.map((id, index) => ({
        id,
        contractId: folded.contractId,
        amount: folded.itemAmounts[index],
      }));
      if (
        folded.items.length !== normalizedExpected.length ||
        folded.itemIds.length !== folded.items.length ||
        folded.itemAmounts.length !== folded.items.length ||
        JSON.stringify(actual) !== JSON.stringify(normalizedExpected)
      ) {
        throw new Error(
          "Exact fold could not resolve every reviewed claim; refresh and try again",
        );
      }
      parsed[1] = [...folded.items, ...parsed[1]];
      msg.params = parsed as typeof msg.params;
      msg.foldedClaims = {
        count: folded.count,
        total: folded.total,
        contractId: folded.contractId,
        itemAmounts: folded.itemAmounts,
      };
      // Durable execution semantics are granted only after the exact token,
      // advertised rows, and built claim items have all matched.
      msg.exactFoldExecution = true;
      return;
    }

    try {
      const folded = await buildFold();
      if (folded.items.length > 0) {
        parsed[1] = [...folded.items, ...parsed[1]];
        msg.params = parsed as typeof msg.params;
        msg.foldedClaims = {
          count: folded.count,
          total: folded.total,
          contractId: folded.contractId,
          itemAmounts: folded.itemAmounts,
        };
      }
    } catch (error) {
      console.warn("[psy-wallet][approve] foldPendingClaims skipped", error);
    }
  }

  private async processQueue() {
    if (this.processing) return;
    this.processing = true;
    try {
      while (this.queue.length > 0) {
        const head = this.queue[0];
        // A connect that queued behind an earlier prompt may be approved by
        // NOW (the user just approved this origin at the previous head).
        // Resolve it silently instead of double-asking — same shape as the
        // enqueue-time short-circuit in receiveApproveMsg.
        const alreadyApproved = this.connectAlreadyApprovedResult(head);
        if (alreadyApproved) {
          this.settleQueuedRequest(head, alreadyApproved);
          this.queue.shift();
          continue;
        }
        try {
          // Fold pending claims NOW - when the popup is actually about to
          // open - so the consent screen reflects the claimable set as of
          // this moment, not as of enqueue (see receiveApproveMsg).
          if (head.core) {
            await this.foldPendingClaimsIntoMsg(head.msg, head.core);
          }
          const result = await this.promptForApproval(head.msg, head.sender);
          this.settleQueuedRequest(head, result);
        } catch (e: any) {
          // Popup creation or anything inside promptForApproval threw
          // (e.g. browser refused windows.create). Resolve the queued
          // promise with a structured error so the dapp side sees a
          // failure rather than hanging forever.
          this.settleQueuedRequest(head, {
            id: head.msg.id,
            result: null,
            error: e?.message || String(e) || "approve popup failed",
          });
        }
        this.queue.shift();
      }
    } finally {
      this.processing = false;
    }
  }

  private async promptForApproval(
    msg: ApproveMsg,
    sender: browser.Runtime.MessageSender,
  ): Promise<any> {
    this.approveState = msg;
    const { id } = msg;

    return new Promise((resolve) => {
      let popupPoll: ReturnType<typeof setInterval> | undefined;
      let promptTimeout: ReturnType<typeof setTimeout> | undefined;
      const settle = (value: any) => {
        if (pendingResponses[id]) {
          delete pendingResponses[id];
        }
        if (this._approveState?.id === id) {
          this.approveState = undefined;
        }
        if (popupPoll != null) clearInterval(popupPoll);
        if (promptTimeout != null) clearTimeout(promptTimeout);
        resolve(value);
      };

      pendingResponses[id] = settle;
      promptTimeout = setTimeout(() => {
        if (!pendingResponses[id]) return;
        settle({
          id,
          result: null,
          error: "Approval timed out",
        });
      }, APPROVE_PROMPT_TIMEOUT_MS);
      (async () => {
        try {
          const approvePopupUrl = browser.runtime.getURL(
            `src/popup/index.html?${APPROVE_POPUP_ID_PARAM}=${encodeURIComponent(id)}`,
          );
          // Anchor the approve window to the TOP-RIGHT of the window hosting
          // the dapp tab (sender.tab.windowId) — the exact window the request
          // originated from, matching MetaMask's precision (not just the
          // last-focused one, which can drift if the user alt-tabbed between
          // the request and the popup open). Fall back to last-focused when the
          // sender carries no tab (internal / extension-originated requests).
          // Without explicit top/left, windows.create falls back to the OS
          // default — on most platforms that's the top-LEFT corner. If the
          // computed bounds are off-screen / invalid for the platform, the
          // isBoundsError fallback below re-creates WITHOUT left/top.
          const senderWindowId = sender?.tab?.windowId;
          const parent = await (async () => {
            if (typeof senderWindowId === "number") {
              const senderWindow = await browser.windows
                .get(senderWindowId)
                .catch(() => null);
              if (senderWindow) return senderWindow;
            }
            return browser.windows.getLastFocused().catch(() => null);
          })();
          let left: number | undefined;
          let top: number | undefined;
          if (
            parent &&
            typeof parent.left === "number" &&
            typeof parent.top === "number" &&
            typeof parent.width === "number"
          ) {
            left = Math.round(parent.left + parent.width - APPROVE_POPUP_WIDTH);
            top = Math.round(parent.top);
          }
          const popupOptions = {
            url: approvePopupUrl,
            type: "popup",
            width: APPROVE_POPUP_WIDTH,
            height: APPROVE_POPUP_HEIGHT,
            left,
            top,
            focused: true,
          } as const;

          let popup: browser.Windows.Window;
          try {
            popup = await browser.windows.create(popupOptions);
          } catch (error) {
            if (!isBoundsError(error)) throw error;
            popup = await browser.windows.create({
              url: popupOptions.url,
              type: popupOptions.type,
              width: popupOptions.width,
              height: popupOptions.height,
              focused: popupOptions.focused,
            });
          }
          if (popup.id != null) {
            await browser.windows
              .update(popup.id, { focused: true })
              .catch(() => {});
          }

          popupPoll = setInterval(() => {
            if (pendingResponses[id] && popup.id) {
              browser.windows.get(popup.id).catch(() => {
                // Popup window closed by the user (or evicted) — treat as
                // rejection. No log: this fires every time a popup closes
                // and the error itself is just "No window with id N".
                settle({ id, result: null, error: "User reject" });
              });
            } else {
              if (popupPoll != null) clearInterval(popupPoll);
            }
          }, 100);
        } catch (error) {
          if (pendingResponses[id]) delete pendingResponses[id];
          if (this._approveState?.id === id) this.approveState = undefined;
          if (popupPoll != null) clearInterval(popupPoll);
          if (promptTimeout != null) clearTimeout(promptTimeout);
          throw error;
        }
      })().catch((error: any) => {
        settle({
          id,
          result: null,
          error: error?.message || String(error) || "approve popup failed",
        });
      });
    });
  }

  public async handleApproveMsg(
    msg: { id: string; result: string; error: string },
    core: PsyWalletExtCore,
  ) {
    const { id, result, error } = msg;
    const callback = pendingResponses[id];
    // The response must belong to the LIVE prompt: the popup deliberately
    // re-sends results for settled ids (reject-on-unmount, the success
    // duplicate), and processing one against a DIFFERENT live approveState
    // mixes two prompts.
    if (callback && this._approveState && this._approveState.id === id) {
      try {
        const approveState = this._approveState;
        this.approveState = undefined;
        delete pendingResponses[id];
        if (!error) {
          const approveResult =
            typeof result === "string" ? PsyJSON.parse(result) : result;
          switch (approveState.action) {
            case "psy_confirmPreparedMarket": {
              const [account, terms, expected] = approveState.params;
              const validated = await marketConfirmation(terms);
              if (account !== terms.context.account || validated.approvalSha256 !== expected ||
                  approveResult?.approved !== true || approveResult.approvalSha256 !== expected)
                throw Error("Exact market approval does not match the wallet-owned prompt");
              await callback({id, result: PsyJSON.stringify({approved: true, approvalSha256: expected}), error: null});
              break;
            }
            case "psy_requestAccounts":
            case "psy_requestPermissions": {
              const walletAccounts = core
                .getApproveWalletSnapshot()
                .wallets.map((wallet) => wallet.address);
              // Tolerate stale approved accounts instead of hard-failing the
              // whole connect: a deleted wallet's address can survive in the
              // pre-filled approvedAccounts list (old persisted state from
              // before approval-pruning shipped, or a delete that raced this
              // popup). Skip any account that maps to no existing wallet —
              // only a connect with ZERO valid accounts is a real error.
              const validRequested: string[] = approveResult.accounts.filter(
                (account: string) => includesAddress(walletAccounts, account),
              );
              if (!validRequested.length) {
                throw new Error("Approved accounts include unknown wallet");
              }

              const accounts =
                approveState.action === "psy_requestAccounts"
                  ? accountsApproved
                      .getApprovedAccountsForOrigin(approveResult.origin)
                      .filter((account) =>
                        includesAddress(walletAccounts, account),
                      )
                      .concat(validRequested)
                  : validRequested;

              await accountsApproved.editApproved(
                approveResult.origin,
                accounts,
              );
              accountsApproved.currentWalletChanged(
                core._currentWallet?.address,
              );
              await callback({
                id,
                result:
                  approveState.action === "psy_requestPermissions"
                    ? PsyJSON.stringify(
                        accountsApproved.getApprovedAccountsForOrigin(
                          approveResult.origin,
                        ),
                      )
                    : PsyJSON.stringify(
                        accountsApproved.getAccountsForOrigin(
                          approveResult.origin,
                          core._currentWallet?.address,
                        ),
                      ),
                error: null,
              });
              break;
            }
            default: {
              // Every non-connection action runs the same whether it was
              // auto-approved internally or confirmed in the prompt window.
              const res = await this.executeApprovedAction(approveState, core);
              await callback(res);
              break;
            }
          }
        } else {
          callback({
            id,
            result: null,
            error: error || "User rejected",
          });
        }
      } catch (e: any) {
        callback({
          id,
          result: null,
          error: e.message || "Error",
        });
      }
    } else {
      // Late/duplicate result for an id that is not the live prompt. The old
      // code cleared the LIVE prompt state unconditionally (blanking the open
      // popup) and deleted a still-pending callback WITHOUT invoking it -
      // stranding promptForApproval's promise and jamming every subsequent
      // approval from every dApp until the service worker restarted.
      if (callback) {
        delete pendingResponses[id];
        try {
          callback({ id, result: null, error: error || "Approval state lost" });
        } catch {
          // resolver must never throw
        }
      }
      if (this._approveState?.id === id) {
        this.approveState = undefined;
      }
    }
  }
}

export default new ApproveManager();
