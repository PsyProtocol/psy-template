from pathlib import Path
import json,hashlib,gzip
c=Path(__file__).resolve().parent
a=Path('<application-root>')
out=a/'executor/verification/2026-10-30-minimum-stream-integration-v1'
assert not out.exists(), 'fresh public bundle only'
# Only explicitly public proof/context artifacts; never discover wallet files.
files=[p for p in (c/'public').rglob('*') if p.is_file()]
for directory in ['page-proofs-v1','full-ups-v1','full-ups-v2','full-ups-v3','vm-v2','key-public-probe-v1','key-public-probe-v2','key-public-probe-v3','key-witness-audit-v1','native-amm-v1','native-curve-v1','native-route-v1','compatibility-v1','key-replay-v1','saved-key-amm-v1','saved-key-curve-v1']:
 base=c/directory
 if not base.exists():continue
 allowed={'source.json','current.json','intent.json','plan.json','public-session.json','key-proof.bin','request.json','verification.json','REPORT.json','draw.json','review.json','policy.json','plan.json','source-pages.json','minimum-pages.json','queue.json','result.json','DERIVATION.json','0.json','42.json','43.json','1000.json'}
 for p in base.rglob('*'):
  if p.is_file() and (p.name in allowed or p.name.endswith('-REPORT.json') or (directory.startswith('native-') and p.suffix=='.json') or (directory=='page-proofs-v1' and p.suffix in ['.bin','.json'])):files.append(p)
for directory in ['fixtures-v1','fixtures-v2','fixtures-v3']:
 files.extend(p for p in (c/directory).rglob('*') if p.is_file() and p.suffix in ['.json','.rs','.log'])
for p in c.glob('application-v*'):
 files.extend(p/n for n in ['APPLICATION.json','Cargo.toml','Cargo.lock'])
 for n in ['src/random_minimum.rs','src/market_key.rs','src/stream_policy.rs','src/stream_source.rs','src/bin/compile_minimum_stream.rs','src/bin/minimum_key_probe.rs','src/bin/minimum_stream_plan.rs','tests/minimum_page.rs','tests/batch_lifecycle.rs','tests/support/stream_full_ups.rs','tests/support/minimum_stream_full_ups.rs']:
  if (p/n).is_file():files.append(p/n)
files.extend(p for p in c.iterdir() if p.is_file() and p.suffix in ['.py','.mjs'])
sha=lambda b:hashlib.sha256(b).hexdigest()
forbidden={'private_key','privateKey','mnemonic','secretKey','signing_witness','signature_witness','secp256k1_slots','recoveryPhrase'}
def scan(v):
 if isinstance(v,dict):
  assert not set(v)&forbidden,'secret-shaped JSON field'
  for x in v.values():scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
rows=[]
out.mkdir()
for p in sorted(set(files)):
 assert not p.is_symlink();raw=p.read_bytes();b=raw
 if p.suffix!='.bin':
  t=raw.decode()
  t=t.replace(str(c),'<case-root>').replace(str(a),'<application-root>').replace(str(c.parent),'<evidence-root>').replace(str(Path.home()),'<home>')
  b=t.encode()
  if p.suffix=='.json':scan(json.loads(b))
 dest=out/'files'/(p.relative_to(c).as_posix()+'.gz');dest.parent.mkdir(parents=True,exist_ok=True)
 z=gzip.compress(b,mtime=0)
 with dest.open('xb')as f:f.write(z)
 assert gzip.decompress(dest.read_bytes())==b
 rows.append({'source':p.relative_to(c).as_posix(),'file':dest.relative_to(out).as_posix(),'originalSha256':sha(raw),'publicSha256':sha(b),'gzipSha256':sha(z),'gzipBytes':len(z),'redacted':raw!=b})
summary=json.loads((c/'public/FINAL-SUMMARY-v1.json').read_text())
for name,v in [('index.json',rows),('SUMMARY.json',summary),('PUBLISHED-AUDIT.json',{'files':len(rows),'allCompressedAndPublicDigestsVerified':True,'explicitProjectionFieldScanPassed':True,'rawWitnessesIncluded':False,'financialOperations':0})]:
 with(out/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'files':len(rows),'gzipBytes':sum(r['gzipBytes']for r in rows)}))
