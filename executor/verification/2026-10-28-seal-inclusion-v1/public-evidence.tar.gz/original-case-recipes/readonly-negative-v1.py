from pathlib import Path
import copy, hashlib, json, os, subprocess, time
b=Path(__file__).resolve().parent
s=b.parent/'sdk-mainnet-beta-20261027-v1'
f=b/'component-proof-v1'
o=b/'readonly-negative-v1'
o.mkdir()
statement=json.loads((f/'statement.json').read_text())
layout=json.loads((f/'layout.json').read_text())
opening=json.loads((f/'opening.json').read_text())
root=json.loads((f/'REPORT.json').read_text())['checkpointRoot']
results=[]
env=dict(os.environ, RAYON_NUM_THREADS='2', PSY_NETWORK='testnet')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label, tool, st=None, la=None, op=None, rt=None, cp='105', proof=None, existing=None):
    case=o/label;case.mkdir()
    inputs=[]
    for name,value,original in [('statement',st,f/'statement.json'),('layout',la,f/'layout.json'),('opening',op,f/'opening.json')]:
        if value is None: path=original
        else:
            path=case/(name+'.json')
            path.write_bytes(value if isinstance(value,bytes) else json.dumps(value).encode())
        inputs.append(path)
    statement_path,layout_path,opening_path=inputs
    proof_path=f/'proof.bin'
    if proof is not None:
        proof_path=case/'proof.bin';proof_path.write_bytes(proof)
    report=existing or case/'REPORT.json'
    before=digest(report) if report.exists() else None
    binary=s/'target/release'/tool
    args=[str(binary),str(statement_path),str(layout_path),rt or root]
    args += [str(opening_path),str(report)] if tool=='verify_seal_inclusion' else [cp,str(proof_path),str(report)]
    start=time.monotonic()
    result=subprocess.run(args,env=env,capture_output=True,timeout=20)
    (case/'output.log').write_bytes(result.stdout+result.stderr)
    assert result.returncode!=0,(label,'unexpected acceptance')
    assert digest(report)==before if before else not report.exists(),(label,'output modified')
    results.append({'case':label,'tool':tool,'exitCode':result.returncode,'seconds':time.monotonic()-start,'arguments':args[1:],'toolSha256':digest(binary),'inputs':[{'path':str(p),'sha256':digest(p)}for p in [statement_path,layout_path,opening_path if tool=='verify_seal_inclusion' else proof_path]],'existingReportPreserved':bool(before),'financialOperations':0,'proofsGenerated':0})
def field(index):
    value=copy.deepcopy(statement);value['fields'][index]=str(int(value['fields'][index])+1);return value
def mutate(path, value):
    p=copy.deepcopy(opening);at=p
    for key in path[:-1]: at=at[key]
    at[path[-1]]=value;return p
native='verify_seal_inclusion';zk='verify_seal_component';zero='0'*64
for label,index in [('network',1),('chain',18),('round',9),('draw',8),('queue',42),('member',52),('code',22),('layout-root',26),('function-root',30),('key-fingerprint',34),('vault',4)]:
    run('native-'+label,native,st=field(index))
for label,path,value in [('late-seal',['checkpoint_id'],120),('genesis',['chain_anchor_leaf','global_chain_root'],zero),('contract-code',['contract_leaf','code_root'],zero),('contract-layout',['contract_leaf','state_layout_root'],zero),('contract-function',['contract_leaf','function_tree_root'],zero),('key',['key_public_param'],zero),('vault-nonce',['user_leaf','nonce'],0),('stored-word',['root_words',0,'value'],zero),('different-snapshot',['state_roots','user_tree_root'],zero),('missing-path',['contract_proof','siblings'],opening['contract_proof']['siblings'][:-1]),('extra-word',['root_words'],opening['root_words']+[opening['root_words'][0]]),('duplicate-word',['root_words',1],opening['root_words'][0]),('claimed-success',['verified'],True)]:
    run('native-'+label,native,op=mutate(path,value))
la=copy.deepcopy(layout);la['root_slot']=2
run('native-wrong-reviewed-slot',native,la=la)
run('native-wrong-expected-root',native,rt=zero)
run('native-noncanonical-root',native,rt=root.upper())
st=copy.deepcopy(statement);st['seed']=['1','0','0','0']
run('native-seed-in-frozen-fields',native,st=st)
run('native-oversize-opening',native,op=b' '*131073)
for label,index in [('network',1),('chain',18),('round',9),('member',52),('code',22),('layout-root',26),('function-root',30),('key-fingerprint',34)]:
    run('saved-proof-'+label,zk,st=field(index))
run('saved-proof-wrong-root',zk,rt=zero)
run('saved-proof-wrong-checkpoint',zk,cp='106')
run('saved-proof-leading-zero-checkpoint',zk,cp='0105')
run('saved-proof-wrong-reviewed-slot',zk,la=la)
run('saved-proof-seed-in-frozen-fields',zk,st=st)
run('saved-proof-oversize-fields',zk,st=b' '*16385)
run('saved-proof-trailing-bytes',zk,proof=(f/'proof.bin').read_bytes()+b'\x00')
run('saved-proof-oversize-proof',zk,proof=b' '*2000001)
run('native-existing-report',native,existing=b/'public/native-opening-verification-v1.json')
run('saved-proof-existing-report',zk,existing=b/'public/saved-component-verification-v1.json')
report={'schema':1,'scope':'synthetic component CLI rejection, not real beacon/finality/UPS/network fault acceptance','cases':results,'rejected':len(results),'financialOperations':0,'proofsGenerated':0,'randomAuthorization':False}
with (b/'public/readonly-negative-v1.json').open('x')as out:json.dump(report,out,indent=2);out.write('\n')
print('Rejected',len(results),'read-only cases; no new proof or financial operation')
