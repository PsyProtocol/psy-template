from pathlib import Path
import json,hashlib,gzip,datetime
c=Path(__file__).resolve().parent;a=Path('<application-root>');out=a/'executor/verification/2026-10-29-random-minimum-promotion-v1';out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
files=list(p for p in(c/'public').rglob('*')if p.is_file())
for n in ['component-v1','component-v2','compatibility-v1']:
 files.extend(p for p in(c/n).iterdir()if p.suffix in ['.json','.bin'])
for n in ['application-v1','application-v2']:
 files.extend(c/n/f for f in ['APPLICATION.json','Cargo.toml','Cargo.lock','src/random_minimum.rs','tests/random_minimum.rs'])
files.extend(c/n for n in ['run.py','rpc_check_v1.py','publish_v1.py'])
rows=[]
for p in sorted(set(files)):
 assert not p.is_symlink();raw=p.read_bytes();b=raw
 if p.suffix!='.bin':
  t=raw.decode();t=t.replace(str(c),'<case-root>').replace(str(a),'<application-root>').replace(str(c.parent),'<evidence-root>').replace(str(Path.home()),'<home>');b=t.encode()
  if p.suffix=='.json':
   def scan(v):
    if isinstance(v,dict):
     assert not set(v)&{'private_key','privateKey','mnemonic','secretKey','signing_witness','signature_witness','secp256k1_slots'}
     for x in v.values():scan(x)
    elif isinstance(v,list):
     for x in v:scan(x)
   scan(json.loads(b))
 dest=out/'files'/(p.relative_to(c).as_posix()+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(b,mtime=0)
 with dest.open('xb')as f:f.write(z)
 assert gzip.decompress(dest.read_bytes())==b
 rows.append({'source':p.relative_to(c).as_posix(),'file':dest.relative_to(out).as_posix(),'originalSha256':sha(raw),'publicSha256':sha(b),'gzipSha256':sha(z),'gzipBytes':len(z),'redacted':raw!=b})
fixture=c.parent/'random-source-stream-20261029-v1/native-planner-v1';refs={n:sha((fixture/n).read_bytes())for n in ['review.json','source.json','0.json','42.json','43.json','1000.json']}
report=json.loads((c/'component-v2/REPORT.json').read_text());rpc=json.loads((c/'public/rpc-precheck-v1/SUMMARY.json').read_text())
summary={'schema':1,'applicationBase':'416332b6','sdkCommit':'c92880c8b6e2c8d392f19368bc8801a2584fd427','generatedUniqueComponentProofs':10,'reusedComponentProofsVerified':10,'componentAttackRejections':14,'unchangedV10KeyProofsVerified':2,'coherentLegacyAttackRejections':6,'circuitDigest':report['circuitDigest'],'fixedPublicInputs':report['publicInputs'],'sameRankAsV10':True,'conditionalOnly':True,'replacementContractAndKeyInstalled':False,'fullUpsVerified':False,'financialOperations':0,'newLiveInstances':0,'liveWrites':'disabled','rpc':rpc,'priorPublicFixture':'2026-10-29-source-random-stream-v1/files/native-planner-v1','fixtureOriginalSha256':refs,'remaining':['embed minimum targets and continuity into replacement contract and SD-key','key-level epoch/maintenance/total-fee admission review','replacement actual bytecode and complete UPS acceptance','fresh identities/deadline/funding fit and owned precise broadcast driver','new isolated registration, real settlement, signed ordinary claims and recovery']}
for name,v in [('index.json',rows),('SUMMARY.json',summary),('PUBLISHED-AUDIT.json',{'files':len(rows),'allCompressedAndPublicDigestsVerified':True,'explicitProjectionFieldScanPassed':True,'rawWitnessesIncluded':False,'financialOperations':0})]:
 with(out/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
print(len(rows),sum(r['gzipBytes']for r in rows))
