from pathlib import Path
import json,hashlib,shutil,subprocess,os
c=Path(__file__).resolve().parent
d=c/'native-planner-curve-v1';d.mkdir()
s=json.loads((c/'full-ups-v3/bondingcurve-order-0/source.json').read_text());cur=json.loads((c/'full-ups-v3/bondingcurve-source-0/current.json').read_text());contracts={x['id']:x['leaf'] for x in s['contracts']}
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def asset(id,path):
 name=str(id)+'.json';shutil.copyfile(c/path,d/name)
 return {'id':id,'artifact':name,'artifact_sha256':hashlib.sha256((d/name).read_bytes()).hexdigest(),'function_root':contracts[id]['function_tree_root']}
m=asset(1000,'fixtures-v4/bondingcurve/compiled/compilation_artifact.json')
r={'schema':1,'artifact':m['artifact'],'artifact_sha256':m['artifact_sha256'],'market':1000,'kind':2,'function_root':m['function_root'],'unit':'1000000000000000000','assets':[asset(0,'fixtures-v4/native.json'),asset(42,'fixtures-v4/token/compilation_artifact.json'),asset(43,'fixtures-v4/token/compilation_artifact.json')]}
put(d/'review.json',r);put(d/'source.json',s)
p=s['history']['checkpoint_path'];draw={'checkpoint':cur['checkpoint'],'path':{'root':p['root'],'index':101,'value':p['siblings'][0],'siblings':[p['value']]+p['siblings'][1:]}};put(d/'draw.json',draw)
shutil.copyfile(c/'fixtures-v4/bondingcurve/stream-policy.json',d/'policy.json')
args=[str(c/'bin-v4/random_stream_plan'),str(d/'review.json'),str(d/'source.json'),p['root'],str(d/'draw.json'),str(d/'policy.json'),str(d/'prepared')]
env=os.environ.copy();env.update(PSY_NETWORK='testnet',PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',PSY_CONFIG_PATH=str(c.parent/'sdk-mainnet-beta-20261027-v1/source/psy-sdk/psy-genesis/config.json'),RAYON_NUM_THREADS='2')
a=subprocess.run(args,env=env,capture_output=True,text=True,timeout=120)
put(d/'result.json',{'exitCode':a.returncode,'stdout':a.stdout,'stderr':a.stderr,'financialOperations':0,'syntheticHistory':True});print(a.returncode,a.stderr)
