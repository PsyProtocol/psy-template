"""Verify the exact preserved parent from an extracted public archive."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
assert len(sys.argv)==4,'EXTRACTED_ROOT TRUSTED_BUILT_VERIFIER FRESH_OUTPUT_DIRECTORY'
root,tool,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir();f=root/'proof-v1';r=json.loads((f/'REPORT.json').read_text());report=out/'verification.json'
p=subprocess.run([str(tool),str(f/'candidate.json'),str(f/'layout.json'),r['checkpointRoot'],str(r['sealCheckpoint']),str(f/'linked-proof.bin'),str(report)],env=dict(os.environ,RAYON_NUM_THREADS='2',PSY_NETWORK='testnet'),capture_output=True,timeout=20)
with (out/'output.log').open('xb')as log:log.write(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
value=json.loads(report.read_text());assert value['linkedComponentProofVerified']
assert not any(value[k]for k in ['finalityVerified','beaconUnpredictabilityVerified','marketSemanticsVerified','randomAuthorization','fullUpsVerified','broadcast'])
assert value['financialOperations']==0
with (out/'REPORT.json').open('x')as dest:json.dump({'schema':1,'exactExtractedParentVerified':True,'toolSha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest(),'proofsGenerated':0,'financialOperations':0,'randomAuthorization':False},dest,indent=2);dest.write('\n')
print('Exact extracted parent verified; no new proof or finance.')
