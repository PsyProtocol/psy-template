fn get_temp_guta_rand_seed<Hash: Q256BitHash>() -> Hash {
    let mut bytes = [0u8; 32];
    rand::thread_rng().fill_bytes(&mut bytes);
    Hash::from_owned_32bytes(bytes)
}
pub fn get_new_coordinator_guta_update_gatherer_backup_file_path(
