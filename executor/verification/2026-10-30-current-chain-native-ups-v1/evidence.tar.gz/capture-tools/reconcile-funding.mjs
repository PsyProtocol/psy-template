// Read-only inventory for the original unresolved faucet identity. No resend.
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {parseLosslessJson,losslessJson} from '../../psy-template-security-20261016/amm/u124/client.mjs';
import {decodeFeltSlot} from '../../psy-template-security-20261016/orderbook/matcherCore.mjs';
const base=new URL('./',import.meta.url),out=new URL('funding-reconciliation-v1/',base);
await mkdir(out,{mode:0o700});
const save=(name,v)=>writeFile(new URL(name,out),losslessJson(v)+'\n',{flag:'wx'});
const old=parseLosslessJson(JSON.parse(await readFile(new URL('../market-amm-reset-live-20261027-v1/public/faucet-precheck-5.json',base),'utf8')).responseText).result;
const current=parseLosslessJson(await readFile(new URL('capture-v3/faucet-config.json',base),'utf8')).result;
const before=old.operator_user_ids.map(Number).sort((a,b)=>a-b),operators=current.operator_user_ids.map(Number).sort((a,b)=>a-b);
if(JSON.stringify(before)!==JSON.stringify(operators)||operators.length!==100||new Set(operators).size!==100||operators.some(n=>!Number.isSafeInteger(n)||n<1||n>=2097152))throw Error('Faucet operator inventory changed; original source unknown');
const checkpoint=21882,recipient=223232,queue=operators.flatMap(sender=>[{sender,user:sender,slot:3+2*recipient,kind:'sent'},{sender,user:recipient,slot:4+2*sender,kind:'claimed'}]);
let at=0,reads=0,failure=null;
const rows=[];
const deadline=AbortSignal.timeout(240000);
await save('PLAN.json',{checkpoint,recipient,operatorCount:operators.length,requests:queue.length,concurrency:4,attempts:1,financialOperations:0,originalFaucetLockPreserved:true});
await Promise.all(Array.from({length:4},async()=>{
 while(!failure&&at<queue.length){
  const i=at++,job=queue[i];reads++;
  const request={jsonrpc:'2.0',id:i+1,method:'psy_get_user_contract_state_tree_leaf_hash',params:{checkpoint_id:checkpoint,user_id:job.user,contract_id:0,leaf_id:Math.floor(job.slot/4)}};
  await save(i+'-request.json',request);
  try{
   const url=job.user<1048576?'https://realm0-stg.psy-protocol.xyz':'https://realm1-stg.psy-protocol.xyz';
   const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),redirect:'error',signal:AbortSignal.any([deadline,AbortSignal.timeout(25000)])});
   const text=await response.text();if(Buffer.byteLength(text)>8192)throw Error('Response too large');
   await writeFile(new URL(i+'-response.json',out),text,{flag:'wx'});
   const result=parseLosslessJson(text);if(response.status!==200||result.id!==BigInt(i+1)||result.error)throw Error('RPC response failed');
   rows.push({...job,amount:decodeFeltSlot(result.result,job.slot)});
  }catch(error){failure={read:i,error:error.message};await save(i+'-failure.json',failure);}
 }
}));
const grants=[];
if(!failure&&rows.length===queue.length)for(const sender of operators){
 const sent=rows.find(r=>r.sender===sender&&r.kind==='sent').amount,claimed=rows.find(r=>r.sender===sender&&r.kind==='claimed').amount;
 if(sent<claimed){failure={sender,error:'Native funding cursor underflow'};break;}
 grants.push({sender,sent,claimed,pending:sent-claimed});
}
const summary={schema:1,complete:!failure&&rows.length===queue.length,checkpoint,recipient,reads,operatorCount:operators.length,failure,grants,pendingTotal:grants.reduce((n,g)=>n+g.pending,0n),scope:'RPC-observed funding cursors from the exact historical/current advertised operator set; not a global pending-request, receipt or finality proof',originalFaucetOutcomeResolved:false,financialOperations:0,newFaucetRequests:0,financialReady:false};
await save('SUMMARY.json',summary);
console.log(losslessJson({...summary,grants:undefined}).replace(',"grants":undefined',''));
if(!summary.complete)process.exitCode=1;
