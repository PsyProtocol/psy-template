"""Package only reviewed public observations. No wallet/key/trace export."""
from pathlib import Path
import gzip, hashlib, io, json, re, tarfile

CASE = Path(__file__).resolve().parent
ROOT = CASE.parent.parent / 'psy-template-security-20261016'
OUT = ROOT / 'executor/verification/2026-10-30-current-chain-native-ups-v1'
OUT.mkdir(parents=True, exist_ok=False)
envelope = json.loads((CASE/'capture-v3/runtime-client-resources.json').read_text())
registry = json.loads(envelope['result'])
roles = ['ups_start','ups_start_register_user','ups_cfc_standard_tx','ups_cfc_deferred_tx','ups_end_cap',
         'zk_circuit','secp_circuit','private_note_inclusion_minifier','shield_deposit_claim_minifier',
         'eth_personal_secp_circuit','single_leaf_circuit','two_leaf_circuit','two_agg_circuit',
         'left_leaf_right_agg_circuit','left_agg_right_leaf_circuit']
proofs = ['ups_start_whitelist_proof','ups_start_register_user_whitelist_proof',
          'ups_cfc_standard_tx_whitelist_proof','ups_cfc_deferred_tx_whitelist_proof']
parameters = ['leaf_circuit_config_id','leaf_verifier_data_cap_height','agg_verifier_data_cap_height']
assert set(registry) == set(roles+proofs+parameters+['ups_circuit_whitelist_root','circuit_inclusion_proofs'])
def h(value):
    assert isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value)
def proof(value):
    assert set(value)=={'root','value','index','siblings'}
    h(value['root']);h(value['value'])
    assert type(value['index']) is int and 0<=value['index']<2**64
    assert isinstance(value['siblings'],list) and len(value['siblings'])<=64
    for item in value['siblings']:h(item)
for name in roles:
    item=registry[name];assert set(item)=={'fingerprint','verifier_config'};h(item['fingerprint'])
    key=item['verifier_config'];assert set(key)=={'constants_sigmas_cap','circuit_digest'};h(key['circuit_digest'])
    assert isinstance(key['constants_sigmas_cap'],list) and len(key['constants_sigmas_cap'])<=256
    for value in key['constants_sigmas_cap']:h(value)
for name in proofs:proof(registry[name])
for name in parameters:assert type(registry[name]) is int and 0<=registry[name]<2**64
h(registry['ups_circuit_whitelist_root'])
inclusion=registry['circuit_inclusion_proofs']
expected={name+'_merkle_proof' for name in roles[10:]}|{'circuit_whitelist_tree_root'}
assert set(inclusion)==expected
for name,value in inclusion.items():
    if name=='circuit_whitelist_tree_root':h(value)
    else:proof(value)

files=[]
for directory in ['public','capture','capture-v2','capture-v3','native-bound-v2','native-bound-sealed-v4','funding-reconciliation-v1']:
    for path in sorted((CASE/directory).rglob('*')):
        if path.is_file() and path.suffix in {'.json','.log','.png'}:
            assert not path.is_symlink()
            files.append((str(path.relative_to(CASE)),path.read_bytes()))
for directory in ['application-v2','application-v4']:
    path=CASE/directory/'APPLICATION.json';files.append((str(path.relative_to(CASE)),path.read_bytes()))
layout=CASE.parent/'pair-live-readiness-20261029-v1/native-capture-v2/candidate-layout-abi.json'
files.append(('inputs/candidate-layout-abi.json',layout.read_bytes()))
for name in ['capture.py','capture-v2.py','reconcile-funding.mjs','package_public.py']:
    files.append(('capture-tools/'+name,(CASE/name).read_bytes()))
for name,data in files:
    assert len(data)<16_000_000
    for marker in [b'-----BEGIN PRIVATE KEY-----',b'-----BEGIN OPENSSH PRIVATE KEY-----',
                   b'"privateKey":',b'"private_key":',b'"mnemonic":',b'"seedPhrase":']:
        assert marker not in data,name

archive=OUT/'evidence.tar.gz'
with archive.open('xb') as destination:
    with gzip.GzipFile(fileobj=destination,filename='',mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,data in files:
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
manifest={'schema':1,'scope':'Native/current-checkpoint and ordinary UPS verifier preflight; no financial acceptance',
          'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'members':[{'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in files],
          'publication':'All exact circuit registry fields were explicitly checked as public verifier hashes, caps, paths and numeric configuration; no signing witness or wallet file is included',
          'financialOperations':0}
with (OUT/'manifest.json').open('x') as output:json.dump(manifest,output,indent=2);output.write('\n')
print(json.dumps({'members':len(files),'gzipBytes':archive.stat().st_size,'archiveSha256':manifest['archiveSha256']}))
