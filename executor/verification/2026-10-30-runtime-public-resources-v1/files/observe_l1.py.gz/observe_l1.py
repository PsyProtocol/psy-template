import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
config=json.loads((C/'quarantine/public-l1-config.body').read_bytes())
url=config['l1']['rpc_url']
address=next(x['address'] for x in config['contracts'] if x['name']=='StateManager')
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json';rp.write_text(json.dumps(req));rp.chmod(0o600)
 out=C/'quarantine'/f'{label}.body'
 assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes() if out.exists() else b''
 if out.exists():out.chmod(0o600)
 record={'schema':1,'kind':'untrusted-public-l1-rpc-observation-v1','url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'elapsedSeconds':time.monotonic()-start,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'finalityVerified':False,'canBroadcast':False}
 dest=C/'public'/f'{label}-transport.json'
 with dest.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'error'in v or 'result'not in v:raise RuntimeError('RPC result rejected')
 return v['result']
chain=call('l1-chain-id','eth_chainId',[])
if chain!='0xaa36a7':raise RuntimeError('wrong chain; stop')
block=call('l1-finalized-observation','eth_getBlockByNumber',['finalized',False])
assert isinstance(block,dict) and isinstance(block.get('hash'),str) and len(block['hash'])==66
fixed={'blockHash':block['hash'],'requireCanonical':True}
code=call('l1-state-manager-code','eth_getCode',[address,fixed])
if not isinstance(code,str) or code=='0x':raise RuntimeError('no code at observed block; stop')
idword=call('l1-state-manager-checkpoint','eth_call',[{'to':address,'data':'0x3590a6a3'},fixed])
rootword=call('l1-state-manager-root','eth_call',[{'to':address,'data':'0x6bf60cb1'},fixed])
assert isinstance(idword,str) and len(idword)==66 and isinstance(rootword,str) and len(rootword)==66
slot='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'
implementation=call('l1-state-manager-implementation','eth_getStorageAt',[address,slot,fixed])
assert isinstance(implementation,str) and len(implementation)==66
summary={'schema':1,'kind':'untrusted-l1-state-manager-observation-v1','chainId':int(chain,16),'configSha256':hashlib.sha256((C/'quarantine/public-l1-config.body').read_bytes()).hexdigest(),'address':address,'blockHash':block['hash'],'blockNumber':block['number'],'blockStateRoot':block['stateRoot'],'checkpointId':int(idword,16),'checkpointRootWord':rootword,'proxyCodeBytes':len(bytes.fromhex(code[2:])),'proxyCodeSha256':hashlib.sha256(bytes.fromhex(code[2:])).hexdigest(),'eip1967ImplementationWord':implementation,'rpcFinalizedTagObserved':True,'headerConsensusVerified':False,'contractStorageProofVerified':False,'runtimeCodeSourceVerified':False,'finalityVerified':False,'qualifiedRandomness':False,'canBroadcast':False}
with (C/'public/l1-state-manager-observation.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary),flush=True)
