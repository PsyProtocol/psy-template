from pathlib import Path
import json,subprocess
case=Path(__file__).resolve().parent
sdk=case.parent/'sdk-mainnet-beta-20261027-v1'
driver=sdk/'target/release/compact_market_wallet'
verify=sdk/'target/release/verify_saved_ups'
public=case/'public'
def save(path,obj):
 with path.open('x') as f: json.dump(obj,f,indent=2);f.write('\n')
def run(args,ok=True):
 p=subprocess.run(list(map(str,args)),text=True,capture_output=True,timeout=90)
 if ok and p.returncode: raise RuntimeError(p.stdout+'\n'+p.stderr)
 return p
results=[]
for market in ['amm','bondingcurve']:
 policy=case/'fixtures-v1'/market/'policy.json'
 p=run([driver,'identity',policy]);identity=json.loads(p.stdout.strip().splitlines()[-1]);save(public/f'{market}-native-identity.json',identity)
 assert identity['orderingModel']=='previous-checkpoint-seeded-v1' and identity['producerInfluence'] and not identity['qualifiedRandomness']
 projection=json.load(open(case/'full-ups-v1'/f'{market}-2-public-key-input.json'));f=projection['fields'];count=int(f[2])
 source={'batch':str(f[1]),'checkpoint':str(f[3]),'root':list(map(str,f[13:17])),'seed':list(map(str,f[74:78])),'owners':[str(f[22+13*i]) for i in range(count)]+['0']*(4-count),'nonces':[str(f[31+13*i]) for i in range(count)]+['0']*(4-count),'count':count}
 inp=public/f'{market}-rank-input.json';out=public/f'{market}-rank.json';save(inp,source)
 run([driver,'producer-order',policy,inp,out]);rank=json.load(open(out))['rank'];assert rank==list(map(int,f[17:21]))
 for n in [2,3]:
  v={**source,'count':n,'owners':source['owners'][:n]+['0']*(4-n),'nonces':source['nonces'][:n]+['0']*(4-n)};inp=public/f'{market}-rank-{n}-input.json';out=public/f'{market}-rank-{n}.json';save(inp,v);run([driver,'producer-order',policy,inp,out]);r=json.load(open(out))['rank'];assert sorted(r[:n])==list(range(n)) and r[n:]==list(range(n,4))
 for request in sorted((case/'full-ups-v1').glob(f'{market}-*-request.json')):
  obj=json.load(open(request));assert obj['user_ec_input']['core']['new_user_leaf']['public_key']==identity['publicKeyHash']
  out=public/(request.stem+'-verified.json');run([verify,request,out]);assert json.load(open(out))['fullProofVerifiedAgainstPinnedNodeKeyAndCommon']
 previous=case/'default-after-fix'/market/'policy.json';p=run([driver,'identity',previous],False);assert p.returncode and 'offline-only' in p.stderr;save(public/f'{market}-v3-guard.json',{'exitCode':p.returncode,'reason':p.stderr.strip(),'broadcast':False})
 results.append({'market':market,'nativeIdentityMatchedBothCompleteUps':True,'nativeRankMatchedCompleteUps':True,'twoAndThreeMemberPadding':True,'v3GuardRetained':True})
save(public/'native-checks.json',{'scope':'offline native CLI and independent saved-request verifier; no RPC/session start/quote/network submission','markets':results,'financialOperations':0,'rpcCalls':0})
print(json.dumps(results))
