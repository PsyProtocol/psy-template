import test from 'node:test';import assert from 'node:assert/strict';import {readFile,mkdtemp,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import {join} from 'node:path';
import {scanBatch} from './reader.mjs';import {members} from './controller.mjs';import {witness,signingRequest} from './policy.mjs';import {losslessJson,encodeAmount,parseLosslessJson,FEE_ESCROW as F} from '../../amm/u124/client.mjs';
import {ExecutionJournal} from '../../executor/journal.mjs';import {executeCycle} from '../../executor/worker.mjs';import {validateOptions} from '../../executor/config.mjs';
const root=process.env.BATCH_BUILD;if(!root)throw Error('BATCH_BUILD required');const read=async p=>JSON.parse(await readFile(`${root}/${p}`));
for(const market of['amm','orderbook','bondingcurve','nftmarket']){
 const artifact=await read(`${market}/compiled/compilation_artifact.json`),config=await read(`${market}/config.json`),policy=await read(`${market}/policy.json`),abi=artifact.abi;
 test(`${market}: restart reads committed members without rediscovery and expires the same batch`,async()=>{
  const map=new Map(abi.contract.state.map(f=>[f.name,f.offset])),values=new Map(),set=(n,v,i=0)=>values.set(`100:1000:${map.get(n)+i}`,v),pair=(n,v)=>encodeAmount(v).forEach((x,i)=>set(n,x,i));
  set('batch_phase',1n);set('batch_id',7n);set('batch_cutoff',100n);set('batch_expiry',120n);[1n<<63n,2n,3n,4n].forEach((v,i)=>set('batch_root',v,i));
  // A committed malformed/expired candidate still has an explicit refund;
  // discovery hints never decide whether it disappears after restart.
  set('frozen_owner',200n);set('frozen_nonce',1n);set('frozen_kind',market==='nftmarket'?2n:1n);set('frozen_deadline',99n);set('frozen_fee_delta',0n);set('frozen_paid_a_lo',17n);set('frozen_pool',100n);values.set('200:42:33554853',17n);
  if(market==='amm'){pair('reserve_a',1000n);pair('reserve_b',1000n);pair('total_shares',1000n);}
  let cp=101,reads=[];const state=async()=>({checkpoint:cp,slot:async(u,c,o)=>{reads.push(u);return values.get(`${u}:${c}:${o}`)??0n;}}),options={kind:market,vaultId:100,contractId:1000,users:[999999],rpcConfig:'unused'};
  const a=await scanBatch(options,state,{abi,config,policy});options.users=[];const b=await scanBatch(options,state,{abi,config,policy});assert.deepEqual(a.action,b.action);assert.ok(!reads.includes(999999));assert.equal(a.action.kind,'batch_settle');assert.equal(parseLosslessJson(a.action.submission).software_defined_call.inputs[13],1n<<63n);
  values.set('200:42:33554853',18n);const drift=await scanBatch(options,state,{abi,config,policy});assert.equal(drift.action,null);assert.equal(drift.reason,'frozen-funding-drift-awaiting-expiry');
  cp=121;const e=await scanBatch(options,state,{abi,config,policy});assert.equal(e.action.kind,'batch_expire');assert.equal(e.action.batchId,'7');
 });
 test(`${market}: new profile pins sponsor and retains distinct asset bindings`,()=>{const asset=id=>({contractId:id,codeRoot:'a'.repeat(64),layoutRoot:'b'.repeat(64),abi:'asset.json'});const input={kind:market,profile:'batch-v2',network:'testnet',contractId:1000,vaultId:100,batchSponsorId:300,publicKeyHash:'c'.repeat(64),fingerprint:'d'.repeat(64),codeRoot:'e'.repeat(64),layoutRoot:'f'.repeat(64),walletSha256:'a'.repeat(64),wallet:'driver',abi:'abi.json',policy:'policy.json',driverConfig:'config.json',rpcConfig:'rpc.json',runtimeDirectory:'runtime',...(market==='nftmarket'?{collection:asset(41),paymentToken:asset(42)}:{assetA:asset(42),assetB:asset(43)})};assert.equal(validateOptions(input).batchExpiryCheckpoints,256);assert.equal(validateOptions(input).batchMemberLimit,['amm','bondingcurve'].includes(market)?2:4);assert.equal(validateOptions({...input,batchMemberLimit:4}).batchMemberLimit,4);assert.throws(()=>validateOptions({...input,batchMemberLimit:5}),/batchMemberLimit/);if(market==='amm')assert.throws(()=>validateOptions({...input,profile:'u124',batchSponsorId:undefined,batchMemberLimit:4}),/batch fields require/);assert.throws(()=>validateOptions({...input,batchSponsorId:100}),/Sponsor/);assert.throws(()=>validateOptions({...input,batchExpiryCheckpoints:1025}),/1..1024/);});
}
const policy=await read('amm/policy.json');const task=mode=>({kind:mode===1?'batch_commit':'batch_settle',batchId:'7',submission:losslessJson(signingRequest(policy,witness({mode,batch:7n,...(mode===1?{users:[200n],nonces:[1n],expiry:120n,sponsor:300n}:{root:[1n,2n,3n,4n]}),burn:0n})))});
const receipt={status:'included',userId:100,contentHash:'a'.repeat(64),checkpoint:101};
test('lost commit receipt blocks settlement; restart reconciles identity then uses frozen settlement',async()=>{const directory=await mkdtemp(join(tmpdir(),'psy-batch-journal-'));try{const make=()=>new ExecutionJournal({directory,network:'testnet',vaultId:100,fingerprint:'b'.repeat(64)});let scans=0,submits=0,recovered=false;let next=task(1);const adapter={scan:async()=>{scans++;return {checkpoint:100,action:next};},isCurrent:async()=>true,prove:async t=>({calls:t.submission}),submit:async()=>{submits++;throw Error('response lost');},reconcile:async()=>recovered?receipt:{status:'unresolved'}};
 assert.equal((await executeCycle({adapter,journal:make()})).status,'unresolved');next=task(2);assert.equal((await executeCycle({adapter,journal:make()})).status,'unresolved');assert.equal(scans,1);assert.equal(submits,1);
 recovered=true;assert.equal((await executeCycle({adapter,journal:make()})).status,'included');assert.equal(submits,2);const records=await make().records();assert.deepEqual(records.filter(x=>x.status==='broadcast-intent').map(x=>x.task.kind),['batch_commit','batch_settle']);assert.equal((await executeCycle({adapter,journal:make()})).status,'already-included');assert.equal(submits,2);
 }finally{await rm(directory,{recursive:true,force:true});}});
test('crash after commitment proof reuses exactly that immutable request before intent',async()=>{const directory=await mkdtemp(join(tmpdir(),'psy-batch-proof-'));try{const make=()=>new ExecutionJournal({directory,network:'testnet',vaultId:100,fingerprint:'b'.repeat(64)});let reads=0,proofs=0;const original=task(1),args={task:original,isCurrent:async()=>{if(++reads===2)throw Error('simulated restart');return true;},prove:async t=>{proofs++;return {calls:t.submission};},validateProof:async(t,p)=>p.calls===t.submission,submit:async(t,p)=>{assert.equal(p.calls,original.submission);return {};},reconcile:async()=>receipt};await assert.rejects(make().execute(args),/simulated restart/);assert.equal((await make().execute(args)).status,'included');assert.equal(proofs,1);
 }finally{await rm(directory,{recursive:true,force:true});}});

async function idleFixture(market){const artifact=await read(`${market}/compiled/compilation_artifact.json`),config=await read(`${market}/config.json`),policy=await read(`${market}/policy.json`),fields=new Map(artifact.abi.contract.state.map(f=>[f.name,f]));const values=new Map(),put=(u,c,o,n)=>values.set(`${u}:${c}:${o}`,BigInt(n)),field=(u,n,v)=>{const f=fields.get(n);if(Array.isArray(v))v.forEach((x,i)=>put(u,1000,f.offset+i,x));else put(u,1000,f.offset,v);};
 field(100,'batch_ready',1);field(300,'sponsor_pool',100);field(300,'sponsor_amount',2n*F);field(300,'sponsor_nonce',1);field(300,'sponsor_purpose',1);put(300,0,203,2n*F);
 const order=(owner,side=0,more={})=>{for(const[n,v]of Object.entries({kind:1,pool:100,nonce:1,deadline:200,cancelled:0,order_checkpoint:100,side,x:encodeAmount(10n),y:encodeAmount(10n),z:encodeAmount(0n),...more}))if(fields.has(n))field(owner,n,v);put(owner,0,203,F);if(market!=='nftmarket')put(owner,side?43:42,33554853,10);};
 return {field,put,order,options:{kind:market,contractId:1000,vaultId:100,batchSponsorId:300,users:[],rpcConfig:'unused'},files:{abi:artifact.abi,config,policy},state:async()=>({checkpoint:100,slot:async(u,c,o)=>values.get(`${u}:${c}:${o}`)??0n})};}
test('Book discovery includes a compatible bid even with ten earlier asks',async()=>{const f=await idleFixture('orderbook');for(let u=200;u<210;u++)f.order(u);f.order(500,1);f.options.users=[...Array.from({length:10},(_,i)=>200+i),500];const result=await scanBatch(f.options,f.state,f.files);assert.equal(result.action.kind,'batch_commit');const v=parseLosslessJson(result.action.submission).software_defined_call.inputs;assert.equal(v[2],2n);assert.deepEqual(v.slice(5,9),[200n,500n,0n,0n]);f.options.users=f.options.users.filter(u=>u!==500);assert.equal((await scanBatch(f.options,f.state,f.files)).action,null,'do not charge sponsor for a carry-only batch');});
test('NFT discovery groups buyers with listings and does not fill a batch with unmatched listings',async()=>{const f=await idleFixture('nftmarket');for(const u of[200,202,204,206,208])f.order(u,0,{price:encodeAmount(10n)});for(const[u,seller]of[[201,200],[205,204]])f.order(u,0,{kind:2,seller,listing_nonce:1,price:encodeAmount(10n)});f.options.users=[200,202,204,206,208,201,205];const result=await scanBatch(f.options,f.state,f.files),v=parseLosslessJson(result.action.submission).software_defined_call.inputs;assert.deepEqual(v.slice(5,9),[200n,201n,204n,205n]);});
test('NFT stale seller that has become a buyer is a zero-nonce reference, not a second outcome',async()=>{const f=await idleFixture('nftmarket');f.order(200,0,{kind:2,nonce:2,seller:202,listing_nonce:1,price:encodeAmount(10n)});f.order(201,0,{kind:2,seller:200,listing_nonce:1,price:encodeAmount(10n)});f.options.users=[201];const result=await scanBatch(f.options,f.state,f.files),v=parseLosslessJson(result.action.submission).software_defined_call.inputs;assert.deepEqual(v.slice(5,9),[200n,201n,0n,0n]);assert.deepEqual(v.slice(9,13),[0n,1n,0n,0n]);});

test('NFT frozen payout queue waits for claims, then expires without dropping its members',async()=>{
 const f=await idleFixture('nftmarket');f.field(100,'batch_phase',1);f.field(100,'batch_id',7);f.field(100,'batch_cutoff',100);f.field(100,'batch_expiry',120);
 const artifact=await read('nftmarket/compiled/compilation_artifact.json'),offset=new Map(artifact.abi.contract.state.map(x=>[x.name,x.offset]));const put=(name,i,value)=>f.put(100,1000,offset.get(`frozen_${name}`)+i,value);
 for(const[i,u,kind]of[[0,200,1],[1,201,2]]){for(const[n,v]of Object.entries({owner:u,kind,pool:100,nonce:1,deadline:200,cancelled:0,order_checkpoint:100,price_lo:10,price_hi:0,fee_delta:F,fee_sent:F,nft_matches:1,nft_sent:kind===1?1:0,nft_claimed:0,paid_a_lo:kind===2?10:0,paid_a_hi:0,paid_b_lo:0,paid_b_hi:0,seller:kind===2?200:0,listing_nonce:kind===2?1:0}))put(n,i,v);f.put(u,0,203,F);}
 f.put(201,42,33554853,10);f.put(200,41,1182+35*100+32,1);f.put(100,41,1182+35*201+32,4);
 const blocked=await scanBatch(f.options,f.state,f.files);assert.equal(blocked.action,null);assert.equal(blocked.reason,'nft-delivery-backpressure');
 f.put(201,41,1182+35*100+33,1);const ready=await scanBatch(f.options,f.state,f.files);assert.equal(ready.action.kind,'batch_settle');
 const expired=await scanBatch(f.options,async()=>({...await f.state(),checkpoint:121}),f.files);assert.equal(expired.action.kind,'batch_expire');assert.equal(expired.action.batchId,'7');
});

test('uninitialized selected FT accounts are surfaced before freezing a batch',async()=>{const f=await idleFixture('orderbook');f.order(200);f.order(201,1);f.options.users=[200,201];const result=await scanBatch(f.options,async()=>({...await f.state(),contractStateRoot:async(u,c)=>u===200&&c===43?'0'.repeat(64):'1'.repeat(64)}),f.files);assert.equal(result.action,null);assert.equal(result.reason,'asset-account-initialization-required');assert.deepEqual(result.missing,[{userId:200,contractId:43}]);});
test('NFT activation requires an authenticated materialized payer tree before proposing a proof',async()=>{
 const f=await idleFixture('nftmarket');f.field(100,'batch_ready',0);f.options.automaticInitialize=true;f.options.activationPayerId=300;
 f.put(300,0,203,F);f.put(300,42,33554853,1);
 const noReader=await scanBatch(f.options,f.state,f.files);assert.equal(noReader.action,null);assert.equal(noReader.reason,'activation-payer-nft-state-check-required');
 const absent=await scanBatch(f.options,async()=>({...await f.state(),contractStateRoot:async()=> '0'.repeat(64)}),f.files);
 assert.equal(absent.action,null);assert.equal(absent.reason,'activation-payer-nft-initialization-required');assert.equal(absent.initializationRequest.ordinaryOwnerSignatureRequired,true);
 const emptyHolder=await scanBatch(f.options,async()=>({...await f.state(),contractStateRoot:async()=> '1'.repeat(64)}),f.files);assert.equal(emptyHolder.action,null);assert.equal(emptyHolder.reason,'activation-payer-nft-holder-required');
 f.put(300,41,0,1);const ready=await scanBatch(f.options,async()=>({...await f.state(),contractStateRoot:async()=> '1'.repeat(64)}),f.files);assert.equal(ready.action.kind,'batch_maintenance');
});
test('an empty vault needs two fee budgets for separate fund-gas and sender recovery UPSs',async()=>{
 const f=await idleFixture('nftmarket');f.options.users=[200];f.field(200,'kind',0);f.field(200,'recovery_pool',100);f.put(200,0,203,F);f.put(200,42,33554853,1);
 f.field(300,'sponsor_purpose',2);f.field(300,'sponsor_amount',F);f.put(300,0,203,F);
 const short=await scanBatch(f.options,f.state,f.files);assert.equal(short.action,null);assert.equal(short.reason,'recovery-gas-sponsorship-required');assert.equal(short.requiredTotal,(2n*F).toString());assert.equal(short.sponsorPending,F.toString());
 f.field(300,'sponsor_amount',2n*F);f.put(300,0,203,2n*F);const fund=await scanBatch(f.options,f.state,f.files);assert.ok(parseLosslessJson(fund.action.submission).contract_calls.some(c=>c.method_name==='fund_gas'));
 f.put(100,0,0,F);const recover=await scanBatch(f.options,f.state,f.files);assert.ok(parseLosslessJson(recover.action.submission).contract_calls.some(c=>c.method_name==='recover_funding'));
});

for(const market of ['amm','bondingcurve'])test(`${market}: scanner freezes four canonical users and leaves the fifth for a later batch`,async()=>{
 const f=await idleFixture(market);if(market==='bondingcurve')f.field(100,'phase',1);for(const u of[204,203,202,201,200])f.order(u,0,market==='bondingcurve'?{lots:1,limit_mode:1}:{});f.options.users=[204,203,202,201,200];
 const legacy=await scanBatch(f.options,f.state,f.files),before=parseLosslessJson(legacy.action.submission).software_defined_call.inputs;assert.equal(before[2],2n);assert.deepEqual(before.slice(5,9),[200n,201n,0n,0n]);
 f.options.batchMemberLimit=4;const result=await scanBatch(f.options,f.state,f.files),v=parseLosslessJson(result.action.submission).software_defined_call.inputs;
 assert.equal(result.action.kind,'batch_commit');assert.equal(v[2],4n);assert.deepEqual(v.slice(5,9),[200n,201n,202n,203n]);
});

for(const market of ['amm','bondingcurve'])test(`${market}: lowering discovery limit never truncates a frozen four-member set`,async()=>{
 const f=await idleFixture(market);f.options.batchMemberLimit=1;f.options.users=[];
 for(const[n,v]of Object.entries({batch_phase:1,batch_id:7,batch_cutoff:100,batch_expiry:120,batch_root:[1,2,3,4],frozen_owner:[200,201,202,203],frozen_kind:[1,1,1,1],frozen_pool:[100,100,100,100],frozen_nonce:[1,1,1,1],frozen_deadline:[99,99,99,99],frozen_paid_a_lo:[17,17,17,17]}))f.field(100,n,v);
 for(const u of[200,201,202,203])f.put(u,42,33554853,17);
 const result=await scanBatch(f.options,f.state,f.files);assert.equal(result.action.kind,'batch_settle');const v=parseLosslessJson(result.action.submission).software_defined_call.inputs;
 assert.deepEqual([0,1,2,3].map(i=>v[22+13*i]),[200n,201n,202n,203n]);
});
