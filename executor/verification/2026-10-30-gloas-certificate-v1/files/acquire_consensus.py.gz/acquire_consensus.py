import pathlib,json,hashlib,subprocess,time
from concurrent.futures import ThreadPoolExecutor
C=pathlib.Path(__file__).resolve().parent
endpoints=[('lightclient-finality','https://sepolia.lightclient.xyz/eth/v1/beacon/light_client/finality_update'),('lodestar-finality','https://lodestar-sepolia.chainsafe.io/eth/v1/beacon/light_client/finality_update'),('chainsafe-finality','https://beaconstate-sepolia.chainsafe.io/eth/v1/beacon/light_client/finality_update')]
def get(item):
 label,url=item;out=C/'quarantine'/(label+'.body');assert not out.exists();start=time.monotonic()
 p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes()if out.exists()else b''
 if out.exists():out.chmod(0o600)
 r={'schema':1,'url':url,'httpStatus':p.stdout,'curlExit':p.returncode,'elapsedSeconds':time.monotonic()-start,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'publicTransportError':p.stderr.strip(),'finalityVerified':False,'trustAnchorReviewed':False,'canBroadcast':False}
 try:
  v=json.loads(raw);r['version']=v.get('version');r['fields']=list(v);r['dataFields']=list(v['data'])if isinstance(v.get('data'),dict)else None
  if isinstance(v.get('message'),str):r['publicError']=v['message']
 except Exception:pass
 with(C/'public'/(label+'-transport.json')).open('x')as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
with ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(get,endpoints))
