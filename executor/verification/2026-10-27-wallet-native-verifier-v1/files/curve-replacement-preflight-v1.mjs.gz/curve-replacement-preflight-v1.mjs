// Read-only fresh chain observation; no registration, grant or deployment.
import assert from 'node:assert/strict';
import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {publicState} from '/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016/executor/publicState.mjs';
import {binding} from '/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016/batching/admission/liveSupport.mjs';
import {losslessJson} from '/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016/amm/u124/client.mjs';
const l=new URL('./isolated-live-v1/',import.meta.url).pathname,config=l+'public/rpc.json';
const out=new URL('./curve-replacement-preflight-v1/',import.meta.url).pathname;mkdirSync(out);
const read=p=>JSON.parse(readFileSync(p,'utf8')),save=(n,v)=>writeFileSync(out+n,losslessJson(v)+'\n',{flag:'wx'});
const s=await publicState(config);assert.equal(s.networkName,'testnet');assert.equal(BigInt(s.network.magic),1384803358401154921n);
const anchor=await s.rpc(s.coordinator,'psy_get_checkpoint_leaf_data',{checkpoint_id:1});assert.equal(anchor.global_chain_root,'24fe11facdc008ad5a6e6408da654217380b798af1ddb7df59845dfecd395942');
const deps=read(l+'markets-v1/amm/live-registration.json').contracts.filter(c=>c.contract.contractId!==9);
for(const d of deps)assert.deepEqual(await binding(s,d.contract.contractId),d);
const users=[];for(const [name,id]of [['issuer',1590272],['trader',1856512]]){const p=read(l+'public/'+name+'.json');assert.deepEqual(await s.userIds(p.publicKeyHash),[id]);const url=s.network.realm_configs.find(r=>r.id===Math.floor(id/s.network.users_per_realm)).rpc_url[0];const leaf=await s.rpc(url,'psy_get_user_leaf_data',{checkpoint_id:s.checkpoint,user_id:id},{exactIntegers:true});users.push({userId:id,publicKeyHash:p.publicKeyHash,leaf,nativeBalance:(await s.slot(id,0,0)).toString()});}
const faucet=s.network.faucet_url??s.network.psy_faucet_url??s.network.faucet_rpc_url;save('chain.json',{at:new Date().toISOString(),checkpoint:s.checkpoint,chainAt1:anchor.global_chain_root,dependencies:deps,users,financialOperations:0,originalIssuerFaucetUnknown:true});
const url='https://faucet-stg.psy-protocol.xyz';const request={jsonrpc:'2.0',id:1,method:'psy_get_psy_faucet_config',params:[]};save('faucet-config-request.json',request);
try{const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),signal:AbortSignal.timeout(20000),redirect:'error'});writeFileSync(out+'faucet-config.body',await r.text(),{flag:'wx'});save('faucet-status.json',{status:r.status,at:new Date().toISOString(),readOnly:true,financialOperations:0});}catch{save('faucet-status.json',{status:'transport-unavailable',at:new Date().toISOString(),readOnly:true,financialOperations:0});}
console.log('Fresh chain identities and dependency roots checked; public faucet diagnostic retained. No mutation.');
