// Build-time only. Produces a fresh static wallet module; never changes the
// source tree, fetches resources, selects an SDK, signs or sends a transaction.
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { resolve, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import { parseLosslessJson } from "../src/market-preparation/amm/u124/client.mjs";
const SDK = "06d86a86775bef1f217e61a2192b525d657bc8de2d3687e5c28d93e7abfaec8f",
  MAGIC = "1384803358401154921";
const sha = (b) => createHash("sha256").update(b).digest("hex");
const requireThat = (v, m) => {
  if (!v) throw Error(m);
};
const equalInteger = (a, b) =>
  /^(0|[1-9]\d*)$/.test(String(a)) &&
  /^(0|[1-9]\d*)$/.test(String(b)) &&
  BigInt(a) === BigInt(b);
export function validateMarketRelease({
  descriptor,
  bundle,
  pack,
  build,
  bytes,
}) {
  const byteFields = ["bundle", "verifierPack", "build", "wasm", "glue"];
  const descriptorFields = [
    "schema",
    "sdkManifestSha256",
    "networkMagic",
    "chainRootAt1",
    "registryHashes",
    ...byteFields.map((k) => k + "Sha256"),
  ];
  requireThat(
    Object.keys(bytes).sort().join() === byteFields.sort().join() &&
      Object.keys(descriptor).sort().join() === descriptorFields.sort().join(),
    "Exact public release projection required",
  );
  requireThat(
    descriptor.schema === 1 &&
      descriptor.sdkManifestSha256 === SDK &&
      descriptor.networkMagic === MAGIC,
    "Fixed SDK/network release required",
  );
  for (const [key, data] of Object.entries(bytes))
    requireThat(
      descriptor[key + "Sha256"] === sha(data),
      "Release " + key + " bytes changed",
    );
  requireThat(
    equalInteger(pack.schema, 1) &&
      pack.sdk_manifest === SDK &&
      String(pack.network_magic) === MAGIC &&
      build.sdkManifestSha256 === SDK &&
      build.verifierPackSha256 === descriptor.verifierPackSha256,
    "Source-derived verifier report required",
  );
  const registries = [bundle, ...(bundle.amm ? [bundle.amm] : [])];
  requireThat(
    registries.every(
      (b) =>
        b.registry.network.chainRootAt1 === descriptor.chainRootAt1 &&
        b.registry.sdkManifestSha256 === SDK,
    ),
    "Release chain/registry identity changed",
  );
  requireThat(
    Array.isArray(descriptor.registryHashes) &&
      descriptor.registryHashes.length === registries.length &&
      new Set(descriptor.registryHashes).size === registries.length &&
      registries.every((b) =>
        descriptor.registryHashes.includes(b.registryHash),
      ),
    "Exact registry set required",
  );
  requireThat(
    Array.isArray(pack.contracts) &&
      new Set(pack.contracts.map((c) => String(c.contract_id))).size ===
        pack.contracts.length,
    "Unique resource contract identities required",
  );
  const sourceById = new Map(
    build.sources.map((s) => [String(s.contractId), s]),
  );
  for (const b of registries)
    for (const market of b.registry.markets) {
      if (market.quarantined === true) continue;
      for (const d of market.dependencies) {
        const id = d.contract.contractId,
          c = pack.contracts.find((c) => equalInteger(c.contract_id, id)),
          s = sourceById.get(String(id));
        requireThat(
          c &&
            s &&
            c.code_root === d.contract.codeRoot &&
            c.layout_root === d.contract.layoutRoot &&
            c.function_root === d.functionTreeRoot &&
            equalInteger(c.height, d.contract.stateTreeHeight) &&
            equalInteger(c.fields, d.layoutFieldCount) &&
            equalInteger(c.slots, d.layoutSlotCount),
          "Reviewed dependency resources missing or changed: " + id,
        );
        requireThat(
          s.codeRoot === c.code_root &&
            s.layoutRoot === c.layout_root &&
            s.functionRoot === c.function_root,
          "Resource source report differs: " + id,
        );
      }
    }
  const native = pack.contracts.find((c) => equalInteger(c.contract_id, 0));
  requireThat(
    native &&
      ["transfer", "claim", "burn"].every((n) =>
        native.methods.some((m) => m.name === n),
      ),
    "Native public method resources required",
  );
  requireThat(
    bytes.glue
      .toString("utf8")
      .includes("export function get_owned_wasm_module()"),
    "Application-owned sealed glue required",
  );
  return {
    registryHashes: [...descriptor.registryHashes],
    chainRootAt1: descriptor.chainRootAt1,
    release: {
      sdkManifestSha256: SDK,
      networkMagic: MAGIC,
      wasmSha256: descriptor.wasmSha256,
      verifierPackSha256: descriptor.verifierPackSha256,
    },
  };
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const [inputFile, outDir] = process.argv.slice(2);
  requireThat(inputFile && outDir, "REVIEWED_RELEASE_INPUTS_JSON FRESH_OUTPUT");
  const input = JSON.parse(readFileSync(inputFile)),
    out = resolve(outDir);
  requireThat(!existsSync(out), "Fresh release output required");
  const bytes = {
    bundle: readFileSync(input.bundle),
    verifierPack: readFileSync(input.pack),
    build: readFileSync(input.build),
    wasm: readFileSync(input.wasm),
    glue: readFileSync(input.glue),
  };
  const bundle = JSON.parse(bytes.bundle),
    pack = parseLosslessJson(bytes.verifierPack.toString("utf8")),
    build = JSON.parse(bytes.build);
  const release = validateMarketRelease({
    descriptor: input.descriptor,
    bundle,
    pack,
    build,
    bytes,
  });
  // Inspect the actual compiled binary before producing any release module.
  // This is a build identity check, not an extension or transaction acceptance.
  const module = await import(pathToFileURL(resolve(input.glue)).href);
  requireThat(
    typeof module.get_owned_wasm_module === "function" &&
      module.get_owned_wasm_module() === undefined,
    "Fresh sealed module required",
  );
  const compiled = await WebAssembly.compile(bytes.wasm);
  await module.default({ module_or_path: compiled });
  requireThat(
    module.get_owned_wasm_module() === compiled,
    "Build inspector did not load the exact binary",
  );
  const identity = JSON.parse(module.verifier_identity());
  requireThat(
    identity.schema === 1 &&
      identity.sdkManifestSha256 === SDK &&
      identity.networkMagic === MAGIC &&
      identity.verifierPackSha256 === input.descriptor.verifierPackSha256,
    "Compiled verifier pack identity mismatch",
  );
  const types = readFileSync(input.glueTypes, "utf8");
  requireThat(
    types.includes("verify_market_prepared") &&
      types.includes("project_market_identity") &&
      types.includes("verifier_identity"),
    "Actual bindgen declarations required",
  );
  mkdirSync(out);
  mkdirSync(join(out, "assets"));
  writeFileSync(join(out, "assets/market_verifier.js"), bytes.glue);
  writeFileSync(join(out, "assets/market_verifier_bg.wasm"), bytes.wasm);
  writeFileSync(
    join(out, "assets/market_verifier.d.ts"),
    types +
      "\nexport function get_owned_wasm_module(): WebAssembly.Module | undefined;\n",
  );
  writeFileSync(
    join(out, "installed.ts"),
    '// Generated from reviewed public release inputs; no runtime installer.\nimport * as module from "./assets/market_verifier.js";\nimport type {InstalledMarketRelease} from "./runtime";\nexport const installedMarketRelease: InstalledMarketRelease = {...' +
      JSON.stringify(release) +
      ',module,wasmUrl:new URL("./assets/market_verifier_bg.wasm",import.meta.url).href};\n',
  );
  writeFileSync(
    join(out, "RELEASE.json"),
    JSON.stringify(
      {
        schema: 1,
        ...release,
        descriptor: input.descriptor,
        activationPerformed: false,
        compiledIdentityVerified: true,
        financialOperations: 0,
        nftWrite: false,
        boundary:
          "build-time resource identity checks only; native verification, final approval and fresh RPC checks remain mandatory",
      },
      null,
      2,
    ) + "\n",
  );
  console.log(
    JSON.stringify({
      freshOutput: out,
      activationPerformed: false,
      financialOperations: 0,
    }),
  );
}
