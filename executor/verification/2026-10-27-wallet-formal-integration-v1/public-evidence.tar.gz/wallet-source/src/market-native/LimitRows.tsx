export function MarketLimitRows({
  rows,
}: {
  rows: Array<{ label: string; value: string }>;
}) {
  return (
    <dl className="mt-3 space-y-2">
      {rows.map((row) => (
        <div key={row.label}>
          <dt className="font-medium">{row.label}</dt>
          <dd className="break-all">{row.value}</dd>
        </div>
      ))}
    </dl>
  );
}
