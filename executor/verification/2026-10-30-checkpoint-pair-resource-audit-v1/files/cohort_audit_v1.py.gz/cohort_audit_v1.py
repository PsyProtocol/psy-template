from pathlib import Path
import json,re,hashlib
c=Path(__file__).resolve().parent;base=Path('<application-root>');s=c.parent/'sdk-mainnet-beta-20261027-v1/source';m=base/'batching/dependencies/mainnet-beta-20261027/manifest.json';v=json.loads(m.read_text());records=[]
for label,p in [('application',c/'application-v5/Cargo.lock'),('sdk',s/'psy-sdk/Cargo.lock'),('client',s/'psy-node/Cargo.lock')]:
 packages=[]
 for block in p.read_text().split('[[package]]')[1:]:
  fields=dict(re.findall(r'^(name|version|source) = "([^"\n]*)"$',block,re.M))
  if fields.get('name')in ['plonky2','plonky2_field','plonky2_maybe_rayon','plonky2_util']:packages.append(fields)
 assert len(packages)==4 and all('736572e9dd3ca93566471cf5a2a1cb67a13fe01d'in row.get('source','')for row in packages)
 records.append({'label':label,'lockSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'backendPackages':packages})
with(c/'public/LOCK-AND-PIN-AUDIT-v1.json').open('x')as f:json.dump({'freezeManifestSha256':hashlib.sha256(m.read_bytes()).hexdigest(),'verifiedSourceFileCount':sum(len(pin['sourceFiles'])for pin in v['sourcePins']),'sourcePinSets':[{k:val for k,val in pin.items()if k!='sourceFiles'}for pin in v['sourcePins']],'locks':records,'financialOperations':0},f,indent=2);f.write('\n')
print('pinned files',sum(len(pin['sourceFiles'])for pin in v['sourcePins']))
