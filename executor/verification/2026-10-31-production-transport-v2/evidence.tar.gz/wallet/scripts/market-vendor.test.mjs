import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  cpSync,
  rmSync,
  writeFileSync,
  readFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { checkMarketVendor } from "./check-market-vendor.mjs";
import { authoredPaths } from "./format-staged.mjs";

test("generated vendor inventory refuses changed bytes, extra members and changed bundle", () => {
  const root = mkdtempSync(join(tmpdir(), "psy-vendor-integrity-"));
  try {
    const dir = join(root, "modules");
    cpSync(new URL("../src/market-preparation", import.meta.url), dir, {
      recursive: true,
    });
    assert.equal(checkMarketVendor(dir).financialAuthorization, false);
    const source = JSON.parse(readFileSync(join(dir, "SOURCE.json"))),
      p = join(dir, source.files[0].file),
      old = readFileSync(p);
    writeFileSync(p, Buffer.concat([old, Buffer.from("\n")]));
    assert.throws(() => checkMarketVendor(dir), /Generated vendor bytes/);
    writeFileSync(p, old);
    writeFileSync(join(dir, "extra.mjs"), "export {};\n");
    assert.throws(() => checkMarketVendor(dir), /Exact vendor inventory/);
    rmSync(join(dir, "extra.mjs"));
    writeFileSync(join(dir, "bundle.json"), "{}");
    assert.throws(() => checkMarketVendor(dir), /Reviewed bundle/);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("staged formatting selects authored files without rewriting pinned source", () => {
  assert.deepEqual(
    authoredPaths([
      "src/background/main.ts",
      "src/market-preparation/market-client/rpcWire.mjs",
      "psy-genesis/config.json",
      "sdk/mainnet-beta.json",
      "docs/review.md",
      "scripts/format-staged.mjs",
    ]),
    ["src/background/main.ts", "scripts/format-staged.mjs"],
  );
  assert.throws(() => authoredPaths(["../outside.ts"]));
});
