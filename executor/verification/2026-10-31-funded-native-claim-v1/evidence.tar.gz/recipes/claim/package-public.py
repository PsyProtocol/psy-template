from pathlib import Path
import json,hashlib,tarfile,gzip,io,re
c=Path(__file__).resolve().parent;r=c.parent.parent/'psy-template-security-20261016';g=c.parent/'faucet-cache-scope-20261031-v1';out=r/'executor/verification/2026-10-31-funded-native-claim-v1';out.mkdir();items={}
scopes=[('funding',g,['public','capture-v1','reconcile-v1','faucet-code-v1','authorized-repeat-v1','grant-confirmation-v1','grant-confirmation-v2']),('claim',c,['public','claim-precheck-v1','attempts','claim-confirmation-v1'])]
for label,base,dirs in scopes:
 for directory in dirs:
  for p in sorted((base/directory).rglob('*')):
   if p.is_dir():continue
   assert p.is_file()and not p.is_symlink()
   if p.name in ['response-private.body','rpc.json']:continue
   if p.suffix not in ['.json','.log','.body','.lock']:continue
   b=p.read_bytes();name=label+'/'+p.relative_to(base).as_posix()
   assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|"(?:private_key|privateKey|mnemonic|seedPhrase|password)"\s*:',b),name
   items[name]=b
for base,label in [(g,'funding'),(c,'claim')]:
 for p in sorted(base.glob('*.mjs')):items['recipes/'+label+'/'+p.name]=p.read_bytes()
items['recipes/claim/run.py']=(c/'run.py').read_bytes();items['recipes/claim/package-public.py']=Path(__file__).read_bytes()
for f in ['executor/chainReceipts.mjs','executor/chainReceipts.test.mjs','executor/acceptance/captureNativeBinding.mjs','executor/acceptance/captureNativeBinding.test.mjs','batching/admission/liveSupport.mjs']:
 items['source/'+f]=(r/f).read_bytes()
items['claim/application-source-digests.json']=(c/'application-v1/APPLICATION.json').read_bytes()
# Registry was acquired publicly. Do not traverse private key, original private
# faucet error or signing-witness files. Complete requests/proofs and Merkle
# update paths here are public network inputs, not signing witnesses.
assert json.loads(items['funding/capture-v1/runtime-client-resources.json'])['result']==json.loads((c.parent/'current-chain-activation-20261030-v1/capture-v3/runtime-client-resources.json').read_text())['result']
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as t:
 for name,b in sorted(items.items()):
  e=tarfile.TarInfo(name);e.size=len(b);e.mode=0o644;e.mtime=0;t.addfile(e,io.BytesIO(b))
packed=gzip.compress(buffer.getvalue(),mtime=0)
with(out/'evidence.tar.gz').open('xb')as f:f.write(packed)
m={'schema':1,'scope':'One explicit faucet repeat, exact grant inclusion, one complete ordinary CLI claim and conservation; not AMM/browser acceptance','archiveSha256':hashlib.sha256(packed).hexdigest(),'members':[{'file':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(items.items())],'ordinaryClaimsConfirmed':1,'marketFills':0,'browserWalletAcceptance':False,'originalFaucetOutcomeResolved':False}
with(out/'manifest.json').open('x')as f:json.dump(m,f,indent=2);f.write('\n')
with(out/'README.md').open('x')as f:f.write('''# Confirmed grant and ordinary CLI claim

Read the [review report](../../../docs/security/FAUCET_FUNDED_CLAIM_20261031.md).

The explicitly authorized second faucet attempt is included at 25190. One
ordinary claim is included at 25246: 1,000 test PSY input, 1.000002 PSY fee,
998.999998 PSY confirmed Native contract balance. Known source pending is zero.
The first faucet attempt remains unknown and its original lock is untouched.
No AMM deployment, market fill or browser-wallet approval is claimed here.

- `funding/`: declared read phase, current identity/cursors, public faucet code,
  prepared candidate, explicit user authorization, one-repeat intent/lock/safe
  result, and original exact grant receipt/cursor confirmation. The first
  localhost-default lookup failure is retained separately from corrected lookup.
- `claim/`: bounded claim plan, dependency/nonce checks, complete public proof,
  independent fixed verifier report, exact request/wire/intent, single-send ACK,
  original-identity receipt, state audit, timings and failed pre-wire preparations.
- `recipes/`: original acquisition/proving/submission/reconciliation scripts,
  retaining local paths. They are historical recipes, not retry authority.
- `source/`: exact application fixes; application manifest binds frozen build.

Every archive member has size/SHA256 in `manifest.json`; the manifest also binds
archive SHA256. Wallet keys/recovery files, signing witnesses, binary executables,
raw private faucet response bodies and full network configuration are excluded.
Complete ZK proofs, public request/update paths and public verifier metadata are
published as network evidence. Stored user system balance is distinct from PSY
in Native contract 0 slot 0. SDK-internal read counts and physical memory peaks
were not measured. No TPS or matched performance claim follows.
''')
print(json.dumps({'members':len(items),'archiveBytes':len(packed),'sha256':m['archiveSha256']}))
