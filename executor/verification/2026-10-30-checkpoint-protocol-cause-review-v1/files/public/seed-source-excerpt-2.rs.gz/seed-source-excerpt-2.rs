        let witness = QCQEDCheckpointStateTransitionInput::<N::F, N::QHash> {
            partial: QCQEDCheckpointStateTransitionInputPartial {
                pm_jobs_completed: PPMJobsCompletedStats {
                    deploy_contracts_completed: N::F::from_u64_value(self.total_deploy_contract_jobs as u64),
                    register_users_completed: N::F::from_u64_value(self.total_register_user_jobs as u64),
                    gutas_completed: N::F::from_u64_value(self.total_guta_jobs as u64),
                },
                part_1_header: self.get_part_1_header(last_committed, circuit_fingerprint_config),
                old_stats: last_committed.checkpoint_leaf_stats.clone(),
                block_time: N::F::from_u64_value(block_time),
                final_random_seed_contribution: self.guta_gatherer_result.random_seed_guta,
                validator_tree_root: last_committed.checkpoint_state_roots.validator_tree_root,
            },
            append_checkpoint_tree_proof,
            previous_checkpoint_proof,
            last_old_checkpoint_tree_leaf_hash: last_committed.checkpoint_state_transition.old_checkpoint_leaf_hash,
            last_old_checkpoint_tree_root_hash: last_committed.checkpoint_state_transition.old_checkpoint_tree_root,
