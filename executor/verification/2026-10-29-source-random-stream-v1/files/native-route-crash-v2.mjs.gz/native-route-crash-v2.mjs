import assert from 'node:assert/strict';import{parseLosslessJson}from'<application-root>/amm/u124/client.mjs';
import{execFile}from'node:child_process';import{promisify}from'node:util';
import{readFile,writeFile}from'node:fs/promises';import{createHash}from'node:crypto';
import{prepareRandomSourceStream}from'<application-root>/executor/randomSourceStream.mjs';
const c='<case-root>',d=c+'/native-planner-v1';
const sha=b=>createHash('sha256').update(b).digest('hex'),o={historyRoot:JSON.parse(await readFile(d+'/source.json')).history.checkpoint_path.root,wallet:c+'/bin-v4/random_stream_plan',runtimeDirectory:c+'/native-route-crash-v2',walletSha256:sha(await readFile(c+'/bin-v4/random_stream_plan'))};
for(const[n,f]of Object.entries({review:'review.json',snapshot:'source.json',draw:'draw.json',policy:'policy.json'})){o[n]=d+'/'+f;o[n+'Sha256']=sha(await readFile(o[n]));}
const exec=promisify(execFile);let completedBeforeCrash=false,originalBytes;
try{await prepareRandomSourceStream(o,{runNative:async(...args)=>{const result=await exec(...args);completedBeforeCrash=true;originalBytes=await readFile(args[1][5]+'/plan.json');throw Error('simulated process loss before journal commit');}});}catch(e){if(!completedBeforeCrash)throw e;}
const restarted=await prepareRandomSourceStream(o),plan=await restarted.plan();
assert.deepEqual(parseLosslessJson(originalBytes.toString()),plan.plan);
await writeFile(c+'/public/native-route-crash-v2.json',JSON.stringify({schema:1,actualNativeCompletedBeforeSimulatedCrash:completedBeforeCrash,exactNativeReplayAfterRestart:true,status:await restarted.status(),financialOperations:0,syntheticHistory:true},null,2)+'\n',{flag:'wx'});
console.log(await restarted.status());
