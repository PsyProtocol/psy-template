from pathlib import Path
import subprocess,json
c=Path(__file__).resolve().parent;d=c/'public/observed-openings-v1';d.mkdir();q=[]
for cp in [18504,18505]:
 q.extend([{'jsonrpc':'2.0','id':cp*10+1,'method':'psy_get_checkpoint_leaf_data','params':{'checkpoint_id':cp}},{'jsonrpc':'2.0','id':cp*10+2,'method':'psy_get_checkpoint_tree_merkle_proof','params':{'checkpoint_id':cp,'leaf_checkpoint_id':cp}}])
def put(n,v):
 with(d/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
put('PLAN.json',{'maximumReadOnlyRequests':4,'retries':0,'financialOperations':0,'scope':'unverified RPC state openings for public-input consistency diagnosis only; never finality or proof acceptance'});put('request.json',q)
p=subprocess.run(['curl','--silent','--show-error','--connect-timeout','5','--max-time','25','--max-filesize','1048576','--header','content-type: application/json','--data-binary','@-','https://coordinator-stg.psy-protocol.xyz'],input=json.dumps(q).encode(),capture_output=True,timeout=30);(d/'response.raw').write_bytes(p.stdout);put('transport.json',{'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace')});assert p.returncode==0
v=json.loads(p.stdout);rows={r['id']:r for r in v};assert set(rows)=={r['id']for r in q}
for cp in [18504,18505]:
 leaf=rows[cp*10+1]['result'];path=rows[cp*10+2]['result'];put(str(cp)+'.json',{'opening':{'schema':1,'checkpoint_id':cp,'checkpoint_root':path['root'],'checkpoint_leaf_hash':path['value'],'checkpoint_path':path},'leaf':leaf})
