from pathlib import Path
import json,subprocess,os,copy
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';m=b.parent/'market-mainnet-migration-20261027-v1'
out=b/'native-mutations-v1';out.mkdir()
paths=[b/'observations/chain-identity-v1/native-leaf.body',b/'public/native-decoded-v1.json',b/'public/native-layout-reproduced-v2.json',m/'isolated-live-v1/assets/native.json',b/'observations/circuits-response-v1.body',b/'observations/native-functions-v2/CAPTURE.json']
env=dict(os.environ,PSY_NETWORK='testnet',PSY_CONFIG_PATH=str(s/'source/psy-sdk/psy-genesis/config.json'),PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',RAYON_NUM_THREADS='2')
mutations=[('wrong-layout-count',0,lambda x:x['result'].update(state_layout_field_count=7)),('wrong-code-root',0,lambda x:x['result'].update(code_root='0'*64)),('null-layout',2,lambda x:x.clear()),('wrong-endcap-fingerprint',4,lambda x:x.update(result=json.dumps(dict(json.loads(x['result']),ups_end_cap=dict(json.loads(x['result'])['ups_end_cap'],fingerprint='0'*64))))),('wrong-function-root',5,lambda x:x['rows'][0]['response']['result'].update(root='0'*64))]
rows=[]
for name,index,change in mutations:
 args=list(paths);value=json.loads(args[index].read_text());change(value);bad=out/(name+'.json');bad.open('x').write(json.dumps(value)+'\n');args[index]=bad;report=out/(name+'-unexpected-report.json')
 with (out/(name+'.log')).open('x') as log:r=subprocess.run([str(s/'target/release/verify_native_layout'),*map(str,args),str(report)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'mutation':name,'exitCode':r.returncode,'rejected':r.returncode!=0,'successReportAbsent':not report.exists()})
 if r.returncode==0 or report.exists():raise RuntimeError('invalid capture accepted')
(out/'REPORT.json').open('x').write(json.dumps({'scope':'captured public preflight input rejection only; no proof generation or live mutation','rows':rows,'financialOperations':0},indent=2)+'\n')
