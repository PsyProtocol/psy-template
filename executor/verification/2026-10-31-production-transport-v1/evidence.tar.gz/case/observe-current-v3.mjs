// Bounded configured staging reads only. No signing, proof generation or broadcast.
import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {publicState} from '../../psy-template-security-20261016/executor/publicState.mjs';
import {readBoundedUtf8} from '../../psy-template-security-20261016/market-client/rpcWire.mjs';
import {losslessJson} from '../../psy-template-security-20261016/amm/u124/client.mjs';
const out=new URL('current-v3/',import.meta.url);await mkdir(out);let n=0;const deadline=Date.now()+120000;
const fetcher=async(url,options)=>{
 const id=++n;assert.ok(id<=7&&Date.now()<deadline,'declared staging read budget exhausted');
 const q=JSON.parse(options.body);assert.ok(q.method.startsWith('psy_get_'),'reads only');
 await writeFile(new URL(id+'-request.json',out),losslessJson({endpoint:url,wire:options.body}),{flag:'wx'});
 const response=await fetch(url,{...options,signal:AbortSignal.any([options.signal,AbortSignal.timeout(deadline-Date.now())])});
 const raw=await readBoundedUtf8(response,1048576);
 await writeFile(new URL(id+'-response.json',out),raw,{flag:'wx'});
 return new Response(raw,{status:response.status,headers:response.headers});
};
const s=await publicState(new URL('../../psy-template-security-20261016/market-client/reviewed/mainnet-beta-markets-20261027-v3/rpc-config.json',import.meta.url),{fetchImpl:fetcher});
assert.equal(s.networkName,'testnet');assert.equal(BigInt(s.network.magic),1384803358401154921n);
const coordinator=s.coordinator,realm0=s.network.realm_configs.find(r=>r.id===0).rpc_url[0],realm1=s.network.realm_configs.find(r=>r.id===1).rpc_url[0];
const anchor=await s.rpc(coordinator,'psy_get_checkpoint_leaf_data',{checkpoint_id:1});
assert.equal(anchor.global_chain_root,'919896e18690246e20307f68cf2e5725aee496755366bbafff88eccaea975f12','current chain changed; stop');
const heights=[];
for(const checkpoint of [s.checkpoint,9223372036854775807n])heights.push({endpoint:realm0,checkpoint,result:await s.rpc(realm0,'psy_get_contract_tree_state_heights',{checkpoint_id:checkpoint,contract_ids:[8]},{exactIntegers:true})});
const result={schema:1,checkpoint:s.checkpoint,chainRootAt1:anchor.global_chain_root,heights,readRequests:n,scope:'Final code revision: formal configured transport, fresh chain observation and exact checkpoint wire only. Not a full state/proof preflight or metadata recovery acceptance.',sourceCompilations:0,newProofs:0,financialOperations:0,canBroadcast:false};
await writeFile(new URL('SUMMARY.json',out),losslessJson(result)+'\n',{flag:'wx'});console.log(losslessJson(result));
