import {writeFileSync} from 'node:fs';
import {encodeCandidateStatement} from '../../psy-template-security-20261016/batching/random-order/statement.mjs';
const h=n=>BigInt(n).toString(16).padStart(64,'0');
const candidate={version:1,networkMagic:'1384803358401154921',market:'amm',marketId:'1000',vaultId:'100',epoch:'1',cutoff:'100',sealByCheckpoint:'110',drawCheckpoint:'120',round:'3',settleUntil:'150',recoveryAt:'160',maxFee:'2000200000',sourceId:h(1),chainRootAt1:h(2),codeRoot:h(3),layoutRoot:h(4),functionRoot:h(5),keyFingerprint:h(6),publicKeyHash:h(7),queueRoot:h(8),batchRoot:h(9),members:[200,201,202,203].map((owner,i)=>({owner:String(owner),nonce:i===2?((1n<<62n)-1n).toString():String(i+1),termsRoot:h(i+10)}))};
writeFileSync(new URL('./public/candidate-v1.json',import.meta.url),JSON.stringify(candidate,null,2)+'\n',{flag:'wx'});
const fields=encodeCandidateStatement(candidate).fields;
writeFileSync(new URL('./public/client-statement-v1.json',import.meta.url),JSON.stringify({fields,seed:['11','22','33','44']},null,2)+'\n',{flag:'wx'});
