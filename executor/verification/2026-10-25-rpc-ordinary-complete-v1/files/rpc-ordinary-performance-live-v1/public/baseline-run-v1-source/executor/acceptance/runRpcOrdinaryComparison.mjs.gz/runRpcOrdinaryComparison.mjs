// Matched real fills. Baseline modules/binaries are frozen before mutations.
// A partial/unknown attempt is a stop, never permission to replace a payment.
import assert from 'node:assert/strict';
import {existsSync,mkdirSync,readFileSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {hostname,cpus,totalmem,loadavg} from 'node:os';
import {threeMarketCase,SDK} from './threeMarketCase.mjs';
import {formal as candidateFormal,pause} from './candidateHarness.mjs';
import {LiveMarket} from '../../batching/admission/liveMarket.mjs';
import {ordinary,read,save,confirmUps} from '../../batching/admission/liveSupport.mjs';
import {call,encodeAmount,FEE_ESCROW as F,parseLosslessJson} from '../../amm/u124/client.mjs';
import {sponsorCalls} from '../../batching/v2/client.mjs';
import {cohortAssets,payoutClaims} from '../../batching/admission/liveAssets.mjs';
import {publicState} from '../publicState.mjs';
import {sha256} from '../requestBinding.mjs';
import {ordinaryResident} from '../ordinaryResident.mjs';
import {residentScope} from '../residentScope.mjs';
import {freezeAppModules} from './sourceClosure.mjs';
import {saveObservation} from '../observations.mjs';

const [base,original,selection='baseline']=process.argv.slice(2);
assert.ok(base&&original);assert.ok(['baseline','candidate'].includes(selection));
assert.ok(!existsSync(join(base,'public',selection+'-COMPLETE.json')),'closed round');
freezeAppModules(fileURLToPath(import.meta.url),base,selection+'-run-v1');
const old=await threeMarketCase(original,{toolManifest:'TOOLS-v2.json'});
assert.equal(read(join(original,'public/ACCEPTANCE-CLOSED-v1.json')).fullProofAccountingPending,false);
const release=read(join(base,'public/RELEASE.json')),sdkManifest=join(process.cwd(),'batching/dependencies/session-bound-sdk-20261020/manifest.json');
assert.equal(sha256(readFileSync(sdkManifest)),SDK);assert.equal(release.sdkManifestSha256,SDK);
const round=join(base,selection);if(!existsSync(round)){mkdirSync(round);mkdirSync(join(round,'public'));mkdirSync(join(round,'attempts'));copyFileSync(join(base,'public/rpc.json'),join(round,'public/rpc.json'));}
const config=join(round,'public/rpc.json'),m=new LiveMarket({...old.by.orderbook,base:round,config});
const baselineFormal=(await import(pathToFileURL(join(base,'baseline-source/executor/acceptance/candidateHarness.mjs')).href)).formal;
const h={...old,base:round,config,markets:[m],by:{orderbook:m},residentScope:residentScope()};
const ordinaryTool=selection==='candidate'?release.binaries.ordinary:old.tools.binaries.ordinary;
assert.equal(sha256(readFileSync(ordinaryTool.file)),ordinaryTool.sha256);
const env={...h.env,...(selection==='candidate'?{}:{PSY_ORDINARY_GUARD_MODE:'serial-v1'})};
const depsFile=join(round,'public/ordinary-dependencies.json');if(!existsSync(depsFile))save(depsFile,m.contracts);
const workers=new Map();
const user=async(actor,label,calls)=>{
 const out=join(round,'attempts',label),input=join(round,'public',label+'.json');
 assert.ok(!existsSync(out)&&!existsSync(input),'partial original ordinary attempt; reconcile exact identity before resuming');
 let worker;
 if(selection==='candidate'){
  if(!workers.has(actor))workers.set(actor,await ordinaryResident({binary:ordinaryTool.file,binarySha256:ordinaryTool.sha256,config,dependencies:depsFile,secret:h.actors[actor].secret,publicKeyHash:h.actors[actor].publicKeyHash,sdkManifest,sdkSha256:SDK,env}));
  worker=workers.get(actor);
 }
 const startedAt=new Date().toISOString(),t=performance.now();
 const result=await ordinary({base:round,config,binary:ordinaryTool.file,secret:h.actors[actor].secret,name:label,calls:typeof calls==='function'?await calls():calls,bindings:h.bindings,env,worker,historyConcurrency:selection==='baseline'?1:4});
 saveObservation(join(round,'public',label+'-end-to-end.json'),{startedAt,finishedAt:new Date().toISOString(),wallMilliseconds:performance.now()-t,selection,actor,scope:'fresh dependency/snapshot reads, ordinary preparation/proof, ACK, indexed receipt and common visibility; ordinary payout claims are real UPSs'});
 return result;
};
const fund=(label,purpose=2)=>user('sponsor',label,async()=>{
 const s=await publicState(config);
 return sponsorCalls({marketId:BigInt(m.id),abi:m.abi,vaultId:BigInt(m.vault),nonce:await h.at(s,m,h.actors.sponsor.id,'sponsor_nonce')+1n,purpose:BigInt(purpose),amount:purpose===1?2n*F:F});
});
const U=h.actors.bob.id,B=h.actors.buyer.id,unit=10n**18n;
const spec={users:[U,B,h.actors.sponsor.id,...old.markets.map(m=>m.vault),...old.pin.legacyAssetVaults],assets:[2483,2484],nftId:2496};
const named=name=>t=>t.kind==='batch_maintenance'&&parseLosslessJson(t.submission).contract_calls.some(c=>c.method_name===name);
const pair=async jobs=>{const results=await Promise.allSettled(jobs.map(fn=>fn()));const bad=results.find(r=>r.status==='rejected');if(bad)throw bad.reason;};
let f;
try {
 const s=await publicState(config);
 assert.equal(await h.at(s,m,m.vault,'queue_phase'),3n);
 assert.ok([3n,4n].includes(await h.at(s,m,m.vault,'batch_phase')));
 const nonceU=await h.at(s,m,U,'nonce')+1n,nonceB=await h.at(s,m,B,'nonce')+1n;
 assert.equal(nonceU,nonceB);
 const before=await cohortAssets(s,spec);save(join(round,'public/assets-before.json'),before);
 assert.ok(before.accounts[U].ft[2483]>=unit&&before.accounts[B].ft[2484]>=unit);
 assert.ok(before.accounts[h.actors.sponsor.id].native>=12_000_000_000n,'explicit sponsor budget');
 saveObservation(join(round,'public/ENVIRONMENT.json'),{at:new Date().toISOString(),host:hostname(),logicalCpus:cpus().length,physicalMemoryBytes:totalmem(),loadAverage:loadavg(),threads:2,sdkSha256:SDK,compactBinary:h.binarySha256,ordinaryBinary:ordinaryTool.sha256,selection,market:m.id,vault:m.vault,inputPerSide:unit.toString(),fills:1,matching:'existing deterministic Book priority, two members, one trade; normal new orders only, no contract updates'});
 await pair([
  ()=>user('bob','owner-order',[m.order('open_sell',[BigInt(m.vault),0n,encodeAmount(unit),encodeAmount(unit),BigInt(s.checkpoint+8192),nonceU]),{contract_id:0n,method_name:'simple_transfer',inputs:[BigInt(m.vault),F]},call(2483n,h.token,'transfer',[BigInt(m.vault),encodeAmount(unit)])]),
  ()=>user('buyer','buyer-order',[m.order('open_sell',[BigInt(m.vault),1n,encodeAmount(unit),encodeAmount(unit),BigInt(s.checkpoint+8192),nonceB]),{contract_id:0n,method_name:'simple_transfer',inputs:[BigInt(m.vault),F]},call(2484n,h.token,'transfer',[BigInt(m.vault),encodeAmount(unit)])])
 ]);
 await fund('start-fund');
 const at=await publicState(config),plan={version:1,epoch:Number(await h.at(at,m,m.vault,'queue_epoch'))+1,cutoff:at.checkpoint+512,members:[U,B].sort((a,b)=>a-b).map(owner=>({owner,nonce:nonceU.toString()}))};save(join(round,'public/PLAN.json'),plan);
 f=await(selection==='baseline'?baselineFormal:candidateFormal)(h,m,'rpc-ordinary',plan,{performanceMetrics:true,expiry:512,runtimeSuffix:'-comparison'});
 await f.step('start',named('start_epoch'));
 await pair([()=>user('bob','owner-consent',[m.order('request_admission',[BigInt(plan.epoch),BigInt(plan.cutoff)])]),()=>fund('admit-0-fund')]);
 await user('buyer','buyer-consent',[m.order('request_admission',[BigInt(plan.epoch),BigInt(plan.cutoff)])]);
 await f.step('admit-0',named('admit_entry'));
 await fund('admit-1-fund');await f.step('admit-1',named('admit_entry'));
 await fund('seal-fund');
 const waitStart=performance.now(),waitAt=new Date().toISOString();
 while((await publicState(config)).checkpoint<=plan.cutoff)await pause(10000);
 saveObservation(join(round,'public/cutoff-wait.json'),{startedAt:waitAt,finishedAt:new Date().toISOString(),wallMilliseconds:performance.now()-waitStart,cutoff:plan.cutoff,scope:'protocol cutoff wait, separate from prover/RPC execution cost'});
 await f.step('seal',named('seal_epoch'));await fund('commit-fund',1);
 await f.step('commit',t=>t.kind==='batch_commit');await f.step('settle',t=>t.kind==='batch_settle');
 await pair([
  ()=>user('bob','owner-payout',async()=>payoutClaims(await publicState(config),{userId:U,markets:[m],tokenAbi:h.token,nftAbi:h.nft})),
  ()=>user('buyer','buyer-payout',async()=>payoutClaims(await publicState(config),{userId:B,markets:[m],tokenAbi:h.token,nftAbi:h.nft}))
 ]);
 const after=await cohortAssets(await publicState(config),spec);save(join(round,'public/assets-after.json'),after);
 for(const id of spec.assets)assert.equal(after.totals[id],before.totals[id]);
 for(const [id,row]of Object.entries(before.accounts))for(const asset of spec.assets){const delta=id===String(U)?(asset===2483?-unit:unit):id===String(B)?(asset===2483?unit:-unit):0n;assert.equal(after.accounts[id].ft[asset]-row.ft[asset],delta,'actual owner/vault FT delta');}
 const terminal=await m.snapshot('terminal');assert.equal(terminal.fields.queue_phase[0],3n);assert.equal(terminal.fields.queue_count[0],2n);assert.deepEqual(terminal.fields.queue_outcome.slice(0,2),[1n,1n]);
 for(const owner of [U,B])assert.equal(await h.at(await publicState(config),m,m.vault,'consumed',owner),nonceU);
 await f.journal.reconcile(f.adapter.reconcile);assert.equal((await f.journal.unresolved()).length,0);
 save(join(base,'public',selection+'-COMPLETE.json'),{at:new Date().toISOString(),selection,fills:1,members:2,ordinaryClaimsIncluded:true,fullProofAccountingPending:true,assets:spec,ftConserved:true,oldContractUpdates:false,scope:'one real new Book epoch on the same owned QA market/key/vault and economic workload; not a four-market or steady-state TPS benchmark'});
} finally { await f?.close();await h.residentScope.close();for(const worker of workers.values())await worker.close(); }
