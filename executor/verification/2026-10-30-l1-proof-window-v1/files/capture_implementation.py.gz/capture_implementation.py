import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
previous=C.parent/'runtime-resource-acquisition-20261030-v1'
s=json.loads((previous/'public/l1-state-manager-observation.json').read_bytes())
url='https://rpc-eth-stg.psy-protocol.xyz'
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json'
 with rp.open('x')as f:json.dump(req,f)
 rp.chmod(0o600);out=C/'quarantine'/f'{label}.body';assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes()if out.exists()else b''
 if out.exists():out.chmod(0o600)
 r={'schema':1,'url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'elapsedSeconds':time.monotonic()-start,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalityVerified':False,'canBroadcast':False}
 with(C/'public'/f'{label}-transport.json').open('x')as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'result'not in v or 'error'in v:
  with(C/'public'/f'{label}-error.json').open('x')as f:json.dump({'schema':1,'error':v.get('error'),'finalityVerified':False},f,indent=2);f.write('\n')
  raise RuntimeError('RPC rejected; no retry')
 return v['result']


statement=json.loads((C/'public/prospective-statement.json').read_bytes())
fixed={'blockHash':statement['blockHash'],'requireCanonical':True}
implementation='0xd1ca5e95e2b58461343f9d55c61fbb4b6662fb04'
code=call('prospective-implementation-code','eth_getCode',[implementation,fixed])
proof=call('prospective-implementation-proof','eth_getProof',[implementation,['0x0'],fixed])
with(C/'public/implementation-statement.json').open('x')as f:
 statement.update(address=implementation,slots=['0x0']);json.dump(statement,f,indent=2);f.write('\n')
with(C/'public/implementation-proof-projection.json').open('x')as f:json.dump({'schema':1,'proof':{k:proof[k]for k in ['address','accountProof','balance','codeHash','nonce','storageHash','storageProof']}},f,indent=2);f.write('\n')
with(C/'public/implementation-code-projection.json').open('x')as f:json.dump({'schema':1,'blockHash':statement['blockHash'],'address':implementation,'code':code},f,indent=2);f.write('\n')
