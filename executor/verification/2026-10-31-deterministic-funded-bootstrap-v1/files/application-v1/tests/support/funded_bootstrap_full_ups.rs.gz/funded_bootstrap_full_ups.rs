//! New deterministic key/bytecode. Synthetic checkpoint actor prerequisites only.
use super::*;
const OWNER:u64=600;
const CAP:u64=100_000_000_000;
fn registered(chain:&StreamChain)->[u64;4]{
    PoseidonHash::two_to_one(chain.key.g.get_fingerprint().0,chain.source.key_public_param.0)
        .elements.map(|n|n.to_canonical_u64())
}
fn fund(w:&mut World,key:[u64;4])->Result<()> {
    ensure!(!w.slots.keys().any(|(u,_,_)|*u==V)&&w.revision==0,"empty vault");
    w.set(OWNER,0,0,CAP+ESCROW);
    w.run(OWNER,M,"authorize_fee_budget",&[vec![V,1,CAP],key.to_vec()].concat())?;
    w.run(OWNER,0,"transfer",&[V,CAP])?;
    w.fee(I)?;w.pay(I,A,1)?;w.pay(I,B,1)?;Ok(())
}
fn request(page:&SourcePage,w:&World,key:[u64;4])->Request {
    let mut req=basic(14,page,w);req.registered_key=Some(key);
    req.fields[21]=1;req.fields[22]=CAP;req.fields[23]=1;req.fields[24]=I;req
}

#[test]
fn deterministic_bootstrap_atomic_seed_grant_and_cap_rollback()->Result<()> {
    for kind in ["amm","bondingcurve"] {
        let mut w=World::new_fixture(kind,false,false)?;let spec=read_spec(kind)?;
        ensure!(spec["version"]==14,"new deterministic funded profile only");
        let key=[11,22,33,44];fund(&mut w,key)?;
        let page=SourcePage{scope:vec![0;41],facts:vec![[0;4];5],before:Progress::empty(),after:Progress::empty(),rows:vec![]};
        let req=request(&page,&w,key);
        for mutation in ["nonce","cap","key","payer"] {
            let mut bad=req.clone();match mutation {
                "nonce"=>bad.fields[21]+=1,"cap"=>bad.fields[22]+=1,
                "key"=>bad.registered_key.as_mut().unwrap()[0]+=1,_=>bad.fields[24]=OWNER,
            }
            let before=w.slots.clone();ensure!(execute(&mut w,&spec,&bad).is_err()&&w.slots==before,"invalid bootstrap rollback");
        }
        for asset in [0,A,B] {
            let mut excess=w.clone();if asset==0{excess.run(I,0,"transfer",&[V,1])?;}else{excess.pay(I,asset,1)?;}
            let before=excess.slots.clone();ensure!(execute(&mut excess,&spec,&req).is_err()&&excess.slots==before,"exact seed rollback");
        }
        let exact=minimum_exact_fee(&w,&spec,req)?;execute(&mut w,&spec,&exact)?;
        ensure!(w.val(V,"batch_ready",0)==1&&w.balance(V,A)==0&&w.balance(V,B)==0,"returned exact FT seeds");
        let before=w.slots.clone();ensure!(execute(&mut w,&spec,&exact).is_err()&&w.slots==before,"bootstrap cannot replay");
        ensure!(w.state.get_contract_slot(V,0,0)?+w.val(V,"fee_used",0)==CAP+ESCROW,"native conservation");
    }Ok(())
}

#[tokio::test]
#[ignore="bounded deterministic bootstrap full UPSs; fresh output only"]
async fn deterministic_fresh_vault_bootstrap_complete_ups()->Result<()> {
    let out=std::env::var("FUNDED_BOOTSTRAP_OUT")?;fs::create_dir(&out)?;
    for kind in ["amm","bondingcurve"] {
        let mut w=World::new_fixture(kind,false,false)?;
        let mut chain=StreamChain::new_with_maintenance(&w,true).await?;
        ensure!(chain.spec["version"]==14,"new deterministic profile");
        let key=registered(&chain);fund(&mut w,key)?;
        let(_,page)=SourcePage::inactive_maintenance(&chain.review,&chain.source)?;
        let req=request(&page,&w,key);
        chain.prove(&mut w,req,&out,"fresh-bootstrap").await?;
        ensure!(w.revision==1&&w.val(V,"batch_ready",0)==1&&w.val(V,"fee_cap",0)==CAP&&w.val(V,"fee_used",0)>0,"registered first-use endpoints");
        ensure!(w.balance(V,A)==0&&w.balance(V,B)==0,"seeds returned before treasury claim");
        if kind=="bondingcurve" {
            w.fee(I)?;w.pay(I,A,2_000_000*10u128.pow(18))?;
            let mut req=basic(4,&page,&w);req.registered_key=Some(key);
            req.fields[21..34].copy_from_slice(&w.fields("initialize",0,0,0,0,0,0,0,0));
            chain.prove(&mut w,req,&out,"deterministic-curve-initialize").await?;
            ensure!(w.val(V,"phase",0)==1,"actual curve initialization");
        }else{
            let used=w.val(V,"fee_used",0);
            w.run(OWNER,M,"authorize_fee_budget",&[vec![V,2,CAP+ESCROW],key.to_vec()].concat())?;
            let mut req=basic(13,&page,&w);req.registered_key=Some(key);req.fields[21]=2;req.fields[22]=CAP+ESCROW;
            chain.prove(&mut w,req,&out,"deterministic-fee-grant").await?;
            ensure!(w.val(V,"fee_grant_seen",0)==2&&w.val(V,"fee_used",0)>used,"fresh grant never resets fee use");
        }
        ensure!(w.state.get_contract_slot(V,0,0)?+w.val(V,"fee_used",0)==CAP+ESCROW+(if kind=="bondingcurve"{ESCROW}else{0}),"complete native fee conservation");
        fs::write(format!("{out}/{kind}-REPORT.json"),serde_json::to_vec_pretty(&json!({
            "profile":chain.spec["profile"],"emptyVaultAtStart":true,"fullUpsVerified":true,
            "registrationPathVerified":true,"randomMode":false,"seedSourceUsed":false,
            "measurements":chain.measurements,"keyFingerprint":chain.key.g.get_fingerprint(),
            "feeUsed":w.val(V,"fee_used",0),"grantSeen":w.val(V,"fee_grant_seen",0),
            "ordinaryActors":"VM prerequisites, not signed ordinary UPS or network receipts",
            "normalWalletClaims":false,"liveAcceptance":false,"financialOperations":0,
            "scope":"Actual bytecode, key and complete UPS on synthetic checkpoints; no network/finality/production claim"
        }))?)?;
    }Ok(())
}
