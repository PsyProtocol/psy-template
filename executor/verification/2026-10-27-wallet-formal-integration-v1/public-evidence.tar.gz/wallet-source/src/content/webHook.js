// This file runs as a classic MAIN-world content script. Always publish the
// vendored lossless-json API on the page global: Rollup wraps this entry in a
// CommonJS-shaped closure, so the library's stock UMD probe mistakes the
// bundle for CommonJS and writes into a private `exports` object. PsyJSON then
// sees no LosslessJSON binding and every dApp request fails before reaching
// the service worker.
!(function (t, e) {
  e(
    ((t =
      "undefined" != typeof globalThis ? globalThis : t || self).LosslessJSON =
      {}),
  );
})(this, function (t) {
  "use strict";
  function e(t) {
    return r.test(t);
  }
  const r = /^-?[0-9]+$/;
  function n(t) {
    return o.test(t);
  }
  const o = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/;
  function i(t, r) {
    const n = parseFloat(t),
      o = String(n),
      i = a(t),
      c = a(o);
    if (i === c) return !0;
    if (!0 === r?.approx) {
      const r = 14;
      if (!e(t) && c.length >= r && i.startsWith(c.substring(0, r))) return !0;
    }
    return !1;
  }
  let c = (function (t) {
    return (
      (t.underflow = "underflow"),
      (t.overflow = "overflow"),
      (t.truncate_integer = "truncate_integer"),
      (t.truncate_float = "truncate_float"),
      t
    );
  })({});
  function u(t) {
    if (i(t, { approx: !1 })) return;
    if (e(t)) return c.truncate_integer;
    const r = parseFloat(t);
    return isFinite(r)
      ? 0 === r
        ? c.underflow
        : c.truncate_float
      : c.overflow;
  }
  function a(t) {
    return t.replace(f, "").replace(l, "").replace(d, "").replace(s, "");
  }
  const f = /[eE][+-]?\d+$/,
    s = /^-?(0*)?/,
    l = /\./,
    d = /0+$/;
  class h {
    isLosslessNumber = !0;
    constructor(t) {
      if (!n(t)) throw new Error('Invalid number (value: "' + t + '")');
      this.value = t;
    }
    valueOf() {
      const t = u(this.value);
      if (void 0 === t || t === c.truncate_float) return parseFloat(this.value);
      if (e(this.value)) return BigInt(this.value);
      throw new Error(
        `Cannot safely convert to number: the value '${this.value}' would ${t} and become ${parseFloat(this.value)}`,
      );
    }
    toString() {
      return this.value;
    }
  }
  function p(t) {
    return (t && "object" == typeof t && !0 === t.isLosslessNumber) || !1;
  }
  function y(t) {
    return new h(t);
  }
  function w(t, e, r, n) {
    return Array.isArray(r)
      ? n.call(
          t,
          e,
          (function (t, e) {
            for (let r = 0; r < t.length; r++) t[r] = w(t, r + "", t[r], e);
            return t;
          })(r, n),
        )
      : r && "object" == typeof r && !p(r)
        ? n.call(
            t,
            e,
            (function (t, e) {
              return (
                Object.keys(t).forEach((r) => {
                  const n = w(t, r, t[r], e);
                  void 0 !== n ? (t[r] = n) : delete t[r];
                }),
                t
              );
            })(r, n),
          )
        : n.call(t, e, r);
  }
  function b(t) {
    return (t >= J && t <= B) || (t >= Q && t <= Z) || (t >= U && t <= q);
  }
  function g(t) {
    return t >= J && t <= B;
  }
  function v(t, e) {
    if (t === e) return !0;
    if (Array.isArray(t) && Array.isArray(e))
      return t.length === e.length && t.every((t, r) => v(t, e[r]));
    if (A(t) && A(e)) {
      return [...new Set([...Object.keys(t), ...Object.keys(e)])].every((r) =>
        v(t[r], e[r]),
      );
    }
    return !1;
  }
  function A(t) {
    return "object" == typeof t && null !== t;
  }
  const m = {
      '"': '"',
      "\\": "\\",
      "/": "/",
      b: "\b",
      f: "\f",
      n: "\n",
      r: "\r",
      t: "\t",
    },
    C = 92,
    $ = 123,
    S = 125,
    x = 91,
    E = 93,
    N = 32,
    O = 10,
    I = 9,
    j = 13,
    k = 34,
    _ = 43,
    F = 45,
    J = 48,
    L = 49,
    B = 57,
    D = 44,
    T = 46,
    R = 58,
    Q = 65,
    U = 97,
    P = 69,
    W = 101,
    Z = 70,
    q = 102;
  const z = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
  (t.LosslessNumber = h),
    (t.UnsafeNumberReason = c),
    (t.config = function (t) {
      throw new Error(
        "config is deprecated, support for circularRefs is removed from the library. If you encounter circular references in your data structures, please rethink your datastructures: better prevent circular references in the first place.",
      );
    }),
    (t.getUnsafeNumberReason = u),
    (t.isInteger = e),
    (t.isLosslessNumber = p),
    (t.isNumber = n),
    (t.isSafeNumber = i),
    (t.parse = function (t, e) {
      let r =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : y,
        n = 0;
      const o = u();
      return (
        (function (t) {
          if (void 0 === t) throw new SyntaxError(`JSON value expected ${H()}`);
        })(o),
        (function () {
          if (n < t.length)
            throw new SyntaxError(`Expected end of input ${H()}`);
        })(),
        e
          ? (function (t, e) {
              return w({ "": t }, "", t, e);
            })(o, e)
          : o
      );
      function i() {
        if (t.charCodeAt(n) === $) {
          n++, f();
          const e = {};
          let r = !0;
          for (; n < t.length && t.charCodeAt(n) !== S; ) {
            r ? (r = !1) : (l(), f());
            const t = n,
              o = s();
            if (void 0 === o) return void A();
            f(), d();
            const i = u();
            if (void 0 === i) return void q();
            Object.prototype.hasOwnProperty.call(e, o) &&
              !v(i, e[o]) &&
              Q(o, t + 1),
              (e[o] = i);
          }
          return (
            t.charCodeAt(n) !== S &&
              (function () {
                throw new SyntaxError(
                  `Quoted object key or end of object '}' expected ${H()}`,
                );
              })(),
            n++,
            e
          );
        }
      }
      function c() {
        if (t.charCodeAt(n) === x) {
          n++, f();
          const e = [];
          let r = !0;
          for (; n < t.length && t.charCodeAt(n) !== E; ) {
            r ? (r = !1) : l();
            const t = u();
            h(t), e.push(t);
          }
          return (
            t.charCodeAt(n) !== E &&
              (function () {
                throw new SyntaxError(
                  `Array item or end of array ']' expected ${H()}`,
                );
              })(),
            n++,
            e
          );
        }
      }
      function u() {
        f();
        const e =
          s() ??
          (function () {
            const e = n;
            t.charCodeAt(n) === F && (n++, p(e));
            if (t.charCodeAt(n) === J) n++;
            else if (((o = t.charCodeAt(n)), o >= L && o <= B))
              for (n++; g(t.charCodeAt(n)); ) n++;
            var o;
            if (t.charCodeAt(n) === T)
              for (n++, p(e); g(t.charCodeAt(n)); ) n++;
            if (t.charCodeAt(n) === W || t.charCodeAt(n) === P)
              for (
                n++,
                  (t.charCodeAt(n) !== F && t.charCodeAt(n) !== _) || n++,
                  p(e);
                g(t.charCodeAt(n));
              )
                n++;
            if (n > e) return r(t.slice(e, n));
          })() ??
          i() ??
          c() ??
          a("true", !0) ??
          a("false", !1) ??
          a("null", null);
        return f(), e;
      }
      function a(e, r) {
        if (t.slice(n, n + e.length) === e) return (n += e.length), r;
      }
      function f() {
        for (; (e = t.charCodeAt(n)) === N || e === O || e === I || e === j; )
          n++;
        var e;
      }
      function s() {
        if (t.charCodeAt(n) === k) {
          n++;
          let r = "";
          for (; n < t.length && t.charCodeAt(n) !== k; ) {
            if (t.charCodeAt(n) === C) {
              const e = t[n + 1],
                o = m[e];
              void 0 !== o
                ? ((r += o), n++)
                : "u" === e
                  ? b(t.charCodeAt(n + 2)) &&
                    b(t.charCodeAt(n + 3)) &&
                    b(t.charCodeAt(n + 4)) &&
                    b(t.charCodeAt(n + 5))
                    ? ((r += String.fromCharCode(
                        parseInt(t.slice(n + 2, n + 6), 16),
                      )),
                      (n += 5))
                    : z(n)
                  : Z(n);
            } else
              (e = t.charCodeAt(n)) >= 32 && e <= 1114111
                ? (r += t[n])
                : U(t[n]);
            n++;
          }
          return (
            (function () {
              if (t.charCodeAt(n) !== k)
                throw new SyntaxError(`End of string '"' expected ${H()}`);
            })(),
            n++,
            r
          );
        }
        var e;
      }
      function l() {
        if (t.charCodeAt(n) !== D)
          throw new SyntaxError(`Comma ',' expected after value ${H()}`);
        n++;
      }
      function d() {
        if (t.charCodeAt(n) !== R)
          throw new SyntaxError(
            `Colon ':' expected after property name ${H()}`,
          );
        n++;
      }
      function h(t) {
        if (void 0 === t) throw new SyntaxError(`Array item expected ${H()}`);
      }
      function p(e) {
        if (!g(t.charCodeAt(n))) {
          const r = t.slice(e, n);
          throw new SyntaxError(
            `Invalid number '${r}', expecting a digit ${H()}`,
          );
        }
      }
      function A() {
        throw new SyntaxError(`Quoted object key expected ${H()}`);
      }
      function Q(t, e) {
        throw new SyntaxError(
          `Duplicate key '${t}' encountered at position ${e}`,
        );
      }
      function U(t) {
        throw new SyntaxError(`Invalid character '${t}' ${G()}`);
      }
      function Z(e) {
        const r = t.slice(e, e + 2);
        throw new SyntaxError(`Invalid escape character '${r}' ${G()}`);
      }
      function q() {
        throw new SyntaxError(`Object value expected after ':' ${G()}`);
      }
      function z(e) {
        const r = t.slice(e, e + 6);
        throw new SyntaxError(`Invalid unicode character '${r}' ${G()}`);
      }
      function G() {
        return `at position ${n}`;
      }
      function H() {
        return (
          (n < t.length ? `but got '${t[n]}'` : "but reached end of input") +
          " " +
          G()
        );
      }
    }),
    (t.parseLosslessNumber = y),
    (t.parseNumberAndBigInt = function (t) {
      return e(t) ? BigInt(t) : parseFloat(t);
    }),
    (t.reviveDate = function (t, e) {
      return "string" == typeof e && z.test(e) ? new Date(e) : e;
    }),
    (t.stringify = function t(e, r, o, i) {
      const c = (function (t) {
        if ("number" == typeof t) return " ".repeat(t);
        if ("string" == typeof t && "" !== t) return t;
        return;
      })(o);
      return u("function" == typeof r ? r.call({ "": e }, "", e) : e, "");
      function u(e, a) {
        if (Array.isArray(i)) {
          const t = i.find((t) => t.test(e));
          if (t) {
            const r = t.stringify(e);
            if ("string" != typeof r || !n(r))
              throw new Error(
                `Invalid JSON number: output of a number stringifier must be a string containing a JSON number (output: ${r})`,
              );
            return r;
          }
        }
        return "boolean" == typeof e ||
          "number" == typeof e ||
          "string" == typeof e ||
          null === e ||
          e instanceof Date ||
          e instanceof Boolean ||
          e instanceof Number ||
          e instanceof String
          ? JSON.stringify(e)
          : (e && e.isLosslessNumber) || "bigint" == typeof e
            ? e.toString()
            : Array.isArray(e)
              ? (function (t, e) {
                  if (0 === t.length) return "[]";
                  const n = c ? e + c : void 0;
                  let o = c ? "[\n" : "[";
                  for (let e = 0; e < t.length; e++) {
                    const i =
                      "function" == typeof r
                        ? r.call(t, String(e), t[e])
                        : t[e];
                    c && (o += n),
                      (o +=
                        void 0 !== i && "function" != typeof i
                          ? u(i, n)
                          : "null"),
                      e < t.length - 1 && (o += c ? ",\n" : ",");
                  }
                  return (o += c ? "\n" + e + "]" : "]"), o;
                })(e, a)
              : e && "object" == typeof e
                ? (function (e, n) {
                    if ("function" == typeof e.toJSON)
                      return t(e.toJSON(), r, o, void 0);
                    const i = Array.isArray(r) ? r.map(String) : Object.keys(e);
                    if (0 === i.length) return "{}";
                    const a = c ? n + c : void 0;
                    let f = !0,
                      s = c ? "{\n" : "{";
                    return (
                      i.forEach((t) => {
                        const n =
                          "function" == typeof r ? r.call(e, t, e[t]) : e[t];
                        if (
                          (function (t, e) {
                            return (
                              void 0 !== e &&
                              "function" != typeof e &&
                              "symbol" != typeof e
                            );
                          })(0, n)
                        ) {
                          f ? (f = !1) : (s += c ? ",\n" : ",");
                          const e = JSON.stringify(t);
                          (s += c ? a + e + ": " : e + ":"), (s += u(n, a));
                        }
                      }),
                      (s += c ? "\n" + n + "}" : "}"),
                      s
                    );
                  })(e, a)
                : void 0;
      }
    }),
    (t.toLosslessNumber = function (t) {
      if (a(t + "").length > 15)
        throw new Error(
          `Invalid number: contains more than 15 digits and is most likely truncated and unsafe by itself (value: ${t})`,
        );
      if (isNaN(t)) throw new Error("Invalid number: NaN");
      if (!isFinite(t)) throw new Error("Invalid number: " + t);
      return new h(String(t));
    }),
    (t.toSafeNumberOrThrow = function (t, e) {
      const r = parseFloat(t),
        n = u(t);
      if (!0 === e?.approx ? n && n !== c.truncate_float : n) {
        const e = n?.replace(/_\w+$/, "");
        throw new Error(
          `Cannot safely convert to number: the value '${t}' would ${e} and become ${r}`,
        );
      }
      return r;
    });
});

(function () {
  const losslessJson = globalThis.LosslessJSON;
  if (!losslessJson) {
    throw new Error("Psy Wallet JSON codec failed to initialize");
  }

  if (window.psy?.isPsy) {
    window.dispatchEvent(new Event("psy#initialized"));
    console.log("Psy Wallet already initialized.");
    return;
  }

  // PsyJSON
  const MAX_SAFE_INT = BigInt("9007199254740991");
  // parse integer values into a bigint, and use a regular number otherwise
  function customNumberParser(value) {
    return losslessJson.isInteger(value) && BigInt(value) > MAX_SAFE_INT
      ? BigInt(value)
      : parseFloat(value);
  }

  function parseBigIntJson(jsonString) {
    return losslessJson.parse(jsonString, null, customNumberParser);
  }

  function stringifyBigIntJSON(json, spaces = 0) {
    return (
      losslessJson.stringify(json, null, spaces, [
        {
          test: (x) => typeof x === "bigint",
          stringify: (x) => x.toString(),
        },
      ]) || ""
    );
  }

  const PsyJSON = Object.freeze({
    parse: parseBigIntJson,
    stringify: stringifyBigIntJSON,
  });

  function parseWalletResult(result) {
    if (typeof result !== "string") return result;

    const trimmed = result.trim();
    const looksLikeJson =
      trimmed === "null" ||
      trimmed === "true" ||
      trimmed === "false" ||
      trimmed.startsWith("{") ||
      trimmed.startsWith("[") ||
      trimmed.startsWith('"') ||
      /^-?\d/.test(trimmed);

    if (!looksLikeJson) return result;

    try {
      return PsyJSON.parse(result);
    } catch (e) {
      console.warn("Wallet returned a non-JSON string result:", result, e);
      return result;
    }
  }

  // hooks
  const validActions = [
    "psy_getMarketWriteCapabilities",
    "psy_prepareMarketTransaction",
    "psy_verifyMarketPreparation",
    "psy_broadcastMarketPreparation",
    "psy_reconcileMarketPreparation",
    "psy_listMarketPreparations",
    "psy_cancelMarketPreparation",
    "psy_requestAccounts",
    "psy_requestPermissions",
    "psy_accounts",
    "psy_getPermissions",
    "psy_sendTransaction",
    "psy_deployContract",
    "psy_listShieldReceiveAddresses",
    "psy_resolveShieldReceiveAddress",
    "psy_deriveShieldAddress",
    "psy_getNetworkConfig",
    "psy_getWalletBuildInfo",
    "psy_getUserId",
    "psy_simulateContractCall",
    "psy_getClaimRewardsCallArgs",
    "psy_decryptNostrContent",
    // Wallet-internal Nostr actions are intentionally not advertised to web
    // pages; receive discovery is services-only and protocol sends use ext-core.
    // Failing fast client-side gives dApps a clear method-not-available error.
    // Read-only claimables remain available through psy_listClaimables below.
    "psy_listClaimables",
    "psy_addExternalProof",
    "psy_completeFaucetTurnstile",
    "psy_closeFaucetVerificationTab",
    "psy_claimWithExternalProof",
    "psy_claimShieldDeposit",
    "psy_provePrivateNoteInclusion",
    "psy_proveDepositInclusion",
    // Unified UPS surfaces — heterogeneous ClaimBatchItem[] folded into one
    // recursive proof. The approval path is handled by approve-manager.
    "psy_execClaimBatch",
    "psy_execClaimBatchAndPrivateTransfer",
  ];

  class PsyProvider {
    constructor() {
      this.isPsy = true;
      this._contentLoaded = false;
      this._contentLoadedWaiters = [];
      this._events = new Map();
      this._requestListeners = new Map();
      this._accounts = [];
      this._initMessageListener();
    }

    // Resolves the moment the content script has signalled "content-loaded".
    //
    // The previous version polled `this._contentLoaded` every 100 ms AND
    // never `clearInterval`'d on resolve, which had two costs on the dApp
    // connect path: (a) ~50 ms of avg added latency to every request() call
    // even when content-loaded was already true (early-resolve fell through
    // and still scheduled the interval, which a downstream `setInterval`
    // tick had to clear), and (b) a leaked 100 ms timer per request() call
    // for the full 30 s budget, piling up on chatty pages. The
    // content-loaded signal is already event-driven (content/main.js
    // postMessages it; _initMessageListener flips _contentLoaded) — we just
    // queue waiters and the listener drains them synchronously when the
    // signal lands. 30 s safety timeout preserved.
    waitContentLoaded() {
      if (this._contentLoaded) return Promise.resolve();
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const idx = this._contentLoadedWaiters.indexOf(entry);
          if (idx !== -1) this._contentLoadedWaiters.splice(idx, 1);
          reject(new Error("Wait Content Load Timeout"));
        }, 30000);
        const entry = {
          resolve: () => {
            clearTimeout(timer);
            resolve();
          },
        };
        this._contentLoadedWaiters.push(entry);
      });
    }

    // Initialize message monitoring (receive background responses forwarded by content scripts)
    _initMessageListener() {
      window.addEventListener("message", (event) => {
        if (
          event.source !== window ||
          !event.data?.isPsy ||
          this !== window.psy
        )
          return;
        const { type, data: nestedData, source } = event.data;
        console.log("webHook onMessage:", event.data);
        if (source !== "psy-contentscript") {
          return;
        }

        if (type === "content-loaded") {
          console.log("webhook content loaded");
          this._contentLoaded = true;
          // Drain any in-flight waiters (the dApp's first request() call
          // racing the content-loaded signal). Snapshot + clear before
          // resolving — resolving a waiter can synchronously schedule a
          // new request that arrives here while we're still iterating.
          const waiters = this._contentLoadedWaiters;
          this._contentLoadedWaiters = [];
          for (const w of waiters) w.resolve();
          return;
        }

        if (type === "accountsChanged" && nestedData?.accounts) {
          this._accounts = nestedData.accounts;
          this._emit("accountsChanged", nestedData.accounts);
        }

        if (type !== "messageFromWallet") {
          return;
        }
        if (!nestedData) {
          console.log("WebHook received message from wallet: empty data");
          return;
        }

        console.log("WebHook received message from wallet:", event.data);

        const { id, result, error } = nestedData || {};

        if (id && this._requestListeners.has(id)) {
          const { resolve, reject } = this._requestListeners.get(id);
          this._requestListeners.delete(id);

          if (error) {
            reject(new Error(error.message || error));
          } else {
            console.log("onRecieve", { result });
            resolve(parseWalletResult(result));
          }
          return;
        }
      });
    }

    // Send a message to the content script (relay to the background)
    _sendMessage(action, params, id) {
      if (!window.psy) {
        console.error("Psy wallet is not initialized");
        return false;
      } else if (window.psy !== this) return false;

      try {
        window.postMessage(
          {
            isPsy: true,
            action,
            params: PsyJSON.stringify(params),
            id,
          },
          "*",
        );
        return true;
      } catch (error) {
        console.error("Failed to send message:", error);
        return false;
      }
    }

    _generateId() {
      return `psy_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    }

    // EIP-1193 action: handling DApp requests(login, signature, etc.)
    async request({ method, params }) {
      await this.waitContentLoaded();
      return new Promise((resolve, reject) => {
        /** @type {Array<import("../types").ApproveMsgParams['action']>} */
        if (!validActions.includes(method)) {
          reject(new Error(`Unsupported method: ${method}`));
          return;
        }

        const id = this._generateId();

        // Per-method timeout budget. Plonky2 recursive proofs scale roughly
        // linearly with the number of items folded into a single batch —
        // each claim_deposit / claim_with_external_proof adds ~30-90s of
        // proving on consumer hardware. A 7-item batch (6 deposits + a
        // transfer) regularly pushes past the old 10-minute hard cap and
        // would surface to the dApp as "Request timed out: ..." even though
        // the wallet was still actively proving. We give the batched UPS
        // surfaces room for that — wallet UI keeps the user informed via
        // the approve popup's progress, so a long ceiling is safe.
        const METHOD_TIMEOUT_MS = {
          psy_execClaimBatch: 60 * 60_000,
          psy_execClaimBatchAndPrivateTransfer: 60 * 60_000,
          psy_claimWithExternalProof: 30 * 60_000,
          psy_claimShieldDeposit: 30 * 60_000,
          psy_provePrivateNoteInclusion: 30 * 60_000,
          psy_proveDepositInclusion: 30 * 60_000,
          psy_sendTransaction: 30 * 60_000,
        };
        const timeoutMs = METHOD_TIMEOUT_MS[method] ?? 600_000;
        const timeoutId = setTimeout(() => {
          if (this._requestListeners.has(id)) {
            const error = new Error(
              `Request timed out after ${Math.round(timeoutMs / 60_000)}m: ${method}`,
            );
            const listener = this._requestListeners.get(id);
            this._requestListeners.delete(id);
            listener?.reject(error);
          }
        }, timeoutMs);

        this._requestListeners.set(id, {
          resolve: (value) => {
            clearTimeout(timeoutId);
            resolve(value);
          },
          reject: (error) => {
            clearTimeout(timeoutId);
            reject(error);
          },
        });

        const success = this._sendMessage(method, params, id);
        if (!success) {
          clearTimeout(timeoutId);
          this._requestListeners.delete(id);
          reject(new Error("Failed to send request to wallet"));
        }
      });
    }

    async requestAccounts() {
      try {
        // Always query the wallet state here. Returning cached accounts would
        // make dapps see stale accounts after the user switches wallets.
        console.log("Requesting walletAddress from wallet...");

        const result = await this.request({
          method: "psy_requestAccounts",
          params: [
            location.origin,
            document.head.querySelector('[rel="icon"]')?.href,
          ],
        });

        console.log("Received walletAddress from wallet:", result);
        this._accounts = result || [];
        return this._accounts;
      } catch (error) {
        console.error("Error requesting walletAddress:", error);
        throw error;
      }
    }

    async requestPermissions() {
      try {
        return await this.request({
          method: "psy_requestPermissions",
          params: [
            location.origin,
            document.head.querySelector('[rel="icon"]')?.href,
          ],
        });
      } catch (error) {
        console.error("Error requesting account permissions:", error);
        throw error;
      }
    }

    async accounts() {
      try {
        const result = await this.request({
          method: "psy_accounts",
          params: [],
        });

        this._accounts = result || [];
        return this._accounts;
      } catch (error) {
        console.error("Error requesting connected accounts:", error);
        throw error;
      }
    }

    async getPermissions() {
      try {
        return await this.request({
          method: "psy_getPermissions",
          params: [],
        });
      } catch (error) {
        console.error("Error requesting account permissions:", error);
        throw error;
      }
    }

    async getWalletBuildInfo() {
      try {
        return await this.request({
          method: "psy_getWalletBuildInfo",
          params: [],
        });
      } catch (error) {
        console.error("Error requesting wallet build info:", error);
        throw error;
      }
    }

    async psy_listShieldReceiveAddresses(accountAddress) {
      return await this.request({
        method: "psy_listShieldReceiveAddresses",
        params: [accountAddress],
      });
    }

    async psy_deriveShieldAddress(accountAddress, label) {
      return await this.request({
        method: "psy_deriveShieldAddress",
        params: [accountAddress, label],
      });
    }

    async sendTransaction(accountAddress, callArgs) {
      if (!accountAddress) {
        throw new Error("Wallet address is required");
      }
      if (!callArgs || typeof callArgs !== "object") {
        throw new Error("Invalid call arguments. Expected an object.");
      }

      try {
        const result = await this.request({
          method: "psy_sendTransaction",
          params: [accountAddress, callArgs],
        });

        console.log("Received signature from wallet:", result);

        return result || null;
      } catch (error) {
        console.error("Error during signing:", error);
        throw error;
      }
    }

    on(event, listener) {
      if (typeof listener !== "function") {
        console.error("Listener must be a function");
        return;
      }
      if (!this._events.has(event)) {
        this._events.set(event, new Set());
      }
      this._events.get(event).add(listener);
    }

    removeListener(event, listener) {
      if (typeof listener !== "function") {
        console.error("Listener must be a function");
        return;
      }
      this._events.get(event)?.delete(listener);
    }

    _emit(event, data) {
      if (!this._events.has(event)) return;
      const listeners = new Set(this._events.get(event));
      listeners.forEach((listener) => {
        try {
          listener(data);
        } catch (error) {
          console.error(`Error in ${event} listener:`, error);
        }
      });
    }
  }

  // Injected into window.psy
  window.psy = new PsyProvider();
  window.dispatchEvent(new Event("psy#initialized"));
  console.log("Psy Wallet initialized.");
})();
