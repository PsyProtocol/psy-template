import {readFile,writeFile}from'node:fs/promises';
import {createPrepareOnlyMarketService}from'../../psy-wallet-private-ft-20261015/src/market-preparation/market-client/wallet/prepareService.mjs';
const bundle=JSON.parse(await readFile(new URL('../../psy-wallet-private-ft-20261015/src/market-preparation/bundle.json',import.meta.url),'utf8'));
let proofCalls=0,writes=0;const service=createPrepareOnlyMarketService({bundle,store:{get:async()=>undefined,set:async()=>{writes++;}},provider:{},prepareTrace:async()=>{proofCalls++;throw Error('forbidden');},parse:JSON.parse,stringify:JSON.stringify});
let rejection;try{await service.assertChain();throw Error('Expected old-chain rejection');}catch(e){rejection=String(e.message);if(!rejection.includes('Reviewed chain instance changed'))throw e;}
await writeFile(new URL('./public/wallet-old-chain-rejection-v1.json',import.meta.url),JSON.stringify({at:new Date().toISOString(),scope:'vendored wallet module against real RPC; not extension/browser acceptance',rejection,proofCalls,writes,financialOperations:0},null,2)+'\n',{flag:'wx'});
