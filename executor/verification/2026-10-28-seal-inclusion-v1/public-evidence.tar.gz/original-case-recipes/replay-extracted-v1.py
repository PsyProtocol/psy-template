"""Read-only replay from an extracted public case; binaries must be caller-trusted."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
assert len(sys.argv)==5,'EXTRACTED_ROOT TRUSTED_NATIVE_VERIFIER TRUSTED_COMPONENT_VERIFIER FRESH_OUTPUT_DIRECTORY'
root,native,component,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
out.mkdir()
f=root/'component-proof-v1'
cp=json.loads((f/'REPORT.json').read_text())['checkpointRoot']
env=dict(os.environ,RAYON_NUM_THREADS='2',PSY_NETWORK='testnet')
rows=[]
for name,tool,args,claim in [
 ('native',native,[str(f/'statement.json'),str(f/'layout.json'),cp,str(f/'opening.json')],'sealMembershipVerified'),
 ('component',component,[str(f/'statement.json'),str(f/'layout.json'),cp,'105',str(f/'proof.bin')],'membershipComponentProofVerified')]:
 report=out/(name+'.json')
 result=subprocess.run([str(tool),*args,str(report)],env=env,capture_output=True,timeout=20)
 (out/(name+'.log')).write_bytes(result.stdout+result.stderr)
 assert result.returncode==0,(name,result.returncode)
 value=json.loads(report.read_text())
 assert value[claim] and not any(value[k]for k in ['finalityVerified','beaconUnpredictabilityVerified','randomAuthorization','fullUpsVerified','broadcast'])
 assert value['financialOperations']==0
 rows.append({'kind':name,'toolSha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest()})
with (out/'REPORT.json').open('x')as f:json.dump({'schema':1,'exactPreservedInputsVerified':True,'proofsGenerated':0,'financialOperations':0,'randomAuthorization':False,'checks':rows},f,indent=2);f.write('\n')
print('Preserved native opening and membership proof verified; no new proof, RPC or finance.')
