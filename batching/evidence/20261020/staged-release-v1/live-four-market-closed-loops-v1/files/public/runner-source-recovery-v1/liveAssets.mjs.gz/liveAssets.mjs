import assert from 'node:assert/strict';
import {decodeAmount,call} from '../../amm/u124/client.mjs';
export async function cohortAssets(s,{users,assets,nftId}){
 assert.equal(new Set(users).size,users.length);const totals=Object.fromEntries(assets.map(a=>[a,0n]));let nativeTotal=0n;const accounts={},pending=[],nfts=[];
 for(const user of users){const account={native:await s.slot(user,0,0),ft:{},roots:{}};nativeTotal+=account.native;
  for(const asset of assets){const balance=decodeAmount(await Promise.all([s.slot(user,asset,0),s.slot(user,asset,1)]));account.ft[asset]=balance;totals[asset]+=balance;account.roots[asset]=await s.contractStateRoot(user,asset);}
  for(let slot=0;slot<2;slot++){const values=await Promise.all(Array.from({length:9},(_,i)=>s.slot(user,nftId,30+9*slot+i)));assert.ok([0n,1n].includes(values[4]));if(values[4]===1n)nfts.push({user,slot,tokenId:values.slice(0,4),metadataHash:values.slice(5)});}
  accounts[user]=account;
 }
 for(const sender of users)for(const recipient of users.filter(u=>u!==sender)){
  const sent=await s.slot(sender,0,3+2*recipient),claimed=await s.slot(recipient,0,4+2*sender);assert.ok(sent>=claimed,'native cursor');const row={sender,recipient,native:sent-claimed,ft:{}};nativeTotal+=row.native;
  for(const asset of assets){const sent=decodeAmount(await Promise.all([s.slot(sender,asset,33554453+4*recipient),s.slot(sender,asset,33554454+4*recipient)])),claimed=decodeAmount(await Promise.all([s.slot(recipient,asset,33554455+4*sender),s.slot(recipient,asset,33554456+4*sender)]));assert.ok(sent>=claimed,'FT cursor');row.ft[asset]=sent-claimed;totals[asset]+=sent-claimed;}
  pending.push(row);
 }
 assert.equal(new Set(nfts.map(n=>n.tokenId.map(String).join(':'))).size,nfts.length,'duplicate NFT ownership');
 return {checkpoint:s.checkpoint,accounts,pending,nfts,totals,nativeTotal};
}
export async function payoutClaims(s,{userId,markets,tokenAbi,nftAbi,nftSlot}){
 const calls=[];
 for(const m of markets){for(const asset of m.kind==='nftmarket'?[m.driverConfig.tokenId]:[m.driverConfig.assetA,m.driverConfig.assetB]){
  const sent=decodeAmount(await Promise.all([s.slot(m.vault,asset,33554453+4*userId),s.slot(m.vault,asset,33554454+4*userId)])),claimed=decodeAmount(await Promise.all([s.slot(userId,asset,33554455+4*m.vault),s.slot(userId,asset,33554456+4*m.vault)]));assert.ok(sent>=claimed);if(sent>claimed)calls.push(call(BigInt(asset),tokenAbi,'claim',[BigInt(m.vault)]));
 }
 const sent=await s.slot(m.vault,0,3+2*userId),claimed=await s.slot(userId,0,4+2*m.vault);assert.ok(sent>=claimed);if(sent>claimed)calls.push({contract_id:0n,method_name:'simple_claim',inputs:[BigInt(m.vault)]});
 }
 if(nftSlot!==undefined){const m=markets.find(m=>m.kind==='nftmarket'),id=m.driverConfig.nftId,sent=await s.slot(m.vault,id,1182+35*userId+32),claimed=await s.slot(userId,id,1182+35*m.vault+33);assert.equal(sent-claimed,1n,'exactly one delivery');calls.push(call(BigInt(id),nftAbi,'claim',[BigInt(nftSlot),BigInt(m.vault)]));}
 assert.ok(calls.length>0&&calls.length<=16);return calls;
}
