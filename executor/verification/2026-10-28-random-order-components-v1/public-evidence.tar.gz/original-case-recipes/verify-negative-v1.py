from pathlib import Path
import json,subprocess,hashlib,copy,shutil
b=Path(__file__).resolve().parent;tool=b.parent/'sdk-mainnet-beta-20261027-v1/target/release/verify_random_order_component';root=b/'negative-v1';root.mkdir();original=json.loads((b/'public/client-statement-v1.json').read_text());proof=(b/'component-proofs-v1/permutation-proof.bin').read_bytes();rows=[]
cases=[]
for name,index,value in [('network',1,'1'),('chain',18,'3'),('source',14,'2'),('round',9,'4'),('draw',8,'121'),('cutoff',6,'99'),('queue',42,'9'),('batch',46,'10'),('nonce',51,'2'),('noncanonical-field',18,'18446744069414584321'),('leading-zero',9,'03'),('duplicate-member',56,'200')]:
 v=copy.deepcopy(original);v['fields'][index]=value;cases.append((name,json.dumps(v).encode(),proof))
v=copy.deepcopy(original);v['seed'][0]='12';cases.append(('different-seed',json.dumps(v).encode(),proof))
v=copy.deepcopy(original);v['verified']=True;cases.append(('injected-success',json.dumps(v).encode(),proof))
v=copy.deepcopy(original);v['fields'].append('0');cases.append(('extra-field',json.dumps(v).encode(),proof))
cases.extend([('oversized-input',b' ' *16385,proof),('oversized-proof',json.dumps(original).encode(),b'\0'*2000001),('trailing-proof',json.dumps(original).encode(),proof+b'\0')])
for name,data,pbytes in cases:
 d=root/name;d.mkdir();(d/'input.json').write_bytes(data);(d/'proof.bin').write_bytes(pbytes);report=d/'report.json'
 with(d/'stderr.log').open('x')as log:r=subprocess.run([str(tool),str(d/'input.json'),str(d/'proof.bin'),str(report)],stdout=log,stderr=subprocess.STDOUT,timeout=20)
 assert r.returncode!=0 and not report.exists(),name
 rows.append({'case':name,'exitCode':r.returncode,'inputSha256':hashlib.sha256(data).hexdigest(),'proofSha256':hashlib.sha256(pbytes).hexdigest(),'successReportCreated':False})
# An existing exact positive receipt must remain unchanged, even for the same proof.
p=b/'public/independent-component-verification-v1.json';before=p.read_bytes()
with(b/'public/existing-report-refusal-v1.log').open('x')as log:r=subprocess.run([str(tool),str(b/'public/client-statement-v1.json'),str(b/'component-proofs-v1/permutation-proof.bin'),str(p)],stdout=log,stderr=subprocess.STDOUT,timeout=20)
assert r.returncode!=0 and p.read_bytes()==before
(b/'public/negative-component-verification-v1.json').write_text(json.dumps({'schema':1,'toolSha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'cases':rows,'existingReportPreserved':True,'newProofsGenerated':0,'financialOperations':0,'scope':'exact preserved conditional component proof verification and bounded parser tests; no entropy/finality or business UPS'},indent=2)+'\n')
