from pathlib import Path,PurePosixPath
import subprocess,re,posixpath,json,hashlib
b=Path(__file__).resolve().parent;a=b.parent.parent/'psy-template-security-20261016';rev='85939feb';out=b/'baseline-source-v1';out.mkdir();seen={}
def copy(name):
 if name in seen:return
 assert not name.startswith('/')and'..'not in PurePosixPath(name).parts
 raw=subprocess.check_output(['git','show',rev+':'+name],cwd=a);seen[name]=hashlib.sha256(raw).hexdigest();p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 for dep in re.findall(r"from\s*['\"]([^'\"]+)['\"]",raw.decode()):
  if dep.startswith('.'):copy(posixpath.normpath(posixpath.join(posixpath.dirname(name),dep)))
for name in ['batching/v2/generate.mjs','batching/admission/generate.mjs','batching/v2/policy.mjs']:copy(name)
(b/'public/baseline-sources-v1.json').write_text(json.dumps({'commit':rev,'files':seen,'scope':'fixed committed source generators loaded only for offline deterministic output comparison; no external input/module, SDK or financial operation'},indent=2)+'\n')
