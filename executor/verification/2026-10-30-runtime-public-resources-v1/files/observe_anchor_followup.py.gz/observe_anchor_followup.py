import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
config=json.loads((C/'quarantine/public-l1-config.body').read_bytes())
url=config['l1']['rpc_url']
address=next(x['address'] for x in config['contracts'] if x['name']=='StateManager')
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json';rp.write_text(json.dumps(req));rp.chmod(0o600)
 out=C/'quarantine'/f'{label}.body'
 assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes() if out.exists() else b''
 if out.exists():out.chmod(0o600)
 record={'schema':1,'kind':'untrusted-public-l1-rpc-observation-v1','url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'elapsedSeconds':time.monotonic()-start,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'finalityVerified':False,'canBroadcast':False}
 dest=C/'public'/f'{label}-transport.json'
 with dest.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'error'in v or 'result'not in v:raise RuntimeError('RPC result rejected')
 return v['result']

s=json.loads((C/'public/l1-state-manager-observation.json').read_bytes())
fixed={'blockHash':s['blockHash'],'requireCanonical':True}
implementation='0x'+s['eip1967ImplementationWord'][-40:]
code=call('l1-implementation-code','eth_getCode',[implementation,fixed])
assert isinstance(code,str) and code!='0x'
slot='0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc'
proof=call('l1-proxy-account-proof','eth_getProof',[address,[slot],fixed])
assert isinstance(proof,dict)
url=config['services']['coordinator_rpc']
root=call('coordinator-l1-anchor-root','psy_get_checkpoint_tree_root',{'checkpoint_id':s['checkpointId']})
summary={'schema':1,'kind':'cross-rpc-anchor-observation-v1','checkpointId':s['checkpointId'],'l1RootWord':s['checkpointRootWord'],'coordinatorRoot':root,'implementationAddress':implementation,'implementationCodeBytes':len(bytes.fromhex(code[2:])),'implementationCodeSha256':hashlib.sha256(bytes.fromhex(code[2:])).hexdigest(),'accountProofNodeCount':len(proof.get('accountProof',[])),'storageProofCount':len(proof.get('storageProof',[])),'storageProofVerified':False,'headerConsensusVerified':False,'runtimeSourceIdentityVerified':False,'finalityVerified':False,'qualifiedRandomness':False,'canBroadcast':False}
with (C/'public/cross-rpc-anchor-observation.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary),flush=True)
