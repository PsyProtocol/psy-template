# Verifiable random ordering: source preflight — 28 October 2026

## Scope, owner and frozen release

Application starting commit `ee60c9235fe8d2c80c26ea0d70270a9ed56fcfae`, existing
`markets-batch-capacity-recovery-20261020` branch, clean working tree. Process
inspection found no active market financial, compiler or proof task. Root remains
the sole financial/proof owner; existing UI and read-only services are untouched.
SDK remains `c92880c8b6e2c8d392f19368bc8801a2584fd427`, node/client source
`b280d714a8f0930c61962c885374ea63ea63d274`, and the selected proof backend remains
`736572e9dd3ca93566471cf5a2a1cb67a13fe01d`. No Node or SDK source/pin changes.

In scope: AMM/Curve ordering preflight, versioned candidate statement/permutation
constraints and rejection interfaces that can be independently checked without a
qualified beacon. At most four members; existing shared vaults, U124 arithmetic,
pricing and refund semantics remain unchanged. Orderbook and NFT semantics are
not randomized. Out of scope until dependencies close: enabling a random market,
new random vault/key deployment, full random-market UPS or live settlement.

This phase has zero financial operations, registrations, grants, deployments,
fees or assets budget. It may run bounded offline statement/permutation tests,
with no business UPS or browser task. The original unresolved faucet and its
single-send lock are unchanged. Old contracts and original evidence are intact.

## Code-based capability table

Links refer to the frozen source, not an assertion of current running services.

| Question | Evidence | Verdict |
| --- | --- | --- |
| Where does checkpoint entropy originate? | [`coordinator_guta_update_gatherer.rs:39–43`](https://github.com/PsyProtocol/psy-node/blob/b280d714a8f0930c61962c885374ea63ea63d274/psy_node_common/src/coordinator/processor/gatherers/coordinator_guta_update_gatherer.rs#L39): `rand::thread_rng().fill_bytes`; invocation at 476 | Coordinator-local sampling; no qualified market beacon. |
| Is it durable across normal backup replay? | Same gatherer: backup reader 146–165 and writer 476–499 | A stored backup carries its chosen seed. Durability does not constrain initial choice or prove inability to regenerate before publication. |
| How does it reach checkpoint stats? | [`coordinator_output_builder.rs:341`](https://github.com/PsyProtocol/psy-node/blob/b280d714a8f0930c61962c885374ea63ea63d274/psy_node_common/src/backup/output/coordinator_output_builder.rs#L341) uses `random_seed_guta` | The producer-selected value becomes the recorded field. |
| Does the transition prove an unbiased/unique contribution? | [`checkpoint_state_transition_proofs.rs:83–100`](https://github.com/PsyProtocol/psy-node/blob/b280d714a8f0930c61962c885374ea63ea63d274/psy_plonky2_circuits/src/coordinator/gadgets/checkpoint_state_transition_proofs.rs#L83): virtual hash copied to new stats; witness set at 151 | No VRF/threshold contribution/unique-output verification found in this path. Hashing or recursion does not establish entropy quality. |
| Can a contract authenticate a historical recorded seed? | [`state_readers.rs:1589–1631`](https://github.com/PsyProtocol/psy-node/blob/b280d714a8f0930c61962c885374ea63ea63d274/client_prover/psy_circuit/psy_dpn_circuit/src/vm/gadgets/state_readers.rs#L1589): index, current checkpoint root and stats/state hashes are constrained; seed limbs returned | Historical inclusion relative to the session checkpoint tree exists. It is not a beacon uniqueness, external finality or unpredictability certificate. |
| Is chain instance / round / finality certified together? | The stats reader authenticates checkpoint membership; no market beacon domain/round/finality statement in that interface | Missing dedicated source/domain/finality contract. Existing UPS network magic alone is insufficient. |
| Was the set fixed before the draw was knowable? | [`batching/admission/generate.mjs:55–61`](../../batching/admission/generate.mjs) seals queue root/count and binds members to batch | Current deterministic queue commitment exists. No future draw/source/round or proof of sealed-state inclusion before draw is bound. |
| Can it safely be activated now? | Existing admission generator rejects random mode; Executor accepts only reviewed profiles | No. Preserve deterministic mode. |

The older client-side checkpoint data helper also hashes a contribution with the
old seed (`client_prover/psy_core/psy_data/src/protocol/circuit_inputs/checkpoint_transition.rs:83`).
That is not a uniqueness or unpredictability proof either. It must not be used to
infer a guarantee absent from the actual source and circuit path.

**Inference:** a producer controlling the supplied virtual contribution can try
multiple candidate seeds before publication. A valid checkpoint proof authenticates
the selected result, not that it was the only attempted result. No network attack
or live grinding experiment was performed. Running image/commit, initial entropy
handling and withholding resistance are not attested by this source inspection.

## Threat model and the seal-inclusion requirement

Adversaries include a grinding/withholding producer, a selecting or abandoning
Executor, conflicting Executors, a malicious submitter and stale/wrong-chain RPC.
A compromised admitted identity can submit a slippage-constrained order or fail
to fund it; it must not choose its position after seeing the draw.

A future checkpoint number alone is insufficient. An Executor could see a seed,
then generate a seal UPS using an older source checkpoint and broadcast it late.
`ctx.checkpoint_id` is the proof's source context, not proof that the seal was
included at that wall-clock time. Activation needs authenticated inclusion of the
exact sealed state at a fixed finalized checkpoint strictly before the source's
unpredictability boundary. Historical absence is not a cancellation/escape proof.

The following must be committed before that boundary: version, network magic,
genesis/chain instance, market kind and ID, vault, code/layout/function roots,
SD-key fingerprint/public key, epoch, cutoff, full canonical member set and terms
hashes, count/queue root, beacon source identity, round and draw checkpoint,
seal-inclusion deadline, settlement deadline, recovery point and fee cap.
Legacy sealed queues cannot be reinterpreted as random batches. New code/layout,
key and instance acceptance are required; no old contract is updated to probe it.

## Source-provider deliverables and acceptance

Upstream/source maintainers must supply the following public interfaces and tests;
these are requirements, not methods assumed to exist in the current SDK:

1. A versioned, domain-separated beacon statement with source/key identity,
   exact chain instance, fixed round and draw checkpoint, output and proof bytes.
   Fixed verified keys/common data must be application-owned. An Executor signature,
   RPC `verified` flag, caller-provided verifier or external resource URL is invalid.
2. A circuit-verifiable unique-output proof (or an explicitly reviewed equivalent)
   and security analysis showing unpredictability at the seal boundary and a
   quantified bias/withholding model. One valid output per committed source/round;
   no selectable participant subset, optional reveal, reroll or alternate checkpoint.
3. A verifiable checkpoint/finality opening binding genesis, sealed contract state,
   its actual inclusion checkpoint and the chosen draw to one finalized history.
   Mere membership in an arbitrary supplied root or a signed seed is insufficient.
4. Source availability and delay semantics, key rotation boundaries and rejection
   rules for duplicate/conflicting certificates, old domains and historical rounds.
5. Adversarial vectors for forged proofs, wrong key/domain/round, two alleged valid
   outputs, producer grinding, reveal withholding, late seal inclusion and finality
   rollback. Release exact proof format, verifier/common digests, source code and
   independent review. SDK integration must be tested against the frozen cohort;
   changing dependencies is a separate user-authorized task.

There is currently no approved source adapter. No combination of a nonzero
`random_seed`, Merkle path and signature closes these requirements.

## Protocol boundary and implementation sequence

```text
collect -> seal exact set and draw request -> prove pre-draw seal inclusion
        -> wait for the one certified/final draw -> freeze full permutation
        -> settle in that order -> terminal outcomes
                     | unavailable / expiry / executor exit
                     +-> preserve set, request, seed if known, and permutation
                         -> governed refund/recovery; never reroll or reselect
```

1. Publish this source/threat assessment first, with frozen source hashes.
2. Add an independent candidate statement encoder and full-permutation constraint
   at current capacity. Bind all scope fields and full order identities; define
   canonical integer/hash ordering, domain separation and total tie rules.
3. Harden builder/client/Executor refusal of unreviewed random source/configuration.
   Implement certificate envelope validation without treating parsing as verification;
   with no approved source, execution remains rejected.
4. Test fixed-set mutation, fake certificates, history/round substitution, missing/
   duplicate/extra members, ties, deterministic restoration and restart identities.
   Run actual bounded permutation circuit proofs only if source-level review passes.
   They establish a component property, not beacon authentication or full market UPS.
5. Only after source and seal-inclusion delivery: new contract layout and key with
   the state machine, full CFC/UPS/call-stack and sequential U124 state verification,
   new-instance settlement/ordinary claim/refund/recovery, then matched performance.

AMM/Curve sequentially update shared reserves/curve state in the fixed permutation.
Slippage or invalid funding takes the specified refund disposition at its position;
it is not an excuse to omit the member. Book retains price/time priority and NFT
retains its unique-sale and buyer priority; neither is shuffled by this protocol.

## Cancellation, fees and liveness boundary

A permissionless relayer may advance a valid phase, paying its authorized fee or
using a consented sponsor. No phase transition may infer fresh fee credit from an
unclaimed Outbox. Shared vault/account nonce coordinates competing Executors;
a stale or unknown broadcast is reconciled by original request identity, not
replaced. After a confirmed phase, another Executor must use the same set/source/
round/draw/permutation. A losing Executor cannot consume another nonce as a reroll.

Pre-seal cancellation follows the accepted consent rules. After seal, each member
must reach a defined fill/refund/legal terminal outcome; cancellation must not
change the frozen set. Source lateness or executor abandonment must have a
contract-authorized timeout refund path with the original commitment, plus a
monotonic consumed epoch/order nonce. No deterministic fallback or random re-seal.
Already completed trades return actual remaining/intermediate assets, not a
fictional reversal at the original price. These new random-mode contract paths
are not deployed or accepted by this preflight.

The application cannot force a producer to publish, a relayer to pay fees or an
unfunded sponsor to act. A unique seed plus refunds prevents changing the outcome
of the same sealed batch, but cannot by itself eliminate selective service,
strategic abort/re-entry in a later epoch or withholding losses. Admission outside
the sealed finite queue remains unauthenticated discovery: no global inclusion,
censorship resistance or comprehensive anti-MEV claim. Proof aggregation is not
same-pool parallel execution.

## Measurements and evidence status

No new proof, full UPS, settlement, claim, confirmation, fee or cold/warm sample
has been run at this preflight stage. Random-versus-deterministic full-market
cost and protocol waiting comparisons are **not measured**. Upcoming component
proof timings must not be labeled live market throughput or chain TPS.

## Implemented conditional component milestone

The preflight is published as `85939feb`. The follow-up implements
[`batching/random-order`](../../batching/random-order/README.md) and the native
`random_order` module. This is an independent conditional-permutation component
and an active refusal boundary; it is not an activated random market protocol.

The strict 74-Felt candidate binds the complete scope, roots and fixed schedule
from the preflight, up to four canonical members and their full terms hashes.
The source ID identifies the intended source definition/type; no qualified
source registry exists. Native Poseidon derives a domain-separated frozen root
and each full four-limb order key. The circuit verifies a complete unique active
permutation, canonical unused positions and full unsigned hash comparison with
owner/nonce tie rules. Goldilocks decomposition is constrained to `<= p-1`.
Its expected public root, seed, count and rank are independently checked by a
read-only saved-proof verifier built from the fixed application/SDK source.

The client parses a future envelope with **separate** beacon, sealed-state
inclusion and finality proof blobs. Parsing explicitly remains unverified;
authorization always rejects because no approved adapter is installed. No
caller callback, resource URL or boolean can enable it. Existing V2 and admission
source generators, policy construction and Executor admission plan validation now
share deterministic-only refusal. All eight AMM/Curve/Book/NFT generated source
outputs match the published `85939feb` baseline byte-for-byte for valid inputs.
This compares generated source, not a newly compiled market bytecode or UPS.
Book/NFT semantics are unchanged and are rejected by the random candidate codec.

### Executed checks

- Final JS suite: 29 passes, no skips, with existing reader fixtures explicitly
  selected. The first invocation omitted `BATCH_BUILD` and failed that suite's
  environment gate; it remains failed. Parser tests call the parser directly,
  separately from authorization rejection, so the closed source gate cannot mask
  malformed/missing proof acceptance.
- Rust host statement test and library full-key/owner/nonce tie test pass in
  release mode. An initial compile omitted the `Field64` trait import; its failed
  log is preserved. Corrected builds use actual frozen SDK APIs.
- Exactly two successful standalone component proofs: maximum four-member
  permutation and public-input full-key tie comparator. Four deliberately invalid
  witness attempts reject: wrong rank, duplicate rank, duplicate member, and an
  alternate field-zero decomposition `low=1, high=0xffffffff` reconstructing `p`.
  The last test calls the same canonical-limb constraint used by the real comparator.
- The circuit consumes the exact file emitted by the JS candidate encoder. Native
  inspection and the proof report agree on all root/key/rank values. The resulting
  synthetic order is `[3,2,0,1]`; it is not a market execution or a certified draw.
- A separate fixed-source CLI verifies the preserved proof and exact endpoints
  without regenerating it. Its 18 negative parser/endpoint/proof cases reject
  changed network, chain, source, round, draw, cutoff, queue/batch roots, nonce,
  member, seed, noncanonical/leading-zero fields, injected success, extra fields,
  oversized inputs/proofs and trailing proof bytes. Create-new output preserves
  an existing positive report. A metadata-hash relative-path error is separately
  recorded; the Native inspection itself had already succeeded and was not rerun.

The source-level independent review also corrected a false-positive test pattern:
calling authorization (which always throws) could not establish parser rejection.
The final tests invoke `validateBeaconEnvelope` for malformed inputs and reserve
`RANDOM_SOURCE_UNAVAILABLE` assertions for shape-valid unauthorized envelopes.
This review/test repair is not a discovered live authorization bypass.

### Measurement scope

| Measured component scope | Value |
| --- | ---: |
| Permutation circuit cold construction | 0.080766 s |
| Permutation proof generation | 0.190438 s |
| Expected endpoints plus proof verification | 0.003121 s |
| Whole selected component test, including tie and negative attempts | 0.33 s |
| Cargo launcher through component-test exit, cached build included | 2.073365 s |
| One-second sampled process-family RSS peak for that invocation | 155.08 MiB |
| Corrected host test build / launcher through exit | 43.05 s / 44.449722 s |
| Read-only verifier/inspection binary build / launcher through exit | 36.17 s / 37.128198 s |

Selected SDK, source, two Rayon threads, fixed inputs, commands and all samples
are archived. The circuit has degree 10. This is not a market CFC, recursive
SD-key signature or Endcap, and its timing must not be substituted for their
cost. No actual confirmation, wallet claim, asset conservation, fee or protocol
waiting measurement exists for random mode. There is no matched deterministic/
random full-market cold/warm comparison, p95, steady throughput or speedup claim.
The short test may occur between RSS samples; shared pages may be counted more
than once and actual peaks may be missed. Sampled RSS is not physical peak memory.

### Acceptance matrix and remaining work

| Requirement | Current status |
| --- | --- |
| Exact candidate binding and unique bounded permutation | Native/JS codec and conditional component proofs executed |
| Fake envelope / wrong domain / substitution / seed alternatives | Strict parsing and disabled authorization checks executed; not a real beacon-proof rejection suite |
| Random-mode actual contract state/seal, new layout and SD-key | Not implemented or deployed; blocked pending qualified source and pre-draw sealed-state inclusion delivery |
| Actual ordered market call stack, pricing, U124 fills, fees and refund terminal states | Existing deterministic semantics preserved; not verified with random CFC/key/full UPS |
| Random cancellation/timeout/source delay/selection-abort recovery | Protocol requirements specified; no on-chain random state machine or full-UPS acceptance |
| Restart, lost receipts, two Executor competition | Existing deterministic reader/journal regressions run; not random-mode or multi-host acceptance |
| Real settlement, ordinary claim, failed-stage asset recovery | Not performed; no new funds or chain operation |
| End-to-end performance and protocol wait comparison | Not measured; component data is not a substitute |

The build refusal prevents creating a funded random queue with no implemented
exit. No existing sealed queue is reinterpreted or sent through this candidate.
The future new contract/key must authenticate source and actual seal inclusion,
store the original request/seed/permutation once, enforce stage-specific timeout
refunds and consumed epochs, and bind the complete real UPS stack and resources.
Full actual bytecode, signature/Endcap, U124 asset/fee conservation, ordinary claim
and all financial fault scenarios remain prerequisites to enabling a new instance.
Upstream proof formats/security guarantees and finality openings remain the
concrete external deliverables listed above. No financial authorization is inferred
from these component proofs. Random order would still cover only the fixed set,
not global inclusion, comprehensive anti-MEV or same-pool parallel execution.

[Public conditional proofs, failed runs, frozen build inputs, exact verification and samples](../../executor/verification/2026-10-28-random-order-components-v1/manifest.json).

The public archive was extracted into a fresh directory and the exact preserved
permutation proof was verified from that extraction by the trusted read-only CLI.
`extracted-replay.json` is a separately hashed report. The portable command is:

```sh
python3 original-case-recipes/replay-extracted-v1.py \
  "$EXTRACTED_CASE" "$TRUSTED_BUILT_COMPONENT_VERIFIER" "$FRESH_REPORT"
```

Other archived launchers retain their original case-root paths as provenance;
they are not claimed to run unchanged after extraction. Rebuild from the reviewed
application and frozen SDK, using the recorded target projection and exact inputs.
No runtime/website may provide the trusted verifier binary or its resources.


## Conditional historical seal-inclusion milestone

Starting application `c7a5203000fc62145dc2d0a6914b2c0814a6346e`, same branch and
frozen SDK/backend. The root owner found no active financial/compiler/proof task
before starting this bounded offline case. Budget: one successful seal-component
proof, three invalid witness attempts, one process, two Rayon threads, 300 seconds
and 4 GiB sampled process-family RSS ceiling. No financial operations, business
UPS, RPC, registrations, grants, deployments, settlements, claims or fees.

### Implemented and checked

- [Conditional seal inclusion](../../batching/random-order/SEAL_INCLUSION.md):
  strict seed-free frozen input; native and circuit openings link checkpoint 1
  and the seal checkpoint to one caller-owned checkpoint tree root. The chain
  instance, global roots, vault/key/fingerprint/public parameter, contract
  code/layout/function roots and packed frozen root are bound. The four root
  Felts may cross a packed-word boundary; exact path count/index/height and all
  root limbs are checked.
- The reviewed layout descriptor is a trusted resource input, not supplied by
  an opening. Its correct named field/slot must independently match approved
  source/ABI/layout-root semantics. The circuit embeds these constants; changing
  them constructs different verifier resources. Merkle membership alone does
  not certify the admission, sealing, immutability or refund method semantics.
- The frozen set and `cutoff < inclusion <= sealBy < draw` are circuit-constrained.
  Native positives cover both AMM and Curve and all four root-slot alignments;
  23 native mutation cases reject. Exactly one synthetic membership proof passes;
  three deliberately invalid witness prover attempts reject (late checkpoint,
  wrong stored root and wrong key). They reach the circuit instead of relying
  on the full native opening validator to reject them first.
- Separate source-built read-only CLIs verify the saved opening and saved proof,
  cap reads before deserialization and create/sync a new report. Forty-seven
  negative CLI cases reject wrong scope, history, identities, paths, reviewed
  slot, seed injection, noncanonical inputs, oversized/trailing bodies and output
  replacement. Existing positive reports remain byte-identical.
- The exact previous `c7a52030` permutation proof verifies against the extracted
  shared frozen-statement gadget, without generating a replacement. No market
  generator, deterministic source gate, runtime policy, wallet trust installation,
  Node or SDK dependency is changed by this milestone.

The first native build failed because the fixture exporter tried to serialize a
74-element array with the selected serde version. The corrected exporter uses a
vector. That failed log remains failed; corrected native builds and the bounded
component run are separate records. No failed or slow sample is discarded.

### Measurements: synthetic standalone component only

| Measurement | Result |
| --- | ---: |
| Circuit construction | 0.077178 s |
| Proof generation | 0.208789 s |
| Exact endpoints and proof verification | 0.003353 s |
| Selected test, including negative witness attempts | 0.30 s |
| Cargo launcher through exit, cached build included | 2.080936 s |
| Full-launch-to-exit 1 Hz sampled process-family RSS maximum | 144.23 MiB |
| Final native build / launcher through exit | 39.82 s / 40.359630 s |

Degree 10. One successful synthetic checkpoint-105 proof, four members, root
slot 3 and two packed-word openings. Checkpoint/code/key identities are test
fixtures, not a deployed market or certified history. RSS sampling covers the
process lifetime but can miss short peaks and double-count shared pages; it is
not physical peak memory. There is no random-mode CFC, SD-key, recursion/Endcap,
full UPS, network confirmation, ordinary claim or financial cost measurement.
This is neither an end-to-end comparison nor evidence of faster market settlement.

### Unclosed dependencies and activation refusal

1. The expected checkpoint root is independently supplied. Including the expected
   genesis in a fabricated tree does not establish canonical history or finality.
   No finality verifier/certificate adapter is installed.
2. A qualified unique-output beacon, fixed source/key/round domain and authenticated
   unpredictability/release boundary remain absent. Checkpoint `random_seed` is
   still producer-controlled sampling, not an accepted substitute.
3. **Checkpoint order is not trusted wall-clock order.** An external round can
   become public while this chain stalls. Even a finalized seal checkpoint below
   a future draw height does not by itself show that the seed was unknown when
   that seal was included. The source/finality protocol must establish the causal
   seal-before-release boundary. The inspected `block_time` witness is only
   monotonic, not a trusted clock certificate.
4. Actual new market/key admission, immutable seal, authenticated draw, complete
   call stack, sequential U124 fills/refunds, timeout recovery and full UPS/live
   settlement remain unimplemented and unaccepted for random mode. A component
   proof is not an SD-key, Endcap, spending approval or market admission proof.

[Concrete upstream statements, proof formats and acceptance requirements](../../batching/random-order/PROVIDER_INTERFACE.md)
identify source-provider and finality-maintainer deliverables. No qualified source
adapter exists, and `authorizeRandomBatch` continues to reject every request.
Deterministic mode remains unchanged. This seals only a finite set relative to
trusted inputs; it proves neither global inclusion, censorship resistance,
comprehensive anti-MEV nor same-pool parallel execution.

[Public proof, inputs, source hashes, failed builds, replay and all samples](../../executor/verification/2026-10-28-seal-inclusion-v1/manifest.json).
The archive's portable replay verifies the preserved native opening and ZK proof
from a fresh extraction with caller-selected trusted built binaries. It does not
prove again, install trust, call RPC or broadcast.


## Conditional recursive seal/order linkage milestone

Starting application `009421e10462ff89ae42a888f0fe388d0a65bedc`, clean worktree,
same branch, frozen mainnet-beta SDK and backend. Process inspection found only
the existing read-only UI gateway, with no active market finance/proof/compiler
job. Root remained the sole proof/finance owner. Budget: one matching permutation
proof, one parent proof, three invalid witness attempts, one process, two Rayon
threads, 300-second per-process and 4 GiB sampled family-RSS ceiling. No business
UPS, financial RPC, registration, grant, deployment, fee, fill or claim occurred.

[Seal/order linkage implementation and public encoding](../../batching/random-order/LINKED_PROOF.md)
adds a source-built recursive verifier for both existing component relations. The
parent embeds constant child verifier data and exact child common data; callers
cannot select keys or substitute a verifier callback. It verifies both actual
proofs and connects all four frozen-root limbs **inside the circuit**. Its 19
public inputs bind relation version, exact frozen set, supplied checkpoint root,
inclusion checkpoint, seed, count and complete bounded rank. Host verification
recomputes the full expected endpoints before verifying the parent proof.

### Executed checks and observed results

- Frozen-source verification/materialization and release/locked/offline test and
  read-only CLI build pass. No SDK/Node patch or dependency change. The no-run
  invocation is build evidence only, not counted as an executed test suite.
- The preserved seal proof from the previous milestone is read and verified,
  without regeneration. A preserved old permutation proof for a different frozen
  set is separately verified under the same fixed permutation resources before
  use as the negative witness. This tests two genuinely valid but incompatible
  children, not just malformed placeholders.
- One new matching permutation proof and one recursive parent proof pass, using
  declared synthetic seed `[1,2,3,4]`; rank is `[3,0,1,2]`. That seed is a fixture,
  not an entropy source. The original seal-proof bytes remain unchanged.
- Three invalid recursive witness attempts reject: the individually valid
  different-set children, modified order-rank public input, and modified seal
  checkpoint public input. There is no host root-equality precheck hiding these
  circuit checks. Changed expected seed is also rejected by exact parent endpoints.
- A separate source-built read-only CLI verifies the exact saved parent proof.
  Thirty-one saved-proof/parser/endpoint rejection cases cover network, genesis,
  source, round, epoch, market/vault, code/layout/function/key, queue/batch/member,
  seed, checkpoint/root, reviewed slot/count, fake success/verifier injection,
  a child substituted for the parent, corrupt/oversized/trailing proof, and output
  replacement. The original positive report is preserved byte-for-byte.
- The public archive is hash-checked, extracted fresh, and its preserved parent
  proof is replayed using a caller-trusted built CLI. No proof regeneration or
  financial operation is involved in that reproduction.

### Measurements: one synthetic component case

| Measurement | Result |
| --- | ---: |
| Release build / build launcher through exit | 38.35 s / 39.240666 s |
| Sampled family RSS maximum for build invocation | 1001.23 MiB |
| Both child resources and recursive circuit construction | 0.952116 s |
| New matching permutation proof | 0.187484 s |
| Recursive parent proof | 1.503804 s |
| Expected endpoints plus parent verification | 0.003870 s |
| Selected proof test including negative attempts | 2.71 s |
| Cached-build launcher through proof-test exit | 4.125516 s |
| Full-lifetime 1 Hz sampled family RSS maximum for proof invocation | 549.09 MiB |

Parent degree 13; saved parent 136,080 bytes, matching child 119,456 bytes.
Resource construction includes the two source-built child resources. This is a
single conditional synthetic proof-link case, not a same-workload comparison,
steady-state benchmark or market CFC/signature/Endcap/UPS. No real confirmation,
ordinary-wallet claim, protocol wait, actual financial fee or final asset arrival
was measured. RSS can miss short peaks and duplicate shared pages; it is not a
physical peak. No p95, chain TPS, universal speedup or production claim is made.

### Remaining activation boundary

The parent proves membership and order relative to expected inputs, **not that
those inputs are authoritative**. Correct reviewed layout/slot semantics,
canonical/final checkpoint authentication, a qualified unique future beacon and
seal-before-release causality remain separate unclosed requirements. The same
checkpoint-height comparison remains insufficient when the ledger stalls while
an external source releases its round. The inspected frozen source has no new
adapter that closes these requirements.

No actual random-market admission/seal/draw/recovery state machine, SD-key,
ordered market call stack, U124 fills/refunds, full UPS, live deployment, ordinary
claim or random-mode financial fault acceptance is added. The deterministic source
gate and all four market mechanisms remain unchanged. A linked component report
cannot enable wallet spending or random execution. It does not prove global
inclusion, censorship resistance, comprehensive anti-MEV or same-pool parallelism.

[Public inputs/proofs, exact build inventory, commands, rejection results and all samples](../../executor/verification/2026-10-28-seal-order-v1/manifest.json).


## Local candidate request recovery milestone

Starting application `0453c75ef8d95f0c0fc7b60dbd5f6ae7056fbed2`, same clean branch
and frozen mainnet-beta SDK. Process inspection found the existing read-only UI
gateway, no financial/proof/compiler owner. Root owned the bounded local tests.
This case authorizes zero proofs, financial RPC, grants, registrations, deployed
instances, fees, fills or ordinary claims. No SDK, Psy Node, old market or existing
financial journal is changed.

[Local candidate request recovery](../../batching/random-order/REQUEST_RECOVERY.md)
adds `RandomRequestJournal` and the offline Executor operator entry
`executor/randomCandidate.mjs`. It reuses the existing fsynced/create-new journal
and same-host locking in a separate candidate namespace. A domain-separated
SHA256 over all 74 canonical field strings pins the complete requested identity;
this local digest is not the Poseidon frozen root or an on-chain seal. Different
sets, nonces, epochs, rounds, source, schedule, fees or component identities reject.
The journal cannot accept a financial terminal event, fix an authenticated draw,
close an epoch or clear a broadcast lock.

Only projected public claim fields and decoded-proof byte digests are retained.
Seed claims and checkpoints remain unverified; conflicting claims are diagnostic.
There is no verifier callback, resource URL, signing, broadcast or refund path.
At most 32 distinct evidence/timeout observations are retained, with exact
idempotent duplicates allowed after capacity exhaustion. Full capacity never
rotates the request, removes members or selects a new draw. This is diagnostic
backpressure, not an increased or reduced market batch capacity.

### Correctness repair found during review

The first operator implementation mutated the journal before publishing the
create-new report. An occupied report path could therefore cause an error after
the first candidate was pinned. Independent review identified this case; the
existing repeated-pin test did not cover it. A new first-freeze regression
reproduced the failure before repair. That failed log and pre-repair source remain
unchanged in the public archive.

The corrected entry reserves the fresh report first, durably writes a separate
immutable command intent, then performs journal work. Occupied output fails before
any first pin. A simulated post-pin output write failure retains the intent and
exact journal identity and returns a typed reconciliation-required error. Changed
proposals distinguish their requested identity from the validated retained one.
An empty reserved result is not success; recovery inspects the original journal
using a fresh output and never chooses a replacement candidate.

### Executed acceptance and scope

- Final focused suite: 15 passes, no skips. Earlier 10-pass and 13/14-pass runs are
  provenance, not additional independent acceptance. The deliberately failing
  first-freeze reproduction remains failed.
- Exact input/output mutation and restart identity checks; changes to set/member,
  source/round/schedule, scope or epoch reject without replacing the original.
  Proof-byte aliases deduplicate; different seed claims remain unverified.
- Two independent same-host operator processes race different sets: exactly one
  pins, the other rejects. A separate writer is actually killed with SIGKILL
  after atomic record publication while holding the vault lock; a new instance
  retains that exact record and complete candidate. No cross-machine result.
- Forged journal terminal events, digest corruption, duplicate fixed records,
  foreign domains, injected verifiers/success, premature timeouts and diagnostic
  capacity overflow reject. Timeout and recovery reports keep all financial
  capabilities false; `executionPlan` always rejects unavailable randomness.
- Five separate real CLI processes freeze, inspect after process restart, observe
  synthetic evidence, observe a timeout and emit a blocked recovery plan. A sixth
  process attempts a changed round and rejects. These are actual local operator
  invocations, not network settlement or extension-wallet payment acceptance.
- The public archive is extracted fresh and an inspection of the copied original
  ledger and candidate verifies the same request identity and blocked capabilities.
  No new pin, proof, RPC, draw or financial operation is needed for that replay.

The suite uses Node 24.19.0 with test concurrency one and a 120-second test-invocation
ceiling. Timing is retained as test-run provenance only; no market proof, network
confirmation, final asset arrival, cold/warm throughput, fee or RSS performance
measurement is claimed by these persistence tests. The post-pin ENOSPC-like error
is a controlled filesystem-write fault, not a claim that the disk actually filled.
Acquisition-gate crashes still fail closed for inspection under the existing
journal; the killed-writer result does not establish universal automatic recovery.

### Remaining safety boundary

Local files can be rewritten or a new directory selected by their administrator.
This operational pin cannot prove on-chain pre-draw sealing, force inclusion,
prevent selective service or resolve financial state. Magic plus checkpoint-1
root alone cannot authenticate a unique reset if both values are reused; the
source/finality certificate domain must supply a reviewed instance/key epoch.
Existing financial nonce/balance/broadcast locks remain intact and separate.

Random execution remains disabled. Qualified unique future entropy, canonical
finality and causal pre-release sealing are still missing. Actual new random
market/key state transitions, U124 ordered fills, cancellation/refund/timeout
recovery, full UPS, live deployment and ordinary claim are not implemented or
accepted by this local journal. Existing AMM/Curve pricing, Book price/time
matching and NFT unique-sale semantics remain unchanged. No global fairness,
anti-censorship, comprehensive anti-MEV or production claim follows.

[Public records, commands, failed reproduction, source and regression evidence](../../executor/verification/2026-10-28-random-request-recovery-v1/manifest.json).


## No-Node source/finality/causality capability audit

[Detailed capability matrix and exact U0–U3 upstream deliveries](NO_NODE_RANDOMNESS_FINALITY_20261028.md)
are based on the unchanged frozen source and bounded public observations. The
SDK already exposes `psy_get_checkpoint_state_transition_proof`, checkpoint roots,
leaves and membership paths. No new Node RPC is required to collect those bytes.
The present native random contribution is still coordinator-local sampling;
monotonic checkpoint time or height order cannot establish qualified entropy or
causal seal-before-release. An external source/finality adapter is an application
route, not an installed or qualified implementation.

A new [read-only checkpoint inspector](../../batching/random-order/CHECKPOINT_EVIDENCE.md)
loads fixed cached verifier/common data, recomputes key fingerprints, compares
cached genesis against its source constructor, verifies actual proof bytes and
opens the cumulative PI using the real SDK hash helper. The captured current and
predecessor proof identities are separately recorded. Membership at a declared
index is distinguished from numeric predecessor adjacency, latest append, full
history anchoring, domain authentication and finality; those flags remain false.
Independent review prompted the explicit adjacency boundary and predecessor-byte
identity before this interface was published.

Ten read attempts were made: one Python TLS-store failure retained, then nine
system-curl calls with TLS/hostname validation enabled. The observed head was
6086. Proofs for 6085 and 6086 were each 130,328 bytes; checkpoint 0 returned an
empty proof array. Both nonempty proofs independently fail under the frozen
transition verifier/common data. The compatibility diagnostic exits nonzero and
its original failure is preserved. This does not identify the chain as invalid
or prove which running release/format/parameter/resource caused the mismatch.
No alternate key, SDK, backend, proof generation or chain operation was attempted.

The cached genesis key/common data matches actual frozen source construction,
with degree 12 and fingerprint `ef362aad8a2686a173a67d7aedc881d203754a105fe8134d82786111a8554208`.
Full transition resource construction remains unchecked. Its frozen cached final
fingerprint is `5e4c467c5e5984b52b2ce8a8dc1401ef3d6046ef3b529935e4cc840112e63f06`.
U0 requires a reproducible fixed-source/public-parameter proof/resource tuple;
U1 requires canonical finality/lineage and unique domain evidence; U2 a qualified
unique unpredictable beacon; U3 a release rule causally bound to the finalized
seal. Publishing existing proof/resource data may require no Node code change.
Upgrading the quality of the native random field would be a separate upstream
protocol change, outside this authorized work.

Three offline resource/hash/size unit checks pass; they do not close compatibility.
The actual captured-proof diagnostic fails and is not counted as a passing test.
Targeted guards cover declared index/root/leaf, strict input fields, trailing and
oversized proof data, missing predecessor, exact failed-report predecessor byte
provenance and create-new report preservation. Provenance checks under a blocked
compatibility gate are not represented as successful cryptographic substitution
rejection. No full UPS, random SD-key, market fill, ordinary claim, fee, finality
certificate or causal beacon release is accepted by these checks.

The evidence archive is verified and extracted fresh. Replaying the exact
captured-proof inspection retains a nonzero outcome and the same proof byte
identities. This is reproducible failure evidence, not a manufactured positive.
No original record is overwritten. Native build/RSS samples and all failed runs
are provenance only; no full-market speedup, confirmation throughput, p95 or
production claim follows.

[Public source excerpts, raw observations/proofs, failures, build inventory and guard evidence](../../executor/verification/2026-10-28-random-source-boundary-v1/manifest.json).


Final evidence review also repaired the initial replay guard: any generic failed
inspection could previously be labeled the expected compatibility failure. A
controlled fresh-copy wrong-membership index reproduces that weak classification;
the v2 recipe rejects it and requires the exact frozen predecessor-transition
verification stage, polynomial error, fixed fingerprint and both proof digests.
The original v1 recipe/report/archive remain preserved as superseded. The current
v2 archive and stricter fresh-extraction replay reproduce the actual observed
compatibility failure, without accepting a proof, making RPC calls or proving.
