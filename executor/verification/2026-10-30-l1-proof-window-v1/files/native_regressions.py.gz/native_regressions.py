import json,pathlib,copy,hashlib,subprocess
C=pathlib.Path(__file__).resolve().parent
base={n:json.loads((C/'public'/p).read_bytes())for n,p in [('statement','prospective-statement.json'),('header','prospective-header-projection.json'),('proof','prospective-eip1186-projection.json'),('code','prospective-proxy-code.json')]}
cases=[]
def add(name,fn):
 d=copy.deepcopy(base);fn(d);cases.append((name,d))
add('wrong-network',lambda d:d['statement'].update(chainId=1))
add('claimed-finality',lambda d:d['statement'].update(headerConsensusVerified=True))
add('claimed-anchor-replacement',lambda d:d['statement'].update(originalAnchorReplaced=True))
add('changed-header-state-root',lambda d:d['header']['header'].update(stateRoot='0x'+'00'*32))
add('changed-header-bal',lambda d:d['header']['header'].update(blockAccessListHash='0x'+'00'*32))
add('changed-header-slot',lambda d:d['header']['header'].update(slotNumber='0x1'))
add('missing-header-bal',lambda d:d['header']['header'].pop('blockAccessListHash'))
add('extra-header-field',lambda d:d['header']['header'].update(unsupportedFutureField='0x0'))
add('changed-code-block',lambda d:d['code'].update(blockHash='0x'+'00'*32))
add('changed-code',lambda d:d['code'].update(code='0x00'))
add('changed-account-address',lambda d:d['proof']['proof'].update(address='0x'+'00'*20))
add('changed-account-nonce',lambda d:d['proof']['proof'].update(nonce=hex(int(d['proof']['proof']['nonce'],16)+1)))
add('changed-account-balance',lambda d:d['proof']['proof'].update(balance=hex(int(d['proof']['proof']['balance'],16)+1)))
add('changed-account-storage-root',lambda d:d['proof']['proof'].update(storageHash='0x'+'00'*32))
add('changed-account-code-hash',lambda d:d['proof']['proof'].update(codeHash='0x'+'00'*32))
add('missing-account-node',lambda d:d['proof']['proof']['accountProof'].pop())
add('reversed-account-nodes',lambda d:d['proof']['proof']['accountProof'].reverse())
add('extra-account-node',lambda d:d['proof']['proof']['accountProof'].append(d['proof']['proof']['accountProof'][0]))
add('changed-storage-value',lambda d:d['proof']['proof']['storageProof'][0].update(value='0x1'))
add('missing-storage-node',lambda d:d['proof']['proof']['storageProof'][0]['proof'].pop())
add('duplicate-storage-slot',lambda d:d['proof']['proof']['storageProof'].__setitem__(1,copy.deepcopy(d['proof']['proof']['storageProof'][0])))
add('missing-storage-slot',lambda d:d['proof']['proof']['storageProof'].pop())
add('unrequested-storage-slot',lambda d:d['proof']['proof']['storageProof'][0].update(key='0x2'))
add('noncanonical-storage-quantity',lambda d:d['proof']['proof']['storageProof'][0].update(value='0x00'))
add('duplicate-requested-slot',lambda d:d['statement']['slots'].__setitem__(1,'0x0'))
add('extra-proof-authority',lambda d:d['proof'].update(finalityVerified=True))
root=C/'public/native-negative-v1';root.mkdir();results=[]
for name,d in cases:
 p=root/name;p.mkdir()
 for n,v in d.items():(p/(n+'.json')).write_text(json.dumps(v,indent=2)+'\n')
 pin=hashlib.sha256((p/'statement.json').read_bytes()).hexdigest()
 args=[str(C/'inspector-build-v2/l1-proof-inspector'),str(p/'statement.json'),pin,str(p/'header.json'),str(p/'proof.json'),str(p/'code.json'),str(p/'report.json')]
 r=subprocess.run(args,capture_output=True,text=True,timeout=15)
 (p/'console.log').write_text(r.stdout+r.stderr)
 report=json.loads((p/'report.json').read_bytes())
 assert r.returncode!=0 and report['inspectionPassed'] is False,name
 for field in ['headerConsensusVerified','finalityVerified','qualifiedRandomness','canSign','canBroadcast']:assert report[field] is False,name
 results.append({'name':name,'exitCode':r.returncode,'inspectionPassed':report['inspectionPassed'],'reportSha256':hashlib.sha256((p/'report.json').read_bytes()).hexdigest()})
with(C/'public/native-negative-results.json').open('x')as f:json.dump({'schema':1,'rejections':results,'financialOperations':0,'proofsGenerated':0},f,indent=2);f.write('\n')
print(json.dumps({'negativeCasesRejected':len(results),'financialOperations':0}))
