
        let old_stats = QEDCheckpointLeafStatsGadget::create_virtual(builder);
        let block_time = builder.add_virtual_target();
        let final_random_seed_contribution = builder.add_virtual_hash();

        let old_state_roots_hash = old_state_roots.to_hash::<H, F, D>(builder);
        let new_state_roots_hash = new_state_roots.to_hash::<H, F, D>(builder);

        let zero = builder.zero();

        let rewards_tree_tag_tree_root = hash_tag_tree_node_single_circuit::<H, F, D>(builder, part_1_worker_reward_tree_value, worker_rewards_tree_tag);

        let new_stats = QEDCheckpointLeafStatsGadget {
            guta_fees_collected: part_1_header.global_user_tree_delta.stats.guta_fees_collected,
            da_fees_collected: part_1_header.global_user_tree_delta.stats.da_fees_collected,
            user_ops_processed: part_1_header.global_user_tree_delta.stats.user_ops_processed,
            total_transactions: part_1_header.global_user_tree_delta.stats.total_transactions,
            slots_modified: part_1_header.global_user_tree_delta.stats.slots_modified,
            pm_jobs_completed: part_1_header.combined_pm_jobs_completed,
            block_time,
            random_seed: final_random_seed_contribution,//builder.hash_two_to_one::<H>(old_stats.random_seed, final_random_seed_contribution),
            pm_rewards_commitment: PMRewardCommitmentGadget {
                register_users_root: rewards_tree_tag_tree_root,
                gutas_root: rewards_tree_tag_tree_root,
                deploy_contracts_root: rewards_tree_tag_tree_root,
            },
