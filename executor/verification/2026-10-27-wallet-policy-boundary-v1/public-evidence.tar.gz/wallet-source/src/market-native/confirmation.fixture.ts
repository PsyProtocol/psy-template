import type { MarketConfirmationTerms } from "./confirmation";
import bundle from "../market-preparation/bundle.json";
export function confirmationFixture(): MarketConfirmationTerms {
  return {
    schema: 1,
    context: {
      origin: "https://market.example",
      account: "a".repeat(64),
      userId: 201,
      networkHash: "b".repeat(64),
      fingerprint: "c".repeat(64),
      chainKey: "d".repeat(64),
    },
    intentId: "1".repeat(64),
    recordId: "2".repeat(64),
    preparedHash: "3".repeat(64),
    requestSha256: "4".repeat(64),
    fullCalls: [
      {
        contract_id: "6",
        method_name: "transfer",
        inputs: ["100", "17", "1"],
      },
      { contract_id: "0", method_name: "burn", inputs: ["1000001000"] },
    ],
    actualFee: "1000001000",
    maxNetworkFee: "2000000000",
    validUntilCheckpoint: 164,
    review: {
      request: { kind: "swap" },
      plan: {
        kind: "swap",
        marketId: 9,
        registryHash: bundle.amm.registryHash,
        recipientId: 201,
        walletNonce: "1",
        network: structuredClone(bundle.amm.registry.network),
        debits: [{ contractId: 6, amount: "4611686018427387921" }],
        minimum: "100",
      },
    },
  };
}
