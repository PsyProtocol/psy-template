//! Registration membership relative to captured checkpoint data. No signer,
//! prover, transport, account initialization or financial authorization.
use anyhow::{ensure, Result};
use plonky2::{field::goldilocks_field::GoldilocksField as F, hash::poseidon::PoseidonHash as H};
use psy_client_common::data::qhashout::QHashOut as Q;
use psy_client_data::qdata::checkpoint::{PsyCheckpointGlobalStateRoots, PsyCheckpointLeaf};
use psy_config::network_constants::GLOBAL_USER_TREE_HEIGHT;
use psy_crypto::{common::user_id::get_registration_id_from_user_id,
    hash::{merkle::core::MerkleProofCore, traits::qhashable::QFieldHashable}};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RegistrationCheckpoint {
    pub schema: u32,
    pub checkpoint_id: u64,
    pub user_id: u64,
    pub public_key: Q<F>,
    pub chain_root_at_1: Q<F>,
    pub checkpoint_leaf: PsyCheckpointLeaf<F>,
    pub state_roots: PsyCheckpointGlobalStateRoots<F>,
    pub registration_proof: MerkleProofCore<Q<F>>,
}

pub fn verify_registration_checkpoint(input: &RegistrationCheckpoint,
    expected_chain: Q<F>, expected_user: u64, expected_key: Q<F>) -> Result<()> {
    ensure!(input.schema == 1 && input.checkpoint_id > 0 && input.checkpoint_id < (1u64 << 32), "checkpoint schema/range");
    ensure!(expected_user > 0 && expected_user < (1u64 << 24) && expected_key != Q::ZERO,
        "explicit ordinary identity required");
    ensure!(input.chain_root_at_1 == expected_chain && expected_chain != Q::ZERO,
        "chain instance differs from reviewed domain");
    ensure!(input.user_id == expected_user && input.public_key == expected_key,
        "original registration identity changed");
    let proof = &input.registration_proof;
    ensure!(proof.index == get_registration_id_from_user_id(expected_user)
        && proof.siblings.len() == GLOBAL_USER_TREE_HEIGHT as usize,
        "registration index/height");
    ensure!(proof.value == expected_key && proof.root == input.state_roots.user_registration_tree_root
        && proof.verify::<H>(), "registration membership");
    ensure!(input.state_roots.qfhash::<H>() == input.checkpoint_leaf.global_chain_root,
        "checkpoint state roots differ");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> RegistrationCheckpoint {
        let user = 223232;
        let key = Q::from_values(1, 2, 3, 4);
        let proof = MerkleProofCore::new_from_params::<H>(get_registration_id_from_user_id(user), key,
            vec![Q::ZERO; GLOBAL_USER_TREE_HEIGHT as usize]);
        let mut state_roots = PsyCheckpointGlobalStateRoots::default();
        state_roots.user_registration_tree_root = proof.root;
        let mut checkpoint_leaf = PsyCheckpointLeaf::default();
        checkpoint_leaf.global_chain_root = state_roots.qfhash::<H>();
        RegistrationCheckpoint {schema:1, checkpoint_id:1700, user_id:user, public_key:key,
            chain_root_at_1:Q::from_values(5,6,7,8), checkpoint_leaf, state_roots, registration_proof:proof}
    }
    #[test]
    fn membership_does_not_require_an_initialized_user_state_leaf() -> Result<()> {
        let f = fixture();
        verify_registration_checkpoint(&f, f.chain_root_at_1, f.user_id, f.public_key)?;
        Ok(())
    }
    #[test]
    fn wrong_key_index_root_height_and_chain_reject() {
        for mutate in [0,1,2,3,4,5,6] {
            let mut f = fixture();
            let (chain,user,key) = (f.chain_root_at_1,f.user_id,f.public_key);
            match mutate {
                0 => f.registration_proof.value = Q::ZERO,
                1 => f.registration_proof.index += 1,
                2 => f.registration_proof.siblings.pop().map(|_| ()).unwrap(),
                3 => f.registration_proof.root = Q::ZERO,
                4 => f.checkpoint_leaf.global_chain_root = Q::ZERO,
                5 => f.chain_root_at_1 = Q::ZERO,
                _ => f.user_id += 1,
            }
            assert!(verify_registration_checkpoint(&f,chain,user,key).is_err());
        }
    }
}
