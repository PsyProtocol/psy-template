from pathlib import Path
import json,time,hashlib,concurrent.futures,subprocess
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';config=s/'source/psy-sdk/psy-genesis/config.json';network=json.loads(config.read_text())['networks']['testnet'];url=network['coordinator_configs'][0]['rpc_url'][0];rows=[]
def call(label,method,params):
 assert method in ['psy_get_latest_checkpoint_id','psy_get_checkpoint_tree_root','psy_get_checkpoint_tree_leaf_hash','psy_get_checkpoint_tree_merkle_proof','psy_get_checkpoint_state_transition_proof']
 body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode();start=time.monotonic();entry={'label':label,'method':method,'params':params,'endpoint':url,'requestSha256':hashlib.sha256(body).hexdigest()}
 with (b/'public'/f'{label}-request-v2.json').open('xb')as f:f.write(body)
 try:
  response_path=b/'public'/f'{label}-response-v2.json'
  p=subprocess.run(['/usr/bin/curl','--silent','--show-error','--max-time','15','--max-filesize','12000000','--proto','=https','--tlsv1.2','--header','Content-Type: application/json','--data-binary','@'+str(b/'public'/f'{label}-request-v2.json'),'--output',str(response_path),'--write-out','%{http_code}',url],capture_output=True,timeout=20)
  entry['transportExitCode']=p.returncode;entry['httpStatus']=p.stdout.decode().strip();entry['transportDiagnostic']=p.stderr.decode();assert p.returncode==0,'verified TLS transport failed'
  raw=response_path.read_bytes();assert len(raw)<=12000000,'response limit';assert entry['httpStatus']=='200','HTTP status'
  value=json.loads(raw);assert value.get('jsonrpc')=='2.0'and value.get('id')==1 and 'error'not in value and'result'in value,'RPC error/envelope'
  entry['responseSha256']=hashlib.sha256(raw).hexdigest();entry['ok']=True;return entry,value['result']
 except Exception as e:entry['ok']=False;entry['error']=str(e);return entry,None
 finally:entry['seconds']=time.monotonic()-start
first,cp=call('latest','psy_get_latest_checkpoint_id',[]);rows.append(first)
if isinstance(cp,int)and not isinstance(cp,bool)and 1<=cp<=4294967295:
 jobs=[]
 for label,n in [('genesis',0),('current',cp)]:
  jobs.extend([(label+'-root','psy_get_checkpoint_tree_root',{'checkpoint_id':n}),(label+'-leaf','psy_get_checkpoint_tree_leaf_hash',{'checkpoint_id':n,'leaf_checkpoint_id':n}),(label+'-proof','psy_get_checkpoint_state_transition_proof',{'checkpoint_id':n})])
 jobs.append(('current-path','psy_get_checkpoint_tree_merkle_proof',{'checkpoint_id':cp,'leaf_checkpoint_id':cp}))
 if cp>1:jobs.append(('previous-proof','psy_get_checkpoint_state_transition_proof',{'checkpoint_id':cp-1}))
 assert len(jobs)+2<=10 # includes the preserved failed Python TLS attempt
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for future in [pool.submit(call,*j)for j in jobs]:
   entry,result=future.result();rows.append(entry);print(entry['label'],entry['ok'],flush=True)
report={'schema':1,'network':'testnet','declaredMagic':network['magic'],'configSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'observedCheckpoint':cp,'calls':rows,'transport':'system curl with unchanged TLS/hostname verification','priorFailedAttempts':1,'financialOperations':0,'proofsGenerated':0,'finalityVerified':False,'qualifiedSource':False,'randomAuthorization':False}
with (b/'public/RPC-OBSERVATIONS-v2.json').open('x')as out:json.dump(report,out,indent=2);out.write('\n')
print('Saved',len(rows),'bounded public read attempts; no authorization inferred.',flush=True)
