import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
config=json.loads((C/'quarantine/public-l1-config.body').read_bytes())
url=config['l1']['rpc_url']
address=next(x['address'] for x in config['contracts'] if x['name']=='StateManager')
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json';rp.write_text(json.dumps(req));rp.chmod(0o600)
 out=C/'quarantine'/f'{label}.body'
 assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes() if out.exists() else b''
 if out.exists():out.chmod(0o600)
 record={'schema':1,'kind':'untrusted-public-l1-rpc-observation-v1','url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'elapsedSeconds':time.monotonic()-start,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'finalityVerified':False,'canBroadcast':False}
 dest=C/'public'/f'{label}-transport.json'
 with dest.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'error'in v or 'result'not in v:raise RuntimeError('RPC result rejected')
 return v['result']

s=json.loads((C/'public/l1-state-manager-observation.json').read_bytes())
url=config['services']['coordinator_rpc']
r=call('coordinator-l1-anchor-root','psy_get_checkpoint_tree_root',{'checkpoint_id':s['checkpointId']})
with (C/'public/coordinator-l1-anchor-root-result.json').open('x') as f:json.dump({'schema':1,'checkpointId':s['checkpointId'],'coordinatorRoot':r,'l1RootWord':s['checkpointRootWord'],'finalityVerified':False,'canBroadcast':False},f,indent=2);f.write('\n')
print('coordinator root:',r,flush=True)
