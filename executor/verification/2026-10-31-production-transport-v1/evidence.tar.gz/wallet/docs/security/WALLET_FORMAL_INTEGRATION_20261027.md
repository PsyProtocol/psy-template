# Formal market wallet integration — 27 October 2026

Latest continuation: [31 October transport integrity, frozen-cohort build and
remaining live release gates](TRANSPORT_CANDIDATE_20261031.md). Generic bounded
wire checks are reproduced into the formal wallet; bundle and installed release
are unchanged. This does not enable current-chain payments.

## Current release state

This delivery connects the existing full verifier and exact transport to the
formal background, wallet-owned final approval and page bridge. The checked-in
`src/market-native/installed.ts` remains **null**: no reviewed reset-chain market
release is installed, market financial routes remain closed, and NFT writes are
unconditionally closed. The user chose code-only continuation without unlocking
the dedicated extension. No actual extension approval, faucet grant, registration,
deployment, new proof or payment was performed by this milestone.

Historical prepare-only reports remain intact; this report supersedes their
source-wiring status, not their acceptance boundaries.

## Published application source and reproduction

The 22 embedded module/declaration files, bundle and inventory reproduce exactly
from the already-published application commit
[`6f1fe16b4eae7fb739252dbf999fdac0c4588b2f`](https://github.com/PsyProtocol/psy-template/commit/6f1fe16b4eae7fb739252dbf999fdac0c4588b2f).
Use that commit's `node market-client/wallet/vendor.mjs <fresh-output>` with the
declared Node 24 runtime; compare all 24 output files against
`src/market-preparation`. Optional reviewed input directories must be provided
as an explicit pair. Registry, ABI and RPC configuration hashes and exact network
domains are checked. No existing registry is rewritten.

The SDK remains `c92880c8b6e2c8d392f19368bc8801a2584fd427`, client
`b280d714a8f0930c61962c885374ea63ea63d274`, backend
`736572e9dd3ca93566471cf5a2a1cb67a13fe01d`. No dependency, lockfile or Node source
was changed. Build/typecheck/test used the existing selected cohort whose SDK
472-file distribution guard passes; an unrelated local sibling is not a valid
replacement SDK. The published application source is required to reproduce the
vendor set; branch names alone are insufficient provenance.

## Authority and approval

The background selects `createMarketWalletService` only when compiled static
resources match the reviewed registries and chain; otherwise it selects the
prepare-only service. The page cannot provide a verifier, transport, resource URL
or success report. Seven bounded public methods use the runtime sender's origin,
approved unlocked account and exact intent/request identity. Capability metadata
is not a financial authorization. Missing resources preserve readable history
and allow cancellation only of wholly unbroadcast preparations.

Final approval is an internal-only wallet action with a dedicated prompt. The
prompt binds the exact public plan/request, ordered calls, nonce, fee, expiry and
prepared identities. Primary visible limits cover swap, LP addition, both
withdrawal minima, whole-order input/output and Curve lots/quote limit; unsupported
policies reject. High-limb values remain exact strings. The selected context is
checked before and after approval. A busy approval queue rejects to avoid an
approval/transaction queue cycle. The ordinary transaction queue and existing
browser-origin persistent lock remain authoritative; no cross-machine claim is
made.

Native verification still requires actual call/caller/input/U124, session and
sig_hash evidence in addition to Endcap/common-data validity and endpoint checks.
No verification was replaced by an asserted trace field. Exact request/capsule
persistence precedes verification; exact send intent is persisted/read back before
one transport call. A timeout or ACK remains unknown. Only original-identity
receipt/state reconciliation can release a broadcast hold. No auto-resend,
replacement payment or generic transfer fallback was added. No private keys,
mnemonics or hydrated signing witnesses are included in public messages/evidence.

## Reviewed resource build tool

`scripts/install-market-release.mjs REVIEWED_INPUT_JSON FRESH_OUTPUT` is a
build-only inspector. The input names public bundle/pack/build/WASM/glue/type
files and a fixed public descriptor. It pins raw bytes, validates every active
market dependency and the exact registry set, reads large SDK integers losslessly,
and inspects the actual compiled binary identity via sealed glue. It emits a
fresh static module, assets and RELEASE.json; it does not activate that module,
change source, fetch, sign or broadcast. Activation requires a separate reviewed
source change and actual current-instance preflight/UPS/extension acceptance.

The positive build check used historical public resources and did not activate
them. Those resources bind the previous chain, not the reset instance. A
native-only current-chain pack cannot establish all market identities. NFT
collection/token/metadata/listing/price constraints still require a same-UPS
assertion; neither RPC display nor event payload replaces that condition.

## Checks and remaining acceptance

- Full selected-cohort wallet regression: 65 files, 728 passed, one existing skip.
- Fixed SDK/typecheck guard and staging build passed. Native WASM asset URL and
  large-chunk build warnings remain recorded; actual extension runtime loading
  was not verified by this build.
- Installer protocol tests: two passed; historical compiled identity inspection
  succeeded after retained lossless-parser failures.
- Application client/wallet/gateway suite: 95 passed; dapp market protocol: 50
  passed; dapp production build passed. These are not real trades.
- Static primary-limit markup, mock approval/router and exact transport tests do
  not establish browser runtime approval, original-chain recovery or network
  settlement. No performance comparison, real fill or actual fee sample exists
  for this milestone.

Next: declare the new-instance count/fee ledger, bind new QA identities and
candidate contracts, complete full UPS gates, install a matching reviewed release,
then accept the ordinary-wallet AMM journey before Curve, Book, NFT and two-pool
workflows. Retain original old-chain UNKNOWN records without replay on the reset
chain. Curve 11 remains historical quarantine. Runtime image attestation and
upgrade authorization/replay-rejection evidence remain external service-owner
deliveries. No production, chain TPS or general acceleration claim is made.

[Application report and full public evidence](https://github.com/PsyProtocol/psy-template/blob/6f1fe16b4eae7fb739252dbf999fdac0c4588b2f/docs/security/WALLET_FORMAL_INTEGRATION_20261027.md).
[Published-source reproduction inventory](formal-integration-20261027-v1/published-vendor-reproduction-v1.json).

## Application policy boundary follow-up

The coordinated wallet delivery vendors the exact 24 application modules and
declarations, plus bundle and SOURCE inventory (26 reproduced files), from
published application commit [40d1a212e85068f4c498579cc77d83f0b0323582](https://github.com/PsyProtocol/psy-template/commit/40d1a212e85068f4c498579cc77d83f0b0323582).
Market-kind/eligibility switches and binding limit construction now live in the
reviewed application adapter. Core and final renderer delegate to that compiled
module; they retain generic envelope/digest, account, queue, native proof, fresh
state, exact-send and original-recovery responsibilities. The page cannot inject
a policy, resource URL, verifier or broadcaster. New reviewed instances can use
existing supported policies without wallet business branches; new semantics still
require application policy, resources and full UPS acceptance.

The current null release and NFT quarantine remain closed. No browser session
was taken over, no live financial operation or new proof was performed, and no
current-chain UI/throughput/production claim is made. The candidate passed SDK
distribution/typecheck, 728 wallet cases with one existing skip, and staging
build. Application tests passed 99 cases. Earlier parser/type failures are
retained in the application evidence archive. UI markup is compiled but actual
extension rendering/approval remains unverified.

[Current capability matrix, composition migration gaps and evidence](https://github.com/PsyProtocol/psy-template/blob/40d1a212e85068f4c498579cc77d83f0b0323582/docs/security/VERIFIABLE_INTENT_EXECUTION_20261027.md).
[Exact published-source reproduction](policy-boundary-20261027-v1/vendor-reproduction.json).
