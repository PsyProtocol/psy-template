import {writeFile} from 'node:fs/promises';
const urls=['https://realm0-stg.psy-protocol.xyz','https://realm1-stg.psy-protocol.xyz','https://coordinator-stg.psy-protocol.xyz'];
const observations=[];
for(const [i,url]of urls.entries()){
 const request={jsonrpc:'2.0',id:i+1,method:'psy_get_checkpoint_leaf_data',params:{checkpoint_id:1}},start=performance.now(),row={url,request};
 try{const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),redirect:'manual',signal:AbortSignal.timeout(15000)});row.httpStatus=response.status;row.body=(await response.text()).slice(0,65536);}catch(e){row.error={name:e.name,message:e.message,cause:e.cause?.message,code:e.cause?.code};}
 row.milliseconds=performance.now()-start;observations.push(row);
}
const value={scope:'Second bounded read transport only, three CP-1 requests; original TLS failures retained, no retry loop or finance',rpcRequests:3,totalReadRequests:6,financialOperations:0,observations};
await writeFile(new URL('./public/CURRENT_READ_NODE-v1.json',import.meta.url),JSON.stringify(value,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(value));
