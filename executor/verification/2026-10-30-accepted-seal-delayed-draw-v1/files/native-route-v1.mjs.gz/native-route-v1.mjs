// Owned native CLI + actual durable Executor route. No signer or broadcaster.
import {readFile,writeFile}from'node:fs/promises';import{resolve,join}from'node:path';import assert from'node:assert/strict';
import{prepareSealedMinimumSourceStream}from'<application-root>/executor/randomSourceStream.mjs';
import{parseLosslessJson,losslessJson}from'<application-root>/amm/u124/client.mjs';
import{sha256}from'<application-root>/executor/requestBinding.mjs';
const c=resolve('.'),rows=[];assert.ok(process.argv.length>2);
for(const m of process.argv.slice(2)){
 assert.ok(['amm','bondingcurve'].includes(m));const d=join(c,'native-'+m+'-v3'),head=join(c,'full-ups-v3',m+'-sealed-minimum-1');
 const source=parseLosslessJson(await readFile(join(head,'source.json'),'utf8')),wallet=join(c,'bin-v8/minimum_stream_plan');
 const o={historyRoot:source.history.checkpoint_path.root,wallet,walletSha256:sha256(await readFile(wallet)),runtimeDirectory:join(c,'owned-route-'+m+'-v1')};
 for(const[n,p]of Object.entries({review:join(d,'review.json'),snapshot:join(head,'source.json'),draw:join(d,'derived/draw.json'),policy:join(c,'fixtures-v3',m,'stream-policy.json'),acceptedSeal:join(d,'derived/acceptedSeal.json')})){o[n]=p;o[n+'Sha256']=sha256(await readFile(p));}
 const route=await prepareSealedMinimumSourceStream(o),before=await route.plan();assert.equal(before.status.canBroadcast,false);assert.equal(before.status.sealedHistoryOrderVerified,true);
 const restarted=await prepareSealedMinimumSourceStream(o);assert.deepEqual((await restarted.plan()).plan,before.plan);
 const costs={availableFeeBudgetBaseUnits:'100000000000',maxFeePerUpsBaseUnits:'1000100000',recoveryUpsReserve:2,secondsPerUpsBound:90,checkpointSecondsLowerBound:1,checkpointReserve:10};
 const budget=await route.planBudget(costs);assert.equal(budget.drawWaitCheckpointsReserve,33);assert.throws(()=>route.authorizeSettlement(),/cannot enable writes/);
 const bad=parseLosslessJson(await readFile(o.acceptedSeal,'utf8'));bad.snapshot.fields[5]+=1n;const file=join(d,'route-reselection.json');await writeFile(file,losslessJson(bad)+'\n',{flag:'wx'});
 await assert.rejects(prepareSealedMinimumSourceStream({...o,acceptedSeal:file,acceptedSealSha256:sha256(await readFile(file))}),/immutable random source input changed/);
 assert.deepEqual((await route.plan()).plan,before.plan);
 rows.push({market:m,status:before.status,budget,exactRestartPlanPreserved:true,acceptedSealReplacementRejected:true,usesRealOwnedNativeHelper:true,financialOperations:0,ordinaryWalletClaims:0});
}
await writeFile(join(c,'public','EXECUTOR-NATIVE-'+process.argv.slice(2).join('-')+'-v1.json'),losslessJson({rows,financialOperations:0})+'\n',{flag:'wx'});console.log(rows.map(r=>({market:r.market,status:r.status})));
