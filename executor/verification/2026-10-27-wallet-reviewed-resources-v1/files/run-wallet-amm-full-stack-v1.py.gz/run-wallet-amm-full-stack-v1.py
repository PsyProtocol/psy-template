from pathlib import Path
import os,subprocess,json,time,datetime
m=Path(__file__).resolve().parent
s=m.parent/'sdk-mainnet-beta-20261027-v1'
env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','BATCH_BUILD':str(m/'wallet-amm-identities-fixtures-v1'),'BATCH_FIXTURE_ASSET_A':'6','BATCH_FIXTURE_ASSET_B':'7','BATCH_FIXTURE_NFT':'8','BATCH_FIXTURE_ISSUER':'1590272','BATCH_FIXTURE_SYMBOL_A':'5325121','BATCH_FIXTURE_SYMBOL_B':'5325122','BATCH_DISTINCT_TOKEN_B':'1','BATCH_EXPECTED_MARKET_CODE_ROOT':'92a5f666878fbb9c356fe63623714491c89d92953eef4a507bd594aed99320be','BATCH_FIXTURE_MARKET':'9','BATCH_FIXTURE_VAULT':'631808','MARKET_WALLET_TEST_MARKET':'amm','BATCH_ADMISSION_TEST':'1','BATCH_PROOF_PROFILE':'compact-v1','MARKET_WALLET_VERIFIER_OUT':str(m/'wallet-amm-full-stack-verifier-v1')})
cmd=['cargo','+nightly-2025-09-20','test','--release','--locked','--offline','--manifest-path',str(m/'application-wallet-v29/Cargo.toml'),'--test','batch_lifecycle','full_ups::wallet_proof::full_stack_wallet_verifier_and_mutations','--','--exact','--ignored','--nocapture']
start=time.monotonic()
with (m/'public/wallet-amm-full-stack-verifier-v1.log').open('x') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
with (m/'public/wallet-amm-full-stack-verifier-v1-exit.json').open('x') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'seconds':time.monotonic()-start,'command':cmd,'financialOperations':0},f,indent=2)
raise SystemExit(r.returncode)
