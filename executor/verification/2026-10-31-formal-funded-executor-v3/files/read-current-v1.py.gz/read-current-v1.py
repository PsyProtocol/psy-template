import json,time,urllib.request
from pathlib import Path
c=Path(__file__).resolve().parent
urls=['https://realm0-stg.psy-protocol.xyz','https://realm1-stg.psy-protocol.xyz','https://coordinator-stg.psy-protocol.xyz'];rows=[]
def read(url,method,params):
 body=json.dumps({'jsonrpc':'2.0','id':len(rows)+1,'method':method,'params':params}).encode();started=time.monotonic();row={'url':url,'request':json.loads(body)}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,data=body,headers={'content-type':'application/json'}),timeout=15)as r:row.update(httpStatus=r.status,response=json.loads(r.read(1048576)))
 except Exception as e:row['error']=str(e)
 row['seconds']=time.monotonic()-started;rows.append(row);return row.get('response',{}).get('result')
roots=[read(url,'psy_get_checkpoint_leaf_data',{'checkpoint_id':1}) for url in urls]
expected='919896e18690246e20307f68cf2e5725aee496755366bbafff88eccaea975f12'
matched=all(isinstance(r,dict)and r.get('global_chain_root')==expected for r in roots)
if matched:
 heads=[read(url,'psy_get_latest_l2_block_state',{}) for url in urls[:2]]
 if all(isinstance(r,dict)and isinstance(r.get('checkpoint_id'),int)for r in heads):
  cp=min(r['checkpoint_id']for r in heads)
  read(urls[2],'psy_get_contract_leaf_data',{'contract_id':8})
  read(urls[0],'psy_get_user_contract_state_tree_leaf_hash',{'checkpoint_id':cp,'user_id':223232,'contract_id':8,'leaf_id':0})
  read(urls[0],'psy_get_user_contract_state_tree_leaf_hash',{'checkpoint_id':cp,'user_id':223232,'contract_id':0,'leaf_id':0})
result={'schema':1,'chainRootMatched':matched,'rpcRequests':len(rows),'financialOperations':0,'fullPreflightPassed':False,'observations':rows}
with(c/'public/CURRENT_READ-v1.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'chainRootMatched':matched,'rpcRequests':len(rows),'observations':[{'method':r['request']['method'],'response':r.get('response'),'error':r.get('error')}for r in rows]}))
