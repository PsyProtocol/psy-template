// Read-only original-registration audit. No signing, proving or write RPC.
import{readFile,mkdir,writeFile,copyFile,chmod}from'node:fs/promises';import{execFileSync}from'node:child_process';import{fileURLToPath}from'node:url';import{createHash}from'node:crypto';import assert from'node:assert/strict';
import{parseLosslessJson,losslessJson}from'../../psy-template-security-20261016/amm/u124/client.mjs';
const base=new URL('./',import.meta.url),pub=new URL('public/',base),out=new URL('registration-checkpoint-v2/',pub);await mkdir(out);const who=JSON.parse(await readFile(new URL('qa-issuer-lp.json',pub))),plan=JSON.parse(await readFile(new URL('PLAN-v1.json',pub)));let seq=0;
const save=async(name,v)=>writeFile(new URL(name,out),typeof v==='string'?v:losslessJson(v)+'\n',{flag:'wx'});
async function rpc(url,method,params){assert.ok(method.startsWith('psy_get_'));const q={jsonrpc:'2.0',id:1,method,params},r=await fetch(url,{method:'POST',body:JSON.stringify(q),headers:{'content-type':'application/json'},redirect:'error',signal:AbortSignal.timeout(20000)});const raw=await r.text();await save(`${++seq}-${method}.json`,{url,request:q,httpStatus:r.status,responseText:raw});assert.equal(r.status,200);const v=parseLosslessJson(raw);assert.ok(!v.error);return v.result;}
const c='https://coordinator-stg.psy-protocol.xyz';const chain=await rpc(c,'psy_get_checkpoint_leaf_data',{checkpoint_id:1});assert.equal(chain.global_chain_root,plan.chainRootAt1);
const ids=await rpc(c,'psy_get_user_ids_for_public_key',[who.publicKeyHash,0,64]);assert.equal(ids.length,1);const id=ids[0];assert.equal(id,223232n);
await mkdir(new URL('drivers-v2/',base));const bin=new URL('drivers-v2/verify_registration_checkpoint',base);await copyFile(new URL('../sdk-mainnet-beta-20261027-v1/target/release/verify_registration_checkpoint',base),bin);await chmod(bin,0o700);
const index=BigInt(execFileSync(fileURLToPath(bin),['index',String(id)],{encoding:'utf8'}).trim());const heads=await Promise.all([0,1].map(n=>rpc(`https://realm${n}-stg.psy-protocol.xyz`,'psy_get_latest_l2_block_state',{})));const cp=heads.map(x=>x.checkpoint_id).reduce((a,b)=>a<b?a:b)-1n;assert.ok(cp>0n&&cp<4294967296n);
const head=await rpc(c,'psy_get_latest_l2_block_state',{});assert.ok(head.checkpoint_id>cp&&head.checkpoint_id<4294967296n);
const [proof,roots,leaf,user,treeRoot,anchorProof,checkpointProof]=await Promise.all([
 rpc(c,'psy_get_user_registration_tree_merkle_proof',{checkpoint_id:Number(cp),leaf_index:Number(index)}),
 rpc(c,'psy_get_checkpoint_global_state_roots',{checkpoint_id:Number(cp)}),
 rpc(c,'psy_get_checkpoint_leaf_data',{checkpoint_id:Number(cp)}),
 rpc(`https://realm${id/1048576n}-stg.psy-protocol.xyz`,'psy_get_user_leaf_data',{checkpoint_id:Number(cp),user_id:Number(id)}),
 rpc(c,'psy_get_checkpoint_tree_root',{checkpoint_id:Number(head.checkpoint_id)}),
 rpc(c,'psy_get_checkpoint_tree_merkle_proof',{checkpoint_id:Number(head.checkpoint_id),leaf_checkpoint_id:1}),
 rpc(c,'psy_get_checkpoint_tree_merkle_proof',{checkpoint_id:Number(head.checkpoint_id),leaf_checkpoint_id:Number(cp)})]);
const input={schema:2,checkpoint_id:cp,user_id:id,public_key:who.publicKeyHash,chain_anchor_leaf:chain,chain_anchor_proof:anchorProof,checkpoint_proof:checkpointProof,checkpoint_leaf:leaf,state_roots:roots,registration_proof:proof};await save('input.json',input);
execFileSync(fileURLToPath(bin),[plan.chainRootAt1,treeRoot,String(id),who.publicKeyHash,fileURLToPath(new URL('input.json',out)),fileURLToPath(new URL('verified.json',out))],{stdio:'pipe'});
const url='https://services-stg.psy-protocol.xyz/api/v1/get/user/transactions?user_id='+id+'&limit=100&offset=0';const r=await fetch(url,{signal:AbortSignal.timeout(20000)});const raw=await r.text();await save('indexed-registration-list.json',{url,httpStatus:r.status,responseText:raw});
const result=parseLosslessJson(raw);const event=result.data?.items?.find(e=>e.tx_type==='register_user'&&e.owner_user_id===id&&e.result?.user_id===id&&e.result?.public_key===who.publicKeyHash);
if(event){const u='https://services-stg.psy-protocol.xyz/api/v1/transaction/hash/'+event.content_hash;const res=await fetch(u,{signal:AbortSignal.timeout(20000)});const body=await res.text();await save('indexed-registration-receipt.json',{url:u,httpStatus:res.status,responseText:body});const value=parseLosslessJson(body);assert.equal(value.data?.status,'included');assert.equal(value.data?.content_hash,event.content_hash);assert.equal(value.data?.result?.public_key,who.publicKeyHash);assert.equal(value.data?.result?.user_id,id);}
await save('RESULT.json',{userId:id,publicKeyHash:who.publicKeyHash,checkpoint:cp,registrationIndex:index,registrationTreeVerified:true,checkpointMembershipVerified:true,checkpointTreeRoot:treeRoot,indexedReceiptMatched:Boolean(event),userStateInitialized:user.public_key!=='0'.repeat(64),faucetRequests:0,ordinaryUps:0,fullUpsVerified:false,financialUiWritesEnabled:false,verifierSha256:createHash('sha256').update(await readFile(bin)).digest('hex')});
console.log('registration membership verified; user initialization, faucet and full UPS remain separate');
