import os,sys,time,json,subprocess,signal
from pathlib import Path
case=Path(__file__).resolve().parent
sdk=case.parent/'sdk-mainnet-beta-20261027-v1'
label,limit=sys.argv[1],int(sys.argv[2])
env=os.environ.copy()
env.update(PSY_NETWORK='testnet',PSY_CONFIG_PATH=str(sdk/'source/psy-sdk/psy-genesis/config.json'),PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',CARGO_TARGET_DIR=str(sdk/'target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',GOROOT='/opt/homebrew/Cellar/go/1.26.0/libexec')
env['PATH']=env['GOROOT']+'/bin:'+env['PATH']
start=time.monotonic();samples=[];reason=None
with (case/(label+'.raw.log')).open('xb') as log:
 p=subprocess.Popen(sys.argv[3:],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True)
  rows=[tuple(map(int,r.split())) for r in rows.splitlines() if len(r.split())==3]
  ids={p.pid};changed=True
  while changed:
   old=len(ids);ids.update(pid for pid,parent,rss in rows if parent in ids);changed=len(ids)!=old
  rss=sum(rss for pid,parent,rss in rows if pid in ids);elapsed=time.monotonic()-start
  samples.append({'elapsedSeconds':elapsed,'familyRssKiB':rss})
  if elapsed>limit or rss>8388608:
   reason='deadline' if elapsed>limit else 'sampled RSS limit';os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(1)
 try: code=p.wait(timeout=10)
 except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);code=p.wait()
report={'exitCode':code,'elapsedSeconds':time.monotonic()-start,'stopReason':reason,'samples':samples,'sampledFamilyRssPeakKiB':max([s['familyRssKiB'] for s in samples],default=0),'memoryScope':'sampled process-family RSS; includes shared pages; not physical peak','financialOperations':0}
(case/'public'/(label+'-result.json')).write_text(json.dumps(report,indent=2)+'\n')
text=(case/(label+'.raw.log')).read_text(errors='replace').replace(str(case.parent),'<evidence-root>').replace(str(Path.home()),'<home>')
(case/'public'/(label+'.log')).write_text(text)
print(json.dumps({k:v for k,v in report.items()if k!='samples'}))
sys.exit(code if code>=0 else 1)
