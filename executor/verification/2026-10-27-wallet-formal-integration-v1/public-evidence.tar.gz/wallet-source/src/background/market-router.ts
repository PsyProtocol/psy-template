import type PsyWalletExtCore from "./psy-wallet-ext-core";
import {
  assertApprovedAccountForOrigin,
  assertWalletUnlocked,
} from "./security-gates";
import { marketActions } from "../market-native/actions";
export { marketActions } from "../market-native/actions";
type MarketCore = Pick<
  PsyWalletExtCore,
  | "isWalletLocked"
  | "getMarketWriteCapabilities"
  | "prepareMarketTransaction"
  | "verifyMarketPreparation"
  | "broadcastMarketPreparation"
  | "reconcileMarketPreparation"
  | "listMarketPreparations"
  | "cancelMarketPreparation"
>;
// Origin is supplied from Runtime.MessageSender by the background listener.
// No positional argument can replace it or install an execution adapter.
export async function routeMarketRequest(
  core: MarketCore,
  action: string,
  params: unknown[],
  origin: string | undefined,
) {
  if (action === "psy_getMarketWriteCapabilities") {
    if (params.length !== 0) throw Error("Capabilities take no page arguments");
    return core.getMarketWriteCapabilities();
  }
  const count =
    action === "psy_broadcastMarketPreparation"
      ? 3
      : action === "psy_listMarketPreparations"
        ? 1
        : 2;
  if (
    !marketActions.includes(action as (typeof marketActions)[number]) ||
    params.length !== count ||
    typeof params[0] !== "string" ||
    !/^[0-9a-f]{64}$/.test(params[0])
  )
    throw Error("Exact market request parameters required");
  const address = params[0];
  assertApprovedAccountForOrigin(origin, address);
  assertWalletUnlocked(core.isWalletLocked());
  if (action === "psy_listMarketPreparations")
    return core.listMarketPreparations(address, origin!);
  if (action === "psy_cancelMarketPreparation") {
    if (typeof params[1] !== "string" || !/^[0-9a-f]{64}$/.test(params[1]))
      throw Error("Exact original intent required");
    return core.cancelMarketPreparation(address, origin!, params[1]);
  }
  const capabilities = core.getMarketWriteCapabilities();
  if (
    capabilities.prepareOnly !== false ||
    capabilities.nativeFullCallVerifier !== true ||
    capabilities.broadcast !== true
  )
    throw Error(
      "Reviewed instance-specific wallet release is not installed; market writes remain closed",
    );
  if (action === "psy_prepareMarketTransaction") {
    if (!params[1] || typeof params[1] !== "object" || Array.isArray(params[1]))
      throw Error("Reviewed public plan record required");
    return core.prepareMarketTransaction(
      address,
      origin!,
      params[1] as Parameters<MarketCore["prepareMarketTransaction"]>[2],
    );
  }
  const intent = params[1];
  if (typeof intent !== "string" || !/^[0-9a-f]{64}$/.test(intent))
    throw Error("Exact original intent required");
  switch (action) {
    case "psy_verifyMarketPreparation":
      return core.verifyMarketPreparation(address, origin!, intent);
    case "psy_reconcileMarketPreparation":
      return core.reconcileMarketPreparation(address, origin!, intent);
    case "psy_broadcastMarketPreparation": {
      const hash = params[2];
      if (typeof hash !== "string" || !/^[0-9a-f]{64}$/.test(hash))
        throw Error("Exact prepared identity required");
      return core.broadcastMarketPreparation(address, origin!, intent, hash);
    }
    default:
      throw Error("Unsupported market request");
  }
}
