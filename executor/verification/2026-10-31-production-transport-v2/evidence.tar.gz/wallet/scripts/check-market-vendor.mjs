// Integrity of reviewed application source only; not financial authorization.
import assert from "node:assert/strict";
import { readFileSync, readdirSync, lstatSync } from "node:fs";
import { resolve, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

export function checkMarketVendor(directory) {
  assert.ok(
    lstatSync(directory).isDirectory() &&
      !lstatSync(directory).isSymbolicLink(),
    "Regular vendor directory required",
  );
  const walk = (name = "") =>
    readdirSync(join(directory, name), { withFileTypes: true }).flatMap(
      (entry) => {
        assert.ok(!entry.isSymbolicLink(), "Vendor links forbidden");
        const path = name ? name + "/" + entry.name : entry.name;
        return entry.isDirectory() ? walk(path) : [path];
      },
    );
  // Reject all links before opening any declared member.
  const actual = walk();
  const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
  const read = (name) => {
    const p = join(directory, name);
    assert.ok(
      lstatSync(p).isFile() && !lstatSync(p).isSymbolicLink(),
      "Regular vendor member required",
    );
    return readFileSync(p);
  };
  const source = JSON.parse(read("SOURCE.json"));
  assert.equal(source.schema, 1);
  assert.ok(
    Array.isArray(source.files) && source.files.length > 0,
    "Complete vendor inventory required",
  );
  const names = ["SOURCE.json", "bundle.json"];
  for (const entry of source.files) {
    assert.equal(typeof entry.file, "string");
    assert.ok(
      !entry.file.startsWith("/") &&
        entry.file.split(/[\\/]/).every((p) => p && p !== "." && p !== ".."),
      "Confined vendor member required",
    );
    assert.match(entry.sha256, /^[0-9a-f]{64}$/);
    assert.equal(
      sha(read(entry.file)),
      entry.sha256,
      "Generated vendor bytes changed: " + entry.file,
    );
    names.push(entry.file);
  }
  assert.equal(new Set(names).size, names.length, "Duplicate vendor member");
  assert.deepEqual(
    actual.sort(),
    names.sort(),
    "Exact vendor inventory required",
  );
  const bytes = read("bundle.json");
  assert.equal(sha(bytes), source.bundleSha256, "Reviewed bundle changed");
  const bundle = JSON.parse(bytes);
  assert.equal(
    bundle.registry.sdkManifestSha256,
    source.requiredSdkManifestSha256,
  );
  return {
    schema: 1,
    members: source.files.length,
    bundleSha256: source.bundleSha256,
    financialAuthorization: false,
  };
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const root = resolve(fileURLToPath(new URL("../", import.meta.url)));
  console.log(
    JSON.stringify(checkMarketVendor(join(root, "src/market-preparation"))),
  );
}
