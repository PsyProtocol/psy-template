import bundle from "@/market-preparation/bundle.json";
import { useEffect, useState } from "react";
import type { ApprovePreparedMarketMsg } from "@/types";
import { usePsyStateSelector } from "@/hooks/use-psy-state";
import { sendApproveResult } from "@/message";
import { MarketLimitRows } from "@/market-native/LimitRows";
import { marketConfirmation } from "@/market-native/confirmation";
import {reviewMarketConfirmation,type MarketApprovalReview} from "@/market-preparation/market-client/wallet/approvalPolicy.mjs";
import {
  ApproveShell,
  ApproveHero,
  ApproveOriginCard,
  ApproveAccountCard,
  DetailDisclosure,
} from "../approve-ui";
import { Icons } from "@/components/ui/icons";

export default function ApproveMarket({
  msg,
}: {
  msg: ApprovePreparedMarketMsg;
}) {
  const [account, terms, expected] = msg.params;
  const { wallets } = usePsyStateSelector("wallets");
  const wallet = wallets.find((w) => w.address === account);
  const [valid, setValid] = useState(false);
  const [review, setReview] = useState<MarketApprovalReview | null>(null);
  useEffect(() => {
    let live = true;
    void marketConfirmation(terms)
      .then(async (v) => {
        const reviewed = await reviewMarketConfirmation(v.terms, bundle);
        if (live) {
          setValid(
            v.approvalSha256 === expected && account === terms.context.account,
          );
          setReview(reviewed);
        }
      })
      .catch(() => {
        if (live) setValid(false);
      });
    return () => {
      live = false;
    };
  }, [account, terms, expected]);
  const deny = () => {
    void sendApproveResult(
      msg.id,
      null,
      "User rejected exact market transaction",
    ).finally(window.close);
  };
  const allow = async () => {
    const checked = await marketConfirmation(terms);
    if (
      !valid ||
      !wallet ||
      !review ||
      checked.approvalSha256 !== expected
    )
      throw Error("Exact market approval changed");
    await sendApproveResult(
      msg.id,
      { approved: true, approvalSha256: expected },
      null,
    );
    window.close();
  };
  const plan = terms.review.plan;
  return (
    <ApproveShell
      onCancel={deny}
      onConfirm={allow}
      confirmDisabled={!valid || !wallet || !review}
      cancelLabel="Reject"
      confirmLabel="Approve exact transaction"
      footerNote="Approval permits one exact send after fresh checks. Confirmation and asset claim are separate steps."
    >
      <ApproveHero
        icon={<Icons.security className="h-7 w-7" />}
        eyebrow="Verified transaction intent"
        title="Approve transaction intent"
        subtitle="Review the account, limits and exact request before broadcast."
      />
      <ApproveOriginCard origin={terms.context.origin} />
      {wallet && (
        <ApproveAccountCard
          address={wallet.address}
          name={wallet.name}
          userId={wallet.userId}
        />
      )}
      {review && <>
        <MarketLimitRows rows={review.rows}/>
        <div className="rounded-2xl border border-borderGray p-4 text-sm">
          <p className="mb-2">Assets: {review.assets.map(a=>`contract ${a.contractId} (${a.decimals} decimals)`).join(" / ")}</p>
          <p className="font-medium">Maximum asset debits</p>
          <MarketLimitRows rows={review.debits}/>
          <MarketLimitRows rows={review.limits}/>
        </div>
      </>}
      <p className="text-sm text-black2">
        A submitted order is not a completed trade. Outputs remain pending until
        settlement and claim.
      </p>
      <DetailDisclosure summary="Exact approved plan and ordered calls">
        <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-all text-xs">
          {JSON.stringify(
            { request: terms.review.request, plan, calls: terms.fullCalls },
            null,
            2,
          )}
        </pre>
      </DetailDisclosure>
      <DetailDisclosure summary="Transaction identity">
        <pre className="whitespace-pre-wrap break-all text-xs">
          {JSON.stringify(
            {
              requestSha256: terms.requestSha256,
              preparedHash: terms.preparedHash,
              approvalSha256: expected,
              chainRootAt1: plan.network.chainRootAt1,
            },
            null,
            2,
          )}
        </pre>
      </DetailDisclosure>
    </ApproveShell>
  );
}
