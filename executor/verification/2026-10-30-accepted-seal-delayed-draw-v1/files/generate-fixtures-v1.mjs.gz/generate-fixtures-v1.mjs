import {mkdir,cp,readFile,writeFile} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {generateSealedMinimumStream} from '<application-root>/batching/checkpoint-stream/sealed-generate.mjs';
import {makeStreamPolicy} from '<application-root>/batching/checkpoint-stream/build-policy.mjs';
const read=async p=>JSON.parse(await readFile(p,'utf8'));
const prior='../minimum-vault-bootstrap-20261030-v1/fixtures-v1',root='fixtures-v1';
await mkdir(root);for(const n of ['native.json','token','nft'])await cp(prior+'/'+n,root+'/'+n,{recursive:true,errorOnExist:true,force:false});
const constants=await read('../minimum-stream-integration-20261030-v1/public/MINIMUM-CONSTANTS-v1.json');
for(const m of ['amm','bondingcurve']){
 await mkdir(root+'/'+m);const cfg=await read(prior+'/'+m+'/config.json');await writeFile(root+'/'+m+'/config.json',JSON.stringify(cfg,null,2)+'\n',{flag:'wx'});
 const src=root+'/'+m+'/contract.psy';await writeFile(src,generateSealedMinimumStream(m,cfg,constants),{flag:'wx'});
 const log=execFileSync('./bin-v2/compile_minimum_stream',[src,root+'/'+m+'/compiled','42','43'],{maxBuffer:3000000});await writeFile('public/'+m+'-compile-v1.log',log,{flag:'wx'});
 const p=makeStreamPolicy(m,1000,cfg,await read(root+'/'+m+'/compiled/compilation_artifact.json'),await read(root+'/token/compilation_artifact.json'),await read(root+'/nft/compilation_artifact.json'),{random:true,minimum:true,bootstrap:true,sealed:true,window:8192});
 for(const[n,v]of [['policy.json',p.base],['stream-policy.json',p]])await writeFile(root+'/'+m+'/'+n,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
}
