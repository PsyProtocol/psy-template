from pathlib import Path
import json,hashlib
c=Path(__file__).resolve().parent;r=c/'full-ups-v3';rows={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for market,phases in [('amm',['fresh-bootstrap']),('bondingcurve',['fresh-bootstrap','curve-initialize'])]:
 report=json.loads((r/(market+'-REPORT.json')).read_text());assert report['fullUpsVerified']and not report['broadcast']and not report['normalWalletClaims']
 for phase in phases:
  d=r/(market+'-'+phase);v=json.loads((d/'verification.json').read_text());q=json.loads((d/'request.json').read_text());p=json.loads((d/'plan.json').read_text());s=json.loads((d/'public-session.json').read_text());core=q['user_ec_input']['core']
  assert v['fullUpsVerified']and v['fixedVerifier']and not v['broadcast'];assert v['keyFingerprint']==report['keyFingerprint']==s['keyFingerprint'];assert len(s['stack'])==40 and v['calls']==len(s['actualCalls'])==int(s['txCount'])
  assert core['state_transition']['start_user_leaf_hash']==v['storedStartLeaf'];assert s['session']['start_user_leaf_hash']==v['signatureStartLeaf']
  assert int(core['stats']['guta_fees_collected'])+int(core['stats']['da_fees_collected'])==v['fee'];assert v['fee']==1000000000+1000*v['slots']
  assert s['actualCalls'][-2]['inputs']==[v['fee'],*p['registered_key']];assert s['actualCalls'][-1]['inputs']==[v['fee']]
  if phase=='fresh-bootstrap':
   assert v['firstUse']and v['storedStartLeaf']=='0'*64 and int(core['new_user_leaf']['nonce'])==1
   assert v['signatureStartLeaf']!='0'*64 and int(s['session']['start_user_leaf']['nonce'])==0
   assert [x['method_name']for x in s['actualCalls']]==['claim','claim','claim','activate_batch_vault','transfer','transfer','apply_fee_grant','claim','account_executor_fee','burn']
   assert 'first-use-grant-only-preemption'in v['keyAttackRejections'] and 'current-chain-anchor'in v['keyAttackRejections'] and 'signature-network-domain'in v['keyAttackRejections']
  else:
   first=rows[market+'-fresh-bootstrap'];assert not v['firstUse'] and v['storedStartLeaf']==first['endLeaf'] and int(core['new_user_leaf']['nonce'])==2
  rows[market+'-'+phase]={**{k:v[k]for k in ['keyFingerprint','calls','logicalSlots','fee','slots','firstUse','storedStartLeaf','signatureStartLeaf','endLeaf','seconds','keySeconds','endcapAndAuditSeconds','keyAttackRejections']},'finalNonce':int(core['new_user_leaf']['nonce']),'publicFiles':{n:sha(d/n)for n in ['request.json','plan.json','verification.json','public-session.json','key-proof.bin']}}
result={'scope':'public structural consistency only; native complete proof verification is separately recorded, no live receipt or ordinary signature implied','completeSyntheticUps':3,'ordinaryPrerequisitesSigned':False,'liveBroadcasts':0,'ordinaryWalletClaims':0,'cryptographicVerificationPerformedByThisScript':False,'rows':rows}
with(c/'public/STARTUP-AUDIT-v1.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'completeSyntheticUps':3,'rows':list(rows),'liveBroadcasts':0}))
