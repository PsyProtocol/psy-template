from pathlib import Path
import json,subprocess
c=Path(__file__).resolve().parent;d=c/'public/funding-status-v1';d.mkdir();cp=min(json.loads((c/'public/rpc-precheck-v1/SUMMARY.json').read_text())['heads'].values())
def put(n,v):
 with(d/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
put('PLAN.json',{'maximumReadOnlyRequests':2,'retries':0,'financialOperations':0,'recipient':223232,'checkpoint':cp,'originalRequestSha256':'85332da2e78775c0653737658234df46df80a5e326ee3440afb81879ba2d286d','mayResendOriginal':False})
queries=[('registration','https://coordinator-stg.psy-protocol.xyz',{'jsonrpc':'2.0','id':1,'method':'psy_get_user_ids_for_public_key','params':['97a9f5724e2f2ea4a7a59c884b9e6f79c7978016629519bae26e96e8b681d834',0,64]}),('leaf','https://realm0-stg.psy-protocol.xyz',{'jsonrpc':'2.0','id':2,'method':'psy_get_user_leaf_data','params':{'checkpoint_id':cp,'user_id':223232}})]
for label,url,q in queries:
 put(label+'-request.json',{'url':url,'request':q});p=subprocess.run(['curl','--silent','--show-error','--connect-timeout','5','--max-time','15','--max-filesize','1048576','--header','content-type: application/json','--data-binary','@-',url],input=json.dumps(q).encode(),capture_output=True,timeout=20);(d/(label+'-response.raw')).write_bytes(p.stdout);put(label+'-transport.json',{'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace')})
 if not p.returncode:put(label+'-result.json',json.loads(p.stdout))
