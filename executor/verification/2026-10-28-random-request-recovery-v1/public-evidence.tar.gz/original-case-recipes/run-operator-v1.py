from pathlib import Path
import json,subprocess,hashlib
b=Path(__file__).resolve().parent;a=b.parent.parent/'psy-template-security-20261016';node='/Users/geir/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node'
h=lambda n:format(n,'064x')
c={'version':1,'networkMagic':'1384803358401154921','market':'amm','marketId':'1000','vaultId':'100','epoch':'1','cutoff':'100','sealByCheckpoint':'110','drawCheckpoint':'120','round':'3','settleUntil':'150','recoveryAt':'160','maxFee':'2000200000','sourceId':h(1),'chainRootAt1':h(2),'codeRoot':h(3),'layoutRoot':h(4),'functionRoot':h(5),'keyFingerprint':h(6),'publicKeyHash':h(7),'queueRoot':h(8),'batchRoot':h(9),'members':[{'owner':str(200+i),'nonce':str(i+1),'termsRoot':h(i+10)}for i in range(2)]}
e={'format':'psy-market-beacon-certificate-v1','sourceId':c['sourceId'],'chainRootAt1':c['chainRootAt1'],'round':c['round'],'drawCheckpoint':c['drawCheckpoint'],'sealIncludedCheckpoint':'105','seed':h(13),'beaconProof':'AAAA','sealInclusionProof':'AAAA','finalityProof':'AAAA'}
for name,value in [('candidate',c),('envelope',e),('changed',{**c,'round':'4'})]:
 with (b/'public'/f'{name}-v1.json').open('x')as out:json.dump(value,out,indent=2);out.write('\n')
rows=[]
for label,action,input_name,extra,expected in [('fixed','freeze','candidate',[],0),('restart-inspect','inspect','candidate',[],0),('evidence','observe','candidate',[str(b/'public/envelope-v1.json')],0),('timeout','timeout','candidate',['160'],0),('recovery','recovery-plan','candidate',[],0),('reselect-rejected','freeze','changed',[],1)]:
 report=b/'public'/f'operator-{label}-v1.json';cmd=[node,str(a/'executor/randomCandidate.mjs'),action,str(b/'operator-ledger-v1'),str(b/'public'/f'{input_name}-v1.json'),str(report),*extra]
 p=subprocess.run(cmd,cwd=a,capture_output=True,timeout=20)
 with (b/'public'/f'operator-{label}-v1.log').open('xb')as out:out.write(p.stdout+p.stderr)
 assert p.returncode==expected,(label,p.stderr)
 if expected==0:
  value=json.loads(report.read_text());assert not any(value[k]for k in ['chainSealVerified','qualifiedSource','randomAuthorization','canSign','canBroadcast','canRefund']);assert value['financialOperations']==0
 rows.append({'label':label,'command':cmd,'exitCode':p.returncode,'financialOperations':0,'proofsGenerated':0})
with (b/'public/operator-result-v1.json').open('x')as out:json.dump({'schema':1,'scope':'separate real CLI processes and persistent local synthetic records; no chain or beacon verification','commands':rows,'financialOperations':0,'proofsGenerated':0},out,indent=2);out.write('\n')
print('Five separate-process operator commands pass; changed draw rejected; all financial permissions false.')
