// Tests the formal wallet's reproduced module, not a page-supplied verifier.
import { describe, it, expect } from "vitest";
import {
  RpcProtocolError,
  rpcEnvelope,
  readBoundedUtf8,
} from "../market-preparation/market-client/rpcWire.mjs";

describe("wallet-owned reproduced transport framing", () => {
  it("rejects unrelated ACK identities and contradictory outcomes", () => {
    for (const response of [
      { jsonrpc: "2.0", id: 2, result: "expected-endpoint" },
      { jsonrpc: "1.0", id: 1, result: "expected-endpoint" },
      { jsonrpc: "2.0", id: 1, result: "expected-endpoint", error: null },
    ])
      expect(() => rpcEnvelope(response)).toThrow(RpcProtocolError);
    expect(
      rpcEnvelope({ jsonrpc: "2.0", id: 1n, result: 4611686018427387921n })
        .result,
    ).toBe(4611686018427387921n);
  });

  it("enforces byte limits and rejects malformed UTF-8 in the installed source", async () => {
    await expect(readBoundedUtf8(new Response("é"), 1)).rejects.toThrow(
      /limit/,
    );
    await expect(
      readBoundedUtf8(new Response(new Uint8Array([0xff])), 10),
    ).rejects.toThrow(/UTF-8/);
    await expect(readBoundedUtf8(new Response("é"), 2)).resolves.toBe("é");
  });
});
