import{readFile,mkdir,writeFile}from'node:fs/promises';
import{receiptReader}from'../../psy-template-security-20261016/executor/chainReceipts.mjs';
import{losslessJson,parseLosslessJson}from'../../psy-template-security-20261016/amm/u124/client.mjs';
import{decodeFeltSlot}from'../../psy-template-security-20261016/orderbook/matcherCore.mjs';
const base=new URL('./',import.meta.url),out=new URL('grant-confirmation-v2/',base);await mkdir(out,{mode:0o700});const save=(n,v)=>writeFile(new URL(n,out),losslessJson(v)+'\n',{flag:'wx'});
const ack=parseLosslessJson(await readFile(new URL('authorized-repeat-v1/RESULT.json',base),'utf8')).ack;if(!ack||ack.already_submitted||ack.amount!=='1000000000000')throw Error('Grant ACK invalid');
await save('PLAN.json',{schema:1,maximumReadRequests:40,maximumHistoryPages:2,financialOperations:0,originalFaucetOutcome:'unresolved',newGrantConfirmed:false});
let reads=0;async function observed(url,options){const i=++reads;if(i>40)throw new RangeError('Grant confirmation budget');await save(i+'-request.json',{url,method:options?.method??'GET',body:options?.body?JSON.parse(options.body):null});const r=await fetch(url,{...options,redirect:'manual',signal:AbortSignal.timeout(20000)});let n=0,parts=[];for await(const b of r.body){n+=b.length;if(n>1048576)throw Error('Read response limit');parts.push(b);}const raw=Buffer.concat(parts);await writeFile(new URL(i+'-response.json',out),raw,{flag:'wx'});return{ok:r.ok,status:r.status,json:async()=>JSON.parse(raw)};}
const config=new URL('public/rpc.json',base).pathname;
// Avoid URL-escaped filesystem paths when loading the frozen config.
const{fileURLToPath}=await import('node:url');const reader=await receiptReader(fileURLToPath(new URL('public/rpc.json',base)),{fetchImpl:observed,maxPages:2});
const result=await reader({userId:Number(ack.operator_user_id),endUserLeafHash:ack.tx_hash,minCheckpoint:Number(ack.checkpoint_id)});await save('RECEIPT.json',result);
if(result.status!=='included'){await save('SUMMARY.json',{confirmed:false,spendable:false,requests:reads,originalOutcomeResolved:false});console.log('Grant original identity remains unresolved; no claim');process.exit(2);}
async function rpc(endpoint,method,params){const r=await observed(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params})});const v=await r.json();if(!r.ok||v.error||v.id!==1)throw Error('Grant RPC rejected');return v.result;}
const checkpoint=result.checkpoint,sender=Number(ack.operator_user_id),recipient=223232;
const anchor=await rpc('https://coordinator-stg.psy-protocol.xyz','psy_get_checkpoint_leaf_data',{checkpoint_id:1});if(anchor.global_chain_root!=='919896e18690246e20307f68cf2e5725aee496755366bbafff88eccaea975f12')throw Error('Wrong grant chain');
const sentSlot=3+2*recipient,claimedSlot=4+2*sender;
const sent=decodeFeltSlot(await rpc('https://realm1-stg.psy-protocol.xyz','psy_get_user_contract_state_tree_leaf_hash',{checkpoint_id:checkpoint,user_id:sender,contract_id:0,leaf_id:Math.floor(sentSlot/4)}),sentSlot);
const claimed=decodeFeltSlot(await rpc('https://realm0-stg.psy-protocol.xyz','psy_get_user_contract_state_tree_leaf_hash',{checkpoint_id:checkpoint,user_id:recipient,contract_id:0,leaf_id:Math.floor(claimedSlot/4)}),claimedSlot);
if(sent-claimed!==1000000000000n)throw Error('Exact grant cursor mismatch');
await save('SUMMARY.json',{schema:1,confirmed:true,spendable:false,recipient,sender,checkpoint,endUserLeafHash:ack.tx_hash,contentHash:result.contentHash,sent,claimed,pending:sent-claimed,requests:reads,ordinaryClaimRequired:true,originalFaucetOutcomeResolved:false,financialOperations:0});console.log(losslessJson({confirmed:true,spendable:false,sender,recipient,checkpoint,pending:sent-claimed,contentHash:result.contentHash,requests:reads}));
