import ApproveMarket from "./approve-market";
import { ApproveMsg } from "@/types";
import ApproveConnect from "./approve-connect";
import ApproveTransaction from "./approve-tx";
import ApproveDeployContract from "./approve-deploy-contract";
import ApproveShieldDeposit from "./approve-shield-deposit";
import ApproveClaimWithExternalProof from "./approve-claim-with-external-proof";
import ApproveGeneric from "./approve-generic";
import ApproveShieldAddress from "./approve-shield-address";

export default function ApprovePanel({ msg }: { msg: ApproveMsg }) {
  if (msg.action === "psy_confirmPreparedMarket") return <ApproveMarket msg={msg}/>;
  if (
    msg.action === "psy_requestAccounts" ||
    msg.action === "psy_requestPermissions"
  ) {
    return <ApproveConnect msg={msg} />;
  }

  if (msg.action === "psy_sendTransaction") {
    return <ApproveTransaction msg={msg} />;
  }

  // psy_execClaimBatch + psy_execClaimBatchAndPrivateTransfer reuse the
  // same transaction-approval surface: the inner ApproveTransaction
  // flattens ClaimBatchItem[] (and the optional private-send request)
  // into a display-only ContractCallArgs list, so the user reviews each
  // action exactly as they would with a multi-call psy_sendTransaction.
  // Real execution still runs through approve-manager's typed dispatch
  // with the original batch — the flattening is purely visual.
  if (
    msg.action === "psy_execClaimBatch" ||
    msg.action === "psy_execClaimBatchAndPrivateTransfer"
  ) {
    return <ApproveTransaction msg={msg} />;
  }

  if (msg.action === "psy_deployContract") {
    return <ApproveDeployContract msg={msg} />;
  }

  if (msg.action === "psy_claimShieldDeposit") {
    return <ApproveShieldDeposit msg={msg} />;
  }

  if (msg.action === "psy_claimWithExternalProof") {
    return <ApproveClaimWithExternalProof msg={msg} />;
  }

  if (
    msg.action === "psy_listShieldReceiveAddresses" ||
    msg.action === "psy_deriveShieldAddress"
  ) {
    return <ApproveShieldAddress msg={msg} />;
  }

  // if (msg.action === "psy_claimRewards") {
  //   return <ApproveClaimRewards msg={msg} />;
  // }

  return <ApproveGeneric msg={msg} />;
}
