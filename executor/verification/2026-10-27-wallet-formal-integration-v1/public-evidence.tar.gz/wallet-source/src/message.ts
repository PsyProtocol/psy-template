import {marketActions} from "./market-native/actions";
import browser from "webextension-polyfill";
import { PsyJSON } from "@psy-protocol/psy-sdk";
import type {
  IPsyStateDispatch,
  IPsyState,
} from "./background/psy-wallet-ext-core";
import type {
  ApproveMsg,
  IPsyAccountsApprovedState,
  IPsyTokensState,
  IPsyTxState,
  PsyInternalRequest,
} from "./types";

export const approveActions = [
  "psy_requestAccounts",
  "psy_requestPermissions",
  "psy_sendTransaction",
  "psy_deployContract",
  "psy_deriveShieldAddress",
  "psy_claimShieldDeposit",
  "psy_claimWithExternalProof",
  // Unified UPS surfaces — heterogeneous ClaimBatchItem[] folded into one
  // recursive proof, surfaced through one approve popup. Handlers live in
  // approve-manager.ts's executeApprovedAction switch; the popup UI
  // reuses ApproveTransaction with claimBatchItemToDisplayArg flattening.
  //
  // Listing here is load-bearing: main.ts:215 silently drops actions that
  // aren't in the `actions` superset (`approveActions` feeds into that
  // superset). Without these two names below, the bridge's psy.request
  // call just hangs — the message is swallowed, no popup, no error
  // response — and the dApp is stuck on its in-flight UI until the
  // 10-minute webHook timeout.
  "psy_execClaimBatch",
  "psy_execClaimBatchAndPrivateTransfer",
] as const;
export const actions = [
  ...marketActions,
  ...approveActions,
  "psy_accounts",
  "psy_getPermissions",
  "psy_getNetworkConfig",
  "psy_listShieldReceiveAddresses",
  "psy_resolveShieldReceiveAddress",
  "psy_getClaimRewardsCallArgs",
  "psy_getUserId",
  "psy_simulateContractCall",
  "psy_decryptNostrContent",
  "psy_getNostrNpub",
  // Read-only, secrets-free claimables summary for approved dApps — the
  // bridge's replacement for the (web-revoked) Nostr note drain. Handled
  // inline in main.ts with approved-origin + unlock gates; returns
  // kind/id/contractId/amount only (see core.listClaimablesForDapp).
  "psy_listClaimables",
  "psy_getWalletBuildInfo",
  "psy_addExternalProof",
  "psy_completeFaucetTurnstile",
  "psy_closeFaucetVerificationTab",
  "psy_provePrivateNoteInclusion",
  "psy_proveDepositInclusion",
] as const;

export async function sendApproveResult(
  id: string,
  result: any,
  error: any = null,
) {
  if (result !== null) {
    result = PsyJSON.stringify(result);
  }

  if (error && typeof error !== "string") {
    error = error.message || String(error);
  }

  try {
    browser.runtime.sendMessage({
      action: "approval-result",
      isPsy: true,
      id,
      result,
      error,
    });
  } catch (e: any) {
    console.warn("[psy-wallet][approve] sendMessage failed:", e);
  }
  return new Promise((rsv) => {
    setTimeout(rsv, 100);
  });
}

let id = 9999;

// background send to psy state
export const STATE_DISPATCH_ACTION = "psy_state_dispatch";
export async function psyStateDispatch(state: Partial<IPsyState>) {
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: STATE_DISPATCH_ACTION,
      isPsy: true,
      state: PsyJSON.stringify(state),
    })
    .catch((_) => {});
}

// send to src/background/psy-wallet-ext-core
export const PSY_INTERNAL_REQUEST_ACTION = "psy_internal_request";
export function psyInternalRequest<T extends keyof IPsyStateDispatch>(
  type: T,
  params?: Parameters<IPsyStateDispatch[T]>,
): ReturnType<IPsyStateDispatch[T]> {
  try {
    if (!browser.runtime.id) throw new Error("Connection interrupted");
    // @ts-ignore
    return browser.runtime
      .sendMessage({
        id: `psy_request_${++id}`,
        action: PSY_INTERNAL_REQUEST_ACTION,
        type,
        isPsy: true,
        params: params ? PsyJSON.stringify(params) : "[]",
      } as PsyInternalRequest)
      .then((res: any) => {
        // Error envelope from the background's internal-request handler.
        // The background can't re-throw (a rejected onMessage listener
        // promise gets logged by Chrome as an extension error and reaches
        // us with an "Uncaught Error: " prefix), so expected failures come
        // back as this shape and are converted into a clean rejection here.
        if (res && typeof res === "object" && "__psyInternalError" in res) {
          throw new Error(String(res.__psyInternalError));
        }
        if (res !== undefined && res !== null) {
          return typeof res === "string" ? PsyJSON.parse(res) : res;
        }
      });
  } catch (e) {
    // @ts-ignore
    return new Promise((rsv, rej) => rej(e));
  }
}

export const PSY_APPROVE_MSG_DISPATCH_ACTION = "psy_approve_msg_dispatch";

export async function psyApproveMsgDispatch(state?: Partial<ApproveMsg>) {
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: PSY_APPROVE_MSG_DISPATCH_ACTION,
      isPsy: true,
      state,
    })
    .catch((error) => {
      if (
        error.message !==
        "Could not establish connection. Receiving end does not exist."
      ) {
        console.warn("psy tx dispatch Error: ", error);
      }
    });
}

export const PSY_TX_STATE_DISPATCH_ACTION = "psy_tx_state_dispatch";
export async function psyTxStateDispatch(state: Partial<IPsyTxState>) {
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: PSY_TX_STATE_DISPATCH_ACTION,
      isPsy: true,
      state: PsyJSON.stringify(state),
    })
    .catch((error) => {
      if (
        error.message !==
        "Could not establish connection. Receiving end does not exist."
      ) {
        console.warn("psy tx dispatch Error: ", error);
      }
    });
}

export const PSY_ACCOUNTS_APPROVE_DISPATCH_ACTION =
  "psy_accounts_approved_dispatch";

export async function psyAccountsApproveDispatch(
  state: Partial<IPsyAccountsApprovedState>,
) {
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: PSY_ACCOUNTS_APPROVE_DISPATCH_ACTION,
      isPsy: true,
      state,
    })
    .catch((error) => {
      if (
        error.message !==
        "Could not establish connection. Receiving end does not exist."
      ) {
        console.warn("psy tx dispatch Error: ", error);
      }
    });
}

export const PSY_TOKENS_STATE_DISPATCH_ACTION = "psy_tokens_state_dispatch";

export async function psyTokenStateDispatch(state: IPsyTokensState["tokens"]) {
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: PSY_TOKENS_STATE_DISPATCH_ACTION,
      isPsy: true,
      state,
    })
    .catch((error) => {
      if (
        error.message !==
        "Could not establish connection. Receiving end does not exist."
      ) {
        console.warn("psy tx dispatch Error: ", error);
      }
    });
}

export async function psyTokenStateChange(
  tokens: IPsyTokensState["tokens"],
  oldTokens: IPsyTokensState["tokens"],
) {
  if (JSON.stringify(tokens) === JSON.stringify(oldTokens)) return;
  return browser.runtime
    .sendMessage({
      id: `psy_dispatch_${++id}`,
      action: PSY_TOKENS_STATE_DISPATCH_ACTION + "_to_background",
      isPsy: true,
      tokens,
    })
    .catch((error) => {
      if (
        error.message !==
        "Could not establish connection. Receiving end does not exist."
      ) {
        console.warn("psy tx dispatch Error: ", error);
      }
    });
}
