from pathlib import Path
import json,subprocess,hashlib
c=Path(__file__).resolve().parent;d=c/'public/checkpoint-current-v2';d.mkdir()
heads=json.loads((c/'public/rpc-precheck-v1/SUMMARY.json').read_text())['heads'];cp=min(heads.values());q=[{'jsonrpc':'2.0','id':n,'method':'psy_get_checkpoint_state_transition_proof','params':{'checkpoint_id':n}}for n in [cp-1,cp]]
def put(name,v):
 with(d/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
put('PLAN.json',{'maxReadOnlyRequests':2,'maximumAttempts':1,'supersedesTransportOnly':'v1 retained; failed return-code assertion before JSON decode; stderr was not retained by that old harness','financialOperations':0,'selectedVerifier':'unchanged frozen cached resources; no alternate key'})
put('request.json',q)
p=subprocess.run(['curl','--silent','--show-error','--max-time','25','--connect-timeout','5','--max-filesize','4194304','--header','content-type: application/json','--data-binary','@-','https://coordinator-stg.psy-protocol.xyz'],input=json.dumps(q).encode(),capture_output=True,timeout=30)
(d/'response.raw').write_bytes(p.stdout);put('transport.json',{'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace'),'bytes':len(p.stdout)})
if p.returncode:raise SystemExit('Read failed; original preserved; no retry')
v=json.loads(p.stdout);assert isinstance(v,list)and len(v)==2
for row in v:
 assert 'result'in row,row;data=bytes(row['result']);assert 0<len(data)<=2000000;(d/(str(row['id'])+'.bin')).write_bytes(data)
binary=c.parent/'sdk-mainnet-beta-20261027-v1/target/release/diagnose_checkpoint_resources';put('binary.json',{'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'existingFrozenCohortDiagnostic':True})
r=subprocess.run([str(binary),'cached',str(d/(str(cp-1)+'.bin')),str(d/(str(cp)+'.bin')),str(d/'verified.json')],capture_output=True,text=True,timeout=60);(d/'diagnostic.log').write_text(r.stdout+r.stderr);put('process.json',{'exitCode':r.returncode});print('diagnostic exit',r.returncode)
