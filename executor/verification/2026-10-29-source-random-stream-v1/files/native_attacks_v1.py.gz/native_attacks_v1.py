from pathlib import Path
import json,subprocess,os,copy
c=Path(__file__).resolve().parent;d=c/'native-planner-v1';out=c/'native-attacks-v1';out.mkdir()
s=json.loads((d/'source.json').read_text());draw=json.loads((d/'draw.json').read_text());policy=json.loads((d/'policy.json').read_text())
env=os.environ.copy();env.update(PSY_NETWORK='testnet',PSY_CONFIG_PATH=str(c.parent/'sdk-mainnet-beta-20261027-v1/source/psy-sdk/psy-genesis/config.json'),PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',RAYON_NUM_THREADS='2')
rows=[]
for name in ['draw-index','draw-history-root','draw-seed','source-network','source-omission','policy-window','source-manifest']:
 a,b,p=copy.deepcopy(s),copy.deepcopy(draw),copy.deepcopy(policy)
 if name=='draw-index':b['path']['index']+=1
 if name=='draw-history-root':b['path']['root']='b'*64
 if name=='draw-seed':b['checkpoint']['stats']['random_seed']='a'*64
 if name=='source-network':a['fields'][1]+=1
 if name=='source-omission':a['accounts'].pop()
 if name=='policy-window':p['source_window_checkpoints']+=1
 if name=='source-manifest':a['fields'][17]+=1
 folder=out/name;folder.mkdir()
 for n,v in [('source',a),('draw',b),('policy',p)]:
  with (folder/(n+'.json')).open('x')as f:json.dump(v,f)
 args=[str(c/'bin-v4/random_stream_plan'),str(d/'review.json'),str(folder/'source.json'),s['history']['checkpoint_path']['root'],str(folder/'draw.json'),str(folder/'policy.json'),str(folder/'prepared')]
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=60)
 row={'attack':name,'exitCode':r.returncode,'stderr':r.stderr,'outputCreated':(folder/'prepared').exists()};rows.append(row)
 assert r.returncode!=0 and not row['outputCreated'],row
with(c/'public/native-attacks-v1.json').open('x')as f:json.dump({'syntheticHistory':True,'financialOperations':0,'cases':rows},f,indent=2)
print(len(rows),'rejected')
