import json,pathlib,copy,hashlib,subprocess
C=pathlib.Path(__file__).resolve().parent
base={n:json.loads((C/'public'/p).read_bytes())for n,p in [('policy','inspection-policy.json'),('bootstrap','bootstrap.json'),('update','finality-update.json')]}
cases=[]
def add(name,fn):
 d=copy.deepcopy(base);fn(d);cases.append((name,d))
add('claimed-independent-review',lambda d:d['policy'].update(anchorReviewed=True))
add('claimed-broadcast',lambda d:d['policy'].update(canBroadcast=True))
add('wrong-genesis-domain',lambda d:d['policy'].update(genesisValidatorsRoot='0x'+'00'*32))
add('wrong-fork-domain',lambda d:d['policy'].update(forkVersion='0x90000075'))
add('wrong-bootstrap-root',lambda d:d['policy'].update(bootstrapRoot='0x'+'00'*32))
add('changed-committee-member',lambda d:d['bootstrap']['data']['current_sync_committee']['pubkeys'].__setitem__(0,d['bootstrap']['data']['current_sync_committee']['pubkeys'][1]))
add('missing-committee-member',lambda d:d['bootstrap']['data']['current_sync_committee']['pubkeys'].pop())
add('changed-aggregate-key',lambda d:d['bootstrap']['data']['current_sync_committee'].update(aggregate_pubkey='0x'+'00'*48))
add('missing-committee-branch',lambda d:d['bootstrap']['data']['current_sync_committee_branch'].pop())
add('changed-finality-branch',lambda d:d['update']['data']['finality_branch'].__setitem__(0,'0x'+'00'*32))
add('missing-finality-branch',lambda d:d['update']['data']['finality_branch'].pop())
add('changed-finalized-root',lambda d:d['update']['data']['finalized_header']['beacon'].update(proposer_index='1'))
add('changed-execution-hash',lambda d:d['update']['data']['finalized_header'].update(execution_block_hash='0x'+'00'*32))
add('missing-execution-branch',lambda d:d['update']['data']['attested_header']['execution_branch'].pop())
add('wrong-signature-period',lambda d:d['update']['data'].update(signature_slot=str(int(d['update']['data']['signature_slot'])+8192)))
add('signature-before-attestation',lambda d:d['update']['data'].update(signature_slot=d['update']['data']['attested_header']['beacon']['slot']))
add('insufficient-participants',lambda d:d['update']['data']['sync_aggregate'].update(sync_committee_bits='0x01'+'00'*63))
add('changed-participant-set',lambda d:d['update']['data']['sync_aggregate'].update(sync_committee_bits='0xfe'+'ff'*63))
add('zero-signature',lambda d:d['update']['data']['sync_aggregate'].update(sync_committee_signature='0x'+'00'*96))
add('wrong-ssz-version',lambda d:d['update'].update(version='electra'))
add('extra-approval-report',lambda d:d['update'].update(verified=True))
root=C/'public/negative-certificates-v1';root.mkdir();results=[]
for name,d in cases:
 p=root/name;p.mkdir();d['policy']['bootstrapSha256']=hashlib.sha256((json.dumps(d['bootstrap'],indent=2)+'\n').encode()).hexdigest();d['policy']['updateSha256']=hashlib.sha256((json.dumps(d['update'],indent=2)+'\n').encode()).hexdigest()
 for n,v in d.items():(p/(n+'.json')).write_text(json.dumps(v,indent=2)+'\n')
 pin=hashlib.sha256((p/'policy.json').read_bytes()).hexdigest()
 r=subprocess.run([str(C/'gloas-build-v1/gloas-certificate-inspector'),str(p/'policy.json'),pin,str(p/'bootstrap.json'),str(p/'update.json'),str(p/'report.json')],capture_output=True,text=True,timeout=15)
 (p/'console.log').write_text(r.stdout+r.stderr);v=json.loads((p/'report.json').read_bytes());assert r.returncode!=0 and v['inspectionPassed']is False,name
 for field in ['anchorReviewed','independentAnchorAuthenticated','canonicalFinalityVerified','seedSecrecyAuthenticated','qualifiedRandomness','canSign','canBroadcast']:assert v[field]is False,name
 results.append({'name':name,'exitCode':r.returncode,'reportSha256':hashlib.sha256((p/'report.json').read_bytes()).hexdigest()})
with(C/'public/certificate-negative-results.json').open('x')as f:json.dump({'schema':1,'rejections':results,'financialOperations':0,'newZkProofsGenerated':0},f,indent=2);f.write('\n')
print(json.dumps({'rejected':len(results),'financialOperations':0}))
