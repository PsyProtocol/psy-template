"""Explicit public cohort publication; never collects wallets or raw witnesses."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

STAGE = {'source.json','current.json','intent.json','plan.json','request.json',
         'public-session.json','verification.json','key-proof.bin'}
FORBIDDEN = {'private_key','privateKey','secret_key','secretKey','mnemonic',
             'recoveryPhrase','signing_witness','signature_witness','cfc_witness','secp256k1_slots'}
PUBLIC = set('''PLAN.json MEMORY-STOP-v1.json ACTIVE-v1.json ACTIVE-v2.json
CLOSED-v1.json CLOSED-v2.json ACTIVE-GUARD-v1.json CLOSED-GUARD-v1.json
ROOT-CAUSE-v1.json REPLAY-GUARD-PLAN-v1.json CONSISTENCY-v1.json
FIXTURE-REFERENCE-v1.json FINAL-SOURCE-v1.json INDEPENDENT-VERIFICATION-v1.json
application-v1.json application-v2.json application-v3.json application-v4.json
build-v1.log build-v2.log build-v3.log build-v4.log full-ups-v1.raw.log
full-ups-v2.raw.log replay-guard-v1.raw.log rss-v1.jsonl rss-v2.jsonl
rss-guard-v1.jsonl audit-amm-v1.log audit-amm-v2.log audit-full-v1.log audit-full-v2.log'''.split())
sha = lambda data: hashlib.sha256(data).hexdigest()


def scan(value):
    if isinstance(value,dict):
        assert not (value.keys() & FORBIDDEN), 'secret-bearing field'
        for child in value.values(): scan(child)
    elif isinstance(value,list):
        for child in value: scan(child)


def archive(case, out):
    case=case.resolve()
    assert not out.exists() and not out.is_symlink(), 'fresh output required'
    for name in ['CLOSED-v2.json','CLOSED-GUARD-v1.json']:
        assert json.loads((case/'public'/name).read_text())['exitCode']==0
    assert json.loads((case/'public/CONSISTENCY-v1.json').read_text())['completeUps']==16
    files=set()
    for path in (case/'public').iterdir():
        assert path.name in PUBLIC, 'review new public member before publication'
        files.add(path)
    for version in ['v1','v2']:
        for stage in (case/('full-ups-'+version)).iterdir():
            if stage.is_dir():files.update(path for path in stage.iterdir() if path.name in STAGE)
            elif stage.name.endswith('-REPORT.json'):files.add(stage)
    for version in ['v1','v2','v3','v4']:
        base=case/('application-'+version)
        for name in ['APPLICATION.json','Cargo.toml','Cargo.lock','src/stream_policy.rs',
                     'tests/support/stream_full_ups.rs','tests/support/funded_stream_full_ups.rs',
                     'tests/support/funded_bootstrap_full_ups.rs']:
            if (base/name).exists():files.add(base/name)
    for base in ['replay-guard-v1','independent-verification-v1']:
        for path in (case/base).rglob('*'):
            if path.is_file():
                assert path.name in STAGE or path.name=='REPORT.json' or path.suffix in {'.json','.log'}
                files.add(path)
    files.update(case/name for name in ['run.py','run-v2.py','run-guard-v1.py','archive.py'])
    out.mkdir(parents=True)
    index=[]
    for path in sorted(files):
        assert path.is_file() and not path.is_symlink()
        raw=path.read_bytes();public=raw
        if path.suffix!='.bin':
            text=raw.decode()
            for old,new in [(str(case),'<case-root>'),(str(case.parent),'<evidence-root>'),(str(Path.home()),'<home>')]:
                text=text.replace(old,new).replace(json.dumps(old)[1:-1],new)
            public=text.encode()
            if path.suffix=='.json':scan(json.loads(public))
            if path.suffix=='.jsonl':
                for line in text.splitlines():scan(json.loads(line))
        name=path.relative_to(case).as_posix();compressed=gzip.compress(public,mtime=0)
        destination=out/'files'/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
        with destination.open('xb') as stream:stream.write(compressed)
        assert gzip.decompress(destination.read_bytes())==public
        index.append(dict(source=name,file=destination.relative_to(out).as_posix(),
                          originalSha256=sha(raw),publicSha256=sha(public),gzipSha256=sha(compressed),
                          originalBytes=len(raw),gzipBytes=len(compressed),redacted=raw!=public))
    for name,value in [('index.json',index),('PUBLISHED-AUDIT.json',dict(schema=1,members=len(index),
        gzipBytes=sum(row['gzipBytes'] for row in index),allDigestsVerified=True,
        publicFieldScanPassed=True,rawWitnessesIncluded=False,binariesIncluded=False,
        cryptographicVerificationPerformedByArchiver=False,financialOperations=0))]:
        with (out/name).open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    return len(index)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('case',type=Path);parser.add_argument('fresh_output',type=Path)
    args=parser.parse_args();print(archive(args.case,args.fresh_output))
