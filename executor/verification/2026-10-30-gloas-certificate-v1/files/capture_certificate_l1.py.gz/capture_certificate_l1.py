import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
previous=C.parent/'runtime-resource-acquisition-20261030-v1'
s=json.loads((previous/'public/l1-state-manager-observation.json').read_bytes())
url='https://rpc-eth-stg.psy-protocol.xyz'
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json'
 with rp.open('x')as f:json.dump(req,f)
 rp.chmod(0o600);out=C/'quarantine'/f'{label}.body';assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes()if out.exists()else b''
 if out.exists():out.chmod(0o600)
 r={'schema':1,'url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'elapsedSeconds':time.monotonic()-start,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalityVerified':False,'canBroadcast':False}
 with(C/'public'/f'{label}-transport.json').open('x')as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'result'not in v or 'error'in v:
  with(C/'public'/f'{label}-error.json').open('x')as f:json.dump({'schema':1,'error':v.get('error'),'finalityVerified':False},f,indent=2);f.write('\n')
  raise RuntimeError('RPC rejected; no retry')
 return v['result']


from concurrent.futures import ThreadPoolExecutor
u=json.loads((C/'quarantine/lodestar-finality.body').read_bytes())
block_hash=u['data']['finalized_header']['execution_block_hash']
chain=call('certificate-chain-id','eth_chainId',[]);assert chain=='0xaa36a7','wrong chain'
block=call('certificate-execution-header','eth_getBlockByHash',[block_hash,False])
assert block and block['hash']==block_hash,'certificate execution parent unavailable; no latest fallback'
fixed={'blockHash':block_hash,'requireCanonical':True}
keys=['hash','parentHash','sha3Uncles','miner','stateRoot','transactionsRoot','receiptsRoot','logsBloom','difficulty','number','gasLimit','gasUsed','timestamp','extraData','mixHash','nonce','baseFeePerGas','withdrawalsRoot','blobGasUsed','excessBlobGas','parentBeaconBlockRoot','requestsHash','blockAccessListHash','slotNumber']
with(C/'public/certificate-header-projection.json').open('x')as f:json.dump({'schema':1,'header':{k:block[k]for k in keys}},f,indent=2);f.write('\n')
accounts=[('proxy','0x4eC67bA22A3F7a9Af1f19F480e5Df33bFD7B06F1',['0x0','0x1','0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc']),('implementation','0xd1ca5e95e2b58461343f9d55c61fbb4b6662fb04',['0x0'])]
def capture(row):
 role,address,slots=row;p=call('certificate-'+role+'-proof','eth_getProof',[address,slots,fixed])
 statement={'schema':1,'kind':'prospective-execution-state-statement-v1','chainId':11155111,'address':address,'blockHash':block_hash,'blockNumber':block['number'],'stateRoot':block['stateRoot'],'slots':slots,'originalAnchorReplaced':False,'headerConsensusVerified':False,'canBroadcast':False}
 old=C.parent/'checkpoint-l1-archive-followup-20261030-v1';code=json.loads((old/'public'/f'paired-{role}-code.json').read_bytes())['code']
 for suffix,obj in [('statement',statement),('proof',{'schema':1,'proof':{k:p[k]for k in ['address','accountProof','balance','codeHash','nonce','storageHash','storageProof']}}),('code',{'schema':1,'address':address,'blockHash':block_hash,'code':code})]:
  with(C/'public'/f'certificate-{role}-{suffix}.json').open('x')as f:json.dump(obj,f,indent=2);f.write('\n')
 return role
with ThreadPoolExecutor(max_workers=2)as pool:print('certificate-relative inclusion captured',list(pool.map(capture,accounts)))
