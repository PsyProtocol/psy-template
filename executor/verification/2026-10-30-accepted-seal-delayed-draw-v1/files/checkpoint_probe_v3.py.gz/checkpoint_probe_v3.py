# Split the large proof pair into two bounded reads. No verifier fallback.
from pathlib import Path
import json,subprocess,hashlib
c=Path(__file__).resolve().parent;d=c/'public/checkpoint-current-v3';d.mkdir()
cp=min(json.loads((c/'public/rpc-precheck-v1/SUMMARY.json').read_text())['heads'].values())
def put(name,v):
 with(d/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
put('PLAN.json',{'maximumLogicalReadRequests':2,'retriesPerRequest':0,'maxSecondsPerRequest':40,'reason':'Previous combined response exceeded bounded download time. Split exact original checkpoint IDs; no alternate verifier or parameter change.','checkpointIds':[cp-1,cp],'financialOperations':0})
for n in [cp-1,cp]:
 q={'jsonrpc':'2.0','id':n,'method':'psy_get_checkpoint_state_transition_proof','params':{'checkpoint_id':n}};put(str(n)+'-request.json',q)
 p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--connect-timeout','5','--max-filesize','2097152','--header','content-type: application/json','--data-binary','@-','https://coordinator-stg.psy-protocol.xyz'],input=json.dumps(q).encode(),capture_output=True,timeout=45)
 (d/(str(n)+'-response.raw')).write_bytes(p.stdout);put(str(n)+'-transport.json',{'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace'),'bytes':len(p.stdout)})
 if p.returncode:raise SystemExit('Read failed; stop without retry')
 v=json.loads(p.stdout);assert 'result'in v,v;data=bytes(v['result']);assert 0<len(data)<=2000000;(d/(str(n)+'.bin')).write_bytes(data)
binary=c.parent/'sdk-mainnet-beta-20261027-v1/target/release/diagnose_checkpoint_resources';put('binary.json',{'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'unchangedFrozenCohortDiagnostic':True})
r=subprocess.run([str(binary),'cached',str(d/(str(cp-1)+'.bin')),str(d/(str(cp)+'.bin')),str(d/'verified.json')],capture_output=True,text=True,timeout=60);(d/'diagnostic.log').write_text(r.stdout+r.stderr);put('process.json',{'exitCode':r.returncode});print('diagnostic exit',r.returncode)
