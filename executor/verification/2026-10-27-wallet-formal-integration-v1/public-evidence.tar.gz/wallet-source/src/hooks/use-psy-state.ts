import ENV from "@/env";
import { shallow } from "zustand/shallow";
import type {
  IPsyStateDispatch,
  IPsyState,
} from "@/background/psy-wallet-ext-core";
import { create } from "zustand";
import { immer } from "zustand/middleware/immer";
import browser from "webextension-polyfill";
import { psyInternalRequest, STATE_DISPATCH_ACTION } from "@/message";
import { pick } from "@/lib/utils";
import { PsyJSON } from "@psy-protocol/psy-sdk";

export interface PsyState extends IPsyState, IPsyStateDispatch {}

export const usePsyState = create<PsyState>()(
  immer((set) => {
    browser.runtime.onMessage.addListener((msg: any) => {
      if (msg.action === STATE_DISPATCH_ACTION && msg.isPsy) {
        const stateDiff =
          typeof msg.state === "string" ? PsyJSON.parse(msg.state) : msg.state;
        set((state) => ({ ...state, ...stateDiff }));
      }
    });

    return {
      wallets: [],
      totalCount: 0,
      mnLength: 0,
      creatingWalletSince: null,
      currentWallet: undefined,
      hasTriedRestore: false,
      checkpointId: 0,
      isEncrypted: false,
      needPassword: false,
      autoLockTimeoutMs: 5 * 60 * 1000,
      initStatus: "initializing" as const,
      initError: undefined as string | undefined,
      // Default TRUE so the "Preparing prover…" pill only shows when the
      // background explicitly reports a warming prover — never as a flash
      // on a popup that opened against an already-warm service worker.
      proverReady: true,
      proverFailed: false,
      // ENV.network, NOT a hardcoded "localhost": this initial value is all
      // the popup has when the SW never dispatched state (crash/cold boot),
      // and the force-mode network modal seeds its preset selector from it -
      // a Save there silently switched a staging wallet to localhost with the
      // wrong network config ("Can not reach the Psy network"). ENV.network is
      // the build-time network (build:staging = sepolia; localhost only under
      // the dev server).
      network: ENV.network,
      networkKey: "",
      chainKey: "",
      chainKeyChanged: false,
      nativeContractId: "0",
      walletSnapshot: undefined,
      privateTransferStatus: undefined,
      sendBatchStatus: undefined,
      pendingHolds: [],
      reload(config) {
        return psyInternalRequest("reload", [config]);
      },
      retryInit() {
        // Re-runs initialization with the SAVED config — unlike reload(),
        // never writes config/network. For "Try again" after a transient
        // network failure.
        return psyInternalRequest("retryInit");
      },
      refreshPsyState() {
        return psyInternalRequest("refreshPsyState");
      },
      dismissChainKeyChangedNotice() {
        return psyInternalRequest("dismissChainKeyChangedNotice");
      },
      setCurrentWallet(address, refresh) {
        return psyInternalRequest("setCurrentWallet", [address, refresh]);
      },
      renameWallet(address, newName) {
        return psyInternalRequest("renameWallet", [address, newName]);
      },
      removeWallet(address) {
        return psyInternalRequest("removeWallet", [address]);
      },
      resetWallet() {
        return psyInternalRequest("resetWallet", []);
      },
      createShieldReceiveAddress(address, label) {
        return psyInternalRequest("createShieldReceiveAddress", [
          address,
          label,
        ]);
      },
      markShieldReceiveAddressUsed(address, shieldAddress) {
        return psyInternalRequest("markShieldReceiveAddressUsed", [
          address,
          shieldAddress,
        ]);
      },
      updateShieldReceiveAddress(address, shieldAddress, patch) {
        return psyInternalRequest("updateShieldReceiveAddress", [
          address,
          shieldAddress,
          patch,
        ]);
      },
      syncPublicClaimCandidates(address) {
        return psyInternalRequest("syncPublicClaimCandidates", [address]);
      },
      checkRecipientExists(userId) {
        return psyInternalRequest("checkRecipientExists", [userId]);
      },
      addWalletFromPrivateKey(
        privateKeyHex,
        signType,
        fingerprint,
        mnInd,
        changeCurrent,
        walletName,
        sdkKeyCircuitParams,
        shieldReceiveAddresses,
        mode,
      ) {
        return psyInternalRequest("addWalletFromPrivateKey", [
          privateKeyHex,
          signType,
          fingerprint,
          mnInd,
          changeCurrent,
          walletName,
          sdkKeyCircuitParams,
          shieldReceiveAddresses,
          mode,
        ]);
      },
      addWalletFromMnemonic(
        mn,
        signType,
        fingerprint,
        walletName,
        sdkKeyCircuitParams,
      ) {
        return psyInternalRequest("addWalletFromMnemonic", [
          mn,
          signType,
          fingerprint,
          walletName,
          sdkKeyCircuitParams,
        ]);
      },
      importWalletsFromBackup(items) {
        return psyInternalRequest("importWalletsFromBackup", [items]);
      },
      refreshAllWallets() {
        return psyInternalRequest("refreshAllWallets");
      },
      loadWallets(password) {
        return psyInternalRequest("loadWallets", [password]);
      },
      lock() {
        return psyInternalRequest("lock");
      },
      setAutoLockTimeout(timeoutMs) {
        return psyInternalRequest("setAutoLockTimeout", [timeoutMs]);
      },
      saveWallets() {
        return psyInternalRequest("saveWallets");
      },
      addPassword(password) {
        return psyInternalRequest("addPassword", [password]);
      },
      changePassword({
        oldPassword,
        newPassword,
      }: {
        oldPassword: string;
        newPassword?: string;
      }) {
        return psyInternalRequest("changePassword", [
          { oldPassword, newPassword },
        ]);
      },
      getMnemonic(password: string, mnInd) {
        return psyInternalRequest("getMnemonic", [password, mnInd]);
      },
      genPrivateKey(mnInd) {
        return psyInternalRequest("genPrivateKey", [mnInd]);
      },
      newRandomWalletFailed(mnInd) {
        return psyInternalRequest("newRandomWalletFailed", [mnInd]);
      },
      getBalance(address, contractId, checkpointId) {
        return psyInternalRequest("getBalance", [
          address,
          contractId,
          checkpointId,
        ]);
      },
      getUserId(address) {
        return psyInternalRequest("getUserId", [address]);
      },
      getClaimRewardsCallArgs(jobInfos: string) {
        return psyInternalRequest("getClaimRewardsCallArgs", [jobInfos]);
      },
      getClaimAmount(checkpointId, contractId, receiveUserId, sentUserId) {
        return psyInternalRequest("getClaimAmount", [
          checkpointId,
          contractId,
          receiveUserId,
          sentUserId,
        ]);
      },
      getSenderTotalSent(
        checkpointId,
        contractId,
        senderUserId,
        recipientUserId,
      ) {
        return psyInternalRequest("getSenderTotalSent", [
          checkpointId,
          contractId,
          senderUserId,
          recipientUserId,
        ]);
      },
      refreshClaimSnapshots(
        address?: string,
        checkpointId?: number,
        forceRescan?: boolean,
      ) {
        return psyInternalRequest("refreshClaimSnapshots", [
          address,
          checkpointId,
          forceRescan,
        ]);
      },
      refreshWalletSnapshot(force?: boolean) {
        return psyInternalRequest("refreshWalletSnapshot", [force]);
      },
      getClaimableItems(address: string) {
        return psyInternalRequest("getClaimableItems", [address]);
      },
      enqueueTx(kind, address, payload, opts) {
        console.warn("[tx-trace] enqueueTx:popup-request", {
          kind,
          address,
          hasPayload: payload != null,
        });
        return psyInternalRequest("enqueueTx", [kind, address, payload, opts]);
      },
      awaitTx(queueId) {
        return psyInternalRequest("awaitTx", [queueId]);
      },
      cancelTx(queueId) {
        return psyInternalRequest("cancelTx", [queueId]);
      },
      retryTx(queueId) {
        return psyInternalRequest("retryTx", [queueId]);
      },
      prepareMarketTransaction(address, origin, record) {
        return psyInternalRequest("prepareMarketTransaction", [
          address,
          origin,
          record,
        ]);
      },
      listMarketPreparations(address, origin) {
        return psyInternalRequest("listMarketPreparations", [address, origin]);
      },
      cancelMarketPreparation(address, origin, intentId) {
        return psyInternalRequest("cancelMarketPreparation", [
          address,
          origin,
          intentId,
        ]);
      },
      verifyMarketPreparation(address, origin, intentId) {
        return psyInternalRequest("verifyMarketPreparation", [address, origin, intentId]);
      },
      broadcastMarketPreparation(address, origin, intentId, preparedHash) {
        return psyInternalRequest("broadcastMarketPreparation", [address, origin, intentId, preparedHash]);
      },
      reconcileMarketPreparation(address, origin, intentId) {
        return psyInternalRequest("reconcileMarketPreparation", [address, origin, intentId]);
      },
      getMarketWriteCapabilities() {
        return psyInternalRequest("getMarketWriteCapabilities");
      },
      execContractCall(address, args) {
        return psyInternalRequest("execContractCall", [address, args]);
      },
      execContractCallWithoutProof(address, args) {
        return psyInternalRequest("execContractCallWithoutProof", [
          address,
          args,
        ]);
      },
      execClaimBatch(address, claims) {
        return psyInternalRequest("execClaimBatch", [address, claims]);
      },
      startPrivateTransfer(address, req, preClaimItems, runId) {
        return psyInternalRequest("startPrivateTransfer", [
          address,
          req,
          preClaimItems,
          runId,
        ]);
      },
      startSendBatch(address, claims, opts) {
        return psyInternalRequest("startSendBatch", [address, claims, opts]);
      },
      previewSendTrace(address, items) {
        return psyInternalRequest("previewSendTrace", [address, items]);
      },
      previewPrivateTransferTrace(address, opts) {
        return psyInternalRequest("previewPrivateTransferTrace", [
          address,
          opts,
        ]);
      },
      discardPreviewTrace(address, txHash) {
        return psyInternalRequest("discardPreviewTrace", [address, txHash]);
      },
      execClaimBatchWithoutProof(address, claims) {
        return psyInternalRequest("execClaimBatchWithoutProof", [
          address,
          claims,
        ]);
      },
      retryPrivateTransferBackup(address, id) {
        return psyInternalRequest("retryPrivateTransferBackup", [address, id]);
      },
      executePrivateTransfer(address, request, preClaimItems) {
        return psyInternalRequest("executePrivateTransfer", [
          address,
          request,
          preClaimItems,
        ]);
      },
      getPsyFaucetConfig() {
        return psyInternalRequest("getPsyFaucetConfig");
      },
      beginPsyFaucetVerification(recipientUserId) {
        return psyInternalRequest("beginPsyFaucetVerification", [
          recipientUserId,
        ]);
      },
      claimPsyFaucetWithTurnstile(recipientUserId, state, turnstileToken) {
        return psyInternalRequest("claimPsyFaucetWithTurnstile", [
          recipientUserId,
          state,
          turnstileToken,
        ]);
      },
      claimPsyFaucetWallet(recipientUserId) {
        return psyInternalRequest("claimPsyFaucetWallet", [recipientUserId]);
      },
      getPrivateKey(address) {
        return psyInternalRequest("getPrivateKey", [address]);
      },
      decryptNostrSecretsEvent(address, shieldAddress, eventJson) {
        return psyInternalRequest("decryptNostrSecretsEvent", [
          address,
          shieldAddress,
          eventJson,
        ]);
      },
      exportAllWallets(password) {
        return psyInternalRequest("exportAllWallets", [password]);
      },
      getConfig() {
        return psyInternalRequest("getConfig");
      },
      refreshApproveState() {
        return psyInternalRequest("refreshApproveState");
      },
      // getClaimRewardsCallArgs(address, checkpointId, jobInfos) {
      //   return psyRequest("getClaimRewardsCallArgs", [
      //     address,
      //     checkpointId,
      //     jobInfos,
      //   ]);
      // },
      // claimRewards(address, checkpointId, jobInfos) {
      //   return psyRequest("claimRewards", [address, checkpointId, jobInfos]);
      // },
    };
  }),
);

export function selector<T extends keyof PsyState>(...keys: T[]) {
  return (state: PsyState) => pick(state, ...keys);
}

export function usePsyStateSelector<T extends keyof PsyState>(...keys: T[]) {
  // shallow equality: selector(...keys) -> pick() builds a NEW object every
  // call, so with the default Object.is EVERY component using this hook
  // re-rendered on EVERY store dispatch (a checkpoint tick every ~6-10s, plus
  // each balance/snapshot dispatch) - re-rendering open modals (Transfer/Send
  // amount inputs, the Claim list) needlessly. shallow re-renders only when a
  // selected value actually changes.
  return usePsyState(selector(...keys), shallow);
}
