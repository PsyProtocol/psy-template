import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {storeL1EvidencePacket,inspectL1EvidencePair} from '/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016/executor/l1Evidence.mjs';
const c='/Users/geir/Downloads/QED资料/litepaper/psy-market-recovery-20261023/checkpoint-l1-archive-followup-20261030-v1';
const sha=b=>createHash('sha256').update(b).digest('hex');
const build=JSON.parse(await readFile(join(c,'inspector-build-v2/BUILD.json'),'utf8'));
const common={driver:join(c,'inspector-build-v2/l1-proof-inspector'),driverSha256:build.binarySha256,runtimeDirectory:join(c,'read-only-runtime-v1')};
const roles={};
for(const role of ['proxy','implementation']){
 const files={statement:join(c,`public/paired-${role}-statement.json`),header:join(c,'public/paired-header-projection.json'),proof:join(c,`public/paired-${role}-proof.json`),code:join(c,`public/paired-${role}-code.json`)};
 const directory=join(c,`paired-${role}-packet-v1`),saved=await storeL1EvidencePacket({directory,statementSha256:sha(await readFile(files.statement)),files});
 roles[role]={...common,directory,packetSha256:saved.packetSha256,report:join(c,`public/paired-${role}-native-report.json`)};
}
const pair=await inspectL1EvidencePair(roles);assert.equal(pair.finalityVerified,false);
await writeFile(join(c,'public/paired-native-summary.json'),JSON.stringify(pair,null,2)+'\n',{flag:'wx'});
const old=JSON.parse(await readFile(join(c,'public/executor-integration-summary.json'),'utf8'));
let rejected=false;
try{await inspectL1EvidencePair({proxy:{...common,directory:join(c,'packet-v1'),packetSha256:old.packetSha256,report:join(c,'public/mixed-old-proxy-native.json')},implementation:{...roles.implementation,report:join(c,'public/mixed-new-implementation-native.json')}});}catch(e){rejected=true;await writeFile(join(c,'public/mixed-pair-rejection.json'),JSON.stringify({schema:1,rejected:true,error:e.message,financialOperations:0,canBroadcast:false},null,2)+'\n',{flag:'wx'});}
assert.equal(rejected,true,'two separately valid accounts from different headers must not be combined');
console.log(JSON.stringify({pairedAccountsVerified:2,mixedHeaderPairRejected:true,financialOperations:0,finalityVerified:false}));
