// Only the exact committed source tree materialized by baseline-source-v1.py is
// loaded. No page, network, third-party module or financial operation is used.
import assert from 'node:assert/strict';import {createHash} from 'node:crypto';import {writeFileSync} from 'node:fs';
import {generateBatch as oldBatch} from './baseline-source-v1/batching/v2/generate.mjs';
import {generateAdmission as oldAdmission} from './baseline-source-v1/batching/admission/generate.mjs';
import {generateBatch} from '../../psy-template-security-20261016/batching/v2/generate.mjs';
import {generateAdmission} from '../../psy-template-security-20261016/batching/admission/generate.mjs';
import {fixture} from '../../psy-template-security-20261016/amm/u124/generate.mjs';
const rows=[];for(const market of ['amm','bondingcurve','orderbook','nftmarket']){
 const config=market==='nftmarket'?{nftId:41,tokenId:42,networkMagic:'1'}:{...fixture,networkMagic:'1'};
 for(const [profile,old,current]of [['v2',oldBatch,generateBatch],['admission',oldAdmission,generateAdmission]]){
  const before=old(market,config),after=current(market,config);assert.equal(after,before);
  rows.push({market,profile,sourceSha256:createHash('sha256').update(after).digest('hex'),identical:true});
 }
}
writeFileSync(new URL('./public/deterministic-source-comparison-v1.json',import.meta.url),JSON.stringify({baseline:'85939feb',rows,scope:'generated source bytes only; no compilation, bytecode, full UPS, performance or live acceptance'},null,2)+'\n',{flag:'wx'});
