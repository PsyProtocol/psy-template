from pathlib import Path
import json,subprocess,hashlib,shutil
c=Path(__file__).resolve().parent;d=c/'public/checkpoint-current-v1';d.mkdir();cp=json.loads((c/'public/funding-readonly-v1/head-result.json').read_text())['response']['result']['checkpoint_id'];q=[{'jsonrpc':'2.0','id':n,'method':'psy_get_checkpoint_state_transition_proof','params':{'checkpoint_id':n}}for n in [cp-1,cp]]
(d/'PLAN.json').write_text(json.dumps({'maxLogicalReadRequests':2,'checkpointIds':[cp-1,cp],'proofGeneration':0,'financialOperations':0,'selectedVerifier':'unchanged frozen cached resources; no alternate key'})+'\n');(d/'request.json').write_text(json.dumps(q)+'\n')
p=subprocess.run(['curl','--silent','--show-error','--max-time','20','--connect-timeout','5','--max-filesize','4194304','--header','content-type: application/json','--data-binary','@-','https://coordinator-stg.psy-protocol.xyz'],input=json.dumps(q).encode(),capture_output=True,timeout=25);(d/'response.raw').write_bytes(p.stdout);assert p.returncode==0;v=json.loads(p.stdout);assert isinstance(v,list)and len(v)==2
for row in v:
 assert 'result'in row,row;data=bytes(row['result']);assert 0<len(data)<=2000000;(d/(str(row['id'])+'.bin')).write_bytes(data)
binary=c.parent/'sdk-mainnet-beta-20261027-v1/target/release/diagnose_checkpoint_resources';(d/'binary.json').write_text(json.dumps({'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'existingFrozenCohortDiagnostic':True})+'\n')
r=subprocess.run([str(binary),'cached',str(d/(str(cp-1)+'.bin')),str(d/(str(cp)+'.bin')),str(d/'verified.json')],capture_output=True,text=True,timeout=60);(d/'diagnostic.log').write_text(r.stdout+r.stderr);print('diagnostic exit',r.returncode)
report=json.loads((d/'verified.json').read_text());print(json.dumps(report)[:500])
