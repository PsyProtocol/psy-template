// Actual sealed native preparation. No proof generation, wallet or broadcast.
import {readFile,writeFile,mkdir} from 'node:fs/promises';import {join} from 'node:path';import assert from 'node:assert/strict';
import {prepareMinimumSourceStream} from '<application-root>/executor/randomSourceStream.mjs';
import {sha256} from '<application-root>/executor/requestBinding.mjs';
import {parseLosslessJson,losslessJson} from '<application-root>/amm/u124/client.mjs';
const c='<case-root>',out=join(c,'native-route-v1');await mkdir(out);
const results=[];
for(const market of ['amm','curve']){
 const d=join(c,'native-'+market+'-v1'),plan=parseLosslessJson(await readFile(join(d,'prepared/plan.json'),'utf8'));
 const o={historyRoot:plan.historyRoot,wallet:join(c,'bin-v14/minimum_stream_plan'),walletSha256:sha256(await readFile(join(c,'bin-v14/minimum_stream_plan'))),runtimeDirectory:join(out,'runtime-'+market)};
 for(const n of ['review','snapshot','draw','policy']){o[n]=join(d,(n==='snapshot'?'source':n)+'.json');o[n+'Sha256']=sha256(await readFile(o[n]));}
 const a=await prepareMinimumSourceStream(o),original=await a.plan();await prepareMinimumSourceStream(o);assert.equal((await a.status()).canBroadcast,false);assert.equal(original.status.minimumBuildPages,2);assert.equal(original.status.minimumExtractionPages,2);assert.throws(()=>a.authorizeSettlement(),/cannot enable writes/);
 assert.deepEqual(original.pages,parseLosslessJson(await readFile(join(d,'prepared/minimum-pages.json'),'utf8')));
 await assert.rejects(prepareMinimumSourceStream({...o,historyRoot:'f'.repeat(64)}),/immutable random source input changed/);
 const budget=await a.planBudget({availableFeeBudgetBaseUnits:'100000000000',maxFeePerUpsBaseUnits:'1000100000',recoveryUpsReserve:2,secondsPerUpsBound:120,checkpointSecondsLowerBound:1,checkpointReserve:32});
 assert.equal(budget.planningConditionsFit,false,'short eligible deadline does not fit the conditional timing model');
 results.push({market,status:await a.status(),replayedSameImmutablePlan:true,reselectionRejected:true,budget,financialOperations:0});
}
await writeFile(join(out,'REPORT.json'),losslessJson({schema:1,actualSealedNativePlanner:true,financialOperations:0,proofsGenerated:0,canSign:false,canBroadcast:false,results})+'\n',{flag:'wx'});
