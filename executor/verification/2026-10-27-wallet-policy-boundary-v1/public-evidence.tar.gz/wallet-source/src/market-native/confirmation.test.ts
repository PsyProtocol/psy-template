import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { MarketLimitRows } from "./LimitRows";
import { describe, it, expect } from "vitest";
import {
  marketConfirmation,
  type MarketConfirmationTerms,
} from "./confirmation";
import { confirmationFixture } from "./confirmation.fixture";
import {marketLimitRows} from "../market-preparation/market-client/wallet/approvalPolicy.mjs";

describe("wallet-owned exact market confirmation", () => {
  it("binds public plan, high limb, destination, fee and exact request", async () => {
    const original = confirmationFixture(),
      approved = await marketConfirmation(original);
    for (const change of [
      (t: MarketConfirmationTerms) => {
        t.fullCalls[0].inputs[2] = "0";
      },
      (t: MarketConfirmationTerms) => {
        t.requestSha256 = "f".repeat(64);
      },
      (t: MarketConfirmationTerms) => {
        t.review.plan.minimum = "99";
      },
      (t: MarketConfirmationTerms) => {
        t.review.plan.walletNonce = "2";
      },
      (t: MarketConfirmationTerms) => {
        t.actualFee = "1000002000";
      },
    ]) {
      const altered = structuredClone(original);
      change(altered);
      expect((await marketConfirmation(altered)).approvalSha256).not.toBe(
        approved.approvalSha256,
      );
    }
    expect(original).toEqual(confirmationFixture());
  });
  it("rejects missing review, secret-bearing outer envelopes and inconsistent recipients/fees", async () => {
    for (const change of [
      (t: any) => {
        delete t.review;
      },
      (t: any) => {
        t.sign_witness = { secret: "never forward" };
      },
      (t: any) => {
        t.review.plan.recipientId = 202;
      },
      (t: any) => {
        t.actualFee = "3000000000";
      },
      (t: any) => {
        t.review.plan.network.chainRootAt1 = "unknown";
      },
    ]) {
      const t: any = confirmationFixture();
      change(t);
      await expect(marketConfirmation(t)).rejects.toThrow();
    }
  });
});

describe("visible binding limit policies", () => {
  it("shows Book, Curve and both withdrawal legs without numeric truncation", async () => {
    const book = confirmationFixture();
    book.review.plan.kind = "book-order";
    book.review.request = {
      kind: "book-order",
      terms: {
        side: "0",
        amount: "4.611686018427387921",
        minimum: "2.000000000000000017",
      },
    };
    const b = {limits:marketLimitRows(book)};
    expect(b.limits).toContainEqual({
      label: "Minimum opposite asset output",
      value: "2.000000000000000017 tokens (18 decimals)",
    });
    const curve = confirmationFixture();
    curve.review.plan.kind = "curve-buy";
    curve.review.request = {
      kind: "curve-buy",
      terms: { lots: "17", quoteLimit: "4.611686018427387921" },
    };
    expect(marketLimitRows(curve)).toContainEqual({
      label: "Maximum quote spend",
      value: "4.611686018427387921 tokens (18 decimals)",
    });
    curve.review.plan.kind = "curve-sell";
    curve.review.request.kind = "curve-sell";
    expect(marketLimitRows(curve)[1].label).toBe(
      "Minimum quote output",
    );
    const remove = confirmationFixture();
    remove.review.plan.kind = "remove";
    remove.review.request.kind = "remove";
    remove.review.plan.withdrawal = {
      burned: "4611686018427387921",
      minimumA: "4611686018427387905",
      minimumB: "17",
    };
    expect(marketLimitRows(remove)).toHaveLength(3);
    expect(marketLimitRows(remove)[1].value).toBe(
      "4611686018427387905 base units",
    );
    const html = renderToStaticMarkup(
      createElement(MarketLimitRows, {
        rows: marketLimitRows(remove),
      }),
    );
    expect(html).toContain("Minimum asset A output");
    expect(html).toContain("Minimum asset B output");
    expect(html).toContain("4611686018427387905 base units");
    expect(html).not.toContain("<details");
  });
  it("fails closed on missing or unsupported operative limits", async () => {
    for (const kind of [
      "book-order",
      "curve-buy",
      "curve-sell",
      "remove",
      "nft-buy",
      "claim-nft",
      "unknown",
    ]) {
      const t = confirmationFixture();
      t.review.plan.kind = kind;
      t.review.request.kind = kind;
      expect(()=>marketLimitRows(t)).toThrow();
    }
  });
});
