// Operator-owned candidate diagnostics only; no RPC, signer, proof or payment.
import assert from 'node:assert/strict';
import {open} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {RandomRequestJournal} from '../batching/random-order/requestJournal.mjs';
import {publishFile} from './durableFile.mjs';
async function readPublicJson(path,limit){
 const file=await open(path,'r');const chunks=[];let total=0;
 try{while(total<=limit){const part=Buffer.alloc(Math.min(65536,limit+1-total));const {bytesRead}=await file.read(part,0,part.length,null);if(!bytesRead)break;total+=bytesRead;assert.ok(total<=limit,'public file size limit');chunks.push(part.subarray(0,bytesRead));}return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
 finally{await file.close();}
}
export async function runRandomCandidate(args){
 assert.ok(Array.isArray(args));const [action,directory,candidatePath,reportPath,value]=args;
 assert.ok(['freeze','inspect','observe','timeout','recovery-plan'].includes(action),'candidate diagnostic action required');
 assert.equal(args.length,['observe','timeout'].includes(action)?5:4,'ACTION DIRECTORY CANDIDATE_JSON FRESH_REPORT [EVIDENCE_JSON_OR_CHECKPOINT]');
 const candidate=await readPublicJson(candidatePath,16384),journal=new RandomRequestJournal({directory,candidate});let report;
 if(action==='freeze')report=await journal.freeze();
 if(action==='inspect')report=await journal.inspect();
 if(action==='observe')report=await journal.observe(await readPublicJson(value,6100000));
 if(action==='timeout')report=await journal.observeTimeout(value);
 if(action==='recovery-plan')report=await journal.recoveryPlan();
 await publishFile(reportPath,JSON.stringify({...report,financialOperations:0,proofsGenerated:0},null,2)+'\n');return report;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)runRandomCandidate(process.argv.slice(2)).catch(error=>{console.error(error.message);process.exitCode=1;});
