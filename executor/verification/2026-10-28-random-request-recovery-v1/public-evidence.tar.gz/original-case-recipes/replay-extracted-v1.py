"""Inspect a fresh copy of the preserved public candidate ledger; no execution."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
assert len(sys.argv)==5,'EXTRACTED_ROOT TRUSTED_NODE TRUSTED_EXECUTOR_ROUTE FRESH_OUTPUT_DIRECTORY'
root,node,route,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir();ledger=out/'ledger';shutil.copytree(root/'operator-ledger-v1',ledger)
def records():return {p.relative_to(ledger).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in ledger.rglob('*.json')}
before=records();report=out/'inspection.json';p=subprocess.run([str(node),str(route),'inspect',str(ledger),str(root/'public/candidate-v1.json'),str(report)],capture_output=True,timeout=20)
with (out/'output.log').open('xb')as log:log.write(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
value=json.loads(report.read_text());original=json.loads((root/'public/operator-fixed-v1.json').read_text())
assert value['requestSha256']==original['requestSha256']and value['status']=='fixed-awaiting-qualified-source'
assert not any(value[k]for k in ['chainSealVerified','qualifiedSource','randomAuthorization','canSign','canBroadcast','canRefund'])
assert before==records(),'inspection changed original candidate records'
with (out/'REPORT.json').open('x')as dest:json.dump({'schema':1,'scope':'local copied-record inspection, not chain or proof verification','requestSha256':value['requestSha256'],'originalRecordsUnchanged':True,'records':before,'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest(),'executorRouteSha256':hashlib.sha256(route.read_bytes()).hexdigest(),'financialOperations':0,'proofsGenerated':0,'randomAuthorization':False},dest,indent=2);dest.write('\n')
print('Copied original candidate identity retained; no record change, proof or finance.')
