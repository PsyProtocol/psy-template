import { installedMarketRelease } from "./installed";
import {
  loadOwnedMarketVerifier,
  type MarketVerifierReleasePin,
  type OwnedMarketNative,
  type OwnedMarketWasmModule,
} from "../market-preparation/market-client/wallet/native/ownedLoader.mjs";

export interface InstalledMarketRelease {
  release: MarketVerifierReleasePin;
  chainRootAt1: string;
  registryHashes: readonly string[];
  module: OwnedMarketWasmModule;
  wasmUrl: string;
}
interface ReviewedBundle {
  registryHash: string;
  registry: { network: { chainRootAt1: string } };
  amm?: {
    registryHash: string;
    registry: { network: { chainRootAt1: string } };
  };
}
let loaded: Promise<OwnedMarketNative> | undefined;

// Build-owned module only. There is no installer or resource URL on a web RPC.
export function installedMarketOptions(bundle: ReviewedBundle) {
  const installed = installedMarketRelease;
  if (!installed) return null;
  const expected = [bundle, ...(bundle.amm ? [bundle.amm] : [])];
  if (
    expected.some(
      (b) => b.registry.network.chainRootAt1 !== installed.chainRootAt1,
    ) ||
    expected.length !== installed.registryHashes.length ||
    expected.some((b) => !installed.registryHashes.includes(b.registryHash)) ||
    new Set(installed.registryHashes).size !== expected.length
  )
    throw Error(
      "Installed market release differs from reviewed chain/registries",
    );
  const native = () =>
    (loaded ??= loadOwnedMarketVerifier({
      module: installed.module,
      wasmUrl: installed.wasmUrl,
      release: installed.release,
    }));
  return {
    expectedVerifierPackSha256: installed.release.verifierPackSha256,
    native: {
      identity: async () => (await native()).identity(),
      identify: async (request: string) => (await native()).identify(request),
      verify: async (request: string, approval: string, proofBundle: string) =>
        (await native()).verify(request, approval, proofBundle),
    },
  };
}
