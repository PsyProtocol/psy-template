import {mkdir,writeFile,readFile}from'node:fs/promises';
const out=new URL('observations/readiness-v2/',import.meta.url);await mkdir(out);const rows=[];
for(const name of['realm0','realm1','coordinator','faucet']){
 const url=`https://${name}-stg.psy-protocol.xyz`,request={jsonrpc:'2.0',id:1,method:'psy_get_latest_l2_block_state',params:{}};
 await writeFile(new URL(name+'-request.json',out),JSON.stringify(request)+'\n',{flag:'wx'});
 try{const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),redirect:'error',signal:AbortSignal.timeout(20000)}),raw=await response.text();await writeFile(new URL(name+'.body',out),raw,{flag:'wx'});rows.push({name,url,status:response.status,bodyBytes:Buffer.byteLength(raw)});}catch(e){rows.push({name,url,error:String(e.message)});}
}
await writeFile(new URL('REPORT.json',out),JSON.stringify({at:new Date().toISOString(),readOnly:true,financialOperations:0,result:rows},null,2)+'\n',{flag:'wx'});console.log(rows);
