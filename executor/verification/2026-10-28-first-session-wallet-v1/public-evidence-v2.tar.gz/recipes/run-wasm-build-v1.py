from pathlib import Path
import os,subprocess,json,time,signal
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';fixture=b/'fixtures-v2'
assert all((fixture/p).exists()for p in ['native.json','amm','token','token-b','nft'])
env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','MARKET_WALLET_REPLAY_IN':str(b/'complete-ups-v3'),'BATCH_BUILD':str(fixture),'BATCH_FIXTURE_ASSET_A':'6','BATCH_FIXTURE_ASSET_B':'7','BATCH_FIXTURE_NFT':'8','BATCH_FIXTURE_ISSUER':'1590272','BATCH_FIXTURE_SYMBOL_A':'5325121','BATCH_FIXTURE_SYMBOL_B':'5325122','BATCH_FIXTURE_MARKET':'9','BATCH_FIXTURE_VAULT':'631808','BATCH_DISTINCT_TOKEN_B':'1','BATCH_PROOF_PROFILE':'compact-v1','MARKET_WALLET_TEST_MARKET':'amm','MARKET_WALLET_FIRST_SESSION':'1','MARKET_WALLET_VERIFIER_OUT':str(b/'native-replay-v4')})
env.update({'RUSTFLAGS':'--cfg getrandom_backend="wasm_js"','CC_wasm32_unknown_unknown':str(b.parent/'market-mainnet-migration-20261027-v1/wasm-c-compiler-v1/cc-wasm'),'AR_wasm32_unknown_unknown':str(b.parent/'market-mainnet-migration-20261027-v1/wasm-c-compiler-v1/ar'),'RANLIB_wasm32_unknown_unknown':str(b.parent/'market-mainnet-migration-20261027-v1/wasm-c-compiler-v1/ranlib')})
cmd=['cargo','+nightly-2025-09-20','build','--release','--locked','--offline','--target','wasm32-unknown-unknown','--manifest-path',str(b/'wasm-v1/Cargo.toml')]

start=time.monotonic();samples=[];stopped=None
with (b/'public/wasm-build-v1.log').open('x')as f:
 p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=[list(map(int,x.split()))for x in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()];owned={p.pid}
  for _ in range(8):
   more=owned|{pid for pid,parent,rss in rows if parent in owned}
   if more==owned:break
   owned=more
  rss=sum(rss for pid,parent,rss in rows if pid in owned);samples.append({'elapsedSeconds':time.monotonic()-start,'familyRssKiB':rss})
  if time.monotonic()-start>600 or rss>8192*1024:
   stopped='declared time/memory ceiling';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(1)
result={'exitCode':p.returncode,'seconds':time.monotonic()-start,'stopReason':stopped,'samples':samples,'rssScope':'full launch-to-exit sampled process family, shared pages may duplicate, not physical peak','financialOperations':0}
with (b/'public/wasm-build-result-v1.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(result['exitCode'],result['seconds'],flush=True)
