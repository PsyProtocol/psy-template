from pathlib import Path
import json,hashlib,shutil,subprocess,os,copy
c=Path(__file__).resolve().parent
binary=c/'bin-v14/minimum_stream_plan'
env=os.environ.copy();env.update(PSY_NETWORK='testnet',PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',PSY_CONFIG_PATH=str(c.parent/'sdk-mainnet-beta-20261027-v1/source/psy-sdk/psy-genesis/config.json'),RAYON_NUM_THREADS='2')
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def run(args):
 r=subprocess.run([str(binary),*map(str,args)],env=env,capture_output=True,text=True,timeout=120)
 return {'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'financialOperations':0}
for market,kind in [('amm',1),('bondingcurve',2)]:
 d=c/('native-'+('curve'if kind==2 else'amm')+'-v1');d.mkdir()
 head=c/'full-ups-v3'/(market+'-minimum-0');draw=c/'full-ups-v3'/(market+'-source-0')
 s=json.loads((head/'source.json').read_text());contracts={x['id']:x['leaf']for x in s['contracts']}
 def asset(i,source):
  name=str(i)+'.json';shutil.copyfile(c/source,d/name)
  return {'id':i,'artifact':name,'artifact_sha256':hashlib.sha256((d/name).read_bytes()).hexdigest(),'function_root':contracts[i]['function_tree_root']}
 m=asset(1000,'fixtures-v3/'+market+'/compiled/compilation_artifact.json')
 review={'schema':1,'artifact':m['artifact'],'artifact_sha256':m['artifact_sha256'],'market':1000,'kind':kind,'function_root':m['function_root'],'unit':'1000000000000000000','assets':[asset(0,'fixtures-v3/native.json'),asset(42,'fixtures-v3/token/compilation_artifact.json'),asset(43,'fixtures-v3/token/compilation_artifact.json')]}
 put(d/'review.json',review);put(d/'source.json',s);shutil.copyfile(c/'fixtures-v3'/market/'stream-policy.json',d/'policy.json')
 r=run(['--derive-synthetic-draw',head,draw,d/'draw-opening']);put(d/'derive-result.json',r);assert r['exitCode']==0,r
 shutil.copyfile(d/'draw-opening/draw.json',d/'draw.json')
 root=s['history']['checkpoint_path']['root'];args=[d/'review.json',d/'source.json',root,d/'draw.json',d/'policy.json',d/'prepared']
 r=run(args);put(d/'result.json',r);assert r['exitCode']==0,r
 pages=json.loads((d/'prepared/minimum-pages.json').read_text());report=json.loads((c/'full-ups-v3'/(market+'-REPORT.json')).read_text());queue=json.loads((d/'prepared/queue.json').read_text())
 assert [x['member']['owner']for x in queue]==report['permutation']
 for i,page in enumerate(pages):assert page==json.loads((c/'full-ups-v3'/(market+f'-minimum-{i}')/'plan.json').read_text())['minimum']
 attacks=[]
 for name,change,which in [('wrong-draw',lambda v:v['path'].__setitem__('index',v['path']['index']+1),'draw'),('fake-seed',lambda v:v['checkpoint']['stats'].__setitem__('random_seed','1'*64),'draw'),('wrong-network',lambda v:v['fields'].__setitem__(1,v['fields'][1]+1),'source'),('source-omission',lambda v:v['accounts'].pop(),'source'),('old-window',lambda v:v.__setitem__('source_window_checkpoints',256),'policy')]:
  v=json.loads((d/(which+'.json')).read_text());change(v);p=d/(name+'.json');put(p,v);a=args.copy();a[['review','source','history','draw','policy'].index(which)]=p;a[-1]=d/(name+'-output');r=run(a);put(d/(name+'-result.json'),r);assert r['exitCode']!=0,(name,r);assert not a[-1].exists();attacks.append(name)
 put(d/'REPORT.json',{'nativePlannerVerified':True,'financialOperations':0,'proofsGenerated':0,'sameAcceptedFullUpsPages':True,'sameQueue':True,'attacksRejected':attacks,'source':s['fields'][6],'draw':s['fields'][6]+1,'historyRoot':root,'qualifiedRandomness':False,'causalSealBeforeReleaseAuthenticated':False,'canSign':False,'canBroadcast':False})
