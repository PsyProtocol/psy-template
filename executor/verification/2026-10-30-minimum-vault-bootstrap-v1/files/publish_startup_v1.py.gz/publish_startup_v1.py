from pathlib import Path
import gzip,json,hashlib
c=Path(__file__).resolve().parent;a=Path('<application-root>');out=a/'executor/verification/2026-10-30-minimum-vault-bootstrap-v1'
files=[p for p in (c/'public').rglob('*')if p.is_file()]
allowed={'source.json','current.json','intent.json','plan.json','public-session.json','key-proof.bin','request.json','verification.json','REPORT.json'}
for directory in ['full-ups-v1','full-ups-v2','full-ups-v3','legacy-key-replay-v1']:
 for p in (c/directory).rglob('*'):
  if p.is_file()and(p.name in allowed or p.name.endswith('-REPORT.json')or directory=='legacy-key-replay-v1'):files.append(p)
for directory in ['fixtures-v1']:
 files.extend(p for p in(c/directory).rglob('*')if p.is_file()and p.suffix in ['.rs','.json','.log'])
for d in c.glob('application-v*'):
 for n in ['APPLICATION.json','Cargo.toml','Cargo.lock','src/stream_policy.rs','src/stream_source.rs','tests/support/stream_full_ups.rs','tests/support/minimum_bootstrap_full_ups.rs']:
  if(d/n).is_file():files.append(d/n)
files.extend(p for p in c.iterdir()if p.is_file()and p.suffix in ['.py','.mjs'])
forbidden={'private_key','privateKey','mnemonic','secretKey','signing_witness','signature_witness','secp256k1_slots','recoveryPhrase'}
def scan(v):
 if isinstance(v,dict):
  assert not set(v)&forbidden
  for x in v.values():scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
sha=lambda b:hashlib.sha256(b).hexdigest();prepared=[]
for p in sorted(set(files)):
 assert not p.is_symlink();raw=p.read_bytes();data=raw
 if p.suffix!='.bin':
  data=raw.decode().replace(str(c),'<case-root>').replace(str(a),'<application-root>').replace(str(c.parent),'<evidence-root>').replace(str(Path.home()),'<home>').encode()
  if p.suffix=='.json':scan(json.loads(data))
 prepared.append((p,raw,data))
# All input validation precedes fresh output creation.
out.mkdir();rows=[]
for p,raw,data in prepared:
 q=out/'files'/(p.relative_to(c).as_posix()+'.gz');q.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(data,mtime=0)
 with q.open('xb')as f:f.write(z)
 assert gzip.decompress(q.read_bytes())==data
 rows.append({'source':p.relative_to(c).as_posix(),'file':q.relative_to(out).as_posix(),'originalSha256':sha(raw),'publicSha256':sha(data),'gzipSha256':sha(z),'gzipBytes':len(z),'redacted':raw!=data})
for name,v in [('index.json',rows),('SUMMARY.json',json.loads((c/'public/FINAL-SUMMARY-v1.json').read_text())),('PUBLISHED-AUDIT.json',{'files':len(rows),'allPublicAndCompressedDigestsVerified':True,'explicitProjectionFieldScanPassed':True,'rawWitnessesIncluded':False,'financialOperations':0})]:
 with(out/name).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps({'files':len(rows),'gzipBytes':sum(v['gzipBytes']for v in rows)}))
