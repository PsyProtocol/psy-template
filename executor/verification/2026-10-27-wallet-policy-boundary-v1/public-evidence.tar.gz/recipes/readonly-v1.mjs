import{mkdir,writeFile}from'node:fs/promises';
const out=new URL('./observations-v1/',import.meta.url);await mkdir(out);const results=[];
for(const[name,url,method,params]of[
 ['realm0','https://realm0-stg.psy-protocol.xyz','psy_get_latest_l2_block_state',{}],
 ['realm1','https://realm1-stg.psy-protocol.xyz','psy_get_latest_l2_block_state',{}],
 ['checkpoint1','https://coordinator-stg.psy-protocol.xyz','psy_get_checkpoint_leaf_data',{checkpoint_id:1}],
 ['native','https://coordinator-stg.psy-protocol.xyz','psy_get_contract_leaf_data',{contract_id:0}],
 ['circuits','https://prove-stg.psy-protocol.xyz','psy_get_circuits_data',[]],
 ['faucet','https://faucet-stg.psy-protocol.xyz','psy_get_psy_faucet_config',[]]]){
 const request={jsonrpc:'2.0',id:1,method,params};await writeFile(new URL(name+'-request.json',out),JSON.stringify(request)+'\n',{flag:'wx'});
 try{const start=performance.now();const r=await fetch(url,{method:'POST',body:JSON.stringify(request),headers:{'content-type':'application/json'},redirect:'error',signal:AbortSignal.timeout(20000)}),raw=await r.text();await writeFile(new URL(name+'-response.json',out),raw,{flag:'wx'});results.push({name,httpStatus:r.status,bytes:Buffer.byteLength(raw),elapsedMs:performance.now()-start});}catch(e){results.push({name,error:e.message});}
}
await writeFile(new URL('REPORT.json',out),JSON.stringify({at:new Date().toISOString(),results,financialOperations:0,boundary:'single read-only observations, not confirmation performance or service attestation'},null,2)+'\n',{flag:'wx'});console.log(results.map(r=>({name:r.name,status:r.httpStatus??r.error})));
