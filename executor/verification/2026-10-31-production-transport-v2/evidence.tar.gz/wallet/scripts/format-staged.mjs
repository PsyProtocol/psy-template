// Format only staged authored files. Generated/pinned bytes use integrity checks.
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

export function authoredPaths(paths) {
  return paths.filter((name) => {
    assert.ok(
      !name.startsWith("/") &&
        name.split(/[\\/]/).every((p) => p && p !== "." && p !== ".."),
      "Confined staged path required",
    );
    return (
      !["src/market-preparation/", "psy-genesis/", "sdk/"].some((prefix) =>
        name.startsWith(prefix),
      ) && /\.(?:[cm]?js|jsx|[cm]?ts|tsx|json|jsonc|css)$/.test(name)
    );
  });
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const root = fileURLToPath(new URL("../", import.meta.url));
  const listing = spawnSync(
    "git",
    ["diff", "--cached", "--name-only", "--diff-filter=ACMR", "-z"],
    { cwd: root, encoding: "utf8" },
  );
  assert.equal(listing.status, 0, "Cannot inspect staged paths");
  const files = authoredPaths(listing.stdout.split("\0").filter(Boolean));
  if (files.length) {
    const result = spawnSync(
      "pnpm",
      [
        "exec",
        "biome",
        "format",
        "--write",
        ...files.map((name) => "./" + name),
      ],
      { cwd: root, stdio: "inherit" },
    );
    assert.equal(result.status, 0, "Staged authored format failed");
  }
}
