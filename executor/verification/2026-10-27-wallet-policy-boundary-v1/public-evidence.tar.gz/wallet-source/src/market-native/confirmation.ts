import { digest } from "../market-preparation/market-client/protocol.mjs";
import type { PreparationContext } from "../market-preparation/market-client/wallet/prepareService.mjs";
export interface MarketConfirmationTerms {
  schema: 1;
  context: PreparationContext;
  intentId: string;
  recordId: string;
  preparedHash: string;
  requestSha256: string;
  fullCalls: Array<{
    contract_id: string;
    method_name: string;
    inputs: string[];
  }>;
  actualFee: string;
  maxNetworkFee: string;
  validUntilCheckpoint: number;
  review: {
    request: Record<string, unknown>;
    plan: {
      kind: string;
      marketId: number;
      recipientId: number;
      walletNonce: string;
      network: { name: string; chainRootAt1: string };
      debits: Array<{ contractId: number; amount: string }>;
      [key: string]: unknown;
    };
  };
}
const hash = /^[0-9a-f]{64}$/;
// Validate only a public projection. Hydrated traces and signing witnesses must
// never cross into the approval window or its runtime message queue.
export async function marketConfirmation(unknownTerms: unknown) {
  const terms = structuredClone(unknownTerms) as MarketConfirmationTerms;
  const keys = [
    "schema",
    "context",
    "intentId",
    "recordId",
    "preparedHash",
    "requestSha256",
    "fullCalls",
    "actualFee",
    "maxNetworkFee",
    "validUntilCheckpoint",
    "review",
  ];
  if (
    !terms ||
    Object.keys(terms).sort().join() !== keys.sort().join() ||
    terms.schema !== 1 ||
    ![
      terms.intentId,
      terms.recordId,
      terms.preparedHash,
      terms.requestSha256,
      terms.context?.account,
    ].every((v) => hash.test(v ?? "")) ||
    !Array.isArray(terms.fullCalls) ||
    terms.fullCalls.length < 1 ||
    terms.fullCalls.length > 40 ||
    !/^[1-9]\d*$/.test(terms.actualFee) ||
    !/^[1-9]\d*$/.test(terms.maxNetworkFee) ||
    BigInt(terms.actualFee) > BigInt(terms.maxNetworkFee) ||
    !Number.isSafeInteger(terms.validUntilCheckpoint) ||
    terms.review?.plan?.recipientId !== terms.context.userId ||
    !Array.isArray(terms.review?.plan?.debits) ||
    typeof terms.review?.plan?.kind !== "string" ||
    !hash.test(terms.review?.plan?.network?.chainRootAt1 ?? "")
  )
    throw Error("Wallet-owned exact market confirmation is incomplete");
  const origin = new URL(terms.context.origin);
  if (
    origin.origin !== terms.context.origin ||
    !["https:", "http:"].includes(origin.protocol)
  )
    throw Error("Exact requesting origin required");
  return { terms, approvalSha256: await digest(terms) };
}
