from pathlib import Path
import json,subprocess,hashlib,os
c=Path(__file__).resolve().parent;d=c/'public/latest-readiness-v1';d.mkdir()
def put(n,v):
 with(d/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
put('PLAN.json',{'additionalMaximumReadOnlyRequests':3,'previousInvestigationReadRequests':10,'maximumTotalReadRequests':13,'retriesPerRequest':0,'maxSecondsPerRequest':40,'scope':'fresh current-cohort check; original 18504/18505 bytes retained unchanged','financialOperations':0,'financialBudgetBaseUnits':'0','proofsGenerated':0})
def fetch(label,request):
 put(label+'-request.json',request);p=subprocess.run(['curl','--silent','--show-error','--connect-timeout','5','--max-time','40','--max-filesize','2097152','--header','content-type: application/json','--data-binary','@-','https://coordinator-stg.psy-protocol.xyz'],input=json.dumps(request).encode(),capture_output=True,timeout=45);(d/(label+'-response.raw')).write_bytes(p.stdout);put(label+'-transport.json',{'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace')});assert p.returncode==0
 v=json.loads(p.stdout);assert v.get('id')==request['id'] and 'result'in v,v;return v['result']
head=fetch('head',{'jsonrpc':'2.0','id':1,'method':'psy_get_latest_checkpoint_id','params':{}});assert type(head)is int and head>1
ids=[head-1,head];put('selected-checkpoints.json',{'observedHead':head,'ids':ids,'finalityVerified':False})
for cp in ids:
 data=fetch(str(cp),{'jsonrpc':'2.0','id':cp,'method':'psy_get_checkpoint_state_transition_proof','params':{'checkpoint_id':cp}});assert isinstance(data,list)and 0<len(data)<=2000000 and all(type(x)is int and 0<=x<256 for x in data);(d/(str(cp)+'.bin')).write_bytes(bytes(data))
env={**os.environ,'PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(c.parent/'sdk-mainnet-beta-20261027-v1/source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','RAYON_NUM_THREADS':'2'}
p=subprocess.run([str(c/'bin-v5/diagnose_checkpoint_resources'),'cached',*(str(d/(str(i)+'.bin'))for i in ids),str(d/'verified.json')],env=env,capture_output=True,text=True,timeout=90);(d/'diagnostic.log').write_text(p.stdout+p.stderr);put('process.json',{'exitCode':p.returncode,'proofsGenerated':0,'financialOperations':0});print('head',head,'diagnostic exit',p.returncode)
