import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// ── Mocks ───────────────────────────────────────────────────────────────────
// Hermetic in the tx-queue.test.ts style: in-memory extStorage, stubbed
// browser.windows, no SDK/WASM. Counts every popup the manager opens so the
// assertions below are literally "how many times did a window appear".
const {
  store,
  windowsCreated,
  dispatchedApproveStates,
  internalExecClaimBatch,
} = vi.hoisted(() => ({
  store: new Map<string, unknown>(),
  windowsCreated: [] as Array<{ url: string }>,
  dispatchedApproveStates: [] as Array<unknown>,
  internalExecClaimBatch: vi.fn(),
}));

vi.mock("@/lib/extStorage", () => ({
  default: {
    get: async (k: string) => store.get(k),
    set: async (k: string, v: unknown) => void store.set(k, v),
    remove: async (k: string) => void store.delete(k),
    sessionGet: async (k: string) => store.get(k),
    sessionSet: async (k: string, v: unknown) => void store.set(k, v),
    sessionRemove: async (k: string) => void store.delete(k),
  },
}));

vi.mock("webextension-polyfill", () => ({
  default: {
    runtime: {
      id: "test-extension-id",
      getURL: (path: string) => `chrome-extension://test-extension-id/${path}`,
    },
    windows: {
      create: vi.fn(async (options: { url: string }) => {
        windowsCreated.push({ url: options.url });
        return { id: windowsCreated.length };
      }),
      // Popup "stays open": the close-poll must never see a rejection.
      get: vi.fn(async () => ({})),
      // Anchor computation (a721e89) resolves the parent window before every
      // create; a window without numeric bounds keeps left/top undefined —
      // the same create shape these tests always asserted.
      getLastFocused: vi.fn(async () => ({})),
      update: vi.fn(async () => ({})),
    },
  },
}));

// The SDK is only used for PsyJSON (de)serialization here; plain JSON keeps
// the test WASM-free and lets us parse results directly.
vi.mock("@psy-protocol/psy-sdk", () => ({ PsyJSON: JSON }));

// claimables pulls the SDK + poseidon vendor code; approve-manager only calls
// these for shield/external-proof actions, which these tests never exercise.
vi.mock("@/lib/claimables", () => ({
  externalProofParamsToPrivateTransferClaimRaw: vi.fn(),
  shieldDepositParamsToClaimBatchItem: vi.fn(),
}));

vi.mock("@/message", () => ({
  psyApproveMsgDispatch: vi.fn(async (state: unknown) => {
    dispatchedApproveStates.push(state);
  }),
  psyAccountsApproveDispatch: vi.fn(async () => {}),
}));

vi.mock("@/background/connection-manager", () => ({
  default: { broadcast: vi.fn(), getConnections: () => [] },
}));

import approveManager from "@/background/approve-manager";
import accountsApproved from "@/background/accounts-approved";
import type { ApproveMsg } from "@/types";

// ── Fixtures ────────────────────────────────────────────────────────────────

const ORIGIN = "https://dapp.example";
const WALLET = "psy1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

const sender = {
  // NOT the extension id → external dapp path (no internal fast-path).
  id: "some-tab-sender",
  origin: ORIGIN,
  url: `${ORIGIN}/page`,
  tab: { favIconUrl: undefined },
} as any;

const walletSnapshot = {
  currentWallet: { address: WALLET } as any,
  wallets: [{ address: WALLET }] as any,
};

const core = {
  _currentWallet: { address: WALLET },
  getApproveWalletSnapshot: () => walletSnapshot,
  execClaimBatch: internalExecClaimBatch,
} as any;

let nextId = 0;
function connectMsg(
  action: "psy_requestAccounts" | "psy_requestPermissions",
): ApproveMsg {
  nextId += 1;
  return { id: `req-${nextId}`, isPsy: true, action, params: [] } as any;
}

function claimBatchMsg(items: unknown[]): ApproveMsg {
  nextId += 1;
  return {
    id: `req-${nextId}`,
    isPsy: true,
    action: "psy_execClaimBatch",
    params: JSON.stringify([WALLET, items]),
  } as any;
}

function receive(msg: ApproveMsg) {
  return approveManager.receiveApproveMsg(msg, {
    sender,
    currentWallet: WALLET,
    core,
    walletSnapshot,
  });
}

/** Wait until the manager has opened `count` popups. */
async function waitForPopups(count: number) {
  await vi.waitFor(() => expect(windowsCreated.length).toBe(count));
}

/** The live prompt's approval id, read from the popup URL it opened. */
function livePromptId(index = windowsCreated.length - 1): string {
  const url = new URL(windowsCreated[index].url);
  return url.searchParams.get("psy_approve_id")!;
}

/** Simulate the user clicking Connect in the popup for the live prompt. */
function approveLivePrompt() {
  return approveManager.handleApproveMsg(
    {
      id: livePromptId(),
      result: JSON.stringify({ origin: ORIGIN, accounts: [WALLET] }),
      error: "",
    },
    core,
  );
}

/** Simulate the user rejecting the live prompt. */
function rejectLivePrompt() {
  return approveManager.handleApproveMsg(
    { id: livePromptId(), result: "", error: "User rejected" },
    core,
  );
}

beforeEach(() => {
  store.clear();
  windowsCreated.length = 0;
  dispatchedApproveStates.length = 0;
  (accountsApproved as any).approvedMap = {};
});

describe("approve-manager Claim All execution", () => {
  it("passes the complete heterogeneous ClaimBatchItem array to one execClaimBatch call", async () => {
    internalExecClaimBatch.mockResolvedValueOnce({ tx_hash: "0xbatch" });
    const items = [
      {
        type: "public",
        data: {
          contract_id: "0",
          method_name: "simple_claim",
          inputs: ["1001"],
        },
      },
      {
        type: "private_transfer",
        data: {
          contract_id: "0",
          claim: { amount: "400000000" },
        },
      },
      {
        type: "claim_shield_deposit",
        data: {
          contract_id: "4",
          deposit_index: "3",
          amount_u32x8: ["0", "0", "0", "0", "0", "0", "0", "50000000"],
        },
      },
    ];
    const internalSender = {
      id: "test-extension-id",
      origin: "chrome-extension://test-extension-id",
      url: "chrome-extension://test-extension-id/src/popup/index.html",
    } as any;

    const response = (await approveManager.receiveApproveMsg(
      claimBatchMsg(items),
      {
        sender: internalSender,
        currentWallet: WALLET,
        core,
        walletSnapshot,
      },
    )) as { result: string; error: unknown };

    expect(response.error).toBeNull();
    expect(internalExecClaimBatch).toHaveBeenCalledTimes(1);
    expect(internalExecClaimBatch).toHaveBeenCalledWith(WALLET, items);
    expect(windowsCreated).toHaveLength(0);
    expect(JSON.parse(response.result)).toEqual({ tx_hash: "0xbatch" });
  });
});

// ── Tests ───────────────────────────────────────────────────────────────────

describe("approve-manager connect dedupe", () => {
  it("second identical connect during an open prompt resolves without a second popup", async () => {
    const first = receive(connectMsg("psy_requestAccounts"));
    await waitForPopups(1);

    // Dapp double-fires while the prompt is open (React double-mount etc.).
    const second = receive(connectMsg("psy_requestAccounts"));
    await approveLivePrompt();

    const [firstResult, secondResult] = (await Promise.all([
      first,
      second,
    ])) as Array<{ id: string; result: string; error: unknown }>;

    expect(windowsCreated.length).toBe(1); // ONE popup, ever
    expect(firstResult.error).toBeNull();
    expect(secondResult.error).toBeNull();
    expect(JSON.parse(firstResult.result)).toEqual([WALLET]);
    expect(JSON.parse(secondResult.result)).toEqual([WALLET]);
    // Each caller gets its own JSON-RPC id back.
    expect(firstResult.id).not.toBe(secondResult.id);
  });

  it("both connects reject when the single prompt is rejected (no leaked waiter)", async () => {
    const first = receive(connectMsg("psy_requestAccounts"));
    await waitForPopups(1);
    const second = receive(connectMsg("psy_requestAccounts"));
    await rejectLivePrompt();

    const [firstResult, secondResult] = (await Promise.all([
      first,
      second,
    ])) as Array<{ id: string; result: unknown; error: string }>;

    expect(windowsCreated.length).toBe(1);
    expect(firstResult.error).toBe("User rejected");
    expect(secondResult.error).toBe("User rejected");

    // Rejection must not have approved the origin: a fresh connect prompts.
    const third = receive(connectMsg("psy_requestAccounts"));
    await waitForPopups(2);
    await approveLivePrompt();
    const thirdResult = (await third) as { error: unknown };
    expect(thirdResult.error).toBeNull();
  });

  it("requestAccounts queued behind requestPermissions is silently resolved once the origin is approved (head-of-queue re-check)", async () => {
    // The cross-action double-ask: app fires requestPermissions AND
    // requestAccounts back-to-back. These do NOT coalesce (different
    // semantics), but once the permissions prompt approves the origin, the
    // queued requestAccounts must resolve without a second popup.
    const perms = receive(connectMsg("psy_requestPermissions"));
    await waitForPopups(1);
    const accounts = receive(connectMsg("psy_requestAccounts"));
    await approveLivePrompt();

    const [permsResult, accountsResult] = (await Promise.all([
      perms,
      accounts,
    ])) as Array<{ result: string; error: unknown }>;

    expect(windowsCreated.length).toBe(1); // no second popup
    expect(permsResult.error).toBeNull();
    expect(accountsResult.error).toBeNull();
    expect(JSON.parse(accountsResult.result)).toEqual([WALLET]);
  });

  it("an already-approved origin re-prompts for psy_requestPermissions (account re-selection is preserved)", async () => {
    await accountsApproved.editApproved(ORIGIN, [WALLET]);

    const perms = receive(connectMsg("psy_requestPermissions"));
    await waitForPopups(1); // still prompts by design
    await approveLivePrompt();
    const result = (await perms) as { error: unknown };
    expect(result.error).toBeNull();
  });

  it("an unrelated action queued behind a connect still gets its own prompt", async () => {
    // Pre-approve so the tx passes the origin gate at enqueue time.
    await accountsApproved.editApproved(ORIGIN, [WALLET]);

    // requestPermissions always prompts, so it holds the queue head open.
    const perms = receive(connectMsg("psy_requestPermissions"));
    await waitForPopups(1);

    nextId += 1;
    const tx = approveManager.receiveApproveMsg(
      {
        id: `req-${nextId}`,
        isPsy: true,
        action: "psy_sendTransaction",
        params: JSON.stringify([WALLET, { method_name: "m", inputs: [] }]),
      } as any,
      { sender, currentWallet: WALLET, core, walletSnapshot },
    );

    await approveLivePrompt();
    await (perms as Promise<unknown>);

    // The transaction is NOT coalesced and NOT short-circuited: second popup.
    await waitForPopups(2);
    await approveManager.handleApproveMsg(
      { id: livePromptId(1), result: "", error: "User rejected" },
      core,
    );
    const txResult = (await tx) as { error: string };
    expect(txResult.error).toBe("User rejected");
  });

  it("a duplicate connect from a DIFFERENT origin is not coalesced", async () => {
    const first = receive(connectMsg("psy_requestAccounts"));
    await waitForPopups(1);

    nextId += 1;
    const otherSender = {
      ...sender,
      origin: "https://other.example",
      url: "https://other.example/page",
    };
    const other = approveManager.receiveApproveMsg(
      {
        id: `req-${nextId}`,
        isPsy: true,
        action: "psy_requestAccounts",
        params: [],
      } as any,
      { sender: otherSender, currentWallet: WALLET, core, walletSnapshot },
    );

    await approveLivePrompt(); // approves dapp.example only
    await (first as Promise<unknown>);

    // other.example still needs its own consent.
    await waitForPopups(2);
    await approveManager.handleApproveMsg(
      {
        id: livePromptId(1),
        result: JSON.stringify({
          origin: "https://other.example",
          accounts: [WALLET],
        }),
        error: "",
      },
      core,
    );
    const otherResult = (await other) as { error: unknown };
    expect(otherResult.error).toBeNull();
  });
});

describe("approve-manager prompt timeout", () => {
  // An unattended approve prompt times out (APPROVE_PROMPT_TIMEOUT_MS = 5min)
  // and BOTH the head and any coalesced duplicate followers settle as rejected
  // under their own JSON-RPC id — no waiter is ever stranded. Fake timers let
  // us cross the 5-min wall without waiting.
  beforeEach(() => {
    store.clear();
    windowsCreated.length = 0;
    dispatchedApproveStates.length = 0;
    (accountsApproved as any).approvedMap = {};
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("times out after 5 min and settles the head AND coalesced followers as rejected (no leaked waiter)", async () => {
    const head = receive(connectMsg("psy_requestAccounts"));
    // Flush microtasks so the popup-creation IIFE runs and the popup opens.
    await vi.advanceTimersByTimeAsync(0);
    expect(windowsCreated).toHaveLength(1);

    // A dapp double-fire (React double-mount): identical connect piggybacks on
    // the head, never opens a second popup.
    const follower = receive(connectMsg("psy_requestAccounts"));
    await vi.advanceTimersByTimeAsync(0);

    // Cross the 5-min prompt-timeout wall.
    await vi.advanceTimersByTimeAsync(5 * 60_000);

    const [headResult, followerResult] = (await Promise.all([
      head,
      follower,
    ])) as Array<{ id: string; result: unknown; error: string }>;

    expect(windowsCreated).toHaveLength(1); // ONE popup, ever
    expect(headResult.error).toBe("Approval timed out");
    expect(followerResult.error).toBe("Approval timed out");
    // Each caller keeps its own JSON-RPC id back.
    expect(headResult.id).not.toBe(followerResult.id);
    // The queue drained — no queued request leaked.
    expect(
      (approveManager as unknown as { queue: unknown[] }).queue,
    ).toHaveLength(0);
  });

  it("does not time out before the 5-min window (a prompt that resolves just under the deadline still settles normally)", async () => {
    const head = receive(connectMsg("psy_requestAccounts"));
    await vi.advanceTimersByTimeAsync(0);
    expect(windowsCreated).toHaveLength(1);

    // One tick short of the timeout: the prompt is still pending.
    await vi.advanceTimersByTimeAsync(5 * 60_000 - 1);
    expect(windowsCreated).toHaveLength(1);

    // User approves just in time — the head resolves approved, no timeout.
    await approveLivePrompt();
    const headResult = (await head) as {
      id: string;
      result: string;
      error: unknown;
    };
    expect(headResult.error).toBeNull();
    expect(JSON.parse(headResult.result)).toEqual([WALLET]);
  });
});

describe("wallet-owned exact market approval", () => {
  async function terms() {
    const {confirmationFixture} = await import("../../market-native/confirmation.fixture");
    return confirmationFixture();
  }
  it("always opens a dedicated prompt and accepts only its exact digest", async () => {
    const priorExecutions = internalExecClaimBatch.mock.calls.length;
    const pending = approveManager.confirmPreparedMarket(await terms());
    await waitForPopups(1);
    const prompt = dispatchedApproveStates.find((v:any) => v?.action === "psy_confirmPreparedMarket") as any;
    expect(prompt.params[0]).toBe("a".repeat(64));
    await approveManager.handleApproveMsg({id:livePromptId(), result:JSON.stringify({approved:true,approvalSha256:prompt.params[2]}), error:""},core);
    await expect(pending).resolves.toEqual({approved:true,approvalSha256:prompt.params[2]});
    expect(internalExecClaimBatch.mock.calls.length).toBe(priorExecutions);
  });
  it("rejects page-initiated confirmations and substituted approval results", async () => {
    await expect(receive({id:"forged",isPsy:true,action:"psy_confirmPreparedMarket",params:[]} as any)).rejects.toThrow("cannot be initiated");
    const pending = approveManager.confirmPreparedMarket(await terms());
    await waitForPopups(1);
    await approveManager.handleApproveMsg({id:livePromptId(),result:JSON.stringify({approved:true,approvalSha256:"0".repeat(64)}),error:""},core);
    await expect(pending).resolves.toEqual({approved:false});
  });
  it("does not queue behind an approval waiting for the transaction queue", async () => {
    const connect = receive(connectMsg("psy_requestPermissions"));
    await waitForPopups(1);
    await expect(approveManager.confirmPreparedMarket(await terms())).rejects.toThrow("Another wallet approval");
    await rejectLivePrompt();await connect;
    expect(windowsCreated.length).toBe(1);
  });
});
