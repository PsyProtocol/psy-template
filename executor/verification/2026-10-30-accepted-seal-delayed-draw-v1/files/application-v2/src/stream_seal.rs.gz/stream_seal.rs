//! Accepted-seal membership under the *same* signed history as the draw CFC.
//! Certifies index order only, not canonical finality or seed secrecy/bias.
use crate::{
    final_state_coverage::{Review, Snapshot, StateOpening},
    market_key::SDKeyCircuitGadget,
    stream_context::SourceContextTargets,
    stream_source::{lt, Tape},
};
use anyhow::{ensure, Context, Result};
use plonky2::{
    field::{
        goldilocks_field::GoldilocksField as F,
        types::{Field, PrimeField64},
    },
    hash::{hash_types::HashOutTarget, poseidon::PoseidonHash as H},
    iop::{
        target::{BoolTarget, Target},
        witness::{PartialWitness, WitnessWrite},
    },
    plonk::circuit_builder::CircuitBuilder,
};
use psy_client_common::data::qhashout::QHashOut as Q;
use psy_common_circuit::hash::merkle::gadgets::merkle_proof::MerkleProofGadget;
use psy_crypto::hash::{merkle::core::MerkleProofCore, traits::hasher::MerkleZeroHasher};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
pub const DRAW_DELAY: u64 = 32;
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AcceptedSeal {
    pub snapshot: Snapshot,
    pub vault_path: MerkleProofCore<Q<F>>,
}
fn f(n: u64) -> F {
    F::from_canonical_u64(n)
}
fn eq(b: &mut CircuitBuilder<F, 2>, gate: BoolTarget, a: Target, c: Target) {
    crate::batch_policy::eq(b, gate, a, c)
}
fn hash_eq(b: &mut CircuitBuilder<F, 2>, gate: BoolTarget, a: HashOutTarget, c: HashOutTarget) {
    for (x, y) in a.elements.into_iter().zip(c.elements) {
        eq(b, gate, x, y)
    }
}
pub fn word_offsets(r: &Review) -> Result<Vec<u64>> {
    let mut out = vec![];
    for (name, width) in [
        ("stream_scope", 4),
        ("stream_target_users", 4),
        ("stream_source", 1),
        ("stream_id", 1),
        ("stream_expiry", 1),
        ("stream_seed_installed", 1),
        ("stream_phase", 1),
        ("stream_busy", 1),
    ] {
        let start = *r
            .offsets
            .get(name)
            .with_context(|| format!("accepted-seal field {name}"))?;
        out.extend((0..width).map(|i| start + i));
    }
    Ok(out)
}
pub struct Targets {
    pub checkpoint: Target,
    scope: Vec<Target>,
    facts: Vec<HashOutTarget>,
    context: SourceContextTargets,
    words: BTreeMap<u64, MerkleProofGadget>,
}
impl Targets {
    pub fn add(
        b: &mut CircuitBuilder<F, 2>,
        t: &mut Tape,
        r: &Review,
        g: &SDKeyCircuitGadget,
        original: &[Target],
        original_users: HashOutTarget,
        scope_hash: HashOutTarget,
        chain: [u64; 4],
        gate: BoolTarget,
    ) -> Result<Self> {
        let scope = (0..41).map(|_| t.scalar(b)).collect::<Vec<_>>();
        let facts = (0..5).map(|_| t.hash(b)).collect::<Vec<_>>();
        let context = SourceContextTargets::add(b, t, r, g, &scope, &facts, chain, gate)?;
        // Historical C has its own leaf/hash/seed. Only the original immutable market
        // identity, epoch, expiry and chain match S; no fake equality of S/C states.
        for i in [1usize, 2, 3, 4, 5, 7]
            .into_iter()
            .chain(9..13)
            .chain(25..41)
        {
            eq(b, gate, scope[i], original[i]);
        }
        let checkpoint = scope[6];
        let draw = b.add_const(original[6], f(DRAW_DELAY));
        b.range_check(draw, 32);
        let a = lt(b, original[6], checkpoint, 32);
        let c = lt(b, checkpoint, draw, 32);
        let one = b.one();
        let zero = b.zero();
        eq(b, gate, a.target, one);
        eq(b, gate, c.target, one);
        let mut words = BTreeMap::new();
        for offset in word_offsets(r)? {
            let index = offset / 4;
            if !words.contains_key(&index) {
                let proof = t.proof(b, 31);
                let at = b.constant(f(index));
                eq(b, gate, proof.index, at);
                hash_eq(b, gate, proof.root, facts[4]);
                words.insert(index, proof);
            }
        }
        let read = |name: &str, i: u64| {
            let o = r.offsets[name] + i;
            words[&(o / 4)].value.elements[(o % 4) as usize]
        };
        for i in 0..4 {
            eq(
                b,
                gate,
                read("stream_scope", i as u64),
                scope_hash.elements[i],
            );
            eq(
                b,
                gate,
                read("stream_target_users", i as u64),
                original_users.elements[i],
            );
        }
        for (name, value) in [
            ("stream_source", original[6]),
            ("stream_id", original[5]),
            ("stream_expiry", original[7]),
            ("stream_seed_installed", zero),
            ("stream_busy", zero),
        ] {
            eq(b, gate, read(name, 0), value);
        }
        let phase = read("stream_phase", 0);
        let two = b.constant(f(2));
        let p1 = b.is_equal(phase, one);
        let p2 = b.is_equal(phase, two);
        let accepted = b.or(p1, p2);
        eq(b, gate, accepted.target, one);
        Ok(Self {
            checkpoint,
            scope,
            facts,
            context,
            words,
        })
    }
    pub fn set(
        &self,
        pw: &mut PartialWitness<F>,
        r: &Review,
        opening: Option<&AcceptedSeal>,
        original: &[u64],
    ) -> Result<()> {
        if let Some(p) = opening {
            ensure!(
                p.snapshot.fields.len() == 41 && original.len() == 41,
                "accepted seal scope shape"
            );
            for (t, n) in self.scope.iter().zip(&p.snapshot.fields) {
                pw.set_target(*t, f(*n))?;
            }
            let vault = p
                .snapshot
                .accounts
                .iter()
                .find(|a| a.leaf.user_id.to_canonical_u64() == original[4])
                .context("accepted seal vault")?;
            let contracts = [
                vault.native.as_ref().context("seal native")?,
                vault.asset_a.as_ref().context("seal A")?,
                vault.asset_b.as_ref().context("seal B")?,
                &vault.market,
            ];
            pw.set_hash_target(self.facts[0], p.snapshot.history.roots.user_tree_root.0)?;
            for (t, c) in self.facts[1..].iter().zip(contracts) {
                pw.set_hash_target(*t, c.contract_path.value.0)?;
            }
            self.context.set(pw, r, &p.snapshot, &p.vault_path)?;
            for (index, t) in &self.words {
                let proof = vault
                    .market
                    .words
                    .iter()
                    .find(|w| w.index == *index)
                    .context("accepted seal state word")?;
                t.set_witness_core_proof_q(pw, proof)?;
            }
        } else {
            for t in &self.scope {
                pw.set_target(*t, F::ZERO)?;
            }
            for t in &self.facts {
                pw.set_hash_target(*t, plonky2::hash::hash_types::HashOut::ZERO)?;
            }
            self.context.set_empty(pw)?;
            for t in self.words.values() {
                let p = MerkleProofCore::new_from_params::<H>(
                    0,
                    Q::ZERO,
                    (0..31)
                        .map(<H as MerkleZeroHasher<Q<F>>>::get_zero_hash)
                        .collect(),
                );
                t.set_witness_core_proof_q(pw, &p)?;
            }
        }
        Ok(())
    }
}
