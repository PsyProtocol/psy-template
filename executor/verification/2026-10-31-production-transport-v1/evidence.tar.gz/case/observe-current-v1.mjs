// Bounded configured staging reads only. No signing, proof generation or broadcast.
import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {publicState} from '../../psy-template-security-20261016/executor/publicState.mjs';
import {readBoundedUtf8} from '../../psy-template-security-20261016/market-client/rpcWire.mjs';
import {losslessJson} from '../../psy-template-security-20261016/amm/u124/client.mjs';
const out=new URL('current-v1/',import.meta.url);await mkdir(out);let n=0;const deadline=Date.now()+120000;
const fetcher=async(url,options)=>{
 assert.ok(++n<=20&&Date.now()<deadline,'declared staging read budget exhausted');
 const q=JSON.parse(options.body);assert.ok(q.method.startsWith('psy_get_'),'reads only');
 await writeFile(new URL(n+'-request.json',out),losslessJson({endpoint:url,wire:options.body}),{flag:'wx'});
 const response=await fetch(url,{...options,signal:AbortSignal.any([options.signal,AbortSignal.timeout(deadline-Date.now())])});
 const raw=await readBoundedUtf8(response,1048576);
 await writeFile(new URL(n+'-response.json',out),raw,{flag:'wx'});
 return new Response(raw,{status:response.status,headers:response.headers});
};
const s=await publicState(new URL('../../psy-template-security-20261016/market-client/reviewed/mainnet-beta-markets-20261027-v3/rpc-config.json',import.meta.url),{fetchImpl:fetcher});
assert.equal(s.networkName,'testnet');assert.equal(BigInt(s.network.magic),1384803358401154921n);
const coordinator=s.coordinator,realm0=s.network.realm_configs.find(r=>r.id===0).rpc_url[0],realm1=s.network.realm_configs.find(r=>r.id===1).rpc_url[0];
const anchor=await s.rpc(coordinator,'psy_get_checkpoint_leaf_data',{checkpoint_id:1});
assert.equal(anchor.global_chain_root,'919896e18690246e20307f68cf2e5725aee496755366bbafff88eccaea975f12','current chain changed; stop');
const contract=await s.contractLeaf(8);
for(const [k,v]of Object.entries({deployer:223232,code_root:'5627c4d45104b2b5f19f72cbd42c82b818077f06e9018ea0e6115dbbaa129190',state_layout_root:'62224d708fde9cd6df9a304c2fc5eab0a376a30c13766a39407fcd8587a56724',function_tree_root:'90e9e91f134ce4e887f8c9d173700c6ecf44cb88e31d4a6f7b9709cbfe916e40',state_tree_height:31,state_layout_field_count:15,state_layout_slot_count:1174405221}))assert.equal(contract[k],v,'included QA FT identity changed');
const heights=[];
for(const [url,checkpoint]of [[realm0,s.checkpoint],[realm0,9223372036854775807n],[realm1,9223372036854775807n],[coordinator,9223372036854775807n]])heights.push({endpoint:url,checkpoint,result:await s.rpc(url,'psy_get_contract_tree_state_heights',{checkpoint_id:checkpoint,contract_ids:[8]},{exactIntegers:true})});
let state;
try{state={result:await s.slot(223232,8,0),available:true};}
catch(e){state={available:false,error:e.name,message:e.message,cause:e.cause?.message??null};}
const own=await s.rpc(realm0,'psy_get_user_leaf_data',{checkpoint_id:s.checkpoint,user_id:223232},{exactIntegers:true});
assert.equal(own.public_key,'97a9f5724e2f2ea4a7a59c884b9e6f79c7978016629519bae26e96e8b681d834');
const balance=await s.slot(223232,0,0);
const result={schema:1,checkpoint:s.checkpoint,heads:s.heads,chainRootAt1:anchor.global_chain_root,contract,heights,state,issuerNonce:own.nonce,nativeBalanceBaseUnits:balance,readRequests:n,scope:'Hardened formal Executor read path and exact integer transport; RPC observation only, not proof/finality or financial preflight',sourceCompilations:0,newProofs:0,financialOperations:0,canBroadcast:false};
await writeFile(new URL('SUMMARY.json',out),losslessJson(result)+'\n',{flag:'wx'});console.log(losslessJson(result));
