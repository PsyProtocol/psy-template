import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { validateMarketRelease } from "./install-market-release.mjs";
const h = (x) => createHash("sha256").update(x).digest("hex");
function fixture() {
  const SDK =
      "06d86a86775bef1f217e61a2192b525d657bc8de2d3687e5c28d93e7abfaec8f",
    root = h("genesis");
  const c = {
    contract_id: 0,
    code_root: h("code"),
    layout_root: h("layout"),
    function_root: h("functions"),
    height: 32,
    fields: 8,
    slots: 8594128984,
    methods: ["transfer", "claim", "burn"].map((name) => ({ name })),
  };
  const bundle = {
    registryHash: h("registry"),
    registry: {
      sdkManifestSha256: SDK,
      network: { chainRootAt1: root },
      markets: [
        {
          dependencies: [
            {
              contract: {
                contractId: 0,
                codeRoot: c.code_root,
                layoutRoot: c.layout_root,
                stateTreeHeight: 32,
              },
              functionTreeRoot: c.function_root,
              layoutFieldCount: 8,
              layoutSlotCount: c.slots,
            },
          ],
        },
      ],
    },
  };
  const bytes = {
    bundle: Buffer.from(JSON.stringify(bundle)),
    verifierPack: Buffer.from("public metadata fixture only"),
    wasm: Buffer.from("not executable"),
    glue: Buffer.from("export function get_owned_wasm_module() {}"),
  };
  const build = {
    sdkManifestSha256: SDK,
    verifierPackSha256: h(bytes.verifierPack),
    sources: [
      {
        contractId: 0,
        codeRoot: c.code_root,
        layoutRoot: c.layout_root,
        functionRoot: c.function_root,
      },
    ],
  };
  bytes.build = Buffer.from(JSON.stringify(build));
  const descriptor = {
    schema: 1,
    sdkManifestSha256: SDK,
    networkMagic: "1384803358401154921",
    chainRootAt1: root,
    registryHashes: [bundle.registryHash],
    ...Object.fromEntries(
      Object.entries(bytes).map(([k, v]) => [k + "Sha256", h(v)]),
    ),
  };
  return {
    descriptor,
    bundle,
    bytes,
    pack: {
      schema: 1,
      sdk_manifest: SDK,
      network_magic: "1384803358401154921",
      contracts: [c],
    },
    build,
  };
}
test("release metadata binding rejects chain, resource, dependency and registry substitution", () => {
  const f = fixture();
  assert.equal(
    validateMarketRelease(f).chainRootAt1,
    f.descriptor.chainRootAt1,
  );
  for (const change of [
    (f) => {
      f.descriptor.chainRootAt1 = h("other");
    },
    (f) => {
      f.bytes.wasm = Buffer.from("changed");
    },
    (f) => {
      f.pack.contracts[0].layout_root = h("old zero");
    },
    (f) => {
      f.pack.contracts = [];
    },
    (f) => {
      f.descriptor.registryHashes = [h("unknown")];
    },
    (f) => {
      f.build.sources[0].functionRoot = h("different");
    },
  ]) {
    const v = fixture();
    change(v);
    assert.throws(() => validateMarketRelease(v));
  }
  // This fixture exercises metadata rejection only, not a WASM/native proof.
});

test("lossless SDK structural integers remain exact and lossy network metadata rejects", () => {
  const f = fixture();
  f.pack.schema = 1n;
  f.pack.network_magic = 1384803358401154921n;
  for (const c of f.pack.contracts)
    for (const field of ["contract_id", "height", "fields", "slots"])
      c[field] = BigInt(c[field]);
  assert.equal(
    validateMarketRelease(f).release.networkMagic,
    "1384803358401154921",
  );
  f.pack.network_magic = Number(f.pack.network_magic);
  assert.throws(() => validateMarketRelease(f));
  const secret = fixture();
  secret.descriptor.sign_witness = { secret: "not a public release field" };
  assert.throws(() => validateMarketRelease(secret));
});
