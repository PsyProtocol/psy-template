from pathlib import Path
import hashlib,json
b=Path(__file__).resolve().parent
raw=(b/'complete-ups-v3/request.json').read_bytes();q=json.loads(raw)
a=json.loads((b/'complete-ups-v3/approval.json').read_bytes());pack=json.loads((b/'complete-ups-v3/verifiers.json').read_bytes())
proof=json.loads((b/'native-replay-v4/verification.json').read_bytes());replay=json.loads((b/'native-replay-v4/REPLAY.json').read_bytes())
sha=lambda v:hashlib.sha256(v).hexdigest()
assert proof['fullProofVerified']and proof['registrationStartVerified']and proof['endpointsAndFeesBound']
assert proof['requestSha256']==sha(raw)==replay['inputSha256']['request']
for name in ['verifiers','approval','bundle']:
 assert sha((b/f'complete-ups-v3/{name}.json').read_bytes())==replay['inputSha256'][name]
assert len(a['calls'])==2 and [(c['contract_id'],c['method_name'])for c in a['calls']]==[('0','claim'),('0','burn')]
assert a['start_leaf']=='0'*64 and a['nonce']==1 and q['user_ec_input']['core']['new_user_leaf']['balance']==0
native=pack['contracts'];assert len(native)==1 and native[0]['contract_id']==0
assert [native[0][k]for k in ['code_root','layout_root','function_root']]==['5df4b10ccf59e25f3c44b4164edb9597455da33b925c3981881c280f2636ebd1','cd6931e5422fb07be012e3d0642bbffd0880bf499ecc87bcb822276d7426771c','1ad1a069434cf058a419f4d874615c6fc47170471069f5d232874099ef13c5b1']
abi=json.loads((b/'fixtures-v2/native.json').read_bytes())['abi'];fields=abi['contract']['state_layout']['fields']
balance=next(f for f in fields if f['name']=='balance')['start_slot']
other=next(f for f in fields if f['name']=='other_user_info')
structure=next(t for t in abi['types']if t['name']=='OtherUserInfo')
claimed=next(f for f in structure['fields']if f['name']=='amount_claimed')['offset_within_parent']
cursor=other['start_slot']+int(a['calls'][0]['inputs'][0])*other['type']['item_felt_size']+claimed
updates=q['user_ec_input']['contract_state_updates'];assert len(updates)==1 and updates[0]['user_contract_tree_update_proof']['index']==0
changes={v['Positional']['delta_proof']['index']:v['Positional']['delta_proof']for v in updates[0]['updates']}
assert len(changes)==len(updates[0]['updates'])==2 and set(changes)=={balance//4,cursor//4}
def limb(q,i):return int(q[48-i*16:64-i*16],16)
end_balance=limb(changes[balance//4]['new_value'],balance%4);assert limb(changes[balance//4]['old_value'],balance%4)==0
credit=limb(changes[cursor//4]['new_value'],cursor%4)-limb(changes[cursor//4]['old_value'],cursor%4)
fee=int(proof['actualFee']);assert fee==int(a['calls'][1]['inputs'][0]) and end_balance+fee==credit==10001000000
bundle=json.loads((b/'complete-ups-v3/bundle.json').read_bytes());assert all(s['state_delta']['cfc_transaction_input_context']['transaction_end_ctx']['total_balance_spent']==0 for s in bundle['steps'])
report={'schema':1,'requestSha256':sha(raw),'scope':'arithmetic over exact API state updates already authenticated by the complete native verifier; not another verifier or network acceptance','nativeBalanceStart':'0','incomingClaimRaw':str(credit),'nativeBalanceEndRaw':str(end_balance),'actualSyntheticFeeRaw':str(fee),'userLeafBalanceStart':'0','userLeafBalanceEnd':'0','nativeContractBalanceDiffersFromUserLeafBalance':True,'claimCursorWord':cursor//4,'claimCursorLimb':cursor%4,'balanceAndFeeEqualClaim':True,'realFinancialOperations':0,'sdkChanges':[]}
with(b/'public/conservation-v1.json').open('x')as f:json.dump(report,f,indent=2);f.write('\n')
