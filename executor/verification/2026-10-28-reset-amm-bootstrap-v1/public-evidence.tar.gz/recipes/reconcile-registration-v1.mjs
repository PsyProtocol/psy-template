// Original public-key reconciliation only. This file has no write RPC route.
import{readFile,mkdir,open}from'node:fs/promises';import assert from'node:assert/strict';
import{parseLosslessJson,losslessJson}from'../../psy-template-security-20261016/amm/u124/client.mjs';
const base=new URL('./',import.meta.url),pub=new URL('public/',base),out=new URL('registration-reconcile-v1/',pub);await mkdir(out);
const who=JSON.parse(await readFile(new URL('qa-issuer-lp.json',pub))),plan=JSON.parse(await readFile(new URL('PLAN-v1.json',pub)));let seq=0;
const save=async(name,v)=>{const f=await open(new URL(name,out),'wx',0o600);await f.writeFile(losslessJson(v)+'\n');await f.sync();await f.close();};
async function rpc(url,method,params){assert.ok(method.startsWith('psy_get_'));const q={jsonrpc:'2.0',id:1,method,params},r=await fetch(url,{method:'POST',body:JSON.stringify(q),headers:{'content-type':'application/json'},redirect:'error',signal:AbortSignal.timeout(20000)});const raw=await r.text();await save(`${++seq}-${method}.json`,{url,request:q,httpStatus:r.status,responseText:raw});assert.equal(r.status,200);const v=parseLosslessJson(raw);assert.ok(!v.error);return v.result;}
let result={status:'unresolved',publicKeyHash:who.publicKeyHash,automaticRetry:false};
for(let i=0;i<30;i++){
 const chain=await rpc('https://coordinator-stg.psy-protocol.xyz','psy_get_checkpoint_leaf_data',{checkpoint_id:1});assert.equal(chain.global_chain_root,plan.chainRootAt1);
 const ids=await rpc('https://coordinator-stg.psy-protocol.xyz','psy_get_user_ids_for_public_key',[who.publicKeyHash,0,64]);assert.ok(ids.length<=1);
 if(ids.length===1){const id=ids[0];assert.ok(id>0n&&id<16777216n);const heads=await Promise.all([0,1].map(n=>rpc(`https://realm${n}-stg.psy-protocol.xyz`,'psy_get_latest_l2_block_state',{})));const cp=heads.map(x=>x.checkpoint_id).reduce((a,b)=>a<b?a:b);assert.ok(cp>0n&&cp<4294967296n);const leaf=await rpc(`https://realm${id/1048576n}-stg.psy-protocol.xyz`,'psy_get_user_leaf_data',{checkpoint_id:Number(cp),user_id:Number(id)});assert.equal(leaf.user_id,id);
  if(leaf.public_key===who.publicKeyHash){assert.equal(leaf.nonce,0n);result={status:'rpc-observed-included',userId:id,checkpoint:cp,publicKeyHash:who.publicKeyHash,leaf,assurance:'common-checkpoint RPC leaf, not a complete UPS or browser financial acceptance',registrationSends:1,faucetRequests:0,automaticRetry:false};break;}
  assert.equal(leaf.public_key,'0'.repeat(64),'different registered key must halt');
 }
 await new Promise(r=>setTimeout(r,2000));
}
await save('RESULT.json',result);console.log(losslessJson(result));
