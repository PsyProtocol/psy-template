import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const [modulePath,source,out]=process.argv.slice(2);
const {encodeScopedCandidate}=await import(pathToFileURL(modulePath).href);
await mkdir(out);
const hash=limbs=>[...limbs].reverse().map(n=>BigInt(n).toString(16).padStart(16,'0')).join('');
const digest=words=>words.map(n=>BigInt(n).toString(16).padStart(8,'0')).join('');
for(const market of ['amm','curve']){
 const input=JSON.parse(await readFile(source+'/'+market+'-input.json','utf8')),f=input.fields,s=input.scopeFields;
 const candidate={version:1,networkMagic:f[1],market:f[2]==='1'?'amm':'bondingcurve',marketId:f[3],vaultId:f[4],epoch:f[5],cutoff:f[6],sealByCheckpoint:f[7],drawCheckpoint:f[8],round:f[9],settleUntil:f[10],recoveryAt:f[11],maxFee:f[12],members:Array.from({length:Number(f[13])},(_,i)=>({owner:f[50+6*i],nonce:f[51+6*i],termsRoot:hash(f.slice(52+6*i,56+6*i))}))};
 for(const [i,name]of ['sourceId','chainRootAt1','codeRoot','layoutRoot','functionRoot','keyFingerprint','publicKeyHash','queueRoot','batchRoot'].entries())candidate[name]=hash(f.slice(14+4*i,18+4*i));
 const scoped={version:2,candidate,chainInstanceId:digest(s.slice(1,9)),sourceDefinitionSha256:digest(s.slice(9,17)),sourceKeyEpoch:s[17],finalityDefinitionSha256:digest(s.slice(18,26)),finalityKeyEpoch:s[26],releasePolicySha256:digest(s.slice(27,35)),requestNonce:s[35]};
 const encoded=encodeScopedCandidate(scoped);assert.deepEqual(encoded.fields,input.fields);assert.deepEqual(encoded.scopeFields,input.scopeFields);
 await writeFile(out+'/'+market+'-candidate.json',JSON.stringify(scoped,null,2)+'\n',{flag:'wx'});
 await writeFile(out+'/'+market+'-input.json',JSON.stringify({fields:encoded.fields,scopeFields:encoded.scopeFields,seed:input.seed},null,2)+'\n',{flag:'wx'});
}
await writeFile(out+'/RESULT.json',JSON.stringify({schema:2,exactClientNativeRoundtrips:2,sourceAuthenticated:false,randomAuthorization:false,financialOperations:0,proofsGenerated:0},null,2)+'\n',{flag:'wx'});
