from pathlib import Path
import json,hashlib,tarfile,gzip,io,os
p=Path(__file__).resolve().parent
a=Path('/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016')
out=a/'executor/verification/2026-10-31-funded-qa-deployment-v1'
out.mkdir()
files={}
def add(source,name):
 assert source.is_file() and not source.is_symlink()
 assert not any(x in source.parts for x in ['private','target','drivers'])
 assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
 files[name]=source.read_bytes()
for name in ['public','sources','qa-a-v1','qa-b-v1','initial-qa-a-v1','initial-qa-a-v2','initial-qa-b-v1','fixtures-v1','qa-setup-full-ups-v1','fresh-qa-a-v2','attempts','checkpoint-qa-a-v1','qa-a-state-propagation-v1','qa-a-common-state-v1','audit-after-deploy-v1']:
 d=p/name
 for source in sorted(d.rglob('*')):
  if source.is_file() and source!=p/'public/rpc.json':add(source,'case/'+str(source.relative_to(p)))
for source in sorted(p.glob('*.mjs')):add(source,'case/'+source.name)
for name in ['run.py','package-public-v1.py']:
 add(p/name,'case/'+name)
for name in ['application-v1','application-v2','application-v3','application-v4']:
 add(p/name/'APPLICATION.json','case/'+name+'/APPLICATION.json')
paths=['amm/u124/vm-tests/src/bin/prepare_initial_request.rs','amm/u124/vm-tests/tests/support/ordinary_wallet_full_ups.rs','executor/contractMetadataRead.mjs','executor/contractMetadataRead.test.mjs','executor/publicState.mjs','executor/publicState.test.mjs','executor/readRetry.mjs','executor/readRetry.test.mjs','docs/security/UPSTREAM_REALM_METADATA_HANDOFF_20261031.json']
for name in paths:add(a/name,'source/'+name)
# No wallet/private signing material was read by this exporter. The collected
# complete proofs, verifier resources, code, paths and receipts are public data.
for name in files:
 assert not name.endswith(('.wasm','.dylib','.so','.pem','.key'))
 assert 'private/' not in name
records=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(files.items())]
with (out/'evidence.tar.gz').open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(mode='w',fileobj=gz) as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
archive=(out/'evidence.tar.gz').read_bytes()
manifest={'schema':1,'baseCommit':'334533a4becb01e754538ca4926749d3212ac2aa','sdkCommit':'c92880c8b6e2c8d392f19368bc8801a2584fd427','archiveSha256':hashlib.sha256(archive).hexdigest(),'archiveBytes':len(archive),'scope':'New QA exact-bytecode synthetic UPS, initial layouts, single QA A deployment and independent checkpoint inclusion, bounded metadata failure/retry evidence; not AMM or browser acceptance','excluded':['Wallet files, private keys, mnemonics and signature witnesses','Full private/network configuration and executables','Duplicate checkpoint-fixture aliases; their exact request/source are present under the original case paths'],'members':records}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','r:gz') as tar:
 actual={m.name:m for m in tar.getmembers()};assert set(actual)==set(files)
 for record in records:
  data=tar.extractfile(record['path']).read();assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
(out/'README.md').write_text('''# Funded QA candidate and metadata availability evidence

The exact initial request for QA A was sent once and included as contract 8 at
checkpoint 25363. Saved code/layout/request identity and checkpoint membership
verify independently. QA B is compiled/proved but unsent. QA minting and AMM/UI
activation remain closed: Realm 0 reports height 0 while Realm 1 reports 31.

See [the team report](../../../docs/security/FUNDED_QA_DEPLOYMENT_20261031.md)
and [the runtime delivery](../../../docs/security/UPSTREAM_REALM_METADATA_HANDOFF_20261031.json).
The full QA setup proof uses synthetic checkpoint 100, provisional IDs 42/43 and
an ephemeral fixture signer; it is not live initialization or browser approval.

`manifest.json` binds every public member to its exact bytes. `evidence.tar.gz`
contains source, ABI/bytecode, canonical layout requests, full public UPS and
verifier replay, exact broadcast/receipt, checkpoint paths, failures, bounded
read observations, budgets and process RSS samples. Original case records are
unchanged. Duplicate read-only checkpoint-fixture aliases are omitted.
No wallet secret, mnemonic, signature witness, private configuration or binary
is included. Public keys, proofs and verifier data are intentionally public.

Do not run the archived faucet/deployment senders during reproduction: their
one-shot request identities are consumed. Replay saved public verification and
offline tests into fresh directories only. No general performance, finality,
qualified randomness, AMM settlement or wallet-extension acceptance is claimed.
''')
print(json.dumps({'members':len(records),'archiveBytes':len(archive),'archiveSha256':manifest['archiveSha256'],'verifiedEveryMember':True}))
