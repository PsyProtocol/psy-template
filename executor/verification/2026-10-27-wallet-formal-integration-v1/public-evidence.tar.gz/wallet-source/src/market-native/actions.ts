// Public method names only; execution remains in the background router.
export const marketActions = [
  "psy_getMarketWriteCapabilities",
  "psy_prepareMarketTransaction",
  "psy_verifyMarketPreparation",
  "psy_broadcastMarketPreparation",
  "psy_reconcileMarketPreparation",
  "psy_listMarketPreparations",
  "psy_cancelMarketPreparation",
] as const;
