// Called only by the extension bootstrap with statically imported bindgen glue
// and a compiled release pin. Neither argument is accepted through a page RPC.
const instances=new WeakMap(),HEX=/^[0-9a-f]{64}$/;
const SDK='06d86a86775bef1f217e61a2192b525d657bc8de2d3687e5c28d93e7abfaec8f',MAGIC='1384803358401154921';
const ok=(v,m)=>{if(!v)throw Error(m);};
async function digest(bytes){return[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');}
export async function loadOwnedMarketVerifier({module,wasmUrl,release,fetcher=fetch}){
 ok(module&&typeof module.default==='function'&&['verifier_identity','project_market_identity','verify_market_prepared'].every(k=>typeof module[k]==='function'),'Statically imported extension verifier module required');
 ok(release?.sdkManifestSha256===SDK&&release.networkMagic===MAGIC&&HEX.test(release.wasmSha256??'')&&HEX.test(release.verifierPackSha256??''),'Reviewed verifier release identity required');
 const pin=Object.freeze({...release});
 const initialize=module.default.bind(module),identity=module.verifier_identity.bind(module),identify=module.project_market_identity.bind(module),verify=module.verify_market_prepared.bind(module);
 const here=new URL(globalThis.location?.href??'about:blank'),url=new URL(wasmUrl);
 ok(['chrome-extension:','moz-extension:'].includes(here.protocol)&&url.protocol===here.protocol&&url.hostname===here.hostname&&!url.username&&!url.password&&!url.search&&!url.hash,'Verifier must be an extension-owned immutable resource');
 const key=[url.href,pin.wasmSha256,pin.verifierPackSha256,SDK,MAGIC].join(':');
 let cache=instances.get(module);if(!cache){cache=new Map();instances.set(module,cache);}
 if(!cache.has(key))cache.set(key,(async()=>{
  const r=await fetcher(url.href,{redirect:'error',cache:'no-store',signal:AbortSignal.timeout(20000)});ok(r.ok,'Extension verifier resource unavailable');
  const bytes=await r.arrayBuffer();ok(bytes.byteLength>8&&bytes.byteLength<=20_000_000&&await digest(bytes)===pin.wasmSha256,'Verifier binary changed');
  // Supply verified bytes; bindgen must not infer an unpinned URL or fetch again.
  await initialize({module_or_path:bytes});
  const id=JSON.parse(identity());
  ok(id.schema===1&&id.verifierPackSha256===pin.verifierPackSha256&&id.sdkManifestSha256===SDK&&id.networkMagic===MAGIC,'Loaded verifier identity differs from release');
  return Object.freeze({identity:async()=>identity(),identify:async request=>identify(request),verify:async(request,approval,bundle)=>verify(request,approval,bundle)});
 })());
 // A failed initialization stays failed for this exact release/context. It is
 // never permission to silently choose another key, binary or proof profile.
 return cache.get(key);
}
