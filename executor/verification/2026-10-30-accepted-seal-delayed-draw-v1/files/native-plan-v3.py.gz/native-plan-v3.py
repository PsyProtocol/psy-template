# Bounded public-only native plan verification. No keys or financial operations.
from pathlib import Path
import json,subprocess,hashlib,shutil,os,sys
c=Path(__file__).resolve().parent;r=c/'fixtures-v3';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'PSY_NETWORK':'testnet','PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','RAYON_NUM_THREADS':'2'}
rows=[]
selected=sys.argv[1:];assert selected and all(m in ['amm','bondingcurve']for m in selected)
for market,kind in [('amm',1),('bondingcurve',2)]:
 if market not in selected:continue
 d=c/('native-'+market+'-v3');d.mkdir();head=c/'full-ups-v3'/(market+'-sealed-minimum-1');draw_head=c/'full-ups-v3'/(market+'-sealed-minimum-0');cur=json.loads((head/'current.json').read_text());contracts={p['id']:p['leaf']for p in cur['contracts']}
 copy=lambda src,dst:shutil.copyfile(src,d/dst)
 copy(r/market/'compiled/compilation_artifact.json','market.json')
 assets=[]
 for cid,file,src in [(0,'native.json',r/'native.json'),(42,'a.json',r/'token/compilation_artifact.json'),(43,'b.json',r/'token/compilation_artifact.json')]:
  copy(src,file);assets.append({'id':cid,'artifact':file,'artifact_sha256':sha(d/file),'function_root':contracts[cid]['function_tree_root']})
 review={'schema':1,'artifact':'market.json','artifact_sha256':sha(d/'market.json'),'market':1000,'kind':kind,'function_root':contracts[1000]['function_tree_root'],'assets':assets,'unit':'1000000000000000000'}
 (d/'review.json').write_text(json.dumps(review,indent=2)+'\n')
 commands=[[str(c/'bin-v8/minimum_stream_plan'),'--derive-synthetic-draw',str(head),str(draw_head),str(d/'derived')]]
 for args in commands:
  p=subprocess.run(args,env=env,capture_output=True,text=True,timeout=120);(d/'derive.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 history=json.loads((head/'source.json').read_text())['history']['checkpoint_path']['root']
 args=[str(c/'bin-v8/minimum_stream_plan'),str(d/'review.json'),str(head/'source.json'),history,str(d/'derived/draw.json'),str(r/market/'stream-policy.json'),str(d/'prepared'),str(d/'derived/acceptedSeal.json')]
 p=subprocess.run(args,env=env,capture_output=True,text=True,timeout=120);(d/'positive.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 original=json.loads((d/'derived/acceptedSeal.json').read_text());attacks=[]
 for name,change in [('wrong-chain',lambda p:p['snapshot']['fields'].__setitem__(9,p['snapshot']['fields'][9]+1)),('wrong-epoch',lambda p:p['snapshot']['fields'].__setitem__(5,p['snapshot']['fields'][5]+1)),('draw-index-as-seal',lambda p:p['snapshot']['fields'].__setitem__(6,int(json.loads((d/'prepared/plan.json').read_text())['drawCheckpoint']))),('foreign-history-root',lambda p:p['snapshot']['history']['checkpoint_path'].__setitem__('root','1'*64)),('missing-state-words',lambda p:p['snapshot']['accounts'][0]['market'].__setitem__('words',[]))]:
  bad=json.loads(json.dumps(original));change(bad);file=d/(name+'.json');file.write_text(json.dumps(bad)+'\n');q=args.copy();q[-1]=str(file);q[-2]=str(d/('rejected-'+name));res=subprocess.run(q,env=env,capture_output=True,text=True,timeout=120);(d/(name+'.log')).write_text(res.stdout+res.stderr);assert res.returncode!=0 and not Path(q[-2]).exists(),name;attacks.append(name)
 plan=json.loads((d/'prepared/plan.json').read_text());rows.append({'market':market,'profile':plan['profile'],'source':plan['sourceCheckpoint'],'seal':plan['acceptedSealCheckpoint'],'draw':plan['drawCheckpoint'],'members':plan['members'],'attacksRejected':attacks,'cryptographicScope':'native source+seal+draw membership checks; no new UPS or finality','canBroadcast':False})
(c/('public/NATIVE-PLAN-'+'-'.join(selected)+'-v3.json')).write_text(json.dumps({'rows':rows,'financialOperations':0,'binarySha256':sha(c/'bin-v8/minimum_stream_plan')},indent=2)+'\n')
