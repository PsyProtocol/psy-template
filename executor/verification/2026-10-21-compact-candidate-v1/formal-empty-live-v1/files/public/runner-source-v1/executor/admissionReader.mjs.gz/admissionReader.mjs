// Unaccepted intents are hints, never a claim of market-wide completeness.
import assert from 'node:assert/strict';
import {scanAdmission,queueMaintenance} from '../batching/admission/reader.mjs';
import {losslessJson,FEE_ESCROW as F} from '../amm/u124/client.mjs';
import {publicState} from './publicState.mjs';
export function validateAdmissionPlan(p){
 assert.ok(p&&typeof p==='object'&&!Array.isArray(p));
 assert.ok(Object.keys(p).every(k=>['version','epoch','cutoff','members'].includes(k)));
 assert.equal(p.version,1);assert.ok(Number.isSafeInteger(p.epoch)&&p.epoch>0&&p.epoch<2**32);
 assert.ok(Number.isSafeInteger(p.cutoff)&&p.cutoff>0&&p.cutoff<2**32);
 assert.ok(Array.isArray(p.members)&&p.members.length<=4);
 let previous=0;for(const m of p.members){assert.deepEqual(Object.keys(m).sort(),['nonce','owner']);assert.ok(Number.isSafeInteger(m.owner)&&m.owner>previous&&m.owner<16777216);assert.ok(typeof m.nonce==='string'&&/^[1-9]\d*$/.test(m.nonce)&&BigInt(m.nonce)<2n**62n);previous=m.owner;}
 return p;
}
export async function scanExecutorAdmission(o,readState=publicState,files){
 const s=await readState(o.rpcConfig),base=await scanAdmission(o,async()=>s,files);
 if(base.action||!['epoch-not-started','epoch-complete','awaiting-consented-admissions-and-seal'].includes(base.reason))return base;
 const plan=validateAdmissionPlan(files.admissionPlan),V=o.vaultId,C=o.contractId;
 const offsets=new Map(files.abi.contract.state.map(f=>[f.name,f.offset]));
 const at=(u,n,i=0)=>{assert.ok(offsets.has(n),'admission field '+n);return s.slot(u,C,offsets.get(n)+i);};
 const [phase,epoch,count,cutoff]=await Promise.all(['queue_phase','queue_epoch','queue_count','queue_cutoff'].map(n=>at(V,n)));
 let name,a,b=0n;
 if([0n,3n].includes(phase)){
  if(BigInt(plan.epoch)!==epoch+1n)return {...base,reason:'admission-plan-not-next-epoch'};
  if(plan.cutoff<=s.checkpoint||plan.cutoff>s.checkpoint+128)return {...base,reason:'admission-plan-cutoff-unavailable'};
  name='start_epoch';a=BigInt(plan.epoch);b=BigInt(plan.cutoff);
 }else{
  assert.equal(phase,1n);
  if(BigInt(s.checkpoint)>cutoff){name=count===0n?'abort_empty_epoch':'seal_epoch';a=epoch;}
  else{
   if(BigInt(plan.epoch)!==epoch||BigInt(plan.cutoff)!==cutoff)return {...base,reason:'admission-plan-epoch-mismatch'};
   const accepted=await Promise.all([0,1,2,3].map(i=>at(V,'queue_owner',i)));if(count===4n)return {...base,reason:'queue-full-awaiting-cutoff'};
   for(const m of plan.members){if(m.owner===V||accepted.includes(BigInt(m.owner)))continue;
    const [e,c,n,orderNonce,pool,kind,used]=await Promise.all([at(m.owner,'admission_epoch'),at(m.owner,'admission_cutoff'),at(m.owner,'admission_nonce'),at(m.owner,'nonce'),at(m.owner,'pool'),at(m.owner,'kind'),at(V,'consumed',m.owner)]);
    if(e===epoch&&c===cutoff&&n===BigInt(m.nonce)&&orderNonce===n&&pool===BigInt(V)&&kind!==0n&&n>used){name='admit_entry';a=BigInt(m.owner);b=n;break;}
   }
   if(!name)return {...base,reason:'no-eligible-consented-plan-members',unacceptedScope:'plan hints only; no global inclusion guarantee'};
  }
 }
 const payer=o.batchSponsorId;
 const [sent,claimed,baseFee,pool,amount,nonce,used,purpose]=await Promise.all([s.slot(payer,0,3+2*V),s.slot(V,0,4+2*payer),at(V,'settled_fee',payer),at(payer,'sponsor_pool'),at(payer,'sponsor_amount'),at(payer,'sponsor_nonce'),at(V,'used_sponsorship',payer),at(payer,'sponsor_purpose')]);
 if(claimed!==baseFee||sent-baseFee!==F||pool!==BigInt(V)||amount!==F||nonce<=used||purpose!==2n)return {...base,action:null,reason:'admission-gas-sponsorship-required',fundingRequest:{payer,vault:V,purpose:2,amount:F.toString(),nextSponsorshipNonce:(nonce+1n).toString(),operation:name}};
 return {...base,reason:undefined,action:{kind:'batch_maintenance',maintenanceOperation:name,gasAuthorizationNonce:nonce.toString(),profile:'compact-v1',validUntilCheckpoint:String(name==='admit_entry'?Math.min(Number(cutoff),s.checkpoint+64):s.checkpoint+64),submission:losslessJson(queueMaintenance(files.policy,{name,payer:BigInt(payer),a,b}))}};
}
