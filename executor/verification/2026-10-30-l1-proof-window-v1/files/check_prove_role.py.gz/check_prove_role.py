import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
previous=C.parent/'runtime-resource-acquisition-20261030-v1'
s=json.loads((previous/'public/l1-state-manager-observation.json').read_bytes())
url='https://prove-stg.psy-protocol.xyz'
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json'
 with rp.open('x')as f:json.dump(req,f)
 rp.chmod(0o600);out=C/'quarantine'/f'{label}.body';assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes()if out.exists()else b''
 if out.exists():out.chmod(0o600)
 r={'schema':1,'url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'elapsedSeconds':time.monotonic()-start,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalityVerified':False,'canBroadcast':False}
 with(C/'public'/f'{label}-transport.json').open('x')as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'result'not in v or 'error'in v:
  with(C/'public'/f'{label}-error.json').open('x')as f:json.dump({'schema':1,'error':v.get('error'),'finalityVerified':False},f,indent=2);f.write('\n')
  raise RuntimeError('RPC rejected; no retry')
 return v['result']

r=call('prove-role','psy_get_prove_proxy_role',[])
with(C/'public/prove-role-observation.json').open('x')as f:json.dump({'schema':1,'role':r,'checkpointResourcesExported':False,'runtimeBuildAuthenticated':False,'canBroadcast':False},f,indent=2);f.write('\n')
print('role',r)
