# Formal wallet transport candidate — 31 October 2026

This continues `wallet-security-20261016` from
`5c15a9df9d5c47c4df449988ab7cb89b5d397b32`. The corresponding application source
and report are on [the existing application branch](https://github.com/PsyProtocol/psy-template/tree/markets-batch-capacity-recovery-20261020)
at `market-client/rpcWire.mjs` and
`docs/security/PRODUCTION_TRANSPORT_CANDIDATE_20261031.md`.

The wallet now reproduces the generic bounded RPC wire module and declarations,
chain-instance guard and exact transport from that application. The generated
`src/market-preparation/SOURCE.json` binds all 26 module/declaration members.
Every copied byte matches the application source. Registry/bundle/network bytes
and `installedMarketRelease: null` are unchanged. No current market verifier
release, NFT writing capability or financial permission is enabled.

## Behavior

RPC replies require JSON-RPC 2.0, the exact numeric ID and one result or a valid
structured error. An expected-looking end-leaf result with a different ID is
not an acceptable ACK. Streamed byte limits apply before acceptance, even with
missing Content-Length; malformed UTF-8 and oversized declared/observed bodies
reject and cancel. These are generic transport checks, not market business or
cryptographic proof verification.

The existing wallet-owned approval, full ordered-call/session/sig_hash verifier,
fresh nonce/state/fees, exact request persistence and single broadcast remain
required. A malformed/lost ACK remains unknown. No automatic retry, account
release, cancellation, replacement transaction or generic transfer fallback is
added. An ACK still has `confirmed: false`; finality and ordinary asset claim
cannot be inferred from transport success.

Two new wallet tests import the **actual reproduced module** and reject malformed
ACK identities/outcomes, byte overflow and invalid UTF-8 while preserving exact
large integers. The existing preparation fixture now returns a genuine Response
with a readable body. No production check is relaxed for a partial Response mock.

## Validation and provenance

- The SDK remains mainnet-beta `c92880c8b6e2c8d392f19368bc8801a2584fd427`,
  client `b280d714a8f0930c61962c885374ea63ea63d274`, with no package/lockfile changes.
- The canonical workspace SDK guard rejects a different local sibling package.
  It was not bypassed. A fresh source snapshot uses the **previously selected
  frozen cohort**, checks metadata/config and all 472 installed distribution
  files, then passes TypeScript and the staging extension build. No dependency
  install or SDK switch occurred. Its first source copy omitted a public Genesis
  ABI needed by a unit test; the exact original ABI was restored in the isolated
  copy. Original failed logs are retained.
- Full selected-cohort wallet suite: **66 files, 730 passed, one pre-existing
  skip**. The initial run's text-only mock failure is retained. It was corrected
  with a real Response; no type error is ignored.
- The application includes real loopback HTTP framing tests and staged restart/
  account-hold tests. The latter use a synthetic backend and are not extension
  approval, native proof or network payment acceptance.
- Vite reports 14.43 seconds for its build phase, with existing WASM URL and large
  chunk warnings. This excludes typecheck and is not proof, browser startup,
  confirmation, claim or end-to-end performance.

Evidence is linked from the application report and records exact source/vendor,
build output hashes, regression summaries and all original failed log digests.
Full wallet test payloads stay local; the public evidence projects only safe
result/provenance fields. No key, mnemonic, recovery file or signing witness is
published. Neither repository changes Node or any old contract/artifact.

## Release gates remain closed

At checkpoint 27105 the application still observes Realm 0 contract-8 height
zero at both fixed and latest bounds. No current-chain deployment, trade or
ordinary market claim is added. Actual market IDs, new-vault setup/full UPS,
instance-specific verifier resources, real extension approval, exact broadcast,
receipt recovery and ordinary claim/refund remain required. No historical
resource, offline test count or wallet build is accepted as a substitute.

The dedicated browser remains outside this code-only validation. The installed
release remains null until the normal review and actual-instance safety gates
are satisfied. This is a hardened candidate, not production payment acceptance.

## Commit-hook integrity correction

The first local commit `1e57e1e` ran the pre-existing whole-workspace formatter.
It reformatted generated modules after verification and also changed 71 unstaged
paths plus nine Genesis files. The initial workspace/submodule were clean;
only these owned formatter side effects were restored. Original evidence and
the intermediate commit remain intact. The invalid intermediate vendor bytes
are not a release candidate, and were detected before the wallet push.

The vendor was regenerated from the exact already-validated application source.
All 26 module/declaration members and the registry bundle again match their
inventory. The hook now verifies those hashes **before and after** formatting
only staged authored files. Generated application bytes, frozen SDK metadata and
the Genesis submodule are excluded from formatting, with vendor integrity checked
rather than silently ignored. No SDK/proof/state check is removed.

`node scripts/check-market-vendor.mjs` checks regular files, rejects links,
duplicate/missing/extra members, byte changes and bundle changes. Two new script
tests cover corruption and staged-file selection. The release remains closed;
formatter protection is not compiler trust or financial authorization.
