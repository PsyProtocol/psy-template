// Real owned-native planning over previously archived PUBLIC SYNTHETIC fixtures.
// No RPC, signing, proof generation, registration, transfer or broadcasting.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile,cp,readdir} from 'node:fs/promises';
import {join,resolve} from 'node:path';import {execFile} from 'node:child_process';import {promisify} from 'node:util';
import {prepareSealedMinimumSourceStream,validateRandomStreamPlan} from '<application-root>/executor/randomSourceStream.mjs';
import {validateSealedMinimumStreamPlan} from '<application-root>/executor/sealedMinimumSourcePlan.mjs';
import {ExecutionJournal} from '<application-root>/executor/journal.mjs';
import {losslessJson,parseLosslessJson} from '<application-root>/amm/u124/client.mjs';
import {sha256} from '<application-root>/executor/requestBinding.mjs';
const c=resolve(process.argv[2]),old=resolve(process.argv[3]),driver=resolve(process.argv[4]),driverSha=process.argv[5],root=join(c,'native-integration-v1');
assert.equal(sha256(await readFile(driver)),driverSha);await mkdir(root);await mkdir(join(root,'native-runs'));
const names=['plan','source-pages','minimum-pages','queue'];let nativeRuns=0;const run=promisify(execFile);
const save=(p,v)=>writeFile(p,losslessJson(v)+'\n',{flag:'wx'}),read=async p=>parseLosslessJson(await readFile(p,'utf8'));
const runNative=async(bin,args,opts)=>{
 assert.ok(++nativeRuns<=6,'native planning budget');const label='run-'+nativeRuns;
 await save(join(root,'native-runs',label+'.request.json'),{driverSha256:driverSha,args,scope:'public synthetic plan only',financialOperations:0,proofsGenerated:0});
 try{const result=await run(bin,args,{...opts,timeout:Math.min(opts.timeout??120000,120000)});await writeFile(join(root,'native-runs',label+'.stdout'),result.stdout,{flag:'wx'});await writeFile(join(root,'native-runs',label+'.stderr'),result.stderr,{flag:'wx'});return result;}
 catch(e){await writeFile(join(root,'native-runs',label+'.stdout'),e.stdout??'',{flag:'wx'});await writeFile(join(root,'native-runs',label+'.stderr'),e.stderr??String(e),{flag:'wx'});throw e;}
};
const rows=[],options={};
for(const market of ['amm','bondingcurve']){
 const base=join(root,market),input=join(base,'inputs');await mkdir(input,{recursive:true});
 const existing=join(old,'native-'+market+'-v3'),review=await read(join(existing,'review.json'));
 for(const a of [review,...review.assets])await copyFile(join(existing,a.artifact),join(input,a.artifact));
 for(const[name,file]of Object.entries({review:join(existing,'review.json'),snapshot:join(old,'full-ups-v3',market+'-sealed-minimum-1','source.json'),draw:join(existing,'derived/draw.json'),policy:join(old,'fixtures-v3',market,'stream-policy.json'),acceptedSeal:join(existing,'derived/acceptedSeal.json')}))await copyFile(file,join(input,name+'.json'));
 const source=await read(join(input,'snapshot.json')),o={historyRoot:source.history.checkpoint_path.root,wallet:driver,walletSha256:driverSha,runtimeDirectory:join(base,'runtime')};
 for(const n of ['review','snapshot','draw','policy','acceptedSeal']){o[n]=join(input,n+'.json');o[n+'Sha256']=sha256(await readFile(o[n]));}
 options[market]=o;await save(join(base,'options.json'),o);
 const route=await prepareSealedMinimumSourceStream(o,{runNative}),p=await route.plan();assert.equal(p.status.members,5);assert.equal(p.status.accounts,8);assert.equal(p.status.canBroadcast,false);assert.throws(()=>route.authorizeSettlement(),/cannot enable writes/);
 const restarted=await prepareSealedMinimumSourceStream(o,{runNative});assert.deepEqual((await restarted.plan()).plan,p.plan);
 const legacy=await read(join(existing,'prepared/plan.json'));assert.deepEqual(p.plan,legacy,'new receipts must not change any plan, seed, member, capacity or market semantics');
 const journal=new ExecutionJournal({directory:route.directory,network:'offline-producer-stream',vaultId:Number(source.fields[4]),fingerprint:driverSha});const records=await journal.records();assert.equal(records.filter(r=>r.status.endsWith('-native-intent')).length,1);
 rows.push({market,status:p.status,outputs:p.outputs,sourceCheckpoint:String(p.plan.sourceCheckpoint),acceptedSealCheckpoint:String(p.plan.acceptedSealCheckpoint),drawCheckpoint:String(p.plan.drawCheckpoint),sameOriginalPlanAndSeed:true,nativeReceiptSha256:records.find(r=>r.nativeReceiptSha256).nativeReceiptSha256,financialOperations:0,proofsGenerated:0});
}
// Resume in fresh actual Node processes; these must reuse the existing result.
const childCode=`import{readFile}from'node:fs/promises';import{pathToFileURL}from'node:url';const{prepareSealedMinimumSourceStream}=await import(pathToFileURL(process.argv[1]).href);try{const o=JSON.parse(await readFile(process.argv[2],'utf8'));const r=await prepareSealedMinimumSourceStream(o);console.log(JSON.stringify(await r.status()));}catch(e){console.error(e.name+': '+e.message);process.exitCode=e.name==='VaultBusy'?3:1;}`;
const sourceModule='<application-root>/executor/randomSourceStream.mjs';
const child=async(label)=>{
 try{const v=await run(process.execPath,['--input-type=module','-e',childCode,sourceModule,join(root,'amm/options.json')],{env:process.env,timeout:30000,maxBuffer:65536});await writeFile(join(root,label+'.stdout'),v.stdout,{flag:'wx'});return {exitCode:0,status:JSON.parse(v.stdout)};}
 catch(e){await writeFile(join(root,label+'.stderr'),e.stderr??String(e),{flag:'wx'});return {exitCode:e.code,error:e.stderr??String(e)};}
};
const restart=await child('fresh-process-restart');assert.equal(restart.exitCode,0);assert.equal(restart.status.canSign,false);
const competition=await Promise.all([child('competitor-1'),child('competitor-2')]);assert.ok(competition.some(r=>r.exitCode===0));assert.ok(competition.every(r=>r.exitCode===0||r.exitCode===3));
const freshRoute=await prepareSealedMinimumSourceStream(options.amm,{runNative});assert.equal(nativeRuns,2);const st=await read(join(root,'amm/inputs/snapshot.json'));
const journal=new ExecutionJournal({directory:freshRoute.directory,network:'offline-producer-stream',vaultId:Number(st.fields[4]),fingerprint:driverSha});assert.equal((await journal.records()).filter(r=>r.status.endsWith('-native-intent')).length,1);
// Deliver a structurally coherent altered COPY after the actual native process.
// The original native output directory remains byte-for-byte intact.
const tampered={...options.amm,runtimeDirectory:join(root,'tampered-delivery-runtime')};let structuralPassed=false;
await assert.rejects(prepareSealedMinimumSourceStream(tampered,{runNative:async(bin,args,opts)=>{
 const original=args[5]+'-original',a=[...args];a[5]=original;const result=await runNative(bin,a,opts);await mkdir(args[5]);
 for(const n of names)await copyFile(join(original,n+'.json'),join(args[5],n+'.json'));
 const plan=await read(join(args[5],'plan.json')),pages=await read(join(args[5],'minimum-pages.json'));plan.seed[0]+=1n;for(const p of pages){p.seed[0]+=1n;for(const r of p.rows)r.seed[0]+=1n;}
 await writeFile(join(args[5],'plan.json'),losslessJson(plan)+'\n');await writeFile(join(args[5],'minimum-pages.json'),losslessJson(pages)+'\n');
 assert.equal(validateSealedMinimumStreamPlan(plan,await read(join(args[5],'source-pages.json')),pages,await read(join(args[5],'queue.json'))).canSign,false);structuralPassed=true;return result;
}}),/differs from owned native receipt/);assert.ok(structuralPassed);
// Lose only the planning response, then replay the SAME inputs in a fresh output.
const lost={...options.bondingcurve,runtimeDirectory:join(root,'lost-receipt-runtime')};
await assert.rejects(prepareSealedMinimumSourceStream(lost,{runNative:async(bin,args,opts)=>{
 const original=args[5]+'-original',a=[...args];a[5]=original;const result=await runNative(bin,a,opts);await mkdir(args[5]);for(const n of names)await copyFile(join(original,n+'.json'),join(args[5],n+'.json'));return {...result,stdout:''};
}}),/exactly one owned native receipt/);
const recovered=await prepareSealedMinimumSourceStream(lost,{runNative});assert.equal((await recovered.status()).members,5);assert.equal(nativeRuns,5);
// An explicit legacy-format COPY is rejected without a native replay or cleanup.
const legacyOptions={...options.amm,runtimeDirectory:join(root,'legacy-journal-runtime')};await mkdir(legacyOptions.runtimeDirectory);await cp(join(options.amm.runtimeDirectory,'random-source-stream'),join(legacyOptions.runtimeDirectory,'random-source-stream'),{recursive:true});
const legacyScope=join(legacyOptions.runtimeDirectory,'random-source-stream',(await readdir(join(legacyOptions.runtimeDirectory,'random-source-stream')))[0]);const legacyJournal=new ExecutionJournal({directory:legacyScope,network:'offline-producer-stream',vaultId:Number(st.fields[4]),fingerprint:driverSha});
const recordName=(await readdir(legacyJournal.directory)).find(n=>n.endsWith('-sealed-minimum-stream-prepared.json'));assert.ok(recordName);const recordPath=join(legacyJournal.directory,recordName),oldBytes=await readFile(recordPath);await writeFile(join(legacyJournal.directory,'original-prepared-record.json'),oldBytes,{flag:'wx'});const legacyRecord=JSON.parse(oldBytes);delete legacyRecord.nativeReceiptSha256;await writeFile(recordPath,JSON.stringify(legacyRecord)+'\n');
await assert.rejects(prepareSealedMinimumSourceStream(legacyOptions,{runNative}),/legacy prepared plan has no native byte receipt/);assert.equal(nativeRuns,5);assert.deepEqual(await readFile(join(legacyJournal.directory,'original-prepared-record.json')),oldBytes);
const report={schema:1,scope:'actual owned native planning with archived synthetic source/seal/draw; not financial/full UPS/live acceptance',driverSha256:driverSha,rows,nativePlanningRuns:nativeRuns,exactFreshProcessRestart:true,sameHostCompetition:competition,duplicateNativePlanningAfterRestart:0,structurallyCoherentSeedReplacementRejected:true,originalNativeOutputsRetained:true,missingNativeReceiptRejected:true,exactInputPlanningRecovery:true,legacyPreparedCopyRejectedWithoutReplay:true,financialOperations:0,proofsGenerated:0,rpcRequests:0,realFills:0,ordinaryWalletClaims:0,qualifiedRandomness:false,finalityVerified:false,seedSecrecyAuthenticated:false,canBroadcast:false};
await save(join(c,'public/NATIVE-INTEGRATION-v1.json'),report);console.log(JSON.stringify({nativePlanningRuns:nativeRuns,markets:rows.map(r=>r.market),sameOriginalPlans:true,canBroadcast:false}));
