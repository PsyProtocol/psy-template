from pathlib import Path
import copy,hashlib,json,os,subprocess,time
b=Path(__file__).resolve().parent;o=b/'rejection-v1';o.mkdir();d=b/'derived-v1';tool=b.parent/'sdk-mainnet-beta-20261027-v1/target/release/inspect_checkpoint_evidence';opening=json.loads((d/'current-opening.json').read_text());rows=[];env=dict(os.environ,PSY_NETWORK='testnet',PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',RAYON_NUM_THREADS='2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,value=None,proof=None,previous=None,reason=None,report_expected=False):
 case=o/label;case.mkdir();ip=d/'current-opening.json';pp=d/'current-proof.bin';prev=previous or str(d/'previous-proof.bin')
 if value is not None:
  ip=case/'opening.json'
  with ip.open('xb')as out:out.write(value if isinstance(value,bytes)else json.dumps(value).encode())
 if proof is not None:
  pp=case/'proof.bin'
  with pp.open('xb')as out:out.write(proof)
 report=case/'REPORT.json';cmd=[str(tool),str(ip),str(pp),prev,str(report)];start=time.monotonic();r=subprocess.run(cmd,env=env,capture_output=True,timeout=30)
 with (case/'output.log').open('xb')as out:out.write(r.stdout+r.stderr)
 assert r.returncode!=0,(label,'unexpected acceptance')
 if report_expected:
  result=json.loads(report.read_text());assert not result['checkpointCircuitProofVerified']and not result['finalityVerified']and not result['randomAuthorization']
  if reason:assert reason in result['error'],(label,result['error'])
  expected=None if prev=='-'else sha(Path(prev));assert result['previousProofSha256']==expected
 else:assert not report.exists(),label
 rows.append({'label':label,'exitCode':r.returncode,'seconds':time.monotonic()-start,'command':cmd,'targetErrorContains':reason,'reportProduced':report_expected,'financialOperations':0,'proofsGenerated':0})
for label,key,value in [('wrong-path-index','checkpoint_id',opening['checkpoint_id']+1),('wrong-root','checkpoint_root','0'*64),('wrong-leaf','checkpoint_leaf_hash','0'*64)]:
 v=copy.deepcopy(opening);v[key]=value;run(label,v,reason='checkpoint root/leaf/index membership',report_expected=True)
v=copy.deepcopy(opening);v['verified']=True;run('injected-success',v)
run('trailing-proof',proof=(d/'current-proof.bin').read_bytes()+b'\x00')
run('oversize-proof',proof=b' '*2000001)
run('missing-predecessor',previous='-',reason='verified predecessor proof required',report_expected=True)
# This is byte provenance under a blocked compatibility check, not a claim that
# the alternative proof is cryptographically rejected for its changed prefix.
run('substituted-predecessor-identity',previous=str(d/'current-proof.bin'),reason='predecessor transition proof under frozen resources',report_expected=True)
report=b/'public/resource-report-preserved-v3.json';cmd=[str(tool),'resources',str(report)];first=subprocess.run(cmd,env=env,capture_output=True,timeout=30);assert first.returncode==0;before=sha(report);second=subprocess.run(cmd,env=env,capture_output=True,timeout=30);assert second.returncode!=0 and sha(report)==before
rows.append({'label':'existing-resource-report','firstExitCode':0,'secondExitCode':second.returncode,'existingReportUnchanged':True,'financialOperations':0,'proofsGenerated':0})
with (b/'public/rejection-result-v1.json').open('x')as out:json.dump({'schema':1,'scope':'targeted pre-verification guard rejection and failed-report provenance; no positive proof/finality acceptance','cases':rows,'noProofsGenerated':True,'financialOperations':0,'randomAuthorization':False,'currentProofSha256':sha(d/'current-proof.bin'),'previousProofSha256':sha(d/'previous-proof.bin'),'toolSha256':sha(tool)},out,indent=2);out.write('\n')
print('Targeted guards and exact predecessor byte provenance checked; compatibility stays blocked.')
