from pathlib import Path
import os,subprocess,json,time,datetime
m=Path(__file__).resolve().parent
s=m.parent/'sdk-mainnet-beta-20261027-v1'
env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','BATCH_BUILD':str(m/'curve-exact-fixtures-v1'),'BATCH_FIXTURE_ASSET_A':'6','BATCH_FIXTURE_ASSET_B':'7','BATCH_FIXTURE_NFT':'8','BATCH_FIXTURE_ISSUER':'1590272','BATCH_FIXTURE_SYMBOL_A':'5325121','BATCH_FIXTURE_SYMBOL_B':'5325122','BATCH_DISTINCT_TOKEN_B':'1','BATCH_EXPECTED_MARKET_CODE_ROOT':'0d02be6709797e981c802b8515dfb58110c4a0d05708b4a2f8adcf4235777b5d','BATCH_ADMISSION_TEST':'1','BATCH_PROOF_PROFILE':'compact-v1','CURVE_GRADUATION_UPS_OUT':str(m/'curve-graduation-full-ups-v5'),'BATCH_FULL_UPS_OUT':str(m/'curve-graduation-full-ups-v5')})
cmd=['cargo','+nightly-2025-09-20','test','--release','--locked','--offline','--manifest-path',str(m/'application-wallet-v26/Cargo.toml'),'--test','batch_lifecycle','full_ups::full_ups_curve_graduation_recipient_proof','--','--exact','--ignored','--nocapture']
start=time.monotonic()
with (m/'public/curve-graduation-full-ups-v5.log').open('x') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
with (m/'public/curve-graduation-full-ups-v5-exit.json').open('x') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'seconds':time.monotonic()-start,'command':cmd,'financialOperations':0},f,indent=2)
raise SystemExit(r.returncode)
