// Original checkpoint only; no alternate checkpoint, retries, writes or proofs.
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {parseLosslessJson,losslessJson} from '../../psy-template-security-20261016/amm/u124/client.mjs';
const base=new URL('./',import.meta.url),out=new URL('root-views-v1/',base);await mkdir(out,{mode:0o700});
const save=(n,v)=>writeFile(new URL(n,out),losslessJson(v)+'\n',{flag:'wx'});
const checkpoint=Number(parseLosslessJson(await readFile(new URL('capture-v1/SUMMARY.json',base),'utf8')).checkpoint);
let reads=0;const results=[];
for(const endpoint of ['https://realm0-stg.psy-protocol.xyz','https://realm1-stg.psy-protocol.xyz','https://coordinator-stg.psy-protocol.xyz']){
 const row={endpoint,checkpoint};
 for(const [key,method,params]of [['root','psy_get_checkpoint_tree_root',{checkpoint_id:checkpoint}],['proof','psy_get_checkpoint_tree_merkle_proof',{checkpoint_id:checkpoint,leaf_checkpoint_id:checkpoint}]]){
  const q={jsonrpc:'2.0',id:++reads,method,params},label=String(reads);await save(label+'-request.json',{endpoint,request:q});
  try{const r=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(q),redirect:'manual',signal:AbortSignal.timeout(25000)});let bytes=0,parts=[];for await(const b of r.body){bytes+=b.length;if(bytes>32768)throw Error('Response limit');parts.push(b);}const body=Buffer.concat(parts);await writeFile(new URL(label+'-response.json',out),body,{flag:'wx'});const v=parseLosslessJson(body.toString());if(r.status!==200||v.id!==BigInt(q.id)||v.error||!Object.hasOwn(v,'result'))throw Error('Read response rejected');row[key]=v.result;
  }catch(e){row[key+'Error']=e.message;await save(label+'-failure.json',{error:e.message,automaticRetry:false});}
 }
 row.rootEqualsPathRoot=typeof row.root==='string'&&row.root===row.proof?.root;results.push(row);
}
const summary={schema:1,checkpoint,reads,views:results,allReadPairsMatch:results.every(r=>r.rootEqualsPathRoot),allViewsShareRoot:results.every(r=>r.root&&r.root===results[0].root),historicalFaucetCauseProven:false,financialAuthorization:false,financialOperations:0};await save('SUMMARY.json',summary);console.log(losslessJson({...summary,views:results.map(r=>({endpoint:r.endpoint,root:r.root??null,rootEqualsPathRoot:r.rootEqualsPathRoot}))}));
