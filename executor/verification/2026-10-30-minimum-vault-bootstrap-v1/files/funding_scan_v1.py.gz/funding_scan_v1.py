from pathlib import Path
import json,subprocess
c=Path(__file__).resolve().parent;d=c/'public/funding-outbox-scan-v1';d.mkdir()
old=c/'public/funding-readonly-v1'
config=json.loads((old/'config-result.json').read_text())['response']['result'];cp=json.loads((old/'head-result.json').read_text())['response']['result']['checkpoint_id'];ops=config['operator_user_ids'];assert len(ops)<=100 and len(set(ops))==len(ops)
recipient=223232
put=lambda n,v:(d/n).open('x').write(json.dumps(v,indent=2)+'\n')
put('PLAN.json',{'maximumLogicalReadRequests':101,'retries':0,'fixedObservedCheckpoint':cp,'scope':'observations only; no receipt/finality/absence-of-pending-broadcast proof','recipient':recipient,'financialOperations':0})
def read(label,url,q):
 put(label+'-request.json',{'url':url,'request':q});p=subprocess.run(['curl','--silent','--show-error','--max-time','20','--connect-timeout','5','--max-filesize','2097152','--header','content-type: application/json','--data-binary','@-',url],input=json.dumps(q).encode(),capture_output=True,timeout=25);(d/(label+'-response.raw')).write_bytes(p.stdout);assert p.returncode==0
 v=json.loads(p.stdout);put(label+'-result.json',v);return v
leaf=read('recipient','https://realm0-stg.psy-protocol.xyz',{'jsonrpc':'2.0','id':1,'method':'psy_get_user_leaf_data','params':{'checkpoint_id':cp,'user_id':recipient}})
rows=[]
for realm in [0,1]:
 ids=[o for o in ops if o//1048576==realm]
 q=[{'jsonrpc':'2.0','id':o,'method':'psy_get_user_contract_state_tree_leaf_hash','params':{'checkpoint_id':cp,'user_id':o,'contract_id':0,'height':32,'leaf_id':(3+2*recipient)//4}} for o in ids]
 if not q:continue
 res=read('operators-'+str(realm),'https://realm'+str(realm)+'-stg.psy-protocol.xyz',q);assert isinstance(res,list)and len(res)==len(q)
 for v in res:
  if 'error'in v:rows.append({'operator':v['id'],'error':v['error']});continue
  word=int(v['result'],16);limbs=[(word>>(64*i))&((1<<64)-1)for i in range(4)];rows.append({'operator':v['id'],'rawCumulativeSent':str(limbs[(3+2*recipient)%4])})
put('SUMMARY.json',{'recipient':recipient,'checkpoint':cp,'recipientLeaf':leaf,'observedOperators':len(rows),'nonzeroSent':[r for r in rows if int(r.get('rawCumulativeSent','0'))>0],'errors':[r for r in rows if 'error'in r],'rawUnverifiedRpcObservation':True,'originalFaucetResultResolved':False,'mayResendOriginal':False,'financialOperations':0})
print(json.dumps({'operators':len(rows),'nonzero':sum(int(r.get('rawCumulativeSent','0'))>0 for r in rows),'errors':sum('error'in r for r in rows),'recipientNonce':leaf.get('result',{}).get('nonce')}))
