from pathlib import Path
import json,gzip,hashlib,re
c=Path(__file__).resolve().parent
repo=Path('<application-root>')
out=repo/'executor/verification/2026-10-30-source-stream-native-receipt-v1'
files=[p for p in(c/'public').rglob('*')if p.is_file()]
for snap in sorted(c.glob('application-v*')):
 for name in ['APPLICATION.json','Cargo.toml','Cargo.lock','src/source_plan_receipt.rs','src/bin/minimum_stream_plan.rs','src/bin/random_stream_plan.rs']:
  files.append(snap/name)
files.extend(p for p in(c/'javascript-final-v1').rglob('*')if p.is_file())
allowed={'review.json','snapshot.json','draw.json','policy.json','acceptedSeal.json','plan.json','source-pages.json','minimum-pages.json','ordering-pages.json','queue.json','native-receipt.json','binding.json','options.json','original-prepared-record.json'}
for base in [c/'native-integration-v1',c/'v10-runtime-v1']:
 for p in base.rglob('*'):
  if p.is_file()and 'drivers'not in p.relative_to(c).parts and (p.name in allowed or re.match(r'^\d{8}-.*\.json$',p.name)or p.suffix in ['.stdout','.stderr']or p.name.endswith('.request.json')):files.append(p)
files.extend([c/'run.py',c/'native_integration_v1.mjs',c/'final_resume_and_v10_v1.mjs',Path(__file__)])
forbidden={'private_key','privateKey','mnemonic','secretKey','signing_witness','signature_witness','secp256k1_slots','recoveryPhrase'}
def scan(v):
 if isinstance(v,dict):
  assert not set(v)&forbidden,'forbidden public field'
  for x in v.values():scan(x)
 elif isinstance(v,list):
  for x in v:scan(x)
sha=lambda b:hashlib.sha256(b).hexdigest();prepared=[]
for p in sorted(set(files)):
 assert not p.is_symlink();raw=p.read_bytes();data=raw
 if p.suffix!='.bin' and 'compiled-input-blobs'not in p.parts:
  data=raw.decode().replace(str(c),'<case-root>').replace(str(repo),'<application-root>').replace(str(c.parent),'<evidence-root>').replace(str(Path.home()),'<home>').encode()
 if p.suffix=='.json':scan(json.loads(data))
 prepared.append((p,raw,data))
out.mkdir();index=[]
for p,raw,data in prepared:
 q=out/'files'/(p.relative_to(c).as_posix()+'.gz');q.parent.mkdir(parents=True,exist_ok=True);z=gzip.compress(data,mtime=0)
 with q.open('xb')as f:f.write(z)
 assert gzip.decompress(q.read_bytes())==data
 index.append({'source':p.relative_to(c).as_posix(),'file':q.relative_to(out).as_posix(),'originalSha256':sha(raw),'publicSha256':sha(data),'gzipSha256':sha(z),'gzipBytes':len(z),'redacted':raw!=data})
for name,value in [('index.json',index),('SUMMARY.json',json.loads((c/'public/FINAL-SUMMARY-v1.json').read_text())),('PUBLISHED-AUDIT.json',{'indexedFiles':len(index),'publicFieldProjectionScanPassed':True,'allPublicCompressedDigestsVerified':True,'compiledBlobsPreserveExactRawDigests':True,'privateOrSigningWitnessesIncluded':False,'financialOperations':0})]:
 with(out/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({'files':len(index),'gzipBytes':sum(r['gzipBytes']for r in index)}))
