"""Reproduce the preserved compatibility failure; never create a passing claim."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
assert len(sys.argv)==4,'EXTRACTED_ROOT TRUSTED_BUILT_INSPECTOR FRESH_OUTPUT_DIRECTORY'
root,tool,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir();d=root/'derived-v1';report=out/'inspection.json';args=[str(tool),str(d/'current-opening.json'),str(d/'current-proof.bin'),str(d/'previous-proof.bin'),str(report)]
r=subprocess.run(args,env=dict(os.environ,PSY_NETWORK='testnet',PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',RAYON_NUM_THREADS='2'),capture_output=True,timeout=30)
with (out/'output.log').open('xb')as log:log.write(r.stdout+r.stderr)
assert r.returncode!=0,'unexpected acceptance; inspect cohort/resources before drawing conclusions'
value=json.loads(report.read_text());assert value['inspectionPassed']==False and value['checkpointCircuitProofVerified']==False
for key in ['canonicalGenesisVerified','chainDomainAuthenticated','numericPredecessorAdjacencyVerified','latestPositionVerified','historyPrefixAnchored','finalityVerified','qualifiedSource','causalSealVerified','randomAuthorization','broadcast']:assert value[key]==False,key
expected_stage='predecessor transition proof under frozen resources'
expected_cause='Condition failed: `vanishing_polys_zeta[i] == z_h_zeta * reduce_with_powers(chunk, zeta_pow_deg)`'
expected_error=expected_stage+': '+expected_cause
assert value['error']==expected_error,'failure occurred outside the expected proof verification stage: '+value['error']
assert value['resources']['cacheMatchesConstructedGenesis']==True
assert value['resources']['transitionFingerprint']=='5e4c467c5e5984b52b2ce8a8dc1401ef3d6046ef3b529935e4cc840112e63f06'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert value['proofSha256']==sha(d/'current-proof.bin')and value['previousProofSha256']==sha(d/'previous-proof.bin')
with (out/'REPLAY.json').open('x')as f:json.dump({'schema':1,'scope':'exact failed compatibility inspection replay, not proof acceptance','expectedFailureReproduced':True,'expectedVerificationStage':expected_stage,'observedVerificationError':value['error'],'frozenTransitionFingerprint':value['resources']['transitionFingerprint'],'checkpointProofAccepted':False,'exitCode':r.returncode,'toolSha256':sha(tool),'reportSha256':sha(report),'currentProofSha256':value['proofSha256'],'previousProofSha256':value['previousProofSha256'],'financialOperations':0,'proofsGenerated':0,'finalityVerified':False,'randomAuthorization':False},f,indent=2);f.write('\n')
print('Expected compatibility failure reproduced for the exact original bytes; no accepted proof or finance.')
