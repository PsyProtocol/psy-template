"""Bounded public reads only; no signing, funds, faucet or submission."""
from pathlib import Path
import datetime, hashlib, json, urllib.request, subprocess

BASE = Path(__file__).resolve().parent
CAPTURE = BASE / 'capture-v2'
CAPTURE.mkdir()
COORDINATOR = 'https://coordinator-stg.psy-protocol.xyz'
REALMS = ['https://realm0-stg.psy-protocol.xyz', 'https://realm1-stg.psy-protocol.xyz']
count = 0
total = 0

def save(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('redirect rejected')

def unique(rows):
    value = {}
    for key, item in rows:
        if key in value:
            raise ValueError('duplicate JSON field')
        value[key] = item
    return value

def read(label, endpoint, method, params):
    global count, total
    if not method.startswith('psy_get_') or count >= 29:
        raise ValueError('public read budget/allowlist')
    count += 1
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params}
    save(CAPTURE / (label + '-request.json'), request)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        response_path = CAPTURE / (label + '.json')
        transport = subprocess.run(['curl','--silent','--show-error','--max-time','25','--connect-timeout','10','--retry','0','--proto','=https','--tlsv1.2','--max-filesize','4194304','--output',str(response_path),'--write-out','%{http_code}','--header','content-type: application/json','--data-binary','@'+str(CAPTURE/(label+'-request.json')),endpoint],capture_output=True,timeout=30)
        status = int(transport.stdout or b'0')
        raw = response_path.read_bytes() if response_path.exists() else b''
        if transport.returncode != 0 or status != 200:
            raise ValueError('libcurl failed: '+str(transport.returncode)+' HTTP '+str(status)+' '+transport.stderr.decode(errors='replace'))
        if len(raw) > 4_194_304 or total + len(raw) > 33_554_432:
            raise ValueError('capture budget exceeded')
        total += len(raw)
        save(CAPTURE / (label + '-transport.json'), {'endpoint':endpoint,'startedAt':started,'httpStatus':status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'attempts':1})
        envelope = json.loads(raw, object_pairs_hook=unique)
        if envelope.get('jsonrpc') != '2.0' or type(envelope.get('id')) is not int or envelope['id'] != 1 or 'error' in envelope or 'result' not in envelope:
            raise ValueError('RPC error or invalid response identity: ' + label)
        return envelope['result']
    except Exception as error:
        save(CAPTURE / (label + '-failure.json'), {'startedAt':started,'error':str(error),'attempts':1,'financialOperations':0})
        raise

result = {'complete':False,'financialOperations':0}
try:
    heads = [read('realm' + str(i) + '-head', url, 'psy_get_latest_l2_block_state', {}) for i, url in enumerate(REALMS)]
    checkpoint = min(row['checkpoint_id'] for row in heads)
    if type(checkpoint) is not int or checkpoint < 3:
        raise ValueError('invalid common checkpoint')
    roots = [read('anchor-' + str(i), url, 'psy_get_checkpoint_leaf_data', {'checkpoint_id':1}) for i, url in enumerate([*REALMS, COORDINATOR])]
    if len({row['global_chain_root'] for row in roots}) != 1:
        raise ValueError('checkpoint-one root mismatch across views')
    leaf = read('native-leaf', COORDINATOR, 'psy_get_contract_leaf_data', {'contract_id':0})
    read('native-code', COORDINATOR, 'psy_get_contract_code_definition', {'contract_id':0})
    read('source-roots', COORDINATOR, 'psy_get_checkpoint_global_state_roots', {'checkpoint_id':checkpoint})
    checkpoint_leaf = read('source-leaf', COORDINATOR, 'psy_get_checkpoint_leaf_data', {'checkpoint_id':checkpoint})
    read('native-membership', COORDINATOR, 'psy_get_contract_tree_merkle_proof', {'contract_id':0,'checkpoint_id':checkpoint})
    tree_root = read('checkpoint-tree-root', COORDINATOR, 'psy_get_checkpoint_tree_root', {'checkpoint_id':checkpoint})
    anchor_path = read('anchor-path', COORDINATOR, 'psy_get_checkpoint_tree_merkle_proof', {'checkpoint_id':checkpoint,'leaf_checkpoint_id':1})
    checkpoint_path = read('source-path', COORDINATOR, 'psy_get_checkpoint_tree_merkle_proof', {'checkpoint_id':checkpoint,'leaf_checkpoint_id':checkpoint})
    after = read('native-leaf-after', COORDINATOR, 'psy_get_contract_leaf_data', {'contract_id':0})
    if after != leaf:
        raise ValueError('native identity changed during capture')
    context = {'schema':1,'checkpointId':checkpoint,'expectedChainRootAt1':roots[0]['global_chain_root'],
               'chainAnchorLeaf':roots[2],'checkpointLeaf':checkpoint_leaf,'chainAnchorPath':anchor_path,
               'checkpointPath':checkpoint_path,'checkpointTreeRoot':tree_root}
    save(BASE/'public/checkpoint-context.json', context)
    # Scope is the previously recorded public funding identity. No faucet call.
    funding = read('funding-user', REALMS[0], 'psy_get_user_leaf_data', {'checkpoint_id':checkpoint,'user_id':223232})
    # Public registry response stays outside the publish directory until projection.
    read('runtime-client-resources', 'https://prove-stg.psy-protocol.xyz', 'psy_get_circuits_data', [])
    result.update(complete=True,checkpoint=checkpoint,chainRootAt1=context['expectedChainRootAt1'],nativeLeaf=leaf,
                  fundingUser={'userId':funding.get('user_id'),'publicKeyHash':funding.get('public_key'),'nativeBalance':funding.get('balance'),'nonce':funding.get('nonce')},
                  chainFinalityAuthenticated=False,financialReady=False)
except Exception as error:
    result['error'] = str(error)
finally:
    result.update(readRequests=count,captureBytes=total)
    save(BASE/'public/CAPTURE-SUMMARY-v2.json', result)
    print(json.dumps(result))
if not result['complete']:
    raise SystemExit(1)
