from pathlib import Path
import os,subprocess,json,time,datetime,resource
root=Path(__file__).resolve().parent;s=root.parent/'sdk-mainnet-beta-20261027-v1'
env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','BATCH_BUILD':str(root/'curve-recovery-fixtures-v1'),'BATCH_FIXTURE_ASSET_A':'6','BATCH_FIXTURE_ASSET_B':'7','BATCH_FIXTURE_NFT':'8','BATCH_FIXTURE_ISSUER':'1590272','BATCH_FIXTURE_SYMBOL_A':'5325121','BATCH_FIXTURE_SYMBOL_B':'5325122','BATCH_DISTINCT_TOKEN_B':'1','BATCH_EXPECTED_MARKET_CODE_ROOT':'0d02be6709797e981c802b8515dfb58110c4a0d05708b4a2f8adcf4235777b5d','BATCH_ADMISSION_TEST':'1','BATCH_PROOF_PROFILE':'compact-v1','BATCH_FULL_UPS_MARKETS':'bondingcurve','BATCH_FULL_UPS_OUT':str(root/'curve-recovery-full-ups-v2')})
cmd=['cargo','+nightly-2025-09-20','test','--release','--locked','--offline','--manifest-path',str(root/'application-curve-recovery-v1/Cargo.toml'),'--test','batch_lifecycle','full_ups::full_ups_expire_refreeze_and_refund_four_markets','--','--exact','--nocapture']
start=time.monotonic();samples=[];timedout=False
with (root/'public/curve-recovery-v2.log').open('x') as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines();rows=[list(map(int,row.split())) for row in rows];owned={p.pid}
  for _ in range(8):
   new=owned|{pid for pid,parent,rss in rows if parent in owned}
   if new==owned:break
   owned=new
  samples.append({'elapsedSeconds':time.monotonic()-start,'processes':[{'pid':pid,'rssKiB':rss}for pid,parent,rss in rows if pid in owned]})
  if time.monotonic()-start>1500:
   import signal
   os.killpg(p.pid,signal.SIGTERM);timedout=True;break
  time.sleep(2)
 p.wait(timeout=30)
with (root/'public/curve-recovery-v2-rss.json').open('x')as f:json.dump({'scope':'compiler and test process family; sampled RSS, shared pages may be counted repeatedly, not physical peak','intervalSeconds':2,'samples':samples},f)
with (root/'public/curve-recovery-v2-exit.json').open('x')as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'seconds':time.monotonic()-start,'timeout':timedout,'command':cmd,'financialOperations':0},f,indent=2)
raise SystemExit(p.returncode)
