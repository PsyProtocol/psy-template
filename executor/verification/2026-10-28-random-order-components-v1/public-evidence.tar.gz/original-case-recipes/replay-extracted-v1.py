# Use only a trusted verifier built from the reviewed application/frozen SDK.
# This verifies the conditional component; it never certifies a beacon or UPS.
from pathlib import Path
import json,subprocess,sys,hashlib
assert len(sys.argv)==4,'EXTRACTED_CASE TRUSTED_VERIFIER FRESH_REPORT'
b=Path(sys.argv[1]).resolve();tool=Path(sys.argv[2]).resolve();out=Path(sys.argv[3]).resolve();assert not out.exists()
subprocess.run([str(tool),str(b/'public/client-statement-v1.json'),str(b/'component-proofs-v1/permutation-proof.bin'),str(out)],check=True,timeout=20)
v=json.loads(out.read_text());assert v['componentProofVerified'] and not v['qualifiedSource']and not v['sealInclusionVerified']and not v['fullUpsVerified']and not v['broadcast']
assert v['inputSha256']==hashlib.sha256((b/'public/client-statement-v1.json').read_bytes()).hexdigest()
assert v['proofSha256']==hashlib.sha256((b/'component-proofs-v1/permutation-proof.bin').read_bytes()).hexdigest()
