from pathlib import Path
import subprocess,os,time,json,hashlib,signal
b=Path(__file__).resolve().parent
pin=json.loads((b/'public/DRIVERS-v1.json').read_text());identity_plan=json.loads((b/'public/IDENTITY_PREPARATION-v1.json').read_text())
assert identity_plan['financialStageEnabled'] is False
for r in pin['binaries']:assert hashlib.sha256((b/'drivers-v1'/r['file']).read_bytes()).hexdigest()==r['sha256']
assert hashlib.sha256((b/'public/rpc.json').read_bytes()).hexdigest()==identity_plan['configSha256']
env=dict(os.environ);env.update({'PSY_NETWORK':'testnet','PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','RAYON_NUM_THREADS':'2'})
for label in ['qa-issuer-lp','qa-user']:
 secret=b/'private'/(label+'.json');public=b/'public'/(label+'.json');assert not secret.exists() and not public.exists()
 args=[str(b/'drivers-v1/isolated_wallet'),'create',str(b/'public/rpc.json'),str(secret),str(public)]
 started=time.monotonic();samples=[]
 with (b/'public'/(label+'-create-v1.log')).open('x')as log:
  p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   rows=[list(map(int,x.split()))for x in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()];owned={p.pid}
   for _ in range(8):
    next_=owned|{pid for pid,parent,rss in rows if parent in owned}
    if next_==owned:break
    owned=next_
   samples.append({'elapsedSeconds':time.monotonic()-started,'processFamilyRssKiB':sum(rss for pid,parent,rss in rows if pid in owned)})
   if time.monotonic()-started>600:
    os.killpg(p.pid,signal.SIGTERM);p.wait();break
   time.sleep(1)
 result={'schema':1,'operation':'fresh-offline-identity-create','label':label,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-started,'samples':samples,'samplingSeconds':1,'memoryScope':'launch-to-exit process-family sampled RSS; shared pages may duplicate and between-sample peaks may be missed, not physical peak','financialOperations':0,'businessProofsGenerated':0,'privateDataIncluded':False}
 with (b/'public'/(label+'-create-result-v1.json')).open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 if p.returncode!=0:raise SystemExit('Identity preparation failed; original files retained, no retry or financial action')
 assert secret.stat().st_mode & 0o777 == 0o600
 pub=json.loads(public.read_text());assert pub['network']=='testnet' and pub['networkMagic']=='1384803358401154921'
 print(label,'created offline; not registered/funded',flush=True)
