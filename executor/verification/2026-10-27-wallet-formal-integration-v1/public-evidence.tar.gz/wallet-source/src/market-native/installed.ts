// No reviewed reset-chain market release has been installed. A release build
// replaces this module with static imports after exact instance verification.
import type { InstalledMarketRelease } from "./runtime";
export const installedMarketRelease: InstalledMarketRelease | null = null;
