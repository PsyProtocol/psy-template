// Public current system-faucet identity/code only. No execution or update.
import{writeFile,mkdir}from'node:fs/promises';
const out=new URL('faucet-code-v1/',import.meta.url);await mkdir(out,{mode:0o700});let id=0;
for(const method of ['psy_get_contract_leaf_data','psy_get_contract_code_definition']){
 const request={jsonrpc:'2.0',id:++id,method,params:{contract_id:5}};await writeFile(new URL(id+'-request.json',out),JSON.stringify(request)+'\n',{flag:'wx'});
 const r=await fetch('https://coordinator-stg.psy-protocol.xyz',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),redirect:'manual',signal:AbortSignal.timeout(20000)});let n=0,parts=[];for await(const b of r.body){n+=b.length;if(n>1048576)throw Error('Response limit');parts.push(b);}const b=Buffer.concat(parts);await writeFile(new URL(id+'-response.json',out),b,{flag:'wx'});const v=JSON.parse(b);if(r.status!==200||v.id!==id||v.error)throw Error('Read rejected');console.log(JSON.stringify({method,httpStatus:r.status,bytes:n,shape:Object.keys(v.result)}));
}
