"""Single owned, bounded offline proof run; no RPC or financial operations."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

case = Path(__file__).resolve().parent
binary = case / 'drivers/replay-guard-v4'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
initial_digest = digest(binary)
env = dict(os.environ, PSY_NETWORK='testnet',
           PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',
           RAYON_NUM_THREADS='2',
           BATCH_BUILD=str(case.parent / 'deterministic-bootstrap-20261031-v1/fixtures-v1'),
           FUNDED_REPLAY_GUARD_INPUT=str(case / 'full-ups-v1/amm-funding-grant'),
           FUNDED_REPLAY_GUARD_OUT=str(case / 'replay-guard-v1'),
           FUNDED_STREAM_REUSE_GRANTS=str(case / 'full-ups-v1'))
env.pop('PSY_MARKET_SYNTHETIC_WITNESS_AUDIT', None)
command = [str(binary), '--exact',
           'full_ups::stream_full_ups::funded_stream_full_ups::deterministic_saved_grant_reuse_rejects_changed_context',
           '--ignored', '--test-threads=1', '--nocapture']
start = time.monotonic()
with (case / 'public/replay-guard-v1.raw.log').open('x') as log, \
        (case / 'public/rss-guard-v1.jsonl').open('x') as rss:
    child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
    with (case / 'public/ACTIVE-GUARD-v1.json').open('x') as stream:
        json.dump(dict(schema=1, owner='root', pid=child.pid,
                       startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       binarySha256=initial_digest, command=command,
                       maximumSeconds=180, maximumPositiveFullUps=0,
                       financialOperations=0), stream, indent=2)
    peak = family_peak = 0
    samples = 0
    stop = None
    while child.poll() is None:
        elapsed = time.monotonic() - start
        rows = {}
        for line in subprocess.check_output(['ps', '-axo', 'pid=,ppid=,rss='], text=True).splitlines():
            pid, parent, resident = map(int, line.split())
            rows[pid] = (parent, resident)
        family = {child.pid}
        while True:
            extended = family | {pid for pid, (parent, _) in rows.items() if parent in family}
            if extended == family:
                break
            family = extended
        resident = rows.get(child.pid, (0, 0))[1]
        total = sum(rows.get(pid, (0, 0))[1] for pid in family)
        peak, family_peak = max(peak, resident), max(family_peak, total)
        rss.write(json.dumps(dict(seconds=elapsed, childRssKiB=resident,
                                  familySumRssKiB=total, processes=len(family))) + '\n')
        rss.flush()
        samples += 1
        if elapsed > 180 or total > 10 * 1024 * 1024:
            stop = 'time-budget' if elapsed > 180 else 'sampled-family-rss-limit'
            child.terminate()
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                child.kill()
            break
        time.sleep(1)
    code = child.wait()
with (case / 'public/CLOSED-GUARD-v1.json').open('x') as stream:
    json.dump(dict(schema=1, exitCode=code, stopReason=stop,
                   elapsedSeconds=time.monotonic()-start, sampledChildRssPeakKiB=peak,
                   sampledFamilySumRssPeakKiB=family_peak, samples=samples,
                   sampleIntervalSeconds=1, binarySha256=initial_digest,
                   binaryUnchanged=digest(binary)==initial_digest,
                   memoryScope='Sampled child RSS and family sum include shared pages; not physical peak. No matched speedup claim.',
                   financialOperations=0), stream, indent=2)
raise SystemExit(code)
