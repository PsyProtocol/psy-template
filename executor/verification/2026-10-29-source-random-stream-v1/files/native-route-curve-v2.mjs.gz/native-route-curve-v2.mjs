import{readFile,writeFile}from'node:fs/promises';import{createHash}from'node:crypto';
import{prepareRandomSourceStream}from'<application-root>/executor/randomSourceStream.mjs';
const c='<case-root>',d=c+'/native-planner-curve-v1';
const sha=b=>createHash('sha256').update(b).digest('hex'),o={historyRoot:JSON.parse(await readFile(d+'/source.json')).history.checkpoint_path.root,wallet:c+'/bin-v4/random_stream_plan',runtimeDirectory:c+'/native-route-curve-v2',walletSha256:sha(await readFile(c+'/bin-v4/random_stream_plan'))};
for(const[n,f]of Object.entries({review:'review.json',snapshot:'source.json',draw:'draw.json',policy:'policy.json'})){o[n]=d+'/'+f;o[n+'Sha256']=sha(await readFile(o[n]));}
const started=performance.now(),a=await prepareRandomSourceStream(o),status=await a.status(),b=await prepareRandomSourceStream(o);let reselection=false,spending=false;
try{await prepareRandomSourceStream({...o,historyRoot:'b'.repeat(64)});}catch{reselection=true;}
try{a.authorizeSettlement();}catch{spending=true;}
await writeFile(c+'/public/native-route-curve-v2.json',JSON.stringify({schema:1,elapsedMilliseconds:performance.now()-started,status,restartStatus:await b.status(),sameEpochReselectionRejected:reselection,spendingRejected:spending,financialOperations:0,syntheticHistory:true},null,2)+'\n',{flag:'wx'});
console.log(status);
