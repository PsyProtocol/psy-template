from pathlib import Path
import hashlib,json,tarfile,gzip,io,re
c=Path(__file__).resolve().parent;r=c.parent.parent/'psy-template-security-20261016';out=r/'executor/verification/2026-10-31-faucet-start-root-v1';out.mkdir();items={}
for directory in ['public','capture-v1','reconcile-v1','root-views-v1','historical-roots-v1']:
 for p in sorted((c/directory).rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink();assert p.suffix in ['.json','.log'];b=p.read_bytes();name=p.relative_to(c).as_posix()
  assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|"(?:private_key|privateKey|mnemonic|seedPhrase|password)"\s*:',b),name
  items[name]=b
for f in ['run.py','read-root-views.mjs','read-historical-roots.mjs','package-public.py']:items['capture-tools/'+f]=(c/f).read_bytes()
for f in ['amm/u124/vm-tests/src/bin/inspect_ups_start_wire.rs','executor/acceptance/captureNativeBinding.mjs','executor/acceptance/captureNativeBinding.test.mjs','executor/acceptance/upsStartWire.test.mjs']:items['application-source/'+f]=(r/f).read_bytes()
items['application-source/APPLICATION-v1.json']=(c/'application-v1/APPLICATION.json').read_bytes()
# Reviewed public verifier-only payload; no faucet error body, secrets or drivers
# are traversed. Historical correlations contain only public roots and flags.
assert json.loads(items['capture-v1/runtime-client-resources.json'])['result']==json.loads((c.parent/'current-chain-activation-20261030-v1/capture-v3/runtime-client-resources.json').read_text())['result']
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w')as t:
 for name,b in sorted(items.items()):
  e=tarfile.TarInfo(name);e.size=len(b);e.mode=0o644;e.mtime=0;t.addfile(e,io.BytesIO(b))
packed=gzip.compress(buf.getvalue(),mtime=0)
with (out/'evidence.tar.gz').open('xb')as f:f.write(packed)
m={'schema':1,'scope':'Faucet copy-constraint localization and bounded public observations; no historical witness reproduction or financial acceptance','archiveSha256':hashlib.sha256(packed).hexdigest(),'members':[{'file':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(items.items())],'financialOperations':0,'proofsGenerated':0,'originalOutcomeResolved':False}
with (out/'manifest.json').open('x')as f:json.dump(m,f,indent=2);f.write('\n')
with (out/'README.md').open('x')as f:f.write('''# Faucet UPS-start root investigation

Read the [review report](../../../docs/security/FAUCET_START_ROOT_CAUSE_20261031.md).
The frozen/current resource maps error wire (46,12) to the session/path
checkpoint-tree root element 0. Original assignments correlate with public
roots 1758 and 1759 within a bounded 15-root range. Complete historical witness,
running-resource provenance and original request disposition remain unavailable.

- `capture-v1/`: 16 fresh chain/Native/user/public-resource observations.
- `reconcile-v1/`: all 203 config/registration/cursor requests and responses.
- `root-views-v1/`: six root/path reads at current checkpoint 25091.
- `historical-roots-v1/`: all 15 original historical-root reads and correlation
  flags. Raw private assignment values and original faucet body are excluded.
- `public/`: budgets, public error projection, exact topology report, build and
  sealed executable digests, four inspector checks, initial/final 26-case
  regression logs, source/resource checks, manual review and zero-fee closing.
- `application-source/`: source snapshots and the frozen application manifest.
- `capture-tools/`: bounded original acquisition/build-wrapper/package scripts,
  retaining local acquisition paths; no authority to replay finance.

The manifest binds every member, size, SHA256 and archive SHA256. Wallet secrets,
recovery files, raw original private faucet diagnostics, binary executables and
signing witnesses are excluded. Public `private_note_*` verifier metadata is
byte-identical to the previously reviewed public registry, not a secret key.

There were exactly 240 public reads and no new faucet request, financial proof,
deployment, registration, fill or ordinary claim. A pending Outbox is not
spendable; current known funding is zero. Application root consistency checks
remain metadata checks and cannot replace complete Merkle/UPS/session verification.
''')
print(json.dumps({'members':len(items),'archiveBytes':len(packed),'sha256':m['archiveSha256']}))
