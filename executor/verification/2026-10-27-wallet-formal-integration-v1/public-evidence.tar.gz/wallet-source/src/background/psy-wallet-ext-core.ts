import { isPublicTokenCall, publicTokenMethod } from "@/lib/nativeToken";
import {
  createPrepareOnlyMarketService,
  createMarketWalletService,
  type PreparationService,
  type MarketWalletService,
  type PreparationContext,
  type PreparationRecord,
} from "../market-preparation/market-client/wallet/prepareService.mjs";
import marketPreparationBundle from "../market-preparation/bundle.json";
import { installedMarketOptions } from "../market-native/runtime";
import { marketConfirmation } from "../market-native/confirmation";
import {
  type ClaimBatchItem,
  type ContractCallArgs,
  type ContractCallData,
  type DPNFunctionCircuitDefinition,
  type Felt,
  type GeneratedTxTraceJson,
  type PrivateTransferClaimRaw,
  PsyJSON,
  type PsyUserWalletProvider,
  SignType,
  type SimulatedTxJson,
  type TraceStepProgressJson,
} from "@psy-protocol/psy-sdk";
import type { PsyNetworkConfig } from "@psy-protocol/psy-sdk/config";
import { ethers, sha256, toUtf8Bytes } from "ethers";
import { type Event as NostrEvent, nip44 } from "nostr-tools";
import accountsApproved from "@/background/accounts-approved";
import approveManager from "@/background/approve-manager";
import {
  buildPrivateTransferSignedEvents,
  isTransientNostrRelayError,
  publishSignedEvents,
} from "@/background/nostr-gift-wrap";
import pendingHolds, { type IPendingHold } from "@/background/pending-holds";
import { armPendingRecoveryAlarm } from "@/background/pending-recovery-alarm";
import tokensManager from "@/background/tokens-manager.ts";
import { type TraceRecord, traceStore } from "@/background/trace-store";
import transactionManager from "@/background/transaction-manager";
import txQueue, {
  type TxQueueEnqueueOptions,
  type TxQueueEntry,
  type TxQueueJobKind,
  type TxQueuePayloadFor,
} from "@/background/tx-queue";
import type { NetworkType } from "@/env";
import ENV from "@/env";
import { disambiguateAccountName, nextAccountName } from "@/lib/account-naming";
import { AsyncQueue } from "@/lib/async-queue";
import {
  assessClaimBatchAffordability,
  buildImportedShieldDepositClaimBatchItem,
  type ClaimMaterialById,
  claimableAggregatesFromSnapshotItems,
  claimListFromSnapshotItems,
  claimMaterialByIdFromLists,
  clearWalletSnapshotCache,
  type ImportedClaimable,
  identityReproducesOwner,
  inputsForPrivateNote,
  inputsForShieldDeposit,
  filterUnclaimedShieldDepositsByImt,
  isImportedShieldDepositAlreadyClaimed,
  isPrivateNoteAlreadyClaimed,
  loadWalletSnapshotCache,
  mergeShieldDepositSources,
  markPrivateReceiveHistoryClaimed,
  type PrivateNote,
  type PrivateReceiveHistoryItem,
  type PublicClaimItemPersisted,
  parseDecryptedDepositSecrets,
  privateClaimableItemsFromServices,
  privateReceiveHistoryFromServices,
  privateNoteClaimBatchItem,
  privateNoteOwnerLimbs,
  shieldAddressFromNoteOwner,
  publicClaimBatchItem,
  publicClaimItemsFromServices,
  resolvePrivateClaimReceiveIdentities,
  type SnapshotClaimableItem,
  saveWalletSnapshotCache,
  shieldDepositItemsFromBridgeDeposits,
  snapshotClaimableItemsFromLists,
  validatePrivateDepositApiProof,
  validatePrivateTransferApiProof,
  type WalletSnapshot,
} from "@/lib/claimables";
import {
  fetchBlockNumber,
  fetchUserBalance,
  getClaimAmount,
  getSenderTotalSent,
} from "@/lib/data";
import { hostedFaucetOrigin, hostedFaucetVerifyUrl } from "@/lib/faucet";
import {
  isFaucetCooldownActive,
  loadFaucetCooldownMarker,
  markFaucetWindowUsed,
} from "@/lib/faucet-cooldown";
import {
  decryptPrivateTransferNotesFromResponse,
  dedupePrivateNotes,
  normalizeSecretsEvents,
} from "@/lib/nostrGiftWrapDecrypt";
// Static import — see also the `runPrivateTransferQueueEntry` method below.
// Vite generates `__vitePreload` calls around `await import("@/lib/...")`
// dynamic imports, and __vitePreload immediately touches
// document.getElementsByTagName / document.querySelector / document.createElement
// without a typeof guard. In a Chrome MV3 service-worker context (where this
// module runs) `document` is undefined, so the first dynamic import explodes
// with "document is not defined" — and the wallet's private-transfer flow
// surfaces it to the bridge as `sendError: "document is not defined"`.
// Pulling the import to module load eliminates the preload polyfill call
// entirely; the SW lifetime makes lazy-loading worthless here anyway.
import {
  buildNostrPayload,
  buildPrivateTransferCall,
  DEFAULT_NOTE_ROOT_SLOT,
  executePrivateTransfer as executePrivateTransferLib,
  type PrivateTransferResult,
} from "@/lib/privateTransfer";
import extStorage from "@/lib/extStorage";
import {
  deferFtDelivery,
  rememberVerifiedFtDelivery,
  pendingFtDeliveries,
  isTerminalFtError,
  decryptFtDelivery,
  ftPinForContractLeaf,
  ftBalanceFromLeaf,
  fetchFtMailbox,
  ftPublicKey,
  forgetFtDelivery,
  parseFtPacket,
  verifiedFtClaim,
  type MailboxState,
} from "@/lib/privateFtDelivery";
import { adaptPublicFtCall, readFtCounter } from "@/lib/publicFtAdapter";
import { PREVIEW_TRACE_TTL_MS } from "@/lib/preview-trace";
import { nostrRelay } from "@/lib/nostrRelay";
import { computeFee } from "@/lib/fee";
import {
  isProofDeserializeError,
  toFriendlyProofError,
} from "@/lib/proof-errors";
import {
  createMemoryWalletProvider,
  type PrivateFtPacketProver,
} from "@/lib/provider";
import {
  buildSignedFtEvents,
  proveFtOutgoing,
  ftRawPacket,
  type FtWords,
} from "@/lib/privateFtOutgoing";
import {
  probeRecipientRegistration,
  type RecipientExistence,
} from "@/lib/psyId";
import {
  fetchTransactionDetailByHash,
  fetchUserTransactionList,
  inferServicesTxKind,
  normalizeContentHash,
  parseActivityFromSlotUpdates,
  reverseHexBytes,
  type ServicesTransactionDetail,
} from "@/lib/servicesTx";
import {
  derivePrivacyNostrNpub,
  derivePrivacyNostrSecretKey,
  derivePrivacyShieldKeys,
  deriveShieldAddress,
  encodeShieldAddressBase58Check,
  NOSTR_DERIVATION_VERSION,
  normalizeShieldAddress,
} from "@/lib/shield-address";
import {
  backfillReceiveAddressOwnerUserId,
  ensureCurrentIdentityReceiveAddress,
  hasCurrentIdentityAddress,
  isCurrentIdentityAddress,
} from "@/lib/shieldAddresses";
import {
  observeChainIdentity,
  saveChainIdentityRecord,
} from "@/lib/chainIdentity";
import { chainStorageKey } from "@/lib/storageScope";
import {
  type ContractCallResultData,
  type SdkTxResult,
  type TxEndCapData,
  type TxMetadata,
  txHashFromSdkResult,
  endUserLeafHashFromSdkResult,
} from "@/lib/transaction";
import {
  type DepositClaimMaterial,
  listDepositClaimMaterials,
  listTransferBackups,
  findNoteSecret,
  migrateLegacyNoteSecret,
  saveDepositClaimMaterial,
  type TransferBackup,
  transferBackupScope,
  updateTransferBackup,
  updateTransferBackupRequired,
} from "@/lib/transferBackups";
import {
  hashClaimBatchItems,
  inputsForClaimItem,
  mergeInputs,
  publicClaimInput,
  unavailableClaimInputKeys,
} from "@/lib/tx-inputs";
import { isStateRefreshRetryError } from "@/lib/tx-refresh-classifier";
import {
  refreshWidgetWallet,
  runWalletWasmServerMethod,
  setOffscreenWasmConfig,
  storeWalletFromWidgeWallet,
  tryGetUserId,
  validateDeployerUserId,
  type WalletImportMode,
  widgetWalletFromPrivateKey,
} from "@/lib/wallet";
import {
  fetchBridgeDeposits,
  fetchPrivateClaimable,
  fetchPublicClaimable,
  type PrivateClaimableDepositItem,
  type PrivateClaimableResponse,
} from "@/lib/walletSummaryApi";
import { psyStateDispatch } from "@/message";
import type {
  ClaimableSnapshotItem,
  ClaimablesSnapshotEnvelope,
  IPsyWidgetWallet,
  ISdkKeyCircuitParams,
  IShieldReceiveAddress,
  IShieldReceiveAddressPublic,
  IStorageWalletData,
  IWalletInfo,
  TxInput,
} from "@/types";
import PsyPasswordManager from "./psy-password-manager";

function shieldAddressToU64x4(address: unknown): string[] {
  if (typeof address !== "string") return [];
  const normalized = normalizeShieldAddress(address);
  if (!normalized) return [];
  const words = normalized
    .split(":")
    .map((word) => BigInt(`0x${word.replace(/^0x/i, "")}`).toString());
  return words.length === 4 ? words : [];
}

async function publishPrivateTransfer(
  input: {
    receiverNpub: string;
    recipientShieldLimbs: [string, string, string, string];
    amount: string;
    contractId: string;
    txHash: string;
    noteCommitment: string;
    noteProofRaw: string;
    nullifierSecret: [string, string, string, string];
    noteSecret: [string, string, string, string];
  },
  relay: string,
  signedEvents?: NostrEvent[],
): Promise<NostrEvent[]> {
  const events =
    signedEvents?.length === 2
      ? signedEvents
      : buildPrivateTransferSignedEvents(input).events;
  await publishSignedEvents(events, relay, 1);
  return events;
}

/**
 * Live status of a background-run private transfer. The orchestration
 * (chain commit → inclusion proof → Nostr delivery) runs in the service
 * worker via `startPrivateTransfer`; the popup modal only WATCHES this
 * object (dispatched on every step), so closing the popup never interrupts
 * proving or note delivery. Re-sent on refreshPsyState so a reopened popup
 * can still see the latest run.
 */
export interface IPrivateTransferStatus {
  /** Caller-supplied (or generated) id so a popup can match the run it started. */
  runId: string;
  /** Sender wallet address. */
  address: string;
  phase: "running" | "success" | "warning" | "error";
  /** Human step log, same strings lib/privateTransfer's onStep produces. */
  steps: string[];
  /** True when the Step-0 pre-commit backup save failed (recovery impaired). */
  backupSaveFailed: boolean;
  startedAt: number;
  /** Set once the run reaches a terminal phase. */
  result?: {
    success: boolean;
    outcome:
      | "delivered"
      | "committed_incomplete"
      | "submission_unknown"
      | "send_not_committed";
    postCommitFailureStage:
      | "missing_inclusion_identity"
      | "proof_build"
      | "recipient_event"
      | "relay_publish"
      | null;
    txHash: string | null;
    preClaimTxHash: string | null;
    nostrDelivered: boolean;
    error: string | null;
    backupPayload: string | null;
  };
}

/**
 * Live status of a background-run send/claim batch (`startSendBatch`).
 * Same contract as IPrivateTransferStatus: the orchestration (submit →
 * prove → confirm → snapshot refresh) runs in the service
 * worker; the popup modal only WATCHES this object, so closing the popup
 * never interrupts the send or loses its Activity row. Re-sent on
 * refreshPsyState so a reopened popup sees the latest run.
 */
export interface ISendBatchStatus {
  /** Caller-supplied (or generated) id so a popup matches the run it started. */
  runId: string;
  /** Sender wallet address. */
  address: string;
  /** What the user initiated — drives the watching modal's copy. */
  kind: "send" | "claim" | "faucet";
  phase: "running" | "success" | "error";
  /**
   * REAL pipeline milestones, in order, with timestamps — event-driven UI
   * advancement (WaitState activeStepFloor) instead of guessed timers:
   *   "submitted" — Activity rows + balance hold persisted; prove+submit queued.
   *   "confirmed" — the chain accepted the batch; wrapping up bookkeeping.
   */
  steps: { key: "submitted" | "confirmed"; at: number }[];
  /** groupId of this run's Activity rows (set at "submitted"). */
  groupId?: string;
  /** The claims+transfer batch failed and the lone transfer was retried
   *  without the claims (popup parity with the old fallback toast). */
  fallbackUsed?: boolean;
  startedAt: number;
  /** Set once the run reaches a terminal phase. */
  result?: { success: boolean; txHash: string | null; error: string | null };
}

export interface IPsyState {
  wallets: IWalletInfo[];
  totalCount: number;
  mnLength: number;
  /** Start time of the wallet registration still running in the service
   * worker. Null when idle; survives closing and reopening the popup. */
  creatingWalletSince: number | null;
  currentWallet?: IWalletInfo;
  hasTriedRestore: boolean;
  checkpointId: number;
  isEncrypted: boolean;
  needPassword: boolean;
  autoLockTimeoutMs: number;
  initStatus: "initializing" | "network_failed" | "ready";
  initError?: string | null;
  /** WASM circuit init is deferred past the first paint, so the home screen
   *  can be usable (read-only) while the Plonky2 prover warms up. False from
   *  reload until initWasm completes; the popup shows a subtle
   *  "Preparing prover…" pill while false. Only PROVING actions gate on it. */
  proverReady?: boolean;
  /** True when a WASM init ATTEMPT failed (not the network_failed skip).
   *  Flips the warming pill to "Prover unavailable" + Retry. Boolean (not an
   *  optional message) because dispatch JSON-drops undefined, so a cleared
   *  value could never overwrite a stale one. */
  proverFailed?: boolean;
  network: NetworkType;
  networkKey: string;
  /** Bare normalized checkpoint-1 root; networkKey is `${network}:${chainKey}`. */
  chainKey: string;
  chainKeyChanged: boolean;
  walletSnapshot?: WalletSnapshot | null;
  // Pulled from the active network config (PsyNetworkConfig.fees.guta_fee
  // + native_currency_*) so UI can show the current chain fee.
  // Stays null until reloadCore runs.
  fee?: {
    amount: bigint;
    daFee: bigint;
    symbol: string;
    decimals: number;
  };
  /** The native token's contract id from the active network config
   *  (PsyNetworkConfig.native_currency). NOT hardcoded — chains may use a
   *  different id than "0". All native-token checks (fee, holds, display)
   *  must compare against this, not the literal "0". */
  nativeContractId?: string;
  /** Latest background private-transfer run (see IPrivateTransferStatus). */
  privateTransferStatus?: IPrivateTransferStatus;
  /** Latest background send/claim batch run (see ISendBatchStatus). */
  sendBatchStatus?: ISendBatchStatus;
  /** Active balance holds for in-flight/just-confirmed spends. DISPLAY-layer
   *  only: the popup subtracts these from snapshot-derived balances; the
   *  snapshot itself is never mutated (see background/pending-holds). */
  pendingHolds?: IPendingHold[];
}

function feeFromNetworkConfig(
  config: PsyNetworkConfig,
): IPsyState["fee"] | undefined {
  if (config?.fees?.guta_fee == null) return undefined;
  const fees = config.fees as PsyNetworkConfig["fees"] & { da_fee?: number };

  const displaySymbol = String(
    config.native_currency_name ?? config.native_currency ?? "PSY",
  ).replace(/^Test\s+/i, "");

  return {
    amount: BigInt(config.fees.guta_fee),
    // Per-modified-slot fee; total = guta_fee + da_fee * slots (see lib/fee).
    daFee: BigInt(fees.da_fee ?? 0),
    symbol: displaySymbol,
    decimals: Number(config.native_currency_decimal ?? 9),
  };
}

const FAUCET_VERIFICATION_TTL_MS = 10 * 60 * 1000;
const FAUCET_ALREADY_SUBMITTED_WAIT_MS = 30_000;
const FAUCET_WINDOW_ALREADY_USED_MESSAGE =
  "This account has already received test PSY in the current faucet window.";
const SUBMITTED_CONFIRM_TIMEOUT_MS = 5 * 60_000;
let pendingFaucetVerifications: PendingFaucetVerification[] = [];

function isFaucetWindowAlreadyUsedError(error: unknown): boolean {
  // A LOCAL cooldown rejection re-uses the same user-facing message but must
  // never be mistaken for a server verdict (it would re-write the marker it
  // was itself derived from — a self-perpetuating lockout).
  if (
    error instanceof Error &&
    (error as { psyLocalFaucetCooldown?: boolean }).psyLocalFaucetCooldown
  ) {
    return false;
  }
  const message = error instanceof Error ? error.message : String(error ?? "");
  // "faucet already claimed in the current window" is the local prove-proxy's
  // actual rejection wording — previously unmatched, so a genuine server
  // rejection showed the generic failure toast instead of the cooldown.
  return /already received test psy|faucet window has already been used|already used|faucet already claimed/i.test(
    message,
  );
}

interface FaucetClaimResult {
  tx_hash: string;
  operator_user_id: number;
  amount: string;
  checkpoint_id: number;
  window_id: number;
  already_submitted: boolean;
}

interface FaucetCompletionResult extends FaucetClaimResult {
  address: string;
}

interface PendingFaucetVerification {
  state: string;
  address: string;
  userId: string;
  origin: string;
  createdAt: number;
  expiresAt: number;
  claimResult?: FaucetClaimResult;
}

interface CompleteFaucetTurnstileInput {
  state: string;
  recipient_user_id: number | string;
  turnstile_token: string;
}

function containsSimpleClaimCall(
  args: ContractCallArgs | ContractCallArgs[],
): boolean {
  const calls = Array.isArray(args) ? args : [args];
  return calls.some((call) => isPublicTokenCall(call, "claim"));
}

function includedServicesTransaction(
  tx: ServicesTransactionDetail | null | undefined,
): tx is ServicesTransactionDetail {
  return Boolean(
    tx &&
      (tx.included_checkpoint_id != null ||
        (typeof tx.included_at === "string" && tx.included_at.length > 0)),
  );
}

function servicesSettlementTime(
  tx: ServicesTransactionDetail,
): number | undefined {
  const raw = tx.created_at ?? tx.included_at;
  if (!raw) return undefined;
  const time = Date.parse(raw);
  return Number.isFinite(time) ? time : undefined;
}

function base64ToByteArray(base64: string): number[] {
  const binary = atob(base64.trim());
  const bytes: number[] = [];
  for (let i = 0; i < binary.length; i += 1) {
    bytes.push(binary.charCodeAt(i));
  }
  return bytes;
}

function byteArrayToBase64(bytes: number[]): string {
  let binary = "";
  for (const byte of bytes) {
    binary += String.fromCharCode(Number(byte) & 0xff);
  }
  return btoa(binary);
}

function normalizePrivateTransferNoteProof(raw: Record<string, unknown>) {
  const proofB64 =
    typeof raw.note_proof_bincode_b64 === "string" &&
    raw.note_proof_bincode_b64.trim()
      ? raw.note_proof_bincode_b64
      : undefined;
  const proof = raw.note_proof;
  if (proof instanceof Uint8Array) {
    const bytes = Array.from(proof);
    raw.note_proof = bytes;
    raw.note_proof_bincode_b64 = proofB64 ?? byteArrayToBase64(bytes);
    return;
  }
  if (Array.isArray(proof)) {
    const bytes = proof.map((value) => Number(value));
    raw.note_proof = bytes;
    raw.note_proof_bincode_b64 = proofB64 ?? byteArrayToBase64(bytes);
    return;
  }
  if (typeof proof === "string") {
    raw.note_proof = base64ToByteArray(proof);
    raw.note_proof_bincode_b64 = proof;
    return;
  }
  if (proof && typeof proof === "object") {
    const tagged = proof as {
      __psyType?: unknown;
      base64?: unknown;
      values?: unknown;
    };
    if (
      tagged.__psyType === "uint8array" &&
      typeof tagged.base64 === "string"
    ) {
      raw.note_proof = base64ToByteArray(tagged.base64);
      raw.note_proof_bincode_b64 = tagged.base64;
      return;
    }
    if (Array.isArray(tagged.values)) {
      const bytes = tagged.values.map((value) => Number(value));
      raw.note_proof = bytes;
      raw.note_proof_bincode_b64 = proofB64 ?? byteArrayToBase64(bytes);
      return;
    }
    const entries = Object.entries(proof)
      .filter(([key]) => /^\d+$/.test(key))
      .sort(([a], [b]) => Number(a) - Number(b));
    if (entries.length) {
      const bytes = entries.map(([, value]) => Number(value));
      raw.note_proof = bytes;
      raw.note_proof_bincode_b64 = proofB64 ?? byteArrayToBase64(bytes);
      return;
    }
  }
  if (proofB64) {
    raw.note_proof = base64ToByteArray(proofB64);
    raw.note_proof_bincode_b64 = proofB64;
  }
}

function randomFaucetState(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
}

function firstConfigUrl(value: unknown): string {
  return Array.isArray(value)
    ? String(value[0] ?? "").trim()
    : String(value ?? "").trim();
}

// One stalled RPC read (the SDK fetch client has no timeout) must not wedge
// the serial provider read queue forever — after this long the queue moves on
// to the next read while the stuck one keeps running in the background. Kept
// well above normal RPC latency so healthy reads still strictly serialize.
const PROVIDER_READ_QUEUE_RELEASE_MS = 30_000;

// Re-sync claim snapshots at least this often even when the checkpoint is
// unchanged, so public-claim events the indexer commits *after* the checkpoint
// advanced (asynchronous indexing) still get discovered on an idle chain
// instead of waiting for the next checkpoint change or a manual refresh.
const CLAIM_SNAPSHOT_RESYNC_INTERVAL_MS = 15_000;

function faucetLog(message: string, data?: Record<string, unknown>) {
  // Promoted from `console.log` to `console.info` so the faucet narration
  // reads at the same diagnostic level as the rest of the SW boot/refresh
  // logs and stays filterable in devtools by the `[wallet-faucet-bg]`
  // namespace.
  if (data) {
    console.info("[wallet-faucet-bg]", message, data);
  } else {
    console.info("[wallet-faucet-bg]", message);
  }
}

function faucetWarn(message: string, data?: Record<string, unknown>) {
  if (data) {
    console.warn("[wallet-faucet-bg]", message, data);
  } else {
    console.warn("[wallet-faucet-bg]", message);
  }
}

function faucetStateShort(state?: string) {
  return state ? `${state.slice(0, 8)}...${state.slice(-4)}` : "";
}

function faucetRpcUrlLabel(url: string) {
  try {
    return new URL(url).origin;
  } catch {
    return url;
  }
}

function sanitizeFaucetRpcParams(params: unknown[]) {
  return params.map((param) => {
    if (!param || typeof param !== "object") return param;
    const record = param as Record<string, unknown>;
    return {
      ...record,
      turnstile_token:
        typeof record.turnstile_token === "string"
          ? `[redacted:${record.turnstile_token.length}]`
          : record.turnstile_token,
      turnstile_state:
        typeof record.turnstile_state === "string"
          ? faucetStateShort(record.turnstile_state)
          : record.turnstile_state,
    };
  });
}

export const allowMethods = [
  "refreshPsyState",
  "dismissChainKeyChangedNotice",
  "checkRecipientExists",
  "setCurrentWallet",
  "renameWallet",
  "removeWallet",
  "resetWallet",
  "addWalletFromPrivateKey",
  "addWalletFromMnemonic",
  "importWalletsFromBackup",
  "refreshAllWallets",
  "loadWallets",
  "lock",
  "setAutoLockTimeout",
  "saveWallets",
  "addPassword",
  "changePassword",
  "getMnemonic",
  "genPrivateKey",
  "newRandomWalletFailed",
  "getBalance",
  "getUserId",
  "getClaimRewardsCallArgs",
  "getClaimAmount",
  "getSenderTotalSent",
  "getPsyFaucetConfig",
  "beginPsyFaucetVerification",
  "claimPsyFaucetWithTurnstile",
  "claimPsyFaucetWallet",
  "execContractCall",
  "prepareMarketTransaction",
  "listMarketPreparations",
  "cancelMarketPreparation",
  "getMarketWriteCapabilities",
  "verifyMarketPreparation",
  "broadcastMarketPreparation",
  "reconcileMarketPreparation",
  "enqueueTx",
  "awaitTx",
  "cancelTx",
  "retryTx",
  "execContractCallWithoutProof",
  "execClaimBatch",
  "startPrivateTransfer",
  "startSendBatch",
  "previewSendTrace",
  "previewPrivateTransferTrace",
  "discardPreviewTrace",
  "execClaimBatchWithoutProof",
  "executePrivateTransfer",
  "retryPrivateTransferBackup",
  "getPrivateKey",
  "decryptNostrSecretsEvent",
  "createShieldReceiveAddress",
  "markShieldReceiveAddressUsed",
  "updateShieldReceiveAddress",
  "syncPublicClaimCandidates",
  "refreshClaimSnapshots",
  "refreshWalletSnapshot",
  "getClaimableItems",
  "exportAllWallets",
] as const;

export type IPsyStateDispatch = Pick<
  PsyWalletExtCore,
  (typeof allowMethods)[number]
> & {
  reload: (
    config?:
      | PsyNetworkConfig
      | { config: PsyNetworkConfig; network?: NetworkType },
  ) => Promise<void>;
  // Mutation-free re-init (no saveConfig/setActiveNetwork) — the init
  // screen's "Try again" after a network failure.
  retryInit: () => Promise<void>;
  getConfig: () => Promise<PsyNetworkConfig>;
  // Re-broadcasts the background's current pending approve message so a
  // popup that opened after the original dispatch fired still receives it.
  refreshApproveState: () => Promise<void>;
};

const TRANSIENT_PROVE_ERROR_PATTERNS = [
  "failed to parse json response",
  "failed to read response body",
  "error decoding response body",
  "expected value at line 1 column 1",
];

function isTransientProveError(msg: string): boolean {
  const lower = msg.toLowerCase();
  return TRANSIENT_PROVE_ERROR_PATTERNS.some((p) => lower.includes(p));
}

export default class PsyWalletExtCore {
  private _provider: PsyUserWalletProvider;
  private _config: PsyNetworkConfig;
  private readonly _providerReadQueue = new AsyncQueue(
    PROVIDER_READ_QUEUE_RELEASE_MS,
  );
  private _wallets: IPsyWidgetWallet[] = [];
  private _marketPreparation?: PreparationService;
  private _marketExecution?: MarketWalletService;
  private _localWalletUserReady = new Map<string, Promise<void>>();

  private walletInfo(wallet: IPsyWidgetWallet): IWalletInfo {
    return {
      address: wallet.address,
      name: wallet.name,
      userId: String(wallet.userId),
      mnInd: wallet.mnInd,
      signType: wallet.signType,
      fingerprint: wallet.fingerprint,
      sdkKeyCircuitParams: wallet.sdkKeyCircuitParams,
      // Hand-out surface: the popup's currentWallet/wallets feed the Receive
      // screen, QR, copy/share and the transfer own-recipient fusable — expose
      // ONLY current-identity addresses so a devnet-reset re-registration can
      // never advertise a pre-reset address that would strand the payment. The
      // background drain/claim paths keep reading the FULL list separately.
      shieldReceiveAddresses:
        this.currentIdentityShieldReceiveAddresses(wallet),
    };
  }

  private publicShieldReceiveAddresses(
    wallet: IPsyWidgetWallet,
  ): IShieldReceiveAddressPublic[] {
    return (wallet.shieldReceiveAddresses ?? []).map(
      ({
        shieldAddress,
        nostrNpub,
        nostrDerivationVersion,
        shieldStartIndex,
        deriveIndex,
        label,
        createdAt,
        used,
      }) => ({
        shieldAddress:
          encodeShieldAddressBase58Check(shieldAddress) ?? shieldAddress,
        nostrNpub,
        nostrDerivationVersion,
        shieldStartIndex,
        deriveIndex,
        label,
        createdAt,
        used,
      }),
    );
  }

  /**
   * Backfill `ownerUserId` on receive-address records that predate the field.
   * A record whose stored `shieldAddress` is reproducible by `userId`
   * (isCurrentIdentityAddress) is tagged with that user id; otherwise it stays
   * untagged and archived. Existing tags are never rewritten, and derivation —
   * not the tag — remains the source of truth.
   */
  private backfillOwnerUserId(
    userId: IPsyWidgetWallet["userId"],
    addresses: IShieldReceiveAddress[],
  ): IShieldReceiveAddress[] {
    return backfillReceiveAddressOwnerUserId(userId, addresses);
  }

  /**
   * The wallet's CURRENT-identity receive addresses — the only ones safe to
   * HAND OUT (Receive screen, QR, copy/share, dApp list APIs, approve
   * 'Latest'). "Current" is decided by derivation against the live userId
   * (isCurrentIdentityAddress), so addresses bound to an earlier userId drop
   * out automatically and can no longer strand a sender's payment. The
   * DRAIN/claim paths intentionally keep reading the FULL list
   * (publicShieldReceiveAddresses) so older identities keep resolving notes.
   */
  private currentIdentityShieldReceiveAddresses(
    wallet: IPsyWidgetWallet,
  ): IShieldReceiveAddressPublic[] {
    const userId = String(wallet.userId);
    const current = (wallet.shieldReceiveAddresses ?? []).filter((entry) =>
      isCurrentIdentityAddress(userId, entry.r0, entry.r1, entry.shieldAddress),
    );
    return this.publicShieldReceiveAddresses({
      ...wallet,
      shieldReceiveAddresses: current,
    });
  }

  private findShieldReceiveAddress(
    wallet: IPsyWidgetWallet,
    shieldAddress: string,
  ): IShieldReceiveAddress | undefined {
    const target = normalizeShieldAddress(shieldAddress);
    if (!target) return undefined;
    return wallet.shieldReceiveAddresses?.find(
      (item) => normalizeShieldAddress(item.shieldAddress) === target,
    );
  }

  private set wallets(wallets: IPsyWidgetWallet[]) {
    if (this._disposed) return;
    this._wallets = wallets;
    psyStateDispatch({
      wallets: wallets.map((w) => this.walletInfo(w)),
      mnLength: this._passwordManager.getMnemonicsLength(),
      totalCount: this._passwordManager.totalCount,
    });
  }
  _currentWallet: undefined | IPsyWidgetWallet;
  private set currentWallet(wallet: undefined | IPsyWidgetWallet) {
    this.applyCurrentWalletState(wallet);
  }
  private applyCurrentWalletState(
    wallet: undefined | IPsyWidgetWallet,
    { notifyDapps = true }: { notifyDapps?: boolean } = {},
  ) {
    if (this._disposed) return;
    if (wallet !== this._currentWallet) {
      // A data refresh (refreshAllWallets) replaces the wallet object with a
      // fresh one carrying the SAME address, which trips this identity guard.
      // The state dispatch below is wanted (repaints with refreshed data), but
      // the dApp accountsChanged broadcast must fire only on a REAL account
      // switch - otherwise every Refresh-all press spammed accountsChanged to
      // every connected dApp for an account that did not change.
      const addressChanged = wallet?.address !== this._currentWallet?.address;
      this._currentWallet = wallet;
      txQueue.setScope(this._chainKey, wallet?.userId?.toString());
      psyStateDispatch({
        currentWallet: wallet ? this.walletInfo(wallet) : undefined,
      });

      if (notifyDapps && addressChanged) {
        accountsApproved.currentWalletChanged(wallet?.address);
      }
    }
  }
  private _hasTriedRestore: boolean = false;
  private set hasTriedRestore(value: boolean) {
    if (this._disposed) return;
    if (this.hasTriedRestore !== value) {
      this._hasTriedRestore = value;
      psyStateDispatch({
        hasTriedRestore: value,
      });
    }
  }
  get hasTriedRestore() {
    return this._hasTriedRestore;
  }

  private _checkpointId: number = 0;
  private set checkpointId(value: number) {
    if (this._disposed) return;
    if (value !== this._checkpointId) {
      this._checkpointId = value;
      psyStateDispatch({
        checkpointId: value,
      });
    }
  }
  get checkpointId() {
    return this._checkpointId;
  }

  private readonly _nativeContractId: string;
  private _passwordManager: PsyPasswordManager;
  private readonly _fee?: IPsyState["fee"];
  private readonly _network: NetworkType;
  private _networkKey: string;
  private _chainKey: string;
  private readonly _waitForProver: (action: string) => Promise<void>;
  private readonly _initialLoadPromise: Promise<void>;
  private readonly _checkpointIntervalId: ReturnType<typeof setInterval>;
  private _claimSnapshotSync:
    | {
        checkpointId: number;
        address?: string;
        forceRescan: boolean;
        promise: Promise<string[]>;
      }
    | undefined;
  private _faucetCompletionPromises = new Map<
    string,
    Promise<FaucetCompletionResult>
  >();
  private _addWalletInFlight = false;
  // Per-address guard so a self-heal (reconcileWalletIdentity) can't run twice
  // concurrently for the same wallet (e.g. cold-start + a fast wallet switch).
  private _privateFtQueueIds = new Set<string>();
  private _identityHealInFlight = new Set<string>();
  private _walletCreationStartedAt = 0;
  private _disposed = false;
  // Private preview secrets live only for this unlocked core lifetime. The
  // persistent trace store receives only the public envelope and digest.
  private _privatePreviewNotes = new Map<
    string,
    {
      address: string;
      createdAt: number;
      noteSecretHash: [bigint, bigint, bigint, bigint];
      nullifierSecret: [bigint, bigint, bigint, bigint];
      secondaryNoteSecretHash?: FtWords;
      secondaryNullifierSecret?: FtWords;
    }
  >();
  // Fully prepared claim inputs (including receive-identity randoms) are
  // one-shot Review→Confirm material. They must never enter tx_queue storage:
  // only public hashes are durable, while this secret-bearing graph stays in
  // the unlocked background core and is discarded on lock/dispose/TTL.
  private _preparedPreviewClaims = new Map<
    string,
    {
      address: string;
      createdAt: number;
      sourceItemsHash: string;
      queuedItemsHash: string;
      queuedClaims: ClaimBatchItem[];
      claims: ClaimBatchItem[];
      feeCoverInputs: TxInput[];
      feeCoverItemCount: number;
    }
  >();
  /** Exact Review envelopes may contain hydrated receive randoms. Keep the
   * envelope and in-progress proof state in unlocked memory only; storage gets
   * the public identity digest used for CAS/invalidation. */
  private _previewTraceRecords = new Map<string, TraceRecord>();
  private _previewTraceTimers = new Map<
    string,
    { address: string; timer: ReturnType<typeof setTimeout> }
  >();
  private _previewGeneration = 0;

  private previewGenerationIsCurrent(
    generation: number,
    address: string,
    wallet: IPsyWidgetWallet,
  ): boolean {
    return (
      !this._disposed &&
      !this.isWalletLocked() &&
      generation === this._previewGeneration &&
      wallet.address === address &&
      this._currentWallet?.address === address &&
      this._currentWallet.wallet === wallet.wallet &&
      this._wallets.some(
        (current) =>
          current.address === address && current.wallet === wallet.wallet,
      )
    );
  }

  private invalidatePreviewTraces(): void {
    this._previewGeneration++;
    this.discardAllPreviewTraces();
  }

  private cancelPreviewTraceTimer(txHash: string): void {
    const scheduled = this._previewTraceTimers.get(txHash);
    if (scheduled) clearTimeout(scheduled.timer);
    this._previewTraceTimers.delete(txHash);
  }

  private schedulePreviewTraceExpiry(address: string, txHash: string): void {
    this.cancelPreviewTraceTimer(txHash);
    const timer = setTimeout(() => {
      void this.discardPreviewTrace(address, txHash);
    }, PREVIEW_TRACE_TTL_MS);
    this._previewTraceTimers.set(txHash, { address, timer });
  }

  private discardAllPreviewTraces(): void {
    const previews = [...this._previewTraceTimers.entries()];
    this._previewTraceTimers.clear();
    this._privatePreviewNotes.clear();
    this._preparedPreviewClaims.clear();
    this._previewTraceRecords.clear();
    for (const [txHash, { address, timer }] of previews) {
      clearTimeout(timer);
      void traceStore.removeGeneratedPreview(this._chainKey, address, txHash);
    }
  }
  private _chainKeyChanged = false;
  private _pendingChainKey?: string;
  private _chainKeyChangePromise?: Promise<void>;
  private _chainEpoch = 0;
  // Wall-clock of the last claim-snapshot sync, to drive periodic re-syncs that
  // catch indexer-delayed public claims while the checkpoint is idle.
  private _lastClaimSnapshotSyncMs = 0;
  // Coalesces concurrent identical unified-snapshot builds (same wallet,
  // checkpoint, forceRescan) so overlapping triggers don't duplicate RPC work.
  private _walletSnapshotBuilds = new Map<string, Promise<void>>();
  // Last snapshot dispatched (or loaded from cache). One field, three jobs:
  // - Re-sent on refreshPsyState so a reopened popup paints from it instead
  //   of going blank before the next build lands.
  // - Monotonic-checkpoint sequencing: builds for DIFFERENT checkpoints can
  //   overlap (the coalescing map only dedupes identical ones), and an older
  //   build resolving after a newer one must not overwrite the just-dispatched
  //   newer snapshot with stale balances — the same stale-overwrite race the
  //   popup-side refresh loop used to have.
  // - Carry-forward source for failed slot reads during a build (see
  //   _buildCurrentWalletSnapshotNow).
  private _lastWalletSnapshot?: WalletSnapshot;
  // FIFO queue for chain SUBMISSION (generate trace + prove + submit). Two
  // in-flight sends built against the same nonce/chain snapshot race each
  // other; the loser dies with "stale nonce"/"chain state advanced while
  // building this tx". Queueing matches what the user expects when they fire B
  // while A is proving: B waits and executes in order. Activity rows are
  // created BEFORE enqueueing, so a queued tx is visible immediately.
  private _txSubmitQueue: Promise<unknown> = Promise.resolve();
  // Latest background private-transfer run — the popup modal renders from
  // this (dispatched on every step) instead of running the orchestration
  // itself, so popup death never interrupts proving/Nostr delivery.
  private _privateTransferStatus?: IPrivateTransferStatus;
  // Latest background send/claim batch run — same watch-only contract as
  // _privateTransferStatus (see startSendBatch).
  private _sendBatchStatus?: ISendBatchStatus;
  // Resume-path bookkeeping (see resumePendingPrivateTransfers): one scan
  // at a time, and each backup gets ONE auto-attempt per SW lifetime so a
  // failed proof isn't re-hammered on every popup open (a later sweep, in a
  // fresh worker lifetime, retries it — recovery is transaction-pinned, so
  // a "set twice" prover failure is no longer treated as permanent).
  private _resumePrivateTransfersRunning = false;
  private _resumeAttemptedBackupKeys = new Set<string>();

  private _enqueueTxSubmit<T>(task: () => Promise<T>): Promise<T> {
    // Run after the current tail regardless of whether it succeeded — one
    // failed submit must not poison the queue for the next.
    const run = this._txSubmitQueue.then(task, task);
    this._txSubmitQueue = run.catch(() => {});
    return run;
  }

  constructor(
    config: PsyNetworkConfig,
    network: NetworkType,
    networkKey: string,
    skipWasm: boolean = false,
    waitForProver: (action: string) => Promise<void> = async () => {},
    previousChainKey?: string,
  ) {
    this._network = network;
    const resolvedChainKey = chainStorageKey(networkKey) || networkKey;
    this._chainKey =
      previousChainKey && previousChainKey !== resolvedChainKey
        ? previousChainKey
        : resolvedChainKey;
    this._pendingChainKey =
      previousChainKey && previousChainKey !== resolvedChainKey
        ? resolvedChainKey
        : undefined;
    this._networkKey = `${network}:${this._chainKey}`;
    this._nativeContractId = String(config.native_currency ?? "0");
    this._waitForProver = waitForProver;
    this._config = config;
    this._passwordManager = new PsyPasswordManager(() => {
      this.lock();
    }, this._chainKey);
    this._fee = feeFromNetworkConfig(config);
    pendingHolds.setChainKey(this._chainKey);
    pendingHolds.setNativeContractId(this._nativeContractId);
    txQueue.setNativeContractId(this._nativeContractId);
    transactionManager.setNativeContractId(this._nativeContractId);
    tokensManager.setNativeContractId(this._nativeContractId);
    // Pending holds compute the per-group fee from these raw network fee
    // parameters. Keeping the slot math in pending-holds lets multi-item claim
    // batches reserve more than a single-call fee.
    if (this._fee) {
      pendingHolds.setFeeConfig(this._fee.amount, this._fee.daFee);
    }
    // Rebuild the unified snapshot when a tx group FAILS. A snapshot built
    // while the group was in flight excluded its claim inputs via build-time
    // suppression; failure releases the holds, but the popup-side suppression
    // lift cannot restore an item the snapshot never carried — without this
    // refresh the chip/total/Claim list stay short by the item amount until
    // the next periodic checkpoint-tick rebuild. (Success paths already
    // refresh where they settle, e.g. startSendBatch.)
    transactionManager.setOnGroupResolved((success) => {
      if (success || this._disposed) return;
      void this.refreshWalletSnapshot(false).catch(() => undefined);
    });
    setOffscreenWasmConfig(config);
    this._provider = createMemoryWalletProvider(config, skipWasm);
    txQueue.setExecutor(
      async (entry) => {
        if (this._disposed) throw new Error("Wallet core disposed");
        await this.marketPreparation().assertNoPending(
          entry.address,
          this._chainKey,
        );
        let result: unknown;
        if (entry.kind === "contract_call") {
          result = await this.executeQueuedContractCall(
            entry.address,
            entry.payload,
            entry.queueId,
            undefined,
            entry.previewTxHash,
          );
        } else if (entry.kind === "claim_batch") {
          result = await this.executeQueuedClaimBatch(
            entry.address,
            entry.payload,
            entry.queueId,
            undefined,
            entry.previewTxHash,
            entry.exactFoldExecution === true,
          );
        } else {
          const payload = entry.payload;
          console.warn("[tx-trace] private-transfer:queue-entry", {
            address: entry.address,
            queueId: entry.queueId,
            hasPreClaimItems: Array.isArray(payload.preClaimItems)
              ? payload.preClaimItems.length > 0
              : Boolean(payload.preClaimItems),
          });
          // Narrate the queue-path run through privateTransferStatus using the
          // POPUP's runId (threaded via the payload). Before this, the queue
          // path dispatched no status at all, so the processing modal's
          // dispatched-status fallback could never fire: an awaitTx channel
          // loss (MV3 SW recycle) latched "Failed" for a transfer the durable
          // queue then committed - inviting a double payment.
          const ptStatus: IPrivateTransferStatus = {
            runId:
              payload.runId ||
              `ptr_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
            address: entry.address,
            phase: "running",
            steps: [],
            backupSaveFailed: false,
            startedAt: Date.now(),
          };
          this._privateTransferStatus = ptStatus;
          const dispatchPtStatus = () => {
            psyStateDispatch({ privateTransferStatus: ptStatus }).catch(
              () => {},
            );
          };
          dispatchPtStatus();
          try {
            result = await this.runPrivateTransferQueueEntry(
              entry.address,
              payload.request,
              payload.preClaimItems,
              entry.queueId,
              {
                onStep: (step) => {
                  ptStatus.steps = [...ptStatus.steps, step];
                  dispatchPtStatus();
                },
                onBackupSaveFailed: () => {
                  ptStatus.backupSaveFailed = true;
                  dispatchPtStatus();
                },
              },
              entry.previewTxHash,
            );
          } catch (e: any) {
            if (entry.privateTransferSubmissionIntent && entry.hash) {
              result = {
                success: false,
                outcome: "submission_unknown",
                postCommitFailureStage: null,
                txHash: entry.hash,
                nostrDelivered: false,
                error:
                  "Submission is awaiting verification. Do not pay again; recover the original transfer from Saved backups.",
              };
            } else {
              ptStatus.phase = "error";
              ptStatus.result = {
                success: false,
                outcome: "send_not_committed",
                postCommitFailureStage: null,
                txHash: null,
                preClaimTxHash: null,
                nostrDelivered: false,
                error: e?.message || String(e),
                backupPayload: null,
              };
              dispatchPtStatus();
              throw e;
            }
          }
          const ptRes = result as {
            success: boolean;
            outcome:
              | "delivered"
              | "committed_incomplete"
              | "submission_unknown"
              | "send_not_committed";
            postCommitFailureStage:
              | "missing_inclusion_identity"
              | "proof_build"
              | "recipient_event"
              | "relay_publish"
              | null;
            txHash: string | null;
            preClaimTxHash?: string | null;
            nostrDelivered: boolean;
            error: string | null;
            backupPayload?: string | null;
          };
          ptStatus.phase = ptRes.success
            ? "success"
            : ptRes.txHash
              ? "warning"
              : "error";
          ptStatus.result = {
            success: ptRes.success,
            outcome: ptRes.outcome,
            postCommitFailureStage: ptRes.postCommitFailureStage,
            txHash: ptRes.txHash,
            preClaimTxHash: ptRes.preClaimTxHash ?? null,
            nostrDelivered: ptRes.nostrDelivered,
            error: ptRes.error,
            backupPayload: ptRes.backupPayload ?? null,
          };
          dispatchPtStatus();
          if (
            result &&
            typeof result === "object" &&
            "success" in result &&
            !(result as { success?: boolean }).success &&
            !(result as { txHash?: string | null }).txHash &&
            !(result as { preClaimTxHash?: string | null }).preClaimTxHash
          ) {
            throw new Error(
              (result as { error?: string | null }).error ||
                "Private transfer failed before submitting on-chain",
            );
          }
        }
        await this.settleAfterQueuedTx(entry.address);
        return result;
      },
      this._networkKey,
      async (entry) => this.prepareQueuedTx(entry.address),
      async (entry) => {
        return this.recoverQueuedTx(entry);
      },
      (entry) => {
        // Bridge a RECOVERY-terminalized private transfer back to the popup:
        // after an SW recycle the modal (channel lost) waits on a
        // runId-matched privateTransferStatus dispatch, and recovery is the
        // only finisher that never produced one - the modal span forever.
        if (entry.kind !== "private_transfer") return;
        const payload = entry.payload;
        if (!payload?.runId) return;
        const confirmed = entry.status === "confirmed";
        const res = (entry.result ?? {}) as {
          success?: boolean;
          outcome?:
            | "delivered"
            | "committed_incomplete"
            | "submission_unknown"
            | "send_not_committed";
          postCommitFailureStage?:
            | "missing_inclusion_identity"
            | "proof_build"
            | "recipient_event"
            | "relay_publish"
            | null;
          txHash?: string | null;
          preClaimTxHash?: string | null;
          nostrDelivered?: boolean;
          error?: string | null;
          backupPayload?: string | null;
        };
        const status: IPrivateTransferStatus = {
          runId: payload.runId,
          address: entry.address,
          phase: confirmed
            ? entry.kind === "private_transfer" && !res.outcome
              ? "warning"
              : res.success === false
                ? "warning"
                : "success"
            : "error",
          steps: [],
          backupSaveFailed: false,
          startedAt: entry.startedAt ?? Date.now(),
          result: confirmed
            ? entry.kind === "private_transfer" && !res.outcome
              ? {
                  outcome: "committed_incomplete",
                  postCommitFailureStage: "proof_build",
                  success: false,
                  txHash: res.txHash ?? entry.hash ?? null,
                  preClaimTxHash: res.preClaimTxHash ?? null,
                  nostrDelivered: false,
                  error:
                    "The transaction committed while the wallet was interrupted before proof delivery finished. Retry it from Saved backups.",
                  backupPayload: res.backupPayload ?? null,
                }
              : {
                  outcome: res.outcome ?? "delivered",
                  postCommitFailureStage: res.postCommitFailureStage ?? null,
                  success: res.success !== false,
                  txHash: res.txHash ?? entry.hash ?? null,
                  preClaimTxHash: res.preClaimTxHash ?? null,
                  nostrDelivered: !!res.nostrDelivered,
                  error: res.error ?? null,
                  backupPayload: res.backupPayload ?? null,
                }
            : {
                outcome: "send_not_committed",
                postCommitFailureStage: null,
                success: false,
                txHash: null,
                preClaimTxHash: null,
                nostrDelivered: false,
                error: entry.error || "Interrupted while proving",
                backupPayload: null,
              },
        };
        this._privateTransferStatus = status;
        psyStateDispatch({ privateTransferStatus: status }).catch(() => {});
      },
    );
    tokensManager.setNetwork(network, this._networkKey).catch((error) => {
      console.warn("[psy-wallet][tokens] failed to load network tokens", error);
    });
    const baseState = {
      network,
      networkKey: this._networkKey,
      chainKey: this._chainKey,
      chainKeyChanged: this._chainKeyChanged,
      nativeContractId: this._nativeContractId,
    };
    if (this._fee) {
      psyStateDispatch({ ...baseState, fee: this._fee }).catch(() => {});
    } else {
      psyStateDispatch(baseState).catch(() => {});
    }

    this.updateCheckpointId().catch(() => {});
    const checkpointRefreshIntervalMs = 6_000;
    this._checkpointIntervalId = setInterval(() => {
      // Preserve the disposed-guard from shield-poseidon-bridge so a fired
      // interval on a disposed core doesn't hit the wrong network's RPC.
      if (this._disposed) return;
      this.updateCheckpointId().catch(() => {});
    }, checkpointRefreshIntervalMs);

    this._initialLoadPromise = this.initializeWallets(previousChainKey).catch(
      console.warn.bind(null, "@ core load wallets err"),
    );
    this._initialLoadPromise
      .then(() => txQueue.recoverInterruptedProving())
      .then(() => txQueue.drive())
      .catch(() => {});
  }

  private async initializeWallets(previousChainKey?: string): Promise<void> {
    const nextChainKey = this._pendingChainKey;
    await this._passwordManager.ready;
    if (this._disposed) return;

    const isEncrypted = await this._passwordManager.isEncrypted();
    if (isEncrypted) {
      const restored = await this._passwordManager.restoreSession();
      if (this._disposed) return;
      if (!restored) {
        await this.dispatchCurrentState();
        return;
      }
    }

    if (previousChainKey && nextChainKey) {
      await this.handleChainKeyChange(nextChainKey);
      return;
    }
    await this.loadWallets();
  }

  async reconcileLiveChainKey(_source: "popup-open"): Promise<void> {
    if (this._disposed) return;
    const observation = await observeChainIdentity(
      this._config,
      this._chainKey,
    );
    if (!observation || observation.root === this._chainKey) return;
    await this.handleChainKeyChange(observation.root);
  }

  private async handleChainKeyChange(newChainKey: string): Promise<void> {
    if (this._disposed || newChainKey === this._chainKey) return;
    if (this._passwordManager.needPassword) {
      this._pendingChainKey = newChainKey;
      return;
    }
    if (this._chainKeyChangePromise) {
      await this._chainKeyChangePromise;
      if (!this._disposed && newChainKey !== this._chainKey) {
        return this.handleChainKeyChange(newChainKey);
      }
      return;
    }

    const change = async () => {
      const oldChainKey = this._chainKey;
      const oldManager = this._passwordManager;
      const oldCurrentAddress = this._currentWallet?.address;
      const nextNetworkKey = `${this._network}:${newChainKey}`;
      const epoch = this._chainEpoch;
      await oldManager.migrateVault(oldChainKey, newChainKey);
      if (this._disposed) return;

      const newManager = new PsyPasswordManager(() => this.lock(), newChainKey);
      await newManager.ready;
      const encrypted = await newManager.isEncrypted();
      if (encrypted && !(await newManager.restoreSession())) {
        newManager.dispose();
        this._pendingChainKey = newChainKey;
        return;
      }

      const walletData = await newManager.loadWalletsFromStorage();
      const rebuilt: IPsyWidgetWallet[] = [];
      for (const stored of walletData.wallets) {
        if (this._disposed) {
          newManager.dispose();
          return;
        }
        const wallet = await widgetWalletFromPrivateKey(
          this._provider,
          stored.privateKey,
          stored.signType,
          stored.fingerprint,
          stored.mnInd,
          stored.name || nextAccountName(rebuilt.map((item) => item.name)),
          stored.sdkKeyCircuitParams,
          () => this._disposed,
          "restore",
          undefined,
          undefined,
          undefined,
          nextNetworkKey,
        );
        wallet.shieldReceiveAddresses = [];
        try {
          wallet.shieldReceiveAddresses =
            await ensureCurrentIdentityReceiveAddress(
              wallet.userId,
              wallet.shieldReceiveAddresses,
              () =>
                this.deriveShieldReceiveAddressForWallet(
                  wallet,
                  "Private receive 1",
                ),
            );
        } catch (error) {
          console.warn(
            "[psy-wallet][core] could not derive a current-identity receive address after chain cutover; falling back to lazy creation",
            { address: wallet.address, userId: wallet.userId, error },
          );
        }
        rebuilt.push(wallet);
        if (this._disposed || this._chainEpoch !== epoch) {
          newManager.dispose();
          return;
        }
      }

      const currentWallet =
        rebuilt.find(
          (wallet) =>
            wallet.address ===
            (walletData.activeWalletAddress ?? oldCurrentAddress),
        ) ?? rebuilt[0];
      newManager.totalCount = Math.max(newManager.totalCount, rebuilt.length);
      await newManager.saveWalletData({
        networkKey: nextNetworkKey,
        activeWalletAddress: currentWallet?.address,
        wallets: await Promise.all(
          rebuilt.map((wallet) =>
            storeWalletFromWidgeWallet(wallet, nextNetworkKey),
          ),
        ),
      });
      if (this._disposed || this._chainEpoch !== epoch) {
        newManager.dispose();
        return;
      }

      await txQueue.whenIdle();
      if (this._disposed || this._chainEpoch !== epoch) {
        newManager.dispose();
        return;
      }

      this.invalidatePreviewTraces();
      this._chainEpoch += 1;
      this._chainKey = newChainKey;
      this._networkKey = nextNetworkKey;
      this._passwordManager = newManager;
      this._wallets = rebuilt;
      this._currentWallet = currentWallet;
      this._pendingChainKey = undefined;
      this._chainKeyChanged = true;
      this.hasTriedRestore = true;
      this._lastWalletSnapshot = undefined;
      this._claimMaterial = undefined;
      this._claimSnapshotSync = undefined;
      this._checkpointId = 0;
      this._lastClaimSnapshotSyncMs = 0;
      this._identityHealInFlight.clear();
      this._resumeAttemptedBackupKeys.clear();
      this._walletSnapshotBuilds.clear();
      pendingHolds.setChainKey(newChainKey);
      txQueue.setNetworkKey(nextNetworkKey);
      txQueue.setScope(newChainKey, currentWallet?.userId?.toString());
      oldManager.dispose();

      await saveChainIdentityRecord(this._network, {
        root: newChainKey,
        updatedAt: Date.now(),
      });
      await psyStateDispatch({
        chainKey: newChainKey,
        networkKey: nextNetworkKey,
        chainKeyChanged: true,
        wallets: rebuilt.map((wallet) => this.walletInfo(wallet)),
        currentWallet: currentWallet
          ? this.walletInfo(currentWallet)
          : undefined,
        walletSnapshot: null,
        totalCount: newManager.totalCount,
        mnLength: newManager.getMnemonicsLength(),
        isEncrypted: encrypted,
        needPassword: newManager.needPassword,
      });
      accountsApproved.currentWalletChanged(currentWallet?.address);
    };

    this._chainKeyChangePromise = change().finally(() => {
      this._chainKeyChangePromise = undefined;
    });
    await this._chainKeyChangePromise;
  }

  async dismissChainKeyChangedNotice(): Promise<void> {
    this._chainKeyChanged = false;
    await psyStateDispatch({ chainKeyChanged: false });
  }

  async whenReady() {
    await this._initialLoadPromise;
  }

  isWalletLocked(): boolean {
    return this._passwordManager.needPassword;
  }

  /** Dispatch route-critical state (initStatus/needPassword/wallets) without
   *  waiting for the full wallet restore. Used by main.ts's two-phase
   *  refreshPsyState handler so the popup can leave the splash screen
   *  immediately while loadWallets() continues in the background. */
  async dispatchRouteCriticalState(): Promise<void> {
    // Phase 1: dispatch route-critical fields and the real encryption bit.
    // `isEncrypted` is async, but sending it here prevents the popup from
    // briefly seeing the default false value and opening Add/Change Password
    // before Phase 2's full refreshPsyState finishes.
    // Skip wallet dispatch if wallets haven't been loaded yet
    // (_hasTriedRestore=false means loadWallets is still running).
    if (!this._hasTriedRestore) {
      await psyStateDispatch({
        needPassword: this._passwordManager.needPassword,
        creatingWalletSince: this._addWalletInFlight
          ? this._walletCreationStartedAt
          : null,
      });
      return;
    }
    await psyStateDispatch({
      needPassword: this._passwordManager.needPassword,
      isEncrypted: await this._passwordManager.isEncrypted(),
      wallets: this._wallets.map((w) => this.walletInfo(w)),
      currentWallet: this._currentWallet
        ? this.walletInfo(this._currentWallet)
        : undefined,
      hasTriedRestore: this._hasTriedRestore,
      creatingWalletSince: this._addWalletInFlight
        ? this._walletCreationStartedAt
        : null,
    });
  }

  private async refreshQueuedWallet(
    address: string,
  ): Promise<IPsyWidgetWallet | undefined> {
    const index = this._wallets.findIndex((w) => w.address === address);
    if (index < 0) return undefined;
    const refreshed = await refreshWidgetWallet(this._wallets[index]);
    this._wallets[index] = refreshed;
    if (this._currentWallet?.address === address) {
      this._currentWallet = refreshed;
    }
    return refreshed;
  }

  private async prepareQueuedTx(address: string) {
    const wallet = await this.refreshQueuedWallet(address);
    await this.updateCheckpointId();
    await this.refreshPsyState();
    return wallet
      ? {
          nonce: String(wallet.nonce ?? "0"),
          checkpointId: String(this.checkpointId),
        }
      : undefined;
  }

  private queueSettledResult(
    entry: TxQueueEntry,
    settledNonce: string,
  ): Partial<TxMetadata> & Record<string, unknown> {
    // claim_batch FIRST: entry.payload is ClaimBatchItem[] (which IS an
    // array), so the Array.isArray check below would miscast it as
    // ContractCallArgs[]. Reuse txQueue.claimBatchRows for the correct
    // mapping (public→data, private_transfer→claim_with_external_proof,
    // claim_shield_deposit→claim_deposit) instead of duplicating it.
    const args =
      entry.kind === "claim_batch"
        ? txQueue.claimBatchRows(entry.payload)
        : entry.kind === "private_transfer"
          ? [
              {
                contract_id: BigInt(entry.payload.request.contract_id),
                method_name: "private_transfer",
                inputs: [0n, 0n, 0n, 0n, BigInt(entry.payload.request.amount)],
              } as ContractCallArgs,
            ]
          : Array.isArray(entry.payload)
            ? entry.payload
            : [entry.payload];
    const contractCallData: ContractCallResultData = {
      contract_calls: args.map((a) => ({
        contract_id: a.contract_id,
        method_name: a.method_name,
        inputs: a.inputs,
        outputs: [],
      })),
      software_defined_call: { inputs: [] },
    };
    return {
      tx_hash: entry.hash ?? "",
      end_cap_data: {
        checkpoint_id: undefined,
        user_id: undefined,
        global_user_tree_height: 32,
        start_user_leaf_hash: "",
        end_user_leaf_hash: "",
        checkpoint_tree_root_hash: "",
        stats: {},
      } as TxEndCapData,
      contract_call_data: contractCallData,
      success: true,
      settled: true,
      queueId: entry.queueId,
      startedNonce: entry.startedNonce ?? null,
      settledNonce,
      message:
        "The wallet observed this account's nonce advance while settling an interrupted transaction. Treating it as submitted to avoid a duplicate retry.",
    };
  }

  private toUint8Array(value: unknown): Uint8Array {
    if (value instanceof Uint8Array) return value;
    if (Array.isArray(value)) {
      return Uint8Array.from(
        value.map((item) =>
          typeof item === "number" ? item : Number(item ?? 0),
        ),
      );
    }
    if (value && typeof value === "object") {
      return Uint8Array.from(
        Object.values(value as Record<string, unknown>).map((item) =>
          typeof item === "number" ? item : Number(item ?? 0),
        ),
      );
    }
    return new Uint8Array();
  }

  private toNumberArray(value: Uint8Array): number[] {
    return Array.from(value);
  }

  private async ensureWalletUserInWasm(
    wallet: IPsyWidgetWallet,
  ): Promise<void> {
    if (wallet.signType === SignType.SDKeySign && wallet.sdkKeyCircuitParams) {
      await runWalletWasmServerMethod(
        "register_sd_key_circuit",
        "register_sd_key_circuit",
        [
          BigUint64Array.from(
            wallet.sdkKeyCircuitParams.allowedContractIds,
            (value) => BigInt(value),
          ),
          BigUint64Array.from(
            wallet.sdkKeyCircuitParams.allowedMethodIds,
            (value) => BigInt(value),
          ),
          BigInt(wallet.sdkKeyCircuitParams.expectedTxCount),
        ],
      );
    }
    const privateKey = await wallet.wallet.signer.getPrivateKeyHex?.();
    if (!privateKey) {
      throw new Error(`wallet ${wallet.address} cannot export private key`);
    }
    await runWalletWasmServerMethod("trace step add_user", "add_user", [
      privateKey,
      wallet.signType,
      wallet.fingerprint,
    ]);
  }

  private async persistPrivateFtTraceIntent(
    wallet: IPsyWidgetWallet,
    record: TraceRecord,
  ): Promise<void> {
    const scope = this.privateTransferBackupScope(wallet);
    const backups = (await listTransferBackups(scope)).filter(
      (b) => b.ftPin && b.queueId === record.queueId,
    );
    if (!backups.length && !this._privateFtQueueIds.has(record.queueId)) return;
    if (backups.length !== 1 || !record.envelope)
      throw new Error("FT recovery backup is unavailable before submission");
    const backup = backups[0];
    const endUserLeafHash = endUserLeafHashFromSdkResult(
      this.traceResultToSdkTxResult(record.txHash, record.envelope),
    );
    if (!record.txHash || !/^[0-9a-f]{64}$/i.test(endUserLeafHash))
      throw new Error(
        "FT trace lacks the original inclusion identity; no transfer submitted",
      );
    if (
      backup.submissionIntent &&
      (backup.txHash !== record.txHash ||
        backup.endUserLeafHash !== endUserLeafHash)
    )
      throw new Error(
        "FT recovery identity cannot be replaced; reconcile the original transfer",
      );
    // Persist BEFORE the first WASM step, which may submit the endcap. A worker
    // crash after submission can then recover the same note without another send.
    await updateTransferBackupRequired(scope, backup.id, {
      txHash: record.txHash,
      endUserLeafHash,
      submissionIntent: true,
    });
    const saved = (await listTransferBackups(scope)).find(
      (b) => b.id === backup.id,
    );
    if (
      !saved?.submissionIntent ||
      saved.txHash !== record.txHash ||
      saved.endUserLeafHash !== endUserLeafHash
    )
      throw new Error(
        "FT submission identity persistence could not be verified",
      );
    await txQueue.recordPrivateTransferSubmissionIntent(
      record.queueId,
      record.txHash,
    );
  }

  private async hasPrivateFtSubmissionIntent(
    wallet: IPsyWidgetWallet,
    queueId?: string,
  ): Promise<boolean> {
    if (!queueId) return false;
    return (
      await listTransferBackups(this.privateTransferBackupScope(wallet))
    ).some(
      (b) =>
        b.ftPin &&
        b.queueId === queueId &&
        b.submissionIntent &&
        b.txHash &&
        b.endUserLeafHash,
    );
  }

  private async proveTraceRecordBySteps(
    wallet: IPsyWidgetWallet,
    record: TraceRecord,
    persist: boolean,
  ): Promise<SdkTxResult> {
    if (!record.envelope) {
      throw new Error(
        "trace envelope is unavailable; regenerate the transaction",
      );
    }
    await this.persistPrivateFtTraceIntent(wallet, record);
    await this.ensureWalletUserInWasm(wallet);
    let stateBlob = record.stateBlob
      ? this.toUint8Array(record.stateBlob)
      : undefined;
    let proofs = record.proofs?.map((blob) => this.toUint8Array(blob));
    const envelope = record.envelope;
    const envelopeJson = PsyJSON.stringify(envelope);

    if (stateBlob && !proofs) {
      throw new Error("persisted proving state is missing proof blobs");
    }

    const maxStepIterations = (() => {
      try {
        const payload = envelope.trace?.payload;
        if (typeof payload !== "string") return 2048;
        const parsed = JSON.parse(payload) as { steps?: unknown };
        if (!Array.isArray(parsed.steps)) return 2048;
        return Math.max(256, parsed.steps.length * 8 + 64);
      } catch {
        return 2048;
      }
    })();
    let stepIterations = 0;

    while (stepIterations < maxStepIterations) {
      stepIterations += 1;
      const stepResult = (await runWalletWasmServerMethod(
        "prove_trace_step_json",
        "prove_trace_step_json",
        [wallet.address, envelopeJson, stateBlob, proofs],
      )) as TraceStepProgressJson;

      if (stepResult.done === true) {
        if (persist) {
          try {
            await traceStore.remove(record.chainKey, record.txHash);
          } catch (error) {
            console.warn(
              "[trace-step] failed to clear persisted trace after submit",
              {
                txHash: record.txHash,
                error,
              },
            );
          }
        }
        delete record.stateBlob;
        delete record.proofs;
        return this.traceResultToSdkTxResult(stepResult.tx_hash, envelope);
      }

      if ("error" in stepResult) {
        throw new Error(stepResult.error);
      }

      stateBlob = this.toUint8Array(stepResult.state);
      const newProofs = stepResult.proofs.map((blob) =>
        this.toUint8Array(blob),
      );
      proofs = [...(proofs ?? []), ...newProofs];
      record.stateBlob = this.toNumberArray(stateBlob);
      record.proofs = proofs.map((blob) => this.toNumberArray(blob));

      if (persist) {
        await traceStore.update(record.chainKey, record.txHash, {
          status: "proving",
          envelope,
          stateBlob: record.stateBlob,
          proofs: record.proofs,
          error: undefined,
        });
      }
    }
    throw new Error(
      `trace proving exceeded ${maxStepIterations} step iterations`,
    );
  }

  // Decoupled trace flow used by the tx-queue executor: generate a savable
  // trace envelope, persist it (keyed by tx_hash), then prove it step-by-step
  // via the WASM step API while flushing opaque proving state + proofs after
  // every completed unit so an interrupted prove can continue from the last
  // persisted checkpoint.
  private async runTraceTwoStep(
    address: string,
    kind: TxQueueJobKind,
    queueId: string | undefined,
    generate: () => Promise<GeneratedTxTraceJson>,
    _onTraceStep?: (step: string) => void,
  ): Promise<SdkTxResult> {
    await this.marketPreparation().assertNoPending(address, this._chainKey);
    const persist = !!queueId;
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error(`wallet ${address} not found for trace proving`);
    }
    console.warn("[tx-trace] generate:start", {
      kind,
      address,
      queueId,
      persist,
      checkpointId: this.checkpointId,
    });
    const envelope = await generate();
    const txHash = envelope.tx_hash;
    const startUserLeafHash = (() => {
      try {
        const payload = envelope.trace?.payload;
        if (typeof payload !== "string") return undefined;
        const parsed = JSON.parse(payload) as {
          start_user_leaf_hash?: unknown;
        };
        return parsed.start_user_leaf_hash;
      } catch {
        return undefined;
      }
    })();
    console.warn("[tx-trace] generate:done", {
      kind,
      address,
      queueId,
      txHash,
      sigHash: envelope.sig_hash,
      checkpointId: this.checkpointId,
      startUserLeafHash,
      envelopeKeys: Object.keys(envelope),
      traceKeys:
        envelope.trace && typeof envelope.trace === "object"
          ? Object.keys(envelope.trace)
          : undefined,
      tracePayloadLength:
        typeof envelope.trace?.payload === "string"
          ? envelope.trace.payload.length
          : undefined,
      tracePayloadHasMetadata:
        typeof envelope.trace?.payload === "string"
          ? this.tracePayloadMetadataHints(envelope.trace.payload)
          : undefined,
    });
    _onTraceStep?.("[tx-trace] generate trace done");
    const now = Date.now();
    const record: TraceRecord = {
      txHash,
      sigHash: envelope.sig_hash,
      queueId: queueId ?? `ephemeral:${txHash}`,
      address,
      chainKey: this._chainKey,
      networkKey: this._networkKey,
      kind,
      envelope,
      status: "generated",
      createdAt: now,
      updatedAt: now,
    };
    if (persist) {
      await traceStore.save(record.chainKey, record);
      await traceStore.update(record.chainKey, txHash, { status: "proving" });
    }
    try {
      console.warn("[tx-trace] prove:start", {
        kind,
        address,
        queueId,
        txHash,
        mode: "step",
      });
      const stepResult = await this.proveTraceRecordBySteps(
        wallet,
        record,
        persist,
      );
      console.warn("[tx-trace] prove:done", {
        kind,
        address,
        queueId,
        txHash,
        mode: "step",
      });
      return stepResult;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.warn("[runTraceTwoStep] prove failed", {
        txHash,
        checkpointId: this.checkpointId,
        startUserLeafHash,
        error: message,
      });
      if (persist) {
        await traceStore.update(record.chainKey, txHash, {
          status: "failed",
          envelope: record.envelope,
          stateBlob: record.stateBlob,
          proofs: record.proofs,
          error: message,
        });
      }
      throw error;
    }
  }

  // proveTxTraceStep returns the final tx hash, while the full envelope already
  // carries the finalization stats computed at generate time.

  private traceResultToSdkTxResult(
    hash: string,
    envelope: GeneratedTxTraceJson,
  ): SdkTxResult {
    const rawTracePayload = this.parseTracePayloadForResult(
      envelope.trace?.payload,
    );
    const finalization = this.traceFinalizationSubmitInput(rawTracePayload);
    const result: Partial<TxMetadata> & { tx_hash: string } = {
      tx_hash: hash || envelope.tx_hash,
    };
    const endCapData = this.traceEndCapData(finalization);
    if (endCapData) {
      result.end_cap_data = endCapData;
    } else {
      const slots = this.extractSlotsModified(rawTracePayload);
      if (slots != null) {
        result.end_cap_data = {
          checkpoint_id: undefined,
          user_id: undefined,
          global_user_tree_height: 32,
          start_user_leaf_hash: "",
          end_user_leaf_hash: "",
          checkpoint_tree_root_hash: "",
          stats: { slots_modified: slots },
        };
      }
    }
    result.contract_call_data = this.traceContractCallData(
      envelope.call_data,
      rawTracePayload,
    );
    console.warn("[tx-trace] metadata:constructed", {
      txHash: result.tx_hash,
      slotsModified:
        result.end_cap_data &&
        typeof result.end_cap_data === "object" &&
        "stats" in (result.end_cap_data as Record<string, unknown>)
          ? (
              (result.end_cap_data as Record<string, any>).stats as {
                slots_modified?: unknown;
              }
            )?.slots_modified
          : undefined,
      finalizationSlotsModified:
        finalization?.core?.stats &&
        typeof finalization.core.stats === "object" &&
        "slots_modified" in finalization.core.stats
          ? (finalization.core.stats as { slots_modified?: unknown })
              .slots_modified
          : undefined,
      callDataKind: Array.isArray(envelope.call_data)
        ? "array"
        : typeof envelope.call_data,
      callDataItems: Array.isArray(envelope.call_data)
        ? envelope.call_data.length
        : undefined,
      envelopeKeys: Object.keys(envelope),
      tracePayloadLength:
        typeof envelope.trace?.payload === "string"
          ? envelope.trace.payload.length
          : undefined,
      tracePayloadHasMetadata:
        typeof envelope.trace?.payload === "string"
          ? this.tracePayloadMetadataHints(envelope.trace.payload)
          : undefined,
      tracePayloadPreview:
        typeof envelope.trace?.payload === "string"
          ? envelope.trace.payload.slice(0, 500)
          : undefined,
    });
    return result as SdkTxResult;
  }

  private parseTracePayloadForResult(payload?: string): unknown {
    if (typeof payload !== "string" || !payload.trim()) return undefined;
    try {
      return PsyJSON.parse(payload);
    } catch {
      return payload;
    }
  }

  private traceFinalizationSubmitInput(
    rawTracePayload: unknown,
  ): Record<string, any> | undefined {
    if (!rawTracePayload || typeof rawTracePayload !== "object") {
      return undefined;
    }
    const payload = rawTracePayload as Record<string, any>;
    const input = payload.finalization?.submit_end_cap_input;
    return input && typeof input === "object" ? input : undefined;
  }

  private traceEndCapData(
    submitEndCapInput?: Record<string, any>,
  ): TxEndCapData | undefined {
    const core = submitEndCapInput?.core;
    if (!core || typeof core !== "object") return undefined;
    const stateTransition = (core as Record<string, any>).state_transition;
    if (!stateTransition || typeof stateTransition !== "object")
      return undefined;
    return {
      checkpoint_id: (core as Record<string, any>).checkpoint_id,
      user_id: (stateTransition as Record<string, any>).user_id,
      global_user_tree_height: 32,
      start_user_leaf_hash: String(
        (stateTransition as Record<string, any>).start_user_leaf_hash,
      ),
      end_user_leaf_hash: String(
        (stateTransition as Record<string, any>).end_user_leaf_hash,
      ),
      checkpoint_tree_root_hash: String(
        (stateTransition as Record<string, any>).checkpoint_tree_root_hash,
      ),
      stats: (core as Record<string, any>).stats ?? {},
    };
  }

  private traceContractCallData(
    callData: unknown,
    rawTracePayload: unknown,
  ): ContractCallResultData {
    const steps =
      rawTracePayload && typeof rawTracePayload === "object"
        ? (rawTracePayload as { steps?: unknown }).steps
        : undefined;
    const cfcSteps = Array.isArray(steps)
      ? steps.filter(
          (step) =>
            step &&
            typeof step === "object" &&
            ["standard", "inlined", "deferred"].includes(
              String((step as Record<string, unknown>).kind).toLowerCase(),
            ),
        )
      : [];
    // WASM generateBatchClaimTxTrace returns call_data as a
    // ContractCallData object { contract_calls: [...], software_defined_call: {...} },
    // not a bare array. Unwrap .contract_calls when present; otherwise
    // treat callData as a single ContractCallArgs or array (contract_call kind).
    const callDataObj =
      callData && typeof callData === "object"
        ? (callData as Record<string, any>)
        : null;
    const callDataItems = Array.isArray(callData)
      ? callData
      : callDataObj && Array.isArray(callDataObj.contract_calls)
        ? callDataObj.contract_calls
        : callData
          ? [callData]
          : [];
    // Authoritative source: the trace's CFC steps (standard/inlined/deferred).
    // Each step carries contract_id, method_name, and cfc_witness with
    // the actual inputs/outputs the circuit executed. Map them directly
    // rather than index-zipping with callDataItems — the Rust trace arena
    // inserts deferred children immediately after their parent, so
    // callDataItems (top-level calls only) and cfcSteps (all steps) have
    // different lengths and indices when deferred calls are present.
    // Fall back to callDataItems only when trace steps are absent.
    const contractCalls = cfcSteps.length
      ? cfcSteps.map((step) => {
          const s = step as Record<string, any>;
          const witness = s.cfc_witness ?? {};
          return {
            contract_id: s.contract_id,
            method_name: s.method_name,
            inputs: Array.isArray(witness.inputs) ? witness.inputs : [],
            outputs: Array.isArray(witness.outputs) ? witness.outputs : [],
          };
        })
      : callDataItems.map((item) => {
          const source =
            item && typeof item === "object"
              ? (item as Record<string, any>)
              : ({} as Record<string, any>);
          return {
            contract_id: source.contract_id,
            method_name: source.method_name,
            inputs: Array.isArray(source.inputs) ? source.inputs : [],
            outputs: [],
          };
        });
    // Fallback chain: trace finalization → wrapper.software_defined_call → empty.
    const rawSdc =
      rawTracePayload && typeof rawTracePayload === "object"
        ? (rawTracePayload as any).finalization?.software_defined_call
        : undefined;
    return {
      contract_calls: contractCalls,
      software_defined_call: rawSdc ??
        callDataObj?.software_defined_call ?? {
          inputs: [],
        },
    };
  }

  private tracePayloadMetadataHints(payload: string) {
    return {
      endCapData: payload.includes('"end_cap_data"'),
      txMetadata: payload.includes('"tx_metadata"'),
      metadata: payload.includes('"metadata"'),
      contractCallData: payload.includes('"contract_call_data"'),
      storageData: payload.includes('"storage_data"'),
      storageWrites: payload.includes('"storage_writes"'),
      slotsModified: payload.includes('"slots_modified"'),
    };
  }

  private extractSlotsModified(rawTracePayload: unknown): number | undefined {
    const finalization = this.traceFinalizationSubmitInput(rawTracePayload);
    const value = finalization?.core?.stats?.slots_modified;
    if (value == null) return undefined;
    const n = Number(value);
    return Number.isSafeInteger(n) && n >= 0 ? n : undefined;
  }

  private async resumeTraceForQueuedTx(
    entry: TxQueueEntry,
  ): Promise<SdkTxResult | undefined> {
    const wallet = await this.refreshQueuedWallet(entry.address);
    if (!wallet) return undefined;
    const record = await traceStore.findByQueueId(
      entry.chainKey ?? "",
      entry.queueId,
    );
    if (
      !record ||
      (record.status !== "generated" && record.status !== "proving")
    ) {
      return undefined;
    }
    try {
      await traceStore.update(record.chainKey, record.txHash, {
        status: "proving",
      });
      return await this.proveTraceRecordBySteps(wallet, record, true);
    } catch (error) {
      await traceStore.update(record.chainKey, record.txHash, {
        status: "failed",
        envelope: record.envelope,
        stateBlob: record.stateBlob,
        proofs: record.proofs,
        error: error instanceof Error ? error.message : String(error),
      });
      return undefined;
    }
  }

  private async recoverQueuedTx(entry: TxQueueEntry) {
    if (entry.kind === "private_transfer") {
      const wallet = this._wallets.find((w) => w.address === entry.address);
      const intent =
        wallet &&
        (
          await listTransferBackups(this.privateTransferBackupScope(wallet))
        ).find(
          (b) =>
            b.ftPin &&
            b.queueId === entry.queueId &&
            b.submissionIntent &&
            b.txHash &&
            b.endUserLeafHash,
        );
      if (intent && entry.status !== "submitting") {
        entry.status = "submitting";
        entry.privateTransferSubmissionIntent = true;
        entry.hash = intent.txHash;
        entry.result = {
          success: false,
          outcome: "submission_unknown",
          txHash: intent.txHash,
          nostrDelivered: false,
          error:
            "Submission is awaiting verification. Do not pay again; recover the original transfer from Saved backups.",
        };
      }
    }
    const settledWallet = await this.settleAfterQueuedTx(entry.address);
    const settledNonce = String(settledWallet?.nonce ?? "0");
    const startedNonce =
      entry.startedNonce !== undefined ? BigInt(entry.startedNonce) : undefined;
    if (startedNonce !== undefined && BigInt(settledNonce) > startedNonce) {
      return {
        confirmed: true,
        result:
          entry.status === "submitting" && entry.result != null
            ? entry.result
            : this.queueSettledResult(entry, settledNonce),
        settledNonce,
      };
    }
    if (entry.status === "submitting") {
      const submitHash =
        entry.hash ?? txHashFromSdkResult(entry.result as SdkTxResult);
      if (!submitHash && entry.startedNonce === undefined) {
        return {
          confirmed: false,
          settledNonce,
          error:
            "Submitted transaction is still confirming; missing start nonce.",
        };
      }
      const wallet = await this.refreshQueuedWallet(entry.address);
      if (!wallet) {
        return {
          confirmed: false,
          settledNonce,
          error:
            "Submitted transaction is still confirming; wallet unavailable.",
        };
      }
      // Confirm by content hash via the psy-services indexer (source of truth —
      // a relayer-submitted tx may never advance THIS wallet's leaf nonce) and
      // by on-chain nonce advancement as a fallback. Either signal confirms.
      const outcome = await this.confirmSubmittedByServicesOrNonce(
        entry,
        wallet,
        settledNonce,
        SUBMITTED_CONFIRM_TIMEOUT_MS,
      );
      if (!outcome.confirmed) {
        return {
          confirmed: false,
          settledNonce,
          error: "Submitted transaction is still confirming.",
        };
      }
      return {
        confirmed: true,
        result:
          entry.result != null
            ? entry.result
            : this.queueSettledResult(entry, outcome.settledNonce),
        settledNonce: outcome.settledNonce,
        canonicalHash: outcome.canonicalHash,
        settledAt: outcome.settledAt,
      };
    }
    // Nonce didn't advance → not submitted. If a resumable trace was persisted
    // for this entry, resume proving from it before giving up.
    const resumed = await this.resumeTraceForQueuedTx(entry);
    if (resumed) {
      entry.status = "submitting";
      entry.pendingPhase = "confirming";
      entry.result = resumed;
      const resumedTxHash = txHashFromSdkResult(resumed);
      if (resumedTxHash) entry.hash = resumedTxHash;
      if (!resumedTxHash && entry.startedNonce === undefined) {
        return {
          confirmed: false,
          settledNonce,
          error:
            "Submitted transaction is still confirming; missing start nonce.",
        };
      }
      const wallet = await this.refreshQueuedWallet(entry.address);
      if (!wallet) {
        return {
          confirmed: false,
          settledNonce,
          error:
            "Submitted transaction is still confirming; wallet unavailable.",
        };
      }
      const outcome = await this.confirmSubmittedByServicesOrNonce(
        entry,
        wallet,
        settledNonce,
        SUBMITTED_CONFIRM_TIMEOUT_MS,
      );
      if (!outcome.confirmed) {
        return {
          confirmed: false,
          settledNonce,
          error: "Submitted transaction is still confirming.",
        };
      }
      return {
        confirmed: true,
        result: resumed,
        settledNonce: outcome.settledNonce,
        canonicalHash: outcome.canonicalHash,
        settledAt: outcome.settledAt,
      };
    }
    return {
      confirmed: false,
      settledNonce,
      error:
        "Interrupted while proving. The wallet refreshed chain state and did not observe a submitted transaction; retry is allowed.",
    };
  }

  private async settleAfterQueuedTx(
    address: string,
  ): Promise<IPsyWidgetWallet | undefined> {
    let lastError: unknown;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        const wallet = await this.refreshQueuedWallet(address);
        await this.updateCheckpointId();
        await this.refreshPsyState();
        return wallet;
      } catch (error) {
        lastError = error;
        await new Promise((resolve) => setTimeout(resolve, 1_000));
      }
    }
    console.warn("[tx-queue] settle refresh failed", {
      address,
      error: lastError,
    });
  }

  /** The network this core is actually running. Source of truth for "what am
   *  I on right now" — getActiveNetwork() (storage) can drift from this, so
   *  network-specific reads (e.g. getConfig) should key off this instead. */
  get runningNetwork(): NetworkType {
    return this._network;
  }
  get runningNetworkKey(): string {
    return this._networkKey;
  }

  dispose() {
    this._disposed = true;
    this.invalidatePreviewTraces();
    this._faucetCompletionPromises.clear();
    clearInterval(this._checkpointIntervalId);
    this._passwordManager.dispose();
  }

  private async dispatchCurrentState(): Promise<void> {
    if (this._disposed) return;
    psyStateDispatch({
      wallets: this._wallets.map((w) => this.walletInfo(w)),
      totalCount: this._passwordManager.totalCount,
      mnLength: this._passwordManager.getMnemonicsLength(),
      creatingWalletSince: this._addWalletInFlight
        ? this._walletCreationStartedAt
        : null,
      currentWallet: this._currentWallet
        ? this.walletInfo(this._currentWallet)
        : undefined,
      hasTriedRestore: this._hasTriedRestore,
      checkpointId: this._checkpointId,
      isEncrypted: await this._passwordManager.isEncrypted(),
      needPassword: this._passwordManager.needPassword,
      autoLockTimeoutMs: this._passwordManager.autoLockTimeoutMs,
      fee: this._fee,
      network: this._network,
      networkKey: this._networkKey,
      chainKey: this._chainKey,
      chainKeyChanged: this._chainKeyChanged,
      walletSnapshot: this._lastWalletSnapshot,
      privateTransferStatus: this._privateTransferStatus,
      sendBatchStatus: this._sendBatchStatus,
    });
    approveManager.refreshApproveState();
    accountsApproved.refreshAccountsApprovedState();
    transactionManager.refreshTxState();
    tokensManager.refreshTokenState();
    pendingHolds.refreshState();
    void this.resumePendingPrivateTransfers();
  }

  async refreshPsyState(): Promise<void> {
    if (this._disposed) return;
    await this.dispatchCurrentState();
  }

  /** Re-dispatch the last computed wallet snapshot WITHOUT any recompute or
   *  scan. Used by the popup-open boot paint so a reopened popup paints the
   *  home numbers from cache the instant its message reaches the SW, even while
   *  the authoritative refreshPsyState is still resolving. No-op if nothing has
   *  been computed yet (the cold-boot storage read covers that case). */
  repaintLastWalletSnapshot(): void {
    if (this._disposed) return;
    if (this._lastWalletSnapshot) {
      psyStateDispatch({ walletSnapshot: this._lastWalletSnapshot });
    }
  }

  getApproveWalletSnapshot() {
    return {
      currentWallet: this._currentWallet
        ? this.walletInfo(this._currentWallet)
        : undefined,
      wallets: this._wallets.map((wallet) => this.walletInfo(wallet)),
    };
  }

  async updateCheckpointId() {
    if (this._disposed) return;
    const previousCheckpointId = this._checkpointId;
    const checkpointId = await this._providerReadQueue.run(() =>
      fetchBlockNumber(this._provider),
    );
    if (this._disposed) return;
    const nextCheckpointId = Math.max(previousCheckpointId, checkpointId);
    this.checkpointId = nextCheckpointId;
    const checkpointChanged = nextCheckpointId !== previousCheckpointId;
    const now = Date.now();
    const dueForPeriodicResync =
      now - this._lastClaimSnapshotSyncMs >= CLAIM_SNAPSHOT_RESYNC_INTERVAL_MS;
    if (checkpointChanged || dueForPeriodicResync) {
      this._lastClaimSnapshotSyncMs = now;
      this.buildCurrentWalletSnapshot(!checkpointChanged).catch((error) => {
        console.warn(
          "[psy-wallet][home-refresh] wallet snapshot build failed",
          error,
        );
      });
    }
  }

  async setCurrentWallet(address: string, refresh?: boolean) {
    const wallet = this._wallets.find((wallet) => wallet.address === address);
    if (wallet && wallet.address !== this._currentWallet?.address) {
      this._provider.realmEdgeRpcProvider.setUserId(wallet.userId);
      if (refresh) {
        this.currentWallet = await refreshWidgetWallet(wallet);
      } else {
        this.currentWallet = wallet;
      }
      await this.saveWallets();
      // Paint the new wallet instantly from its cached snapshot, then recompute.
      void this.dispatchCachedWalletSnapshot(address);
      void (async () => {
        await this.buildCurrentWalletSnapshot(true).catch(() => undefined);
      })();
      void this.reconcileWalletIdentity(address).catch(() => undefined);
    }
  }

  /** Push the persisted snapshot for `address` (if any) so the popup paints
   *  immediately on wallet switch / cold start, before the fresh build lands. */
  private async dispatchCachedWalletSnapshot(address: string): Promise<void> {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet?.userId) return;
    const cached = await loadWalletSnapshotCache(
      this._chainKey,
      wallet.userId,
    ).catch(() => undefined);
    if (this._disposed) return;
    if (cached && this._currentWallet?.address === address) {
      this._lastWalletSnapshot = cached;
      psyStateDispatch({ walletSnapshot: cached });
    }
  }

  async renameWallet(address: string, newName: string) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }
    wallet.name = newName;

    // Trigger state update
    this.wallets = [...this._wallets];
    if (this._currentWallet?.address === address) {
      this.currentWallet = { ...wallet };
    }

    await this.saveWallets();
  }

  async removeWallet(address: string) {
    const removedWallet = this._wallets.find((w) => w.address === address);
    // Purge the removed wallet's own orphaned snapshot cache key so a
    // create->delete cycle does not leak a permanent extStorage entry. (Its
    // pending holds are keyed by address too, but dropping those safely
    // requires balance-composition review, so they are left for now.)
    if (removedWallet?.userId != null) {
      void clearWalletSnapshotCache(this._chainKey, removedWallet.userId);
    }
    // Drop the removed wallet's own pending holds too (keyed by its address,
    // so no present wallet is affected) - otherwise a same-address re-import
    // inherited a stale hold that understated its Available.
    pendingHolds.releaseHoldsForAddress(this._chainKey, address);
    this.wallets = this._wallets.filter((w) => w.address !== address);
    if (this._currentWallet?.address === address) {
      this.currentWallet = this._wallets[0];
      // The cached snapshot belonged to the removed wallet — paint + rebuild
      // for the new current wallet (same as a wallet switch).
      this._lastWalletSnapshot = undefined;
      if (this._currentWallet) {
        void this.dispatchCachedWalletSnapshot(this._currentWallet.address);
        this.buildCurrentWalletSnapshot().catch(() => {});
      }
    }
    // Prune any dApp approvals that referenced the now-deleted wallet. Without
    // this the approved-accounts store keeps a stale address; on a later
    // connect the approve path resolves an approved account with no backing
    // wallet and hard-fails with "Approved accounts include unknown wallet"
    // (acutely after delete-all, where every approval is stale).
    await accountsApproved.pruneApproved(this._wallets.map((w) => w.address));
    await this.saveWallets();
  }

  // Forgot-password reset from the locked screen: wipe ALL wallet state so the
  // extension returns to first-run (create / restore-from-seed). Works while
  // LOCKED — the encrypted vault is discarded, not decrypted, so a user who
  // forgot their password is never stranded on the unlock screen. The cleared
  // `wallets` / `currentWallet` / `needPassword` setters each dispatch to the
  // popup, which then routes to the first-run welcome screen.
  async resetWallet() {
    await accountsApproved.pruneApproved([]);
    this.wallets = [];
    this.currentWallet = undefined;
    this._lastWalletSnapshot = undefined;
    await this._passwordManager.resetVault();
  }

  private async getWalletPrivateKey(wallet: IPsyWidgetWallet) {
    const privateKeyHex = await wallet.wallet.signer.getPrivateKeyHex?.();
    if (!privateKeyHex) {
      throw new Error("Failed to load private key");
    }
    return privateKeyHex;
  }

  /**
   * Re-import a wallet's signing key into the CURRENT WASM prover via a direct
   * `add_user`. The per-signer `ensureLocalUser` cache (lib/wallet.ts) caches
   * its first success and never re-checks, so when the offscreen / provider
   * WASM is re-initialised AFTER boot — Chrome evicts an idle offscreen
   * document, a network switch zeroes wasmServer, etc. — the user's key is
   * silently gone yet that cache still reports it loaded. Proving then fails
   * with "public key X not found in wallet". Calling `add_user` here bypasses
   * the stale cache and re-seeds the live WASM. Idempotent: re-adding an
   * already-present user is a no-op on the WASM side.
   */
  private async ensureWalletKeyInWasm(wallet: IPsyWidgetWallet) {
    const privateKeyHex = await this.getWalletPrivateKey(wallet);
    await runWalletWasmServerMethod("re-add_user", "add_user", [
      privateKeyHex,
      wallet.signType,
      wallet.fingerprint,
    ]);
  }

  private nextShieldStartIndex(wallet: IPsyWidgetWallet) {
    const addresses = wallet.shieldReceiveAddresses ?? [];
    if (!addresses.length) return 0;
    const sequentialIndices = addresses.flatMap((address, index) => {
      const storedIndex = Number(address.shieldStartIndex);
      if (Number.isFinite(storedIndex)) {
        return storedIndex >= 0 ? [storedIndex] : [];
      }
      // Legacy sequential records may predate shieldStartIndex entirely.
      return [index * 2];
    });
    return Math.max(-2, ...sequentialIndices) + 2;
  }

  /**
   * Derive the next shield receive address for `wallet` without ANY side
   * effects on `_wallets`, state dispatch, or storage. Pure: returns the
   * receive-address record so the caller can decide when to persist /
   * publish state changes. Used both by the public `createShieldReceiveAddress`
   * (which then persists) and by `addWalletFromPrivateKey` (which mutates
   * the wallet before it joins `_wallets`, so we don't want createShieldReceiveAddress's
   * `_wallets.find(...)` lookup or its premature dispatch).
   */
  private async deriveShieldReceiveAddressForWallet(
    wallet: IPsyWidgetWallet,
    label?: string,
  ): Promise<IShieldReceiveAddress> {
    const privateKeyHex = await this.getWalletPrivateKey(wallet);
    const shieldStartIndex = this.nextShieldStartIndex(wallet);
    const { r0, r1 } = await derivePrivacyShieldKeys(
      privateKeyHex,
      shieldStartIndex,
    );
    const shieldAddress = deriveShieldAddress(wallet.userId, r0, r1);
    const nostrNpub = await derivePrivacyNostrNpub(privateKeyHex, r0, r1);
    return {
      shieldAddress,
      r0,
      r1,
      nostrNpub,
      nostrDerivationVersion: NOSTR_DERIVATION_VERSION,
      shieldStartIndex,
      label:
        label?.trim() ||
        `Private receive ${(wallet.shieldReceiveAddresses?.length ?? 0) + 1}`,
      createdAt: new Date().toISOString(),
      used: false,
      // Record the user identity this address is bound to. If re-registration
      // changes the userId, addresses derived under the old one become
      // cryptographically unclaimable; this tag lets Receive/QR/share surfaces
      // show only current-identity addresses. The derivation check remains
      // authoritative.
      ownerUserId: String(wallet.userId),
    };
  }

  async createShieldReceiveAddress(address: string, label?: string) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }

    const receiveAddress = await this.deriveShieldReceiveAddressForWallet(
      wallet,
      label,
    );

    wallet.shieldReceiveAddresses = [
      ...(wallet.shieldReceiveAddresses ?? []),
      receiveAddress,
    ];
    this.wallets = [...this._wallets];
    if (this._currentWallet?.address === address) {
      psyStateDispatch({ currentWallet: this.walletInfo(wallet) });
    }
    await this.saveWallets();
    // Return the freshly-created (current-identity) record from the hand-out
    // view so callers never round-trip an archived address.
    return this.currentIdentityShieldReceiveAddresses(wallet).find(
      (item) =>
        normalizeShieldAddress(item.shieldAddress) ===
        receiveAddress.shieldAddress,
    );
  }

  /**
   * Derive shield receive addresses forward until `shieldAddress` exists in the
   * wallet. Restored/imported wallets may not have derived the target index yet;
   * batch shield deposit claim used to fail the whole batch when one address was missing.
   */
  async ensureShieldReceiveAddress(
    address: string,
    shieldAddress: string,
    targetStartIndex?: number,
  ): Promise<void> {
    const target = normalizeShieldAddress(shieldAddress);
    if (!target) {
      throw new Error("Invalid shield address");
    }
    const walletAtStart = this._wallets.find((w) => w.address === address);
    if (!walletAtStart) {
      throw new Error("Wallet not found");
    }
    const hasTarget = () => {
      const wallet = this._wallets.find((w) => w.address === address);
      return wallet && this.findShieldReceiveAddress(wallet, target);
    };
    if (hasTarget()) return;

    // Absolute cap so a bogus/hostile shield_start_index (e.g. on a
    // user-initiated single claim or a dApp approve params vector) can never
    // drive an unbounded derivation loop. 1000 is far beyond any realistic
    // legitimate shield-address count while keeping the worst case bounded.
    const MAX_SHIELD_DERIVE = 1000;
    const createLimit =
      typeof targetStartIndex === "number" &&
      Number.isFinite(targetStartIndex) &&
      targetStartIndex >= 0
        ? Math.min(Math.floor(targetStartIndex / 2) + 1, MAX_SHIELD_DERIVE)
        : 20;

    for (let i = 0; !hasTarget() && i < createLimit; i += 1) {
      const wallet = this._wallets.find((w) => w.address === address);
      const count = wallet?.shieldReceiveAddresses?.length ?? 0;
      await this.createShieldReceiveAddress(
        address,
        `Private receive ${count + 1}`,
      );
    }

    if (!hasTarget()) {
      throw new Error(
        "Shield receive address not found — derive more private receive addresses and try again.",
      );
    }
  }

  async listShieldReceiveAddresses(address: string) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }
    // Hand-out surface (also the dApp `psy_listShieldReceiveAddresses`): only
    // current-identity addresses, so a connected dApp's auto-fill can never
    // paste a pre-reset address that would strand the payer's note.
    return this.currentIdentityShieldReceiveAddresses(wallet);
  }

  getShieldReceiveAddressSecrets(address: string, shieldAddress: string) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }
    const receiveAddress = this.findShieldReceiveAddress(wallet, shieldAddress);
    if (!receiveAddress) {
      throw new Error("Shield receive address not found");
    }
    return {
      r0: receiveAddress.r0,
      r1: receiveAddress.r1,
    };
  }

  /**
   * Resolve a shield receive address the account OWNS, forward-deriving it when
   * the wallet hasn't materialized it yet, and return its PUBLIC record —
   * crucially including the per-address `nostrNpub`. Deposits delivered over
   * Nostr are addressed to a per-address npub (nostrNpub = derivePrivacyNostrNpub
   * for that address's r0/r1), so the bridge's deposit-backup worker cannot
   * reuse or derive it — only this wallet can. The list-based
   * `psy_listShieldReceiveAddresses` lookup misses any address that was claimed
   * via on-demand forward-derivation but never persisted into the wallet; this
   * resolve closes that gap by materializing the target and returning its npub.
   *
   * Ownership is NOT weakened: it delegates to `ensureShieldReceiveAddress`,
   * which only ever accepts an index whose deriveShieldAddress(userId, r0, r1)
   * reproduces the requested target. A genuinely foreign address can never be
   * reproduced by this wallet's keys, so it still throws "Shield receive address
   * not found" instead of handing back an npub.
   */
  async resolveShieldReceiveAddress(
    address: string,
    shieldAddress: string,
    targetStartIndex?: number,
    r0?: string,
    r1?: string,
  ): Promise<IShieldReceiveAddressPublic | undefined> {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }
    const target = normalizeShieldAddress(shieldAddress);
    // Exact path: a shield DEPOSIT carries its own r0/r1 on the note (NOT a
    // sequential receive-address index), so forward-deriving the receive
    // sequence never reaches it — it just materializes ever more addresses.
    // When the caller hands over r0/r1 (from the deposit note), derive the
    // npub directly. Ownership is enforced by re-deriving the shield address
    // from THIS wallet's userId and confirming it reproduces the requested
    // target; a foreign address (or stale r0/r1) can't, so we throw rather
    // than hand back an npub.
    if (r0 != null && r1 != null && String(r0) !== "" && String(r1) !== "") {
      const derived = deriveShieldAddress(wallet.userId, r0, r1);
      if (normalizeShieldAddress(derived) !== target) {
        console.warn(
          "[wallet-bg-shield-resolve] r0/r1 do not reproduce the requested shield address",
          {
            requested: target,
            derived: normalizeShieldAddress(derived),
            r0: String(r0),
            r1: String(r1),
          },
        );
        throw new Error("Shield receive address not found");
      }
      const privateKeyHex = await this.getWalletPrivateKey(wallet);
      const nostrNpub = await derivePrivacyNostrNpub(privateKeyHex, r0, r1);
      const existing = this.findShieldReceiveAddress(wallet, derived);
      const receiveAddress: IShieldReceiveAddress = {
        ...existing,
        shieldAddress: derived,
        r0: String(r0),
        r1: String(r1),
        nostrNpub,
        nostrDerivationVersion: NOSTR_DERIVATION_VERSION,
        // Packet-provided randoms are not members of the sequential receive
        // derivation. Persist them for discovery without advancing that
        // sequence; retain the caller's hint separately for display/debugging.
        shieldStartIndex: existing?.shieldStartIndex ?? -1,
        deriveIndex:
          existing?.deriveIndex ??
          (typeof targetStartIndex === "number" ? targetStartIndex : undefined),
        label:
          existing?.label ||
          `Private deposit ${(wallet.shieldReceiveAddresses?.length ?? 0) + 1}`,
        createdAt: existing?.createdAt || new Date().toISOString(),
        used: existing?.used ?? false,
        ownerUserId: String(wallet.userId),
      };
      // Deposit addresses use packet-provided r0/r1 and are not part of the
      // sequential receive derivation. Persist the resolved identity so the
      // next services-backed claimable refresh includes both its shield
      // address and Nostr npub; returning it only to the bridge made the
      // deposit disappear from the wallet's Claim list after this request.
      const needsPersistence =
        !existing ||
        existing.nostrNpub !== nostrNpub ||
        existing.nostrDerivationVersion !== NOSTR_DERIVATION_VERSION ||
        existing.r0 !== String(r0) ||
        existing.r1 !== String(r1) ||
        existing.ownerUserId !== String(wallet.userId);
      if (needsPersistence) {
        wallet.shieldReceiveAddresses = existing
          ? (wallet.shieldReceiveAddresses ?? []).map((item) =>
              item === existing ? receiveAddress : item,
            )
          : [...(wallet.shieldReceiveAddresses ?? []), receiveAddress];
        this.wallets = [...this._wallets];
        if (this._currentWallet?.address === address) {
          psyStateDispatch({ currentWallet: this.walletInfo(wallet) });
        }
        await this.saveWallets();
      }
      return this.publicShieldReceiveAddresses(wallet).find(
        (item) => normalizeShieldAddress(item.shieldAddress) === target,
      );
    }
    // Fallback (no r0/r1): forward-derive by shield address along the
    // receive-address sequence.
    await this.ensureShieldReceiveAddress(
      address,
      shieldAddress,
      targetStartIndex,
    );
    return this.publicShieldReceiveAddresses(wallet).find(
      (item) => normalizeShieldAddress(item.shieldAddress) === target,
    );
  }

  async markShieldReceiveAddressUsed(address: string, shieldAddress: string) {
    return this.updateShieldReceiveAddress(address, shieldAddress, {
      used: true,
    });
  }

  async updateShieldReceiveAddress(
    address: string,
    shieldAddress: string,
    patch: { label?: string; used?: boolean },
  ) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw new Error("Wallet not found");
    }
    const receiveAddress = this.findShieldReceiveAddress(wallet, shieldAddress);
    if (!receiveAddress) {
      throw new Error("Shield receive address not found");
    }
    if (patch.label !== undefined) {
      receiveAddress.label = patch.label.trim() || receiveAddress.label;
    }
    if (patch.used !== undefined) {
      receiveAddress.used = patch.used;
    }
    this.wallets = [...this._wallets];
    if (this._currentWallet?.address === address) {
      psyStateDispatch({ currentWallet: this.walletInfo(wallet) });
    }
    await this.saveWallets();
    // Normalize both sides (like findShieldReceiveAddress above): the stored
    // value is base58check-encoded, so a colon-hex/normalized caller arg
    // updated successfully but this strict compare returned undefined.
    const target = normalizeShieldAddress(shieldAddress);
    return this.publicShieldReceiveAddresses(wallet).find(
      (item) => normalizeShieldAddress(item.shieldAddress) === target,
    );
  }

  async syncPublicClaimCandidates(
    address?: string,
    checkpointIdOverride?: number,
    forceRescan = false,
  ) {
    void address;
    void checkpointIdOverride;
    void forceRescan;
    return [];
  }

  private privateTransferBackupScope(wallet: IPsyWidgetWallet) {
    return transferBackupScope(this._chainKey, wallet.userId, wallet.address);
  }

  private async syncClaimSnapshotsForCheckpoint(
    checkpointId: number,
    address?: string,
    forceRescan = false,
  ) {
    if (checkpointId <= 0) return [];
    while (this._claimSnapshotSync) {
      const inFlight = this._claimSnapshotSync;
      const sameCheckpoint = inFlight.checkpointId === checkpointId;
      const inFlightCoversRequest =
        !address || !inFlight.address || inFlight.address === address;
      // A forceRescan request must not piggyback on an in-flight sync that did
      // NOT force a re-scan — that one may have skipped the cursor gate and
      // missed the late-indexed event. Wait it out and start a fresh forced sync.
      const inFlightCoversRescan = !forceRescan || inFlight.forceRescan;
      const synced = await inFlight.promise;
      if (sameCheckpoint && inFlightCoversRequest && inFlightCoversRescan)
        return synced;
      if (this._claimSnapshotSync === inFlight) {
        this._claimSnapshotSync = undefined;
      }
    }
    const syncPromise = this.syncClaimSnapshotsForCheckpointNow(
      checkpointId,
      address,
      forceRescan,
    );
    const syncEntry = {
      checkpointId,
      address,
      forceRescan,
      promise: syncPromise,
    };
    this._claimSnapshotSync = syncEntry;
    try {
      return await syncPromise;
    } finally {
      if (this._claimSnapshotSync === syncEntry) {
        this._claimSnapshotSync = undefined;
      }
    }
  }

  private async syncClaimSnapshotsForCheckpointNow(
    checkpointId: number,
    address?: string,
    forceRescan = false,
  ) {
    void checkpointId;
    void forceRescan;
    return (
      address
        ? this._wallets.filter((wallet) => wallet.address === address)
        : this._wallets
    )
      .filter((wallet) => wallet.userId != null)
      .map((wallet) => wallet.address);
  }

  async refreshClaimSnapshots(
    address?: string,
    checkpointId?: number,
    forceRescan = false,
  ) {
    const targetCheckpointId =
      checkpointId == null ? this._checkpointId : Number(checkpointId);
    if (!Number.isFinite(targetCheckpointId) || targetCheckpointId <= 0) {
      return [];
    }
    return this.syncClaimSnapshotsForCheckpoint(
      Math.floor(targetCheckpointId),
      address,
      forceRescan,
    );
  }

  /**
   * Popup-facing trigger: recompute the current wallet's unified snapshot now and
   * push it. Used by the home "Refresh" control and after a claim/transfer
   * settles. Claimables are services-backed; no local Nostr drain runs here.
   */
  async refreshWalletSnapshot(force = false): Promise<void> {
    await this.buildCurrentWalletSnapshot(force, { throttleForcedDrain: true });
  }

  /**
   * Compute ONE consistent view of the current wallet — confirmed balances for
   * every token plus the three claimable kinds, all resolved against the same
   * checkpoint — and dispatch it to the popup (persisting a copy for instant
   * cold-start paint). Concurrent identical builds are coalesced.
   */
  private async buildCurrentWalletSnapshot(
    forceRescan = false,
    options?: { throttleForcedDrain?: boolean },
  ): Promise<void> {
    if (this._disposed) return;
    const wallet = this._currentWallet;
    const checkpointId = this._checkpointId;
    if (!wallet || wallet.userId == null || checkpointId <= 0) return;
    const throttleForcedDrain = options?.throttleForcedDrain ?? false;
    const key = `${this._chainKey}:${wallet.userId}:${checkpointId}:${forceRescan}:${throttleForcedDrain}`;
    const existing = this._walletSnapshotBuilds.get(key);
    if (existing) return existing;
    const build = this._buildCurrentWalletSnapshotNow(
      wallet,
      checkpointId,
      forceRescan,
      throttleForcedDrain,
    ).finally(() => {
      if (this._walletSnapshotBuilds.get(key) === build) {
        this._walletSnapshotBuilds.delete(key);
      }
    });
    this._walletSnapshotBuilds.set(key, build);
    return build;
  }

  /** Decrypt and persist deposit claim secrets that arrived with the private
   *  claimable response (`psy_deposit_secrets` Nostr events). Best-effort per
   *  item; the row stays visible and can retry on the next rollup. Moved here
   *  from the removed popup discovery pipeline — the rollup is the single
   *  discovery point now. */
  private async _persistDepositSecretsFromResponse(
    wallet: IPsyWidgetWallet,
    response: PrivateClaimableResponse,
  ): Promise<void> {
    const scope = this.privateTransferBackupScope(wallet);
    const depositItems = response.items.filter(
      (item): item is PrivateClaimableDepositItem =>
        item.kind === "private_deposit" &&
        item.claimed !== true &&
        item.proof_verified === true &&
        typeof item.backup_id === "string" &&
        /^[0-9a-f]{64}$/i.test(item.backup_id.trim().replace(/^0x/i, "")) &&
        typeof item.deposit_proof_raw === "string" &&
        item.deposit_proof_raw.trim().length > 0 &&
        item.secrets_event != null,
    );
    await Promise.all(
      depositItems.map(async (item) => {
        const validated = validatePrivateDepositApiProof(item);
        if (!validated) {
          console.warn("[psy-wallet][claimable][deposit-diag] proof rejected", {
            backupId: String(item.backup_id ?? "").slice(0, 16),
            globalDepositIndex: item.deposit_index,
            chainLocalDepositIndex: item.chain_local_deposit_index,
            sourceChainIndex: item.source_chain_index,
            proofVerified: item.proof_verified,
            hasProof: Boolean(item.deposit_proof_raw?.trim()),
          });
          return;
        }
        const normalizedBackupId = validated.backupId;
        const events = normalizeSecretsEvents(item.secrets_event);
        let lastFailure = "no candidate events";
        for (const event of events) {
          try {
            const plaintext = await this.decryptNostrSecretsEvent(
              wallet.address,
              item.shield_address,
              event,
            );
            if (typeof plaintext !== "string" || !plaintext) {
              lastFailure = "decrypt returned empty plaintext";
              continue;
            }
            const secrets = parseDecryptedDepositSecrets(
              plaintext,
              normalizedBackupId,
            );
            if (!secrets) {
              lastFailure = "decrypted secrets did not bind to backup id";
              continue;
            }
            const material: DepositClaimMaterial = {
              kind: "private_deposit",
              id: normalizedBackupId,
              createdAt: Date.now(),
              shieldAddress: item.shield_address,
              nullifierSecret: secrets.nullifierSecret,
              noteSecret: secrets.noteSecret,
              amount: validated.amount.toString(),
              contractId: String(validated.contractId),
              sourceChainIndex: validated.sourceChainIndex,
              depositIndex: validated.depositIndex,
              chainLocalDepositIndex: validated.chainLocalDepositIndex,
              nullifierHash: item.nullifier_hash,
              backupId: normalizedBackupId,
              noteCommitment: normalizedBackupId,
            };
            await saveDepositClaimMaterial(scope, material);
            console.warn(
              "[psy-wallet][claimable][deposit-diag] secrets persisted",
              {
                backupId: normalizedBackupId.slice(0, 16),
                candidateCount: events.length,
                globalDepositIndex: validated.depositIndex,
                chainLocalDepositIndex: validated.chainLocalDepositIndex,
              },
            );
            return;
          } catch (error) {
            lastFailure =
              error instanceof Error ? error.message : String(error);
            // best-effort; try the next event / next rollup.
          }
        }
        console.warn(
          "[psy-wallet][claimable][deposit-diag] secrets unresolved",
          {
            backupId: normalizedBackupId.slice(0, 16),
            candidateCount: events.length,
            reason: lastFailure,
          },
        );
      }),
    );
  }

  /**
   * Read back the three persisted claimable kinds for `wallet` at
   * `checkpointId` and roll them up per contract (as display strings). Pure
   * read of what `syncClaimSnapshotsForCheckpoint` last persisted — no RPC,
   * no discovery — so it's cheap enough to run both for the fast cached paint
   * AND after a fresh claim sync lands.
   */
  private async readClaimableRollup(
    wallet: IPsyWidgetWallet,
    checkpointId: number,
    apiServicesUrl: string,
    previousPrivateReceiveHistory: PrivateReceiveHistoryItem[] = [],
  ): Promise<{
    claimableByContract: Record<string, string>;
    claimableItems: SnapshotClaimableItem[];
    publicItems: PublicClaimItemPersisted[];
    privateNotes: PrivateNote[];
    shieldDeposits: Array<Extract<ImportedClaimable, { kind: "deposit" }>>;
    privateReceiveHistory: PrivateReceiveHistoryItem[];
    complete: boolean;
    servicesCheckpointId: number;
  }> {
    let complete = true;
    let servicesCheckpointId = checkpointId;
    const mergeServicesCheckpoint = (value: unknown) => {
      const next = Number(value);
      if (!Number.isSafeInteger(next) || next < 0) {
        complete = false;
        return;
      }
      servicesCheckpointId = Math.min(servicesCheckpointId, next);
    };

    let publicItems: PublicClaimItemPersisted[] = [];
    let privateNotes: PrivateNote[] = [];
    let privateReceiveHistory = previousPrivateReceiveHistory;
    let shieldDeposits: Array<Extract<ImportedClaimable, { kind: "deposit" }>> =
      [];
    let privateResponse:
      | Awaited<ReturnType<typeof fetchPrivateClaimable>>
      | undefined;
    let bridgeDepositResponses: Array<
      Awaited<ReturnType<typeof fetchBridgeDeposits>>
    > = [];
    const tokenContractIds = tokensManager._tokens.map(
      (token) => String(token.contractId) as unknown as Felt,
    );

    try {
      const publicResponse = await fetchPublicClaimable({
        apiServicesUrl,
        userId: wallet.userId,
        tokenContractIds,
      });
      mergeServicesCheckpoint(publicResponse.services_checkpoint_id);
      publicItems = publicClaimItemsFromServices(publicResponse);
      const advertisedRows = publicResponse.items.filter(
        (item) => item.claimed !== true,
      ).length;
      if (advertisedRows !== publicItems.length) complete = false;
    } catch (error) {
      complete = false;
      console.warn("[psy-wallet][claimable] public API failed", error);
    }

    try {
      const receiveAddresses = this.publicShieldReceiveAddresses(wallet);
      const nostrPubkeys = receiveAddresses
        .map((item) => item.nostrNpub)
        .filter((item) => item.length > 0);
      const shieldAddresses = receiveAddresses
        .map((item) => item.shieldAddress)
        .filter((item) => item.length > 0);

      if (nostrPubkeys.length > 0 && shieldAddresses.length > 0) {
        try {
          privateResponse = await fetchPrivateClaimable({
            apiServicesUrl,
            nostrPubkeys,
            shieldAddresses,
            tokenContractIds,
          });
          mergeServicesCheckpoint(privateResponse.services_checkpoint_id);
          console.warn("[psy-wallet][claimable][deposit-diag] API response", {
            queriedNostrPubkeys: nostrPubkeys.length,
            queriedShieldAddresses: shieldAddresses.length,
            totalItems: privateResponse.items.length,
            depositItems: privateResponse.items.filter(
              (item) =>
                item.kind === "private_deposit" && item.claimed !== true,
            ).length,
          });
          if (
            privateResponse.total != null &&
            privateResponse.total > privateResponse.items.length
          ) {
            complete = false;
          }
        } catch (error) {
          complete = false;
          console.warn("[psy-wallet][claimable] private API failed", error);
        }
      }

      if (privateResponse) {
        privateReceiveHistory =
          privateReceiveHistoryFromServices(privateResponse);
        try {
          privateNotes = await decryptPrivateTransferNotesFromResponse(
            privateResponse,
            (shieldAddress, event) =>
              this.decryptNostrSecretsEvent(
                wallet.address,
                shieldAddress,
                event,
              ),
            JSON.stringify([
              this._chainKey,
              wallet.address,
              String(wallet.userId),
            ]),
          );
        } catch {
          complete = false;
          privateNotes = [];
        }
      }

      if (shieldAddresses.length > 0) {
        if (privateResponse) {
          try {
            await this._persistDepositSecretsFromResponse(
              wallet,
              privateResponse,
            );
          } catch {
            complete = false;
          }
        }
        const depositResponses = await Promise.all(
          shieldAddresses.map(async (shieldAddress) => {
            try {
              return await fetchBridgeDeposits({
                apiServicesUrl,
                shieldAddress,
                limit: 200,
              });
            } catch {
              complete = false;
              return null;
            }
          }),
        );
        bridgeDepositResponses = depositResponses.filter(
          (item): item is NonNullable<typeof item> => item != null,
        );
        if (
          bridgeDepositResponses.some(
            (response) =>
              response.has_next || response.total > response.items.length,
          )
        ) {
          complete = false;
        }

        const depositMaterials = await listDepositClaimMaterials(
          this.privateTransferBackupScope(wallet),
        );
        const bridgeItems =
          bridgeDepositResponses.length > 0
            ? shieldDepositItemsFromBridgeDeposits(
                bridgeDepositResponses,
                privateResponse,
                depositMaterials,
              )
            : [];
        const privateClaimableDepositItems = privateResponse
          ? privateClaimableItemsFromServices(privateResponse, depositMaterials)
              .shieldDeposits
          : [];
        shieldDeposits = mergeShieldDepositSources(
          bridgeItems,
          privateClaimableDepositItems,
        );
        console.warn("[psy-wallet][claimable][deposit-diag] mapping result", {
          bridgeApiRows: bridgeDepositResponses.reduce(
            (total, response) =>
              total +
              response.items.filter((item) => item.claimed !== true).length,
            0,
          ),
          persistedMaterials: depositMaterials.length,
          bridgeMapped: bridgeItems.length,
          privateMapped: privateClaimableDepositItems.length,
          merged: shieldDeposits.length,
        });
      }
    } catch (error) {
      complete = false;
      console.warn("[psy-wallet][claimable] private API failed", error);
    }

    const TIMED_OUT = Symbol("public-claim-verify-timeout");
    const verifiedPublic = await Promise.all(
      publicItems.map(
        async (item): Promise<PublicClaimItemPersisted | null> => {
          let timer: ReturnType<typeof setTimeout> | undefined;
          try {
            const liveAmount = await Promise.race([
              this.getClaimAmount(
                checkpointId,
                item.contractId,
                wallet.userId,
                item.senderUserId,
              ).then((value) => BigInt(value)),
              new Promise<typeof TIMED_OUT>((resolve) => {
                timer = setTimeout(() => resolve(TIMED_OUT), 10_000);
              }),
            ]);
            if (liveAmount === TIMED_OUT) {
              complete = false;
              return item;
            }
            return liveAmount > 0n ? { ...item, amount: liveAmount } : null;
          } catch {
            complete = false;
            return item;
          } finally {
            if (timer != null) clearTimeout(timer);
          }
        },
      ),
    );
    publicItems = verifiedPublic.filter(
      (item): item is PublicClaimItemPersisted => item != null,
    );

    if (privateResponse) {
      const resolvedNoteIds = new Set(privateNotes.map((note) => note.id));
      for (const item of privateResponse.items) {
        if (item.claimed === true || item.kind !== "private_transfer") continue;
        const validated = validatePrivateTransferApiProof(item);
        if (
          !validated ||
          item.secrets_event == null ||
          !resolvedNoteIds.has(validated.backupId)
        ) {
          complete = false;
        }
      }
    }

    // Versioned FT mailbox is independent of legacy proof/secrets pairing.
    // Decrypted data stays inside the background and enters snapshots only
    // after native proof verification and exact code/layout authentication.
    const verifyFt = (
      this._provider.prover as PrivateFtPacketProver
    ).verifyPrivateFtPacket?.bind(this._provider.prover);
    if (verifyFt) {
      for (const receive of wallet.shieldReceiveAddresses ?? []) {
        const storageKey = `psy_private_ft_mailbox:${this._chainKey}:${wallet.address}:${receive.shieldAddress}`;
        try {
          const oldState = (await extStorage.get(storageKey)) as
            | MailboxState
            | undefined;
          let state = oldState ?? { events: [] };
          try {
            state = await fetchFtMailbox(
              apiServicesUrl,
              receive.nostrNpub,
              state,
            );
            if (!state.historyComplete || state.capacityReached)
              complete = false;
            // Persist ciphertext and cursor together before decrypting. An API
            // outage still permits verification of already persisted candidates.
            await extStorage.set(storageKey, state);
          } catch {
            complete = false;
          }
          const key = await this.getWalletPrivateKey(wallet);
          const secret = await derivePrivacyNostrSecretKey(
            key,
            receive.r0,
            receive.r1,
          );
          try {
            const recipient = ftPublicKey(secret);
            for (const delivery of pendingFtDeliveries(state, recipient)) {
              try {
                let raw: string;
                let packet: ReturnType<typeof parseFtPacket>;
                try {
                  raw = decryptFtDelivery(delivery, secret);
                  packet = parseFtPacket(raw);
                } catch {
                  state = forgetFtDelivery(state, delivery);
                  await extStorage.set(storageKey, state);
                  continue;
                }
                const shield = shieldAddressFromNoteOwner(packet.owner);
                if (
                  !shield ||
                  normalizeShieldAddress(receive.shieldAddress) !== shield
                ) {
                  state = forgetFtDelivery(state, delivery);
                  await extStorage.set(storageKey, state);
                  continue;
                }
                const claim = await verifiedFtClaim(raw, (pin, text) =>
                  this._providerReadQueue.run(() =>
                    verifyFt(pin.profile, text, pin.codeRoot, pin.layoutRoot),
                  ),
                );
                const index = packet.proofs[0] ? 0 : 1;
                const envelope = {
                  ...claim,
                  note_proof_bincode_b64: packet.proofs[index],
                };
                const note: PrivateNote = {
                  id: `ft:${packet.contract_id}:${claim.nullifier.join(":")}`,
                  contractId: packet.contract_id,
                  amount: BigInt(claim.amount),
                  timestamp: 0,
                  shieldAddress: shield,
                  noteProofRaw: PsyJSON.stringify(envelope),
                };
                if (
                  (await isPrivateNoteAlreadyClaimed({
                    note,
                    userId: wallet.userId,
                    checkpointId,
                    networkConfig: this._config,
                  })) === true
                ) {
                  state = forgetFtDelivery(state, delivery);
                  await extStorage.set(storageKey, state);
                  continue;
                }
                state = rememberVerifiedFtDelivery(state, delivery);
                await extStorage.set(storageKey, state);
                privateNotes.push(note);
              } catch (error) {
                if (!isTerminalFtError(error)) complete = false;
                state = isTerminalFtError(error)
                  ? forgetFtDelivery(state, delivery)
                  : deferFtDelivery(state, delivery);
                await extStorage.set(storageKey, state);
                // Temporary RPC failures preserve the complete pending packet.
              }
            }
          } finally {
            secret.fill(0);
          }
        } catch (error) {
          // Missing endpoint on older services must leave existing claimables
          // usable. This adapter never projects unverified transport rows.
          complete = false;
          console.warn(
            "[psy-wallet][claimable] encrypted FT mailbox unavailable",
            error instanceof Error ? error.message : "mailbox error",
          );
        }
      }
    }

    privateNotes = dedupePrivateNotes(privateNotes);
    const verifiedPrivateNotes: PrivateNote[] = [];
    const onChainClaimedInputKeys = new Set<string>();
    for (const note of privateNotes) {
      try {
        const claimed = await isPrivateNoteAlreadyClaimed({
          note,
          userId: wallet.userId,
          checkpointId,
          networkConfig: this._config,
        });
        if (claimed === false) {
          verifiedPrivateNotes.push(note);
        } else if (claimed === true) {
          for (const input of inputsForPrivateNote(note)) {
            onChainClaimedInputKeys.add(input.key);
          }
        } else {
          complete = false;
        }
      } catch {
        complete = false;
      }
    }
    privateNotes = verifiedPrivateNotes;
    privateReceiveHistory = markPrivateReceiveHistoryClaimed(
      privateReceiveHistory,
      onChainClaimedInputKeys,
    );
    await this.stampPrivateNoteQuarantine(wallet, privateNotes);

    const resolvedDepositCommitments = new Set(
      shieldDeposits
        .map((dep) =>
          dep.deposit.noteCommitment?.trim().replace(/^0x/i, "").toLowerCase(),
        )
        .filter((value): value is string => Boolean(value)),
    );
    if (privateResponse) {
      for (const item of privateResponse.items) {
        if (item.claimed === true || item.kind !== "private_deposit") continue;
        const validated = validatePrivateDepositApiProof(item);
        if (
          !validated ||
          item.secrets_event == null ||
          !resolvedDepositCommitments.has(validated.backupId)
        ) {
          complete = false;
        }
      }
    }
    for (const response of bridgeDepositResponses) {
      for (const item of response.items) {
        if (item.claimed === true) continue;
        const commitment = String(item.note_commitment ?? "")
          .trim()
          .replace(/^0x/i, "")
          .toLowerCase();
        if (!commitment || !resolvedDepositCommitments.has(commitment)) {
          complete = false;
        }
      }
    }

    const imtFiltered = await filterUnclaimedShieldDepositsByImt({
      deposits: shieldDeposits,
      userId: wallet.userId,
      checkpointId,
      networkConfig: this._config,
    });
    shieldDeposits = imtFiltered.deposits;
    if (!imtFiltered.complete) complete = false;

    if (checkpointId > 0) {
      publicItems = publicItems.map((item) => ({
        ...item,
        checkpointId: item.checkpointId ?? checkpointId,
      }));
    }

    const unavailable = unavailableClaimInputKeys({
      holds: pendingHolds.current(),
      address: wallet.address,
      chainKey: this._chainKey,
    });
    if (unavailable.size > 0) {
      publicItems = publicItems.filter(
        (item) => !unavailable.has(publicClaimInput(item).key),
      );
      privateNotes = privateNotes.filter(
        (note) =>
          !inputsForPrivateNote(note).some((input) =>
            unavailable.has(input.key),
          ),
      );
      shieldDeposits = shieldDeposits.filter(
        (dep) =>
          !inputsForShieldDeposit(dep).some((input) =>
            unavailable.has(input.key),
          ),
      );
    }

    const claimableItems = snapshotClaimableItemsFromLists({
      publicItems,
      privateNotes,
      shieldDeposits,
    });
    const claimableByContract =
      claimableAggregatesFromSnapshotItems(claimableItems);

    return {
      claimableByContract,
      claimableItems,
      publicItems,
      privateNotes,
      shieldDeposits,
      privateReceiveHistory,
      complete,
      servicesCheckpointId,
    };
  }

  /**
   * Private-note quarantine verdict cache, keyed by `${identitySetHash}:${id}`.
   * `identitySetHash` folds the current userId + the sorted materialized
   * (r0:r1) set, so any identity or receive-address change yields new keys and
   * the verdict is recomputed automatically. Kept in memory only; a boolean
   * verdict is cheap and never carries owner/secret material. Reset wholesale
   * when the identity set changes so it cannot grow unbounded.
   */
  private _noteQuarantineCache?: {
    hash: string;
    verdicts: Map<string, boolean>;
  };
  /** How many receive indices to forward-derive (beyond the materialized set)
   *  before quarantining a suspect note — mirrors ensureShieldReceiveAddress's
   *  default look-ahead so a genuine current note at a not-yet-materialized
   *  index is never wrongly quarantined. */
  private static readonly QUARANTINE_FORWARD_SCAN = 20;

  /**
   * Stamp `unclaimable` on private notes whose owner commitment NO
   * owned/derivable identity reproduces. Mutates the notes in place. Cheap path
   * first (materialized identities under the current userId); only genuine
   * suspects trigger a single bounded forward-derivation of extra (r0, r1)
   * candidates, and every per-note verdict is memoized in the (identity-set,
   * note-id) cache so steady-state 6s rollups do no owner work at all. Fails
   * OPEN — a note whose owner limbs are unusable or whose userId is non-numeric
   * is left claimable (the submit-time batch guard is the backstop).
   */
  private async stampPrivateNoteQuarantine(
    wallet: IPsyWidgetWallet,
    notes: PrivateNote[],
  ): Promise<void> {
    if (notes.length === 0) return;
    let userIdBig: bigint;
    try {
      userIdBig = BigInt(wallet.userId as unknown as string);
      if (userIdBig < 0n) return; // unregistered — fail open
    } catch {
      return; // non-numeric userId — fail open, never quarantine
    }

    const materialized = (wallet.shieldReceiveAddresses ?? []).map((entry) => ({
      r0: entry.r0,
      r1: entry.r1,
    }));
    const hash = this.identitySetHash(String(wallet.userId), materialized);
    if (this._noteQuarantineCache?.hash !== hash) {
      this._noteQuarantineCache = { hash, verdicts: new Map() };
    }
    const cache = this._noteQuarantineCache.verdicts;

    // Cheap pass: cache hit, unusable owner (fail open), or a materialized
    // identity already reproduces the owner. Whatever is left is a suspect.
    const suspects: Array<{ note: PrivateNote; limbs: bigint[] }> = [];
    for (const note of notes) {
      const cached = cache.get(note.id);
      if (cached !== undefined) {
        if (cached) note.unclaimable = true;
        continue;
      }
      const limbs = privateNoteOwnerLimbs(note);
      if (!limbs) {
        cache.set(note.id, false); // fail open — never quarantine
        continue;
      }
      if (identityReproducesOwner(limbs, wallet.userId, materialized)) {
        cache.set(note.id, false);
        continue;
      }
      suspects.push({ note, limbs });
    }
    if (suspects.length === 0) return;

    // Forward-derive a bounded set of extra candidate identities ONCE (they are
    // note-independent), then re-check only the suspects against them.
    const forward = await this.deriveForwardShieldSecrets(
      wallet,
      PsyWalletExtCore.QUARANTINE_FORWARD_SCAN,
    ).catch(() => [] as Array<{ r0: string; r1: string }>);
    for (const { note, limbs } of suspects) {
      const owned =
        forward.length > 0 &&
        identityReproducesOwner(limbs, wallet.userId, forward);
      cache.set(note.id, !owned);
      if (!owned) note.unclaimable = true;
    }
  }

  /** Stable hash of the identity set (current userId + sorted materialized
   *  r0:r1 pairs) used to key the quarantine verdict cache. */
  private identitySetHash(
    userId: string,
    identities: ReadonlyArray<{ r0: string; r1: string }>,
  ): string {
    const pairs = identities
      .map((id) => `${id.r0}:${id.r1}`)
      .sort()
      .join("|");
    return `${userId}#${pairs}`;
  }

  /** Forward-derive `count` receive-identity (r0, r1) candidates beyond the
   *  wallet's materialized set WITHOUT persisting them — used only to confirm a
   *  suspect note is not a genuine current note at an unmaterialized index. */
  private async deriveForwardShieldSecrets(
    wallet: IPsyWidgetWallet,
    count: number,
  ): Promise<Array<{ r0: string; r1: string }>> {
    const privateKeyHex = await this.getWalletPrivateKey(wallet);
    const start = this.nextShieldStartIndex(wallet);
    const out: Array<{ r0: string; r1: string }> = [];
    for (let i = 0; i < count; i += 1) {
      const { r0, r1 } = await derivePrivacyShieldKeys(
        privateKeyHex,
        start + i * 2,
      );
      out.push({ r0: String(r0), r1: String(r1) });
    }
    return out;
  }

  /**
   * Secret claim MATERIAL for the current snapshot, keyed by each item's
   * snapshot id, kept in memory only. This is NOT a claim-list source — it holds
   * no authority over WHICH items are claimable (that is solely
   * `_lastWalletSnapshot.claimableItems`); it is the by-id secret store
   * `getClaimableItems` joins so the popup can BUILD a claim. Committed
   * atomically with the snapshot in `_dispatchWalletSnapshot`, keyed to the same
   * build (checkpointId/computedAt) so a join can tell "matches this snapshot"
   * from "not rebuilt yet after an SW restart".
   */
  private _claimMaterial?: {
    chainKey: string;
    address: string;
    checkpointId: number;
    computedAt: number;
    byId: ClaimMaterialById;
  };

  /**
   * The rich claim-item lists for the popup — a STRICT PROJECTION of the ONE
   * source, `_lastWalletSnapshot.claimableItems` (the very array the chip/total
   * sum), with secret material joined by id. There is no separate discovery or
   * stored rich mirror anymore: what the chip counts and what the Claim list
   * enumerates are, by construction, the same item set, so they can never
   * diverge (the live "chip says +2 but list empty / 已全部处理" bug class).
   *
   * Amounts are serialized as strings (PsyJSON round-trips are lossy-safe for
   * strings only); the popup reconstructs bigints. Returns null when there is no
   * snapshot for the requested wallet on the active chain, OR when the snapshot
   * has note/deposit items but the secret-material map has not been rebuilt yet
   * (cold start / SW restart) — callers treat null as "not discovered yet" and
   * show a skeleton rather than an empty/unclaimable list until the next
   * snapshot dispatch rebuilds the material.
   */
  async getClaimableItems(address: string): Promise<{
    checkpointId: number;
    computedAt: number;
    publicItems: Array<
      Omit<PublicClaimItemPersisted, "amount"> & { amount: string }
    >;
    privateNotes: Array<Omit<PrivateNote, "amount"> & { amount: string }>;
    shieldDeposits: Array<
      Omit<Extract<ImportedClaimable, { kind: "deposit" }>, "amount"> & {
        amount: string;
      }
    >;
  } | null> {
    const snapshot = this._lastWalletSnapshot;
    if (
      !snapshot ||
      snapshot.address !== address ||
      snapshot.chainKey !== this._chainKey
    ) {
      return null;
    }
    const items = snapshot.claimableItems ?? [];
    const material = this._claimMaterial;
    const materialMatches =
      !!material &&
      material.address === address &&
      material.chainKey === this._chainKey &&
      material.checkpointId === snapshot.checkpointId;
    if (!materialMatches) {
      // The secret-material map is not aligned with this snapshot (memory-only,
      // dropped on SW restart; or the snapshot was painted from disk cache
      // before the fresh build committed material). If the snapshot has items
      // that REQUIRE secret material to build/render (notes/deposits), report
      // "not synced yet" so the Claim view shows a skeleton instead of rows it
      // cannot act on. A public-only snapshot needs no material — project and
      // return it directly.
      const needsMaterial = items.some(
        (item) => item.kind === "private-note" || item.kind === "deposit",
      );
      if (needsMaterial) return null;
    }
    const byId: ClaimMaterialById = materialMatches
      ? material!.byId
      : { notes: new Map(), deposits: new Map() };
    const lists = claimListFromSnapshotItems(items, byId);
    return {
      checkpointId: snapshot.checkpointId,
      computedAt: snapshot.computedAt,
      publicItems: lists.publicItems.map((item) => ({
        ...item,
        amount: item.amount.toString(),
      })),
      privateNotes: lists.privateNotes.map((note) => ({
        ...note,
        amount: note.amount.toString(),
      })),
      shieldDeposits: lists.shieldDeposits.map((dep) => ({
        ...dep,
        amount: dep.amount.toString(),
      })),
    };
  }

  /**
   * Read-only, secrets-free claimables summary for an APPROVED dApp origin.
   * The SHA-256 token binds wallet address, active network/chain, both chain
   * and services checkpoints, completeness, and the ordered public rows.
   */
  async listClaimablesForDapp(
    address: string,
  ): Promise<ClaimablesSnapshotEnvelope> {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) throw Error("Wallet Not Found");

    let checkpointReadComplete = true;
    try {
      await this.updateCheckpointId();
    } catch {
      checkpointReadComplete = false;
    }
    const checkpointId = this.checkpointId;
    const apiServicesUrl = firstConfigUrl(
      (this._config as { api_services_url?: unknown })?.api_services_url,
    );
    let rollup: Awaited<ReturnType<typeof this.readClaimableRollup>>;
    try {
      rollup = await this.readClaimableRollup(
        wallet,
        checkpointId,
        apiServicesUrl,
      );
    } catch {
      rollup = {
        claimableByContract: {},
        claimableItems: [],
        publicItems: [],
        privateNotes: [],
        shieldDeposits: [],
        privateReceiveHistory: [],
        complete: false,
        servicesCheckpointId: checkpointId,
      };
    }

    const items: ClaimableSnapshotItem[] = [];
    for (const item of rollup.publicItems) {
      items.push({
        kind: "public",
        id: publicClaimInput(item).key,
        contractId: item.contractId,
        amount: item.amount.toString(),
      });
    }
    for (const note of rollup.privateNotes) {
      if (!note.noteProofRaw || !note.shieldAddress || note.unclaimable)
        continue;
      const id = inputsForPrivateNote(note)[0]?.key;
      if (!id) continue;
      items.push({
        kind: "private-note",
        id,
        contractId: note.contractId,
        amount: note.amount.toString(),
      });
    }
    const myUserId = String(wallet.userId ?? "");
    for (const dep of rollup.shieldDeposits) {
      const depUserId = String(dep.shieldNote?.user_id ?? "");
      if (myUserId && depUserId && depUserId !== myUserId) continue;
      const id = inputsForShieldDeposit(dep)[0]?.key;
      if (!id) continue;
      items.push({
        kind: "deposit",
        id,
        contractId: dep.contractId,
        amount: dep.amount.toString(),
      });
    }
    const complete = checkpointReadComplete && rollup.complete;
    const snapshotToken = sha256(
      toUtf8Bytes(
        JSON.stringify([
          "psy_listClaimables:v1",
          address,
          this._networkKey,
          checkpointId,
          rollup.servicesCheckpointId,
          complete,
          items.map((item) => [
            item.kind,
            item.id,
            item.contractId,
            item.amount,
          ]),
        ]),
      ),
    );
    return {
      complete,
      snapshotToken,
      items,
    };
  }
  /**
   * Best-effort fold builder used by legacy `{ contractId }` requests. Exact
   * requests are validated by approve-manager against a complete public
   * snapshot before this builder's aligned `itemIds`/`itemAmounts` are used.
   */
  async buildFoldPendingClaims(
    address: string,
    contractIdRaw: string | number,
    callerClaims: ClaimBatchItem[],
  ): Promise<{
    items: ClaimBatchItem[];
    count: number;
    total: string;
    contractId: string;
    itemAmounts: string[];
    itemIds: string[];
  }> {
    const empty = {
      items: [] as ClaimBatchItem[],
      count: 0,
      total: "0",
      itemAmounts: [] as string[],
      itemIds: [] as string[],
      contractId: String(contractIdRaw ?? ""),
    };
    try {
      const wallet = this._wallets.find((w) => w.address === address);
      if (!wallet) return empty;
      const contractId = Number(contractIdRaw);
      if (!Number.isSafeInteger(contractId) || contractId < 0) return empty;
      const apiServicesUrl = firstConfigUrl(
        (this._config as { api_services_url?: unknown })?.api_services_url,
      );
      const indexerGraphqlUrl = firstConfigUrl(
        (this._config as { indexer_graphql_url?: unknown })
          ?.indexer_graphql_url,
      );
      await this.updateCheckpointId().catch(() => undefined);
      const rollup = await this.readClaimableRollup(
        wallet,
        this.checkpointId,
        apiServicesUrl,
      );

      const takenNullifiers = new Set<string>();
      const takenPublicPairs = new Set<string>();
      for (const item of callerClaims) {
        if (item.type === "private_transfer") {
          const data = item.data;
          const n = "claim" in data ? data.claim.nullifier : undefined;
          if (Array.isArray(n)) takenNullifiers.add(n.map(String).join(","));
        } else if (item.type === "claim_shield_deposit") {
          const data = item.data;
          const n = "nullifier" in data ? data.nullifier : undefined;
          if (Array.isArray(n)) takenNullifiers.add(n.map(String).join(","));
        } else {
          const data = item.data;
          if (
            isPublicTokenCall(data, "claim") &&
            Array.isArray(data.inputs) &&
            data.inputs.length > 0
          ) {
            takenPublicPairs.add(
              `${String(data.contract_id ?? "")}:${String(data.inputs[0])}`,
            );
          }
        }
      }

      const items: ClaimBatchItem[] = [];
      const itemAmounts: string[] = [];
      const itemIds: string[] = [];
      let total = 0n;

      for (const pub of rollup.publicItems) {
        if (pub.contractId !== contractId) continue;
        if (
          takenPublicPairs.has(
            `${String(pub.contractId)}:${String(pub.senderUserId)}`,
          )
        ) {
          continue;
        }
        let record = pub.amount;
        try {
          const claimable = BigInt(
            await this.getClaimAmount(
              this.checkpointId,
              pub.contractId,
              wallet.userId,
              pub.senderUserId,
            ),
          );
          if (claimable <= 0n) continue;
          record = claimable;
        } catch {
          // Legacy fold stays best-effort; exact callers reject incomplete
          // snapshots before invoking this builder.
        }
        items.push(publicClaimBatchItem(pub));
        itemAmounts.push(record.toString());
        itemIds.push(publicClaimInput(pub).key);
        total += record;
      }

      for (const note of rollup.privateNotes) {
        if (
          note.contractId !== contractId ||
          !note.noteProofRaw ||
          !note.shieldAddress ||
          note.unclaimable
        ) {
          continue;
        }
        const id = inputsForPrivateNote(note)[0]?.key;
        if (!id) continue;
        let item: ClaimBatchItem;
        try {
          item = privateNoteClaimBatchItem(note);
        } catch {
          continue;
        }
        if (item.type !== "private_transfer") continue;
        const nullifierKey = item.data.claim.nullifier.join(",");
        if (takenNullifiers.has(nullifierKey)) continue;
        try {
          const claimed = await isPrivateNoteAlreadyClaimed({
            note,
            userId: wallet.userId,
            checkpointId: this.checkpointId,
            networkConfig: this._config,
          });
          if (claimed !== false) continue;
        } catch {
          continue;
        }
        takenNullifiers.add(nullifierKey);
        items.push(item);
        itemAmounts.push(note.amount.toString());
        itemIds.push(id);
        total += note.amount;
      }

      const myUserId = String(wallet.userId ?? "");
      for (const dep of rollup.shieldDeposits) {
        if (dep.contractId !== contractId) continue;
        const depUserId = String(dep.shieldNote?.user_id ?? "");
        if (myUserId && depUserId && depUserId !== myUserId) continue;
        const id = inputsForShieldDeposit(dep)[0]?.key;
        if (!id) continue;
        const depNullifierKey = Array.isArray(dep.shieldNote?.nullifier_secret)
          ? dep.shieldNote.nullifier_secret.map(String).join(",")
          : null;
        if (depNullifierKey && takenNullifiers.has(depNullifierKey)) continue;
        try {
          const claimed = await isImportedShieldDepositAlreadyClaimed({
            item: dep,
            userId: wallet.userId,
            checkpointId: this.checkpointId,
            networkConfig: this._config,
          });
          if (claimed !== false) continue;
          const { claim } = await buildImportedShieldDepositClaimBatchItem(
            dep,
            apiServicesUrl,
            indexerGraphqlUrl || undefined,
          );
          if (String(claim.data.contract_id ?? "") !== String(contractId)) {
            continue;
          }
          if (depNullifierKey) takenNullifiers.add(depNullifierKey);
          items.push(claim);
          itemAmounts.push(dep.amount.toString());
          itemIds.push(id);
          total += dep.amount;
        } catch {
          // Per-item best effort for the legacy path.
        }
      }

      return {
        items,
        count: items.length,
        total: total.toString(),
        contractId: String(contractId),
        itemAmounts,
        itemIds,
      };
    } catch (error) {
      console.warn("[execClaimBatch] fold-pending-claims skipped", error);
      return empty;
    }
  }

  private async _buildCurrentWalletSnapshotNow(
    wallet: IPsyWidgetWallet,
    checkpointId: number,
    forceRescan: boolean,
    throttleForcedDrain = false,
  ): Promise<void> {
    const epoch = this._chainEpoch;
    const networkKey = this._networkKey;
    const chainKey = this._chainKey;
    const apiServicesUrl = firstConfigUrl(
      (this._config as any)?.api_services_url,
    );
    const isCurrent = () =>
      !this._disposed &&
      this._currentWallet?.address === wallet.address &&
      this._chainEpoch === epoch &&
      this._networkKey === networkKey &&
      this._chainKey === chainKey;

    // Retained for RPC compatibility; services-backed rollups currently do not
    // distinguish forced or throttled refreshes.
    void forceRescan;
    void throttleForcedDrain;

    // Confirmed balances are read directly from the chain, while claimables are
    // fetched from psy-services in readClaimableRollup. Older builds did a
    // local Nostr drain and a second dispatch after that drain. That receive
    // path is gone; one services-backed rollup is the current source of truth,
    // and avoiding the second pass prevents popup flicker.

    // On a failed slot read, carry the last-known balance forward instead of
    // writing "0": a transient RPC hiccup must not make the home total dip to
    // zero for a whole snapshot cycle (same guarantee the popup-side refresh
    // loop had before it moved here).
    const previousSnapshot =
      this._lastWalletSnapshot &&
      this._lastWalletSnapshot.address === wallet.address &&
      this._lastWalletSnapshot.networkKey === networkKey
        ? this._lastWalletSnapshot
        : await loadWalletSnapshotCache(chainKey, wallet.userId);

    // Confirmed balances for every token AT THE SAME checkpoint. Fire all
    // reads at once — the provider read-queue still serializes the actual RPC
    // round-trips, but issuing them together removes the JS-side await chain.
    let failedBalanceReads = 0;
    // Contracts whose read failed THIS build: their entries below are
    // carried forward, not chain observations — hold release must know.
    const staleContractKeys: string[] = [];
    const balanceEntries = await Promise.all(
      tokensManager._tokens.map(async (token) => {
        const contractKey = String(token.contractId);
        try {
          const balance = await this.getBalance(
            wallet.address,
            BigInt(token.contractId) as unknown as Felt,
            checkpointId as unknown as Felt,
          );
          return [contractKey, String(balance)] as const;
        } catch {
          failedBalanceReads += 1;
          staleContractKeys.push(contractKey);
          return [
            contractKey,
            previousSnapshot?.balancesByContract?.[contractKey] ?? "0",
          ] as const;
        }
      }),
    );
    // EVERY read failed → the values above are carried forward, not current.
    // Annotate the snapshot so the home can show an honest staleness pill
    // (computedAt alone lies here — it's stamped fresh regardless).
    const balancesStale =
      tokensManager._tokens.length > 0 &&
      failedBalanceReads === tokensManager._tokens.length
        ? true
        : undefined;
    const balancesByContract: Record<string, string> =
      Object.fromEntries(balanceEntries);

    if (!isCurrent()) return;

    const cachedClaimables = await this.readClaimableRollup(
      wallet,
      checkpointId,
      apiServicesUrl,
      previousSnapshot?.privateReceiveHistory ?? [],
    ).catch(() => ({
      claimableByContract: {} as Record<string, string>,
      claimableItems: [] as SnapshotClaimableItem[],
      publicItems: [] as PublicClaimItemPersisted[],
      privateNotes: [] as PrivateNote[],
      shieldDeposits: [] as Array<
        Extract<ImportedClaimable, { kind: "deposit" }>
      >,
      privateReceiveHistory: previousSnapshot?.privateReceiveHistory ?? [],
      complete: false,
      servicesCheckpointId: checkpointId,
    }));

    if (!isCurrent()) return;

    await this._dispatchWalletSnapshot(
      {
        checkpointId,
        address: wallet.address,
        userId: String(wallet.userId),
        networkKey,
        balancesByContract,
        claimableByContract: cachedClaimables.claimableByContract,
        claimableItems: cachedClaimables.claimableItems,
        privateReceiveHistory: cachedClaimables.privateReceiveHistory,
        computedAt: Date.now(),
        balancesStale,
        ...(staleContractKeys.length
          ? { staleBalanceContracts: staleContractKeys }
          : {}),
      },
      // The rich lists that produced the aggregates above — committed to the
      // getClaimableItems mirror atomically with this snapshot so the Claim
      // list and the chip/total can never reflect different builds.
      {
        publicItems: cachedClaimables.publicItems,
        privateNotes: cachedClaimables.privateNotes,
        shieldDeposits: cachedClaimables.shieldDeposits,
      },
    );
  }

  private async _dispatchWalletSnapshot(
    snapshot: WalletSnapshot,
    // The rich claim-material lists this snapshot's items were built from. Only
    // the SECRET material (note proof envelopes / deposit notes) is retained,
    // keyed by each item's snapshot id, into `_claimMaterial` — committed
    // atomically with the snapshot below. It is NOT a claim-list source: the one
    // source of record for WHICH items are claimable is
    // `snapshot.claimableItems`, and `getClaimableItems` projects that array,
    // joining this material by id. Omitted by re-dispatch callers that reuse an
    // already-committed snapshot (its material is already in place).
    claimableRollup?: {
      publicItems: PublicClaimItemPersisted[];
      privateNotes: PrivateNote[];
      shieldDeposits: Array<Extract<ImportedClaimable, { kind: "deposit" }>>;
    },
  ): Promise<void> {
    // Monotonic dispatch: an older-checkpoint build finishing late must not
    // replace a newer snapshot for the same wallet/network. Equal checkpoints
    // may re-dispatch after a fresh services-backed recompute.
    const last = this._lastWalletSnapshot;
    if (
      last &&
      last.address === snapshot.address &&
      last.networkKey === snapshot.networkKey &&
      last.checkpointId > snapshot.checkpointId
    ) {
      return;
    }
    // Stamp the chain identity onto the snapshot BEFORE it becomes
    // _lastWalletSnapshot (which refreshPsyState / repaintLastWalletSnapshot
    // re-dispatch) and before it is persisted — the balance-model gate rejects
    // a snapshot whose chainKey differs from the current checkpoint-1 root.
    snapshot.chainKey = this._chainKey;
    this._lastWalletSnapshot = snapshot;
    // Commit the secret-material map in the SAME step the snapshot is committed
    // (past the monotonic guard above), keyed to this exact build by the SAME
    // item ids the snapshot uses. getClaimableItems projects
    // `snapshot.claimableItems` and joins this by id, so the Claim list can only
    // ever be the item set the chip/total sum — never an independently rebuilt
    // one.
    if (claimableRollup) {
      this._claimMaterial = {
        chainKey: this._chainKey,
        address: snapshot.address,
        checkpointId: snapshot.checkpointId,
        computedAt: snapshot.computedAt,
        byId: claimMaterialByIdFromLists({
          privateNotes: claimableRollup.privateNotes,
          shieldDeposits: claimableRollup.shieldDeposits,
        }),
      };
    }
    // This snapshot reflects on-chain reality at its checkpoint — release
    // any confirmed balance holds it has clearly superseded BEFORE the
    // popup repaints, so hold + new balance never double-subtract.
    const pendingHoldsSnapshot = pendingHolds.expireForSnapshot(
      this._chainKey,
      snapshot.address,
      snapshot.checkpointId,
      snapshot.balancesByContract,
      { dispatch: false, staleContracts: snapshot.staleBalanceContracts },
    );
    // Dispatch first so the popup updates immediately, then await the cache
    // write — keeping the MV3 service worker alive until it persists so the
    // cold-start "paint from cache" path actually has something to read.
    psyStateDispatch({
      walletSnapshot: snapshot,
      pendingHolds: pendingHoldsSnapshot,
    });
    await saveWalletSnapshotCache(snapshot, this._chainKey).catch(
      () => undefined,
    );
  }

  async addWalletFromPrivateKey(
    privateKeyHex: string,
    signType: SignType,
    fingerprint: string | undefined,
    mnInd = -1,
    changeCurrent?: boolean,
    walletName?: string,
    sdkKeyCircuitParams?: ISdkKeyCircuitParams,
    // Shield receive addresses to restore from a backup export. Each entry
    // carries r0/r1 secrets that are generated client-side at creation time
    // and mirrored in WASM state — they are NOT re-derivable from the mnemonic
    // alone, so they must round-trip explicitly through backup exports.
    shieldReceiveAddresses?: IShieldReceiveAddress[],
    mode: WalletImportMode = "restore",
  ) {
    if (this._addWalletInFlight) {
      throw new Error("Account creation is already in progress");
    }
    this._addWalletInFlight = true;
    this._walletCreationStartedAt = Date.now();
    await psyStateDispatch({
      creatingWalletSince: this._walletCreationStartedAt,
    });
    try {
      await this._waitForProver("addWalletFromPrivateKey");

      // Derive the default name from the CURRENT accounts (lowest unused
      // "Account N"), not from the monotonic `totalCount` counter — that
      // counter never decremented on delete, so after delete-all the next
      // account was misnamed "Account 2" instead of "Account 1".
      const newWalletName =
        walletName || nextAccountName(this._wallets.map((w) => w.name));

      const wallet = await widgetWalletFromPrivateKey(
        this._provider,
        privateKeyHex,
        signType,
        fingerprint,
        mnInd,
        newWalletName,
        sdkKeyCircuitParams,
        () => this._disposed,
        mode,
      );

      if (this._wallets.some((w) => w.address === wallet.address))
        throw new Error("Account Exists");

      // Restore shield receive addresses from backup when provided.
      // If the backup predates shield-address support the array is omitted and
      // we fall through to auto-creating a fresh one below.
      if (shieldReceiveAddresses && shieldReceiveAddresses.length > 0) {
        wallet.shieldReceiveAddresses = shieldReceiveAddresses;
      }

      // Auto-create the first private receive address at registration time so
      // dApps that connect to the wallet immediately can read a real shield
      // address via `psy_listShieldReceiveAddresses` instead of seeing an
      // empty list. Previously the first address was created lazily on the
      // first open of the Claim modal — meaning a dApp asking for the user's
      // shielded address right after `psy_requestAccounts` got nothing back,
      // and any "auto-fill private recipient" feature on the dApp side
      // silently no-op'd until the user manually clicked Claim. By the time
      // we're here `widgetWalletFromPrivateKey` has already gone through
      // tryGetUserId / registerUser, so wallet.userId is a real on-chain id
      // (the only piece deriveShieldAddress needs that the helper can't get
      // from the private key alone). Errors here are best-effort: if the
      // derivation fails for any reason we'd rather ship the wallet without
      // a shielded address than fail registration entirely — Claim modal's
      // lazy-create path still works as a fallback.
      // CURRENT-IDENTITY check, not a length check: a backup restored onto a
      // NEW chain (auto re-registration under a fresh userId) carries only
      // old-epoch addresses — the list is non-empty, but every entry is
      // cryptographically unclaimable by this identity. The length check
      // skipped auto-create in exactly that case, so Receive/the private
      // address book stayed empty until a manual derive (user-reported
      // 2026-07-24). Old entries are kept — they still drain their epoch.
      if (
        !hasCurrentIdentityAddress(
          wallet.userId,
          wallet.shieldReceiveAddresses ?? [],
        )
      ) {
        try {
          const receiveAddress =
            await this.deriveShieldReceiveAddressForWallet(wallet);
          wallet.shieldReceiveAddresses = [
            ...(wallet.shieldReceiveAddresses ?? []),
            receiveAddress,
          ];
        } catch (e) {
          console.warn(
            "[psy-wallet] auto-create of first shield receive address failed; falling back to lazy creation",
            e,
          );
        }
      }

      ++this._passwordManager.totalCount;
      // A first-run popup can create a wallet while the boot-time loadWallets
      // promise is still settling. The WalletMain Add Password guard waits for
      // hasTriedRestore to avoid false prompts on encrypted vaults, so mark the
      // restore gate satisfied before publishing the freshly-created wallet.
      if (!this._hasTriedRestore) {
        this.hasTriedRestore = true;
      }
      this.wallets = this._wallets.concat(wallet);
      if (changeCurrent) {
        this.currentWallet = wallet;
      } else if (!this._currentWallet) {
        this.currentWallet = wallet;
      }

      await this.saveWallets();
      if (this._currentWallet?.address === wallet.address) {
        void this.buildCurrentWalletSnapshot(true).catch(() => undefined);
      }
    } finally {
      this._addWalletInFlight = false;
      this._walletCreationStartedAt = 0;
      await psyStateDispatch({ creatingWalletSince: null });
    }
  }

  /**
   * Import a multi-account backup in ONE background call.
   *
   * The popup used to drive this loop itself, one addWalletFromPrivateKey
   * internal request per account — and each iteration is a full wallet
   * setup round-trip (key derivation + on-chain user registration), so
   * closing the popup mid-loop silently dropped every account after the
   * one in flight ("only the first wallet imported"). The service worker
   * outlives the popup, so the loop lives here now: the popup decrypts the
   * keystore entries, hands the whole batch over once, and the import
   * completes regardless of the popup's lifetime.
   *
   * Per-item failures don't abort the rest — already-imported accounts
   * count as skipped, anything else is reported back so the popup can
   * surface it.
   */
  async importWalletsFromBackup(
    items: Array<{
      privateKey: string;
      signType: SignType;
      mnInd?: number;
      name?: string;
      shieldReceiveAddresses?: IShieldReceiveAddress[];
    }>,
  ): Promise<{ imported: number; skipped: number; failed: string[] }> {
    let imported = 0;
    let skipped = 0;
    const failed: string[] = [];
    // Restored names are matched to their account by the keystore entry that
    // carries them (each `item` owns both its private key and its `name`), so
    // re-association is by account identity, never by array position. Two
    // accounts that shared a custom label — or a label already present in the
    // wallet — would otherwise collapse into indistinguishable picker rows, so
    // disambiguate against both the live wallet set and the names already
    // claimed earlier in this same batch. A missing/blank backup name resolves
    // to "" here and falls through to addWalletFromPrivateKey's default
    // nextAccountName fallback (backwards-compatible with pre-name backups).
    const claimedNames: string[] = [];
    for (const item of items) {
      try {
        const restoredName = disambiguateAccountName(item.name, [
          ...this._wallets.map((w) => w.name),
          ...claimedNames,
        ]);
        await this.addWalletFromPrivateKey(
          item.privateKey,
          item.signType,
          undefined,
          item.mnInd ?? -1,
          false,
          restoredName || undefined,
          undefined,
          item.shieldReceiveAddresses,
        );
        // Only reserve the label once the account actually landed — a
        // skipped ("Account Exists") or failed add must not consume a name
        // and push later siblings onto a needless " (2)" suffix.
        if (restoredName) claimedNames.push(restoredName);
        imported++;
      } catch (error: any) {
        if (error?.message === "Account Exists") {
          skipped++;
        } else {
          failed.push(error?.message || String(error));
        }
      }
    }
    if (imported > 0 && this._currentWallet) {
      void this.buildCurrentWalletSnapshot(true).catch(() => undefined);
    }
    return { imported, skipped, failed };
  }

  async refreshAllWallets() {
    const newWallets = await Promise.all(
      this._wallets.map((wallet) => refreshWidgetWallet(wallet)),
    );

    const newCurrentWallet = newWallets.find(
      (wallet) => wallet.address === this._currentWallet?.address,
    );

    this.wallets = newWallets;
    this.currentWallet = newCurrentWallet;
    await this.saveWallets();
  }

  async loadWallets(password?: string) {
    if (this._disposed) return;
    // A plaintext store (wallet created without a password) has no verifyStr,
    // so verifyPassword("") always fails — its exception made loadWallets
    // throw on every cold start, wiping the wallet list and dropping the
    // user onto the Welcome screen as if their wallet had vanished. Only an
    // ENCRYPTED store can meaningfully verify a password.
    if (await this._passwordManager.isEncrypted()) {
      const passwordIsCorrect = await this._passwordManager.verifyPassword(
        password || "",
      );
      if (!passwordIsCorrect) throw Error("Incorrect password");
    }
    if (this._pendingChainKey && this._pendingChainKey !== this._chainKey) {
      const pendingChainKey = this._pendingChainKey;
      await this.handleChainKeyChange(pendingChainKey);
      return;
    }

    const walletData =
      await this._passwordManager.loadWalletsFromStorage(password);
    if (this._disposed) return;

    const wallets: IPsyWidgetWallet[] = [];
    // do not use promise.all
    let count = 0;
    for (const w of walletData.wallets) {
      if (this._disposed) return;
      const {
        privateKey,
        name,
        mnInd,
        signType,
        fingerprint,
        sdkKeyCircuitParams,
      } = w;
      const storedChainKey = chainStorageKey(
        w.networkKey ?? walletData.networkKey,
      );
      const storedUserId =
        storedChainKey === this._chainKey ? w.userId : undefined;
      if (storedUserId === undefined) {
        console.info(
          "[psy-wallet][core] no userId registered for active chain; resolving on-chain",
          { storedChainKey, activeChainKey: this._chainKey },
        );
      }
      try {
        const storedPublicKey =
          storedUserId !== undefined && storedUserId >= 0
            ? w.address
            : undefined;
        const wallet = await widgetWalletFromPrivateKey(
          this._provider,
          privateKey,
          signType,
          fingerprint,
          mnInd,
          name || nextAccountName(wallets.map((existing) => existing.name)),
          sdkKeyCircuitParams,
          () => this._disposed,
          "restore",
          storedUserId,
          storedPublicKey,
          w.cachedUserInfo,
          this._networkKey,
        );
        wallet.shieldReceiveAddresses = this.backfillOwnerUserId(
          wallet.userId,
          w.shieldReceiveAddresses ?? [],
        );
        // widgetWalletFromPrivateKey may re-register the key under a new userId
        // before returning. The later reconciler then exits early, so create
        // that epoch's receive address here while preserving every old address.
        try {
          wallet.shieldReceiveAddresses =
            await ensureCurrentIdentityReceiveAddress(
              wallet.userId,
              wallet.shieldReceiveAddresses,
              () =>
                this.deriveShieldReceiveAddressForWallet(
                  wallet,
                  "Private receive 1",
                ),
            );
        } catch (error) {
          console.warn(
            "[psy-wallet][core] could not derive a current-identity receive address after boot-time re-registration; falling back to lazy creation",
            { address: wallet.address, userId: wallet.userId, error },
          );
        }
        if (this._disposed) return;
        wallets.push(wallet);
        ++count;
      } catch (error) {
        console.warn(
          "[psy-wallet][core] skipping wallet that failed to restore",
          { mnInd, signType, error },
        );
      }
      if (this._disposed) return;
    }

    if (this._disposed) return;
    const currentWallet = walletData.activeWalletAddress
      ? wallets.find((w) => w.address === walletData.activeWalletAddress)
      : null;

    this.wallets = wallets;
    this.currentWallet = currentWallet || wallets[0];
    this.hasTriedRestore = true;
    if (walletData.wallets.length > 0 && walletData.wallets.length === count) {
      await this.saveWallets();
    }
    this.syncPublicClaimCandidates().catch((error) => {
      console.warn("[psy-wallet][public-claim] initial sync failed", error);
    });
    // Paint from cache immediately, then compute a fresh unified snapshot.
    if (this._currentWallet) {
      void this.dispatchCachedWalletSnapshot(this._currentWallet.address);
      // Push the fresh services-backed build off the boot-critical path with a
      // short timer, mirroring kickWasmInitSoon. On a cold boot this runs while
      // the popup is doing its reopen handshake; letting the cached paint and
      // handshake land first keeps the single service-worker thread responsive.
      // Use the forced coalescing slot so this boot build remains distinct from
      // an overlapping ordinary refresh.
      const bootWallet = this._currentWallet;
      setTimeout(() => {
        if (
          this._disposed ||
          this._currentWallet?.address !== bootWallet.address
        )
          return;
        void this.buildCurrentWalletSnapshot(true).catch(() => undefined);
      }, 250);
      // Reconcile the restored current wallet's identity against the chain in
      // the background — heals a userId left stale by a devnet reset without
      // blocking cold-start paint.
      void this.reconcileWalletIdentity(this._currentWallet.address).catch(
        () => undefined,
      );
    }
    this.refreshWalletUserInfoCacheInBackground();
    this.warmUpLocalWalletUsers();
    // Wallets just became available — sweep for private transfers that
    // committed on-chain but never finished proof/delivery (SW restart).
    void this.resumePendingPrivateTransfers();
    // …and reconcile public sends the previous service worker died holding.
    void this._reconcileInterruptedSends();
  }

  /** Best-effort read of a user's current ON-CHAIN nonce. `undefined` when
   *  the RPC fails — callers treat that as "no evidence". */
  /** Recipient-existence probe for the transfer flow. The coordinator user
   *  registration tree is authoritative. A registered account can still have
   *  an empty realm user leaf until its first UPS, so checking realm
   *  leaf.public_key incorrectly rejects valid fresh Psy IDs.
   *
   *  Tri-state keeps the transfer fail-open on RPC trouble: only an
   *  authoritative empty registration leaf (or an out-of-range id) returns
   *  "missing" and blocks the send.
   */
  async checkRecipientExists(
    userId: number | bigint,
  ): Promise<RecipientExistence> {
    try {
      return await probeRecipientRegistration(
        this._provider.coordinatorEdgeRpcProvider,
        this._config,
        userId,
      );
    } catch (error) {
      console.warn("[psy-wallet][tx] recipient existence probe failed", {
        userId: String(userId),
        error,
      });
      return "unknown";
    }
  }

  private async _fetchOnChainNonce(
    userId: number | bigint,
  ): Promise<string | undefined> {
    try {
      const leaf = await this._provider.realmEdgeRpcProvider.getUserLeafData(
        this.checkpointId,
        userId,
      );
      return String(leaf.nonce);
    } catch (error) {
      console.warn("[psy-wallet][tx] on-chain nonce probe failed", {
        userId: String(userId),
        error,
      });
      return undefined;
    }
  }

  private queuedSettlementCall(
    entry: TxQueueEntry,
  ): ContractCallArgs | undefined {
    const calls =
      entry.kind === "contract_call"
        ? Array.isArray(entry.payload)
          ? entry.payload
          : [entry.payload]
        : entry.kind === "claim_batch"
          ? txQueue.claimBatchRows(entry.payload)
          : [
              ...(entry.payload.preClaimItems?.length
                ? txQueue.claimBatchRows(entry.payload.preClaimItems)
                : []),
              {
                contract_id: BigInt(entry.payload.request.contract_id),
                method_name: "private_transfer",
                inputs: [0n, 0n, 0n, 0n, BigInt(entry.payload.request.amount)],
              } as ContractCallArgs,
            ];
    const movements = calls.filter((call) =>
      (isPublicTokenCall(call, "transfer") || ["private_transfer", "withdraw"].includes(call.method_name)),
    );
    if (movements.length === 1) return movements[0];
    return calls.length === 1 ? calls[0] : undefined;
  }

  private submittedHashCandidates(entry: TxQueueEntry): string[] {
    const submitHash =
      entry.hash ?? txHashFromSdkResult(entry.result as SdkTxResult);
    const normalized = normalizeContentHash(submitHash);
    if (!/^[0-9a-f]{64}$/.test(normalized)) return [];
    const reversed = normalizeContentHash(reverseHexBytes(normalized));
    return reversed === normalized ? [normalized] : [normalized, reversed];
  }

  private matchesQueuedSettlement(
    entry: TxQueueEntry,
    tx: ServicesTransactionDetail,
  ): boolean {
    if (!includedServicesTransaction(tx)) return false;
    const call = this.queuedSettlementCall(entry);
    if (!call) return false;
    const contractId = Number(call.contract_id ?? 0);
    if (!Number.isSafeInteger(contractId) || contractId < 0) return false;
    const signal = parseActivityFromSlotUpdates(tx.slot_updates ?? [], tx);
    if (call.method_name === "private_transfer") {
      return (
        inferServicesTxKind(tx) === "private_transfer" &&
        signal.isPrivate === true &&
        signal.contractId === contractId
      );
    }
    if (!isPublicTokenCall(call, "transfer") || signal.isPrivate) {
      return false;
    }

    const recipient = Number(call.inputs?.[0]);
    const amount =
      call.inputs?.[1] != null ? BigInt(call.inputs[1]) : undefined;
    if (!Number.isSafeInteger(recipient) || recipient < 0 || amount == null) {
      return false;
    }
    if (
      !isPublicTokenCall({contract_id: contractId, method_name: signal.method}, "transfer") ||
      signal.direction !== "out" ||
      signal.contractId !== contractId ||
      signal.counterpartyUserId !== String(recipient)
    ) {
      return false;
    }
    const sentSlot = 3 + 2 * recipient;
    return (tx.slot_updates ?? []).some((update) => {
      if (update.contract_id !== contractId || update.slot_index !== sentSlot) {
        return false;
      }
      try {
        const delta = BigInt(update.new_value) - BigInt(update.old_value);
        return (delta < 0n ? -delta : delta) === amount;
      } catch {
        return false;
      }
    });
  }

  private async findSubmittedSettlementInUserHistory(
    entry: TxQueueEntry,
    wallet: IPsyWidgetWallet,
    apiBase: string,
  ): Promise<ServicesTransactionDetail | undefined> {
    const rows = await fetchUserTransactionList({
      userId: entry.userId ?? wallet.userId,
      apiServicesUrl: apiBase,
      limit: 50,
      timeoutMs: 6_000,
    });
    const submitCheckpoint = Number(entry.checkpointId ?? 0);
    const hashCandidates = new Set(this.submittedHashCandidates(entry));
    const included = rows.filter((row) => {
      if (!includedServicesTransaction(row)) return false;
      const checkpoint = Number(row.included_checkpoint_id ?? 0);
      const hasSubmitCheckpoint =
        Number.isFinite(submitCheckpoint) && submitCheckpoint > 0;
      const checkpointInWindow =
        hasSubmitCheckpoint &&
        checkpoint >= submitCheckpoint &&
        checkpoint <= submitCheckpoint + 100;
      const settledAt = servicesSettlementTime(row);
      const timeInWindow =
        settledAt != null &&
        settledAt >= entry.createdAt - 120_000 &&
        settledAt <= entry.createdAt + 10 * 60_000;
      return checkpointInWindow || timeInWindow;
    });
    const exact = included.find((row) =>
      hashCandidates.has(normalizeContentHash(row.content_hash)),
    );
    if (exact) return exact;

    const candidates = await Promise.all(
      included.slice(0, 20).map(async (row) => {
        if (row.slot_updates?.length) return row;
        const detail = await fetchTransactionDetailByHash(
          apiBase,
          row.content_hash,
          6_000,
        );
        return detail ? { ...row, ...detail } : row;
      }),
    );
    const matches = new Map<string, ServicesTransactionDetail>();
    for (const candidate of candidates) {
      const hash = normalizeContentHash(candidate.content_hash);
      if (!/^[0-9a-f]{64}$/.test(hash)) continue;
      if (this.matchesQueuedSettlement(entry, candidate)) {
        matches.set(hash, candidate);
      }
    }
    if (matches.size !== 1) return undefined;
    return matches.values().next().value;
  }

  /**
   * Confirm a submitted tx by EITHER of two signals, polling until one fires:
   *
   *   1. psy-services indexer reports the tx's content hash as included
   *      (`included_checkpoint_id`/`included_at`). This is the source of truth
   *      for tx landing and the ONLY signal that works for relayer-submitted
   *      txs, which may never advance THIS wallet's own leaf nonce.
   *   2. the wallet's on-chain leaf nonce advances past the start nonce
   *      (works for self-submitted txs; a fast local signal when services is
   *      unavailable or lagging).
   *
   * Returns `{ confirmed: true, settledNonce }` on the first signal, or
   * `{ confirmed: false, settledNonce }` on timeout/cancel/dispose. The nonce
   * is the advanced nonce when signal 2 fired, otherwise the passed-in
   * `settledNonce`.
   */
  private async confirmSubmittedByServicesOrNonce(
    entry: TxQueueEntry,
    wallet: IPsyWidgetWallet,
    settledNonce: string,
    timeoutMs: number,
  ): Promise<{
    confirmed: boolean;
    settledNonce: string;
    canonicalHash?: string;
    settledAt?: number;
  }> {
    const shouldStop = () =>
      this._disposed ||
      entry.cancelRequestedAt != null ||
      entry.status === "cancelled";
    const startedNonceRaw = entry.startedNonce;
    let startedNonce: bigint | undefined;
    if (startedNonceRaw !== undefined && startedNonceRaw !== "") {
      try {
        startedNonce = BigInt(startedNonceRaw);
      } catch {
        startedNonce = undefined;
      }
    }
    const submitHash =
      entry.hash ?? txHashFromSdkResult(entry.result as SdkTxResult);
    const apiBase =
      firstConfigUrl(this._config.api_services_url) || ENV.API_SERVICES_URL;
    const lookupHashes = this.submittedHashCandidates(entry);
    const deadline = Date.now() + timeoutMs;
    let nextWarnAt = Date.now() + 90_000;
    let nextHistoryLookupAt = 0;
    let attempt = 0;
    while (!shouldStop() && Date.now() < deadline) {
      attempt += 1;
      // Signal 1 — authoritative services inclusion. Try only validated
      // 32-byte canonical candidates (SDK form and byte-reversed services
      // form). When the submit hash is not the user's indexed endcap hash,
      // fall back to the user transaction list and require one unambiguous
      // semantic match before confirming the durable queue entry.
      if (apiBase) {
        let settlement: ServicesTransactionDetail | undefined;
        for (const lookupHash of lookupHashes) {
          try {
            const detail = await fetchTransactionDetailByHash(
              apiBase,
              lookupHash,
              6_000,
            );
            if (includedServicesTransaction(detail)) {
              settlement = detail;
              break;
            }
          } catch {
            // exact indexer probe failed this tick — keep polling
          }
        }
        if (!settlement && Date.now() >= nextHistoryLookupAt) {
          nextHistoryLookupAt = Date.now() + 15_000;
          try {
            settlement = await this.findSubmittedSettlementInUserHistory(
              entry,
              wallet,
              apiBase,
            );
          } catch {
            // user-history correlation failed this tick — keep polling
          }
        }
        if (settlement) {
          const canonicalHash = normalizeContentHash(settlement.content_hash);
          const settledAt = servicesSettlementTime(settlement);
          console.info("[psy-wallet][tx] submitted tx confirmed by services", {
            queueId: entry.queueId,
            hash: submitHash,
            canonicalHash,
            attempt,
            includedCheckpointId: settlement.included_checkpoint_id ?? null,
          });
          return {
            confirmed: true,
            settledNonce,
            ...(/^[0-9a-f]{64}$/.test(canonicalHash) ? { canonicalHash } : {}),
            ...(settledAt != null ? { settledAt } : {}),
          };
        }
      }
      // Signal 2 — on-chain leaf nonce advanced past the start nonce.
      if (startedNonce !== undefined) {
        await this.updateCheckpointId().catch(() => undefined);
        const latestNonce = await this._fetchOnChainNonce(wallet.userId);
        if (latestNonce !== undefined) {
          try {
            if (BigInt(latestNonce) > startedNonce) {
              await this.refreshQueuedWallet(entry.address).catch(
                () => undefined,
              );
              await this.refreshPsyState().catch(() => undefined);
              console.info("[psy-wallet][tx] submitted tx confirmed by nonce", {
                queueId: entry.queueId,
                hash: submitHash,
                startedNonce: startedNonceRaw,
                latestNonce,
                attempt,
              });
              return { confirmed: true, settledNonce: latestNonce };
            }
          } catch {
            // malformed transient nonce — keep polling
          }
        }
      }
      if (Date.now() >= nextWarnAt) {
        console.warn(
          "[psy-wallet][tx] submitted tx is still waiting for confirmation",
          { queueId: entry.queueId, hash: submitHash, attempt },
        );
        nextWarnAt += 90_000;
      }
      await new Promise((resolve) =>
        setTimeout(
          resolve,
          Math.min(2_000, Math.max(0, deadline - Date.now())),
        ),
      );
    }
    console.warn(
      "[psy-wallet][tx] submitted tx confirmation timed out; leaving it unresolved",
      {
        queueId: entry.queueId,
        hash: submitHash,
        attempt,
        reason: this._disposed
          ? "disposed"
          : entry.cancelRequestedAt != null || entry.status === "cancelled"
            ? "cancelled"
            : "timeout",
      },
    );
    return { confirmed: false, settledNonce };
  }

  private async waitForSubmittedNonceAdvance(
    address: string,
    userId: number | bigint,
    startedNonceRaw: string | undefined,
    context: {
      kind: string;
      groupId?: string;
      queueId?: string;
      txHash?: string | null;
    },
    options: {
      timeoutMs?: number;
      shouldStop?: () => boolean;
    } = {},
  ): Promise<string | undefined> {
    if (startedNonceRaw === undefined) {
      console.warn("[psy-wallet][tx] cannot confirm submitted tx by nonce", {
        ...context,
        address,
        reason: "missing start nonce",
      });
      return undefined;
    }

    let startedNonce: bigint;
    try {
      startedNonce = BigInt(startedNonceRaw);
    } catch {
      console.warn("[psy-wallet][tx] cannot confirm submitted tx by nonce", {
        ...context,
        address,
        startedNonce: startedNonceRaw,
        reason: "invalid start nonce",
      });
      return undefined;
    }

    let latestNonce: string | undefined;
    let nextWarnAt = Date.now() + 90_000;
    const timeoutMs = options.timeoutMs ?? SUBMITTED_CONFIRM_TIMEOUT_MS;
    const deadline = Date.now() + timeoutMs;
    let attempt = 0;
    while (!this._disposed && options.shouldStop?.() !== true) {
      attempt += 1;
      await this.updateCheckpointId().catch(() => undefined);
      latestNonce = await this._fetchOnChainNonce(userId);
      if (latestNonce !== undefined) {
        try {
          if (BigInt(latestNonce) > startedNonce) {
            await this.refreshQueuedWallet(address).catch(() => undefined);
            await this.refreshPsyState().catch(() => undefined);
            console.info("[psy-wallet][tx] submitted tx confirmed by nonce", {
              ...context,
              address,
              startedNonce: startedNonceRaw,
              latestNonce,
              attempt,
            });
            return latestNonce;
          }
        } catch {
          // Keep polling; a malformed transient value should not flip the tx.
        }
      }
      if (Date.now() >= nextWarnAt) {
        console.warn(
          "[psy-wallet][tx] submitted tx is still waiting for nonce confirmation",
          {
            ...context,
            address,
            startedNonce: startedNonceRaw,
            latestNonce: latestNonce ?? "unknown",
            attempt,
          },
        );
        nextWarnAt += 90_000;
      }
      if (Date.now() >= deadline) {
        console.warn(
          "[psy-wallet][tx] submitted tx confirmation timed out; leaving it unresolved",
          {
            ...context,
            address,
            startedNonce: startedNonceRaw,
            latestNonce: latestNonce ?? "unknown",
            timeoutMs,
            attempt,
          },
        );
        return undefined;
      }
      await new Promise((resolve) =>
        setTimeout(
          resolve,
          Math.min(1_500, Math.max(0, deadline - Date.now())),
        ),
      );
    }

    console.warn(
      "[psy-wallet][tx] stopped waiting for submitted tx confirmation",
      {
        ...context,
        address,
        startedNonce: startedNonceRaw,
        latestNonce: latestNonce ?? "unknown",
        reason: this._disposed ? "disposed" : "cancelled",
      },
    );
    return undefined;
  }

  /**
   * QA F-2: in-flight sends used to die silently with the service worker —
   * Activity rows vanished, holds released, zero feedback. Pending rows are
   * now persisted (transaction-manager) and restored at boot; once wallets
   * load, each interrupted group is reconciled against the chain:
   *
   *   - LANDED evidence: the chain's current nonce is PAST the nonce
   *     recorded at submission AND this is the wallet's only interrupted
   *     group (with siblings the advance could belong to any of them) →
   *     mark the rows complete.
   *   - otherwise → mark the rows FAILED with an honest "interrupted by
   *     restart" message telling the user to verify before retrying.
   *
   * NEVER auto-retry (a tx that DID land would be double-spent) and NEVER
   * silently drop. Balance holds need no special handling here: pending-
   * holds already drops "submitted" holds at boot, and txPendingFinished's
   * resolveGroup is a no-op for an absent hold.
   */
  private async _reconcileInterruptedSends(): Promise<void> {
    await transactionManager.whenPendingLoaded();
    if (this._disposed) return;
    const groups = transactionManager.takeRestoredPendingGroups();
    if (!groups.length) return;
    const groupsPerAddress = new Map<string, number>();
    for (const g of groups) {
      const addr = g.rows[0]?.publicKey ?? "";
      groupsPerAddress.set(addr, (groupsPerAddress.get(addr) ?? 0) + 1);
    }
    for (const { groupId, rows } of groups) {
      if (this._disposed) return;
      const address = rows[0]?.publicKey;
      const senderNonce = rows[0]?.senderNonce;
      const wallet = address
        ? this._wallets.find((w) => w.address === address)
        : undefined;
      let landed = false;
      if (
        wallet &&
        senderNonce !== undefined &&
        groupsPerAddress.get(address!) === 1
      ) {
        try {
          await this.updateCheckpointId();
          const current = await this._fetchOnChainNonce(wallet.userId);
          if (current !== undefined) {
            landed = BigInt(current) > BigInt(senderNonce);
          }
        } catch (error) {
          console.warn("[psy-wallet][tx] restart reconcile probe failed", {
            groupId,
            error,
          });
        }
      }
      console.info("[psy-wallet][tx] reconciled interrupted send", {
        groupId,
        rows: rows.length,
        landed,
      });
      if (landed) {
        await transactionManager.txPendingFinished(true, undefined, groupId);
      } else {
        await transactionManager.txPendingFinished(
          false,
          "Interrupted by a wallet restart before confirmation. Check this row in Activity or the explorer to see whether it went through BEFORE retrying — the wallet never retries a send automatically.",
          groupId,
        );
      }
    }
  }

  lock() {
    this._passwordManager.lock();
    this.invalidatePreviewTraces();
    // Drop the cached snapshot so refreshPsyState doesn't re-dispatch a locked
    // wallet's balance. (Display is already guarded by the current-wallet match.)
    this._lastWalletSnapshot = undefined;
    this.wallets = [];
    this.applyCurrentWalletState(undefined, { notifyDapps: false });
    void this.refreshPsyState();
  }

  async setAutoLockTimeout(timeoutMs: number) {
    await this._passwordManager.setAutoLockTimeout(timeoutMs);
    await this.refreshPsyState();
  }

  touchAutoLock() {
    this._passwordManager.touchAutoLock();
  }

  // Driven by the chrome.alarms auto-lock alarm (main.ts onAlarm). Locks the
  // wallet if its idle window has elapsed; otherwise re-arms the alarm. Safe to
  // call on a freshly-woken worker — boot's restoreSession has already run by
  // the time main.ts awaits the initial load.
  async enforceAutoLock() {
    await this._passwordManager.enforceAutoLock();
  }

  async saveWallets() {
    const walletData: IStorageWalletData = {
      networkKey: this._networkKey,
      activeWalletAddress: this._currentWallet?.address,
      wallets: await Promise.all(
        this._wallets.map((w) =>
          storeWalletFromWidgeWallet(w, this._networkKey),
        ),
      ),
    };
    psyStateDispatch({
      mnLength: this._passwordManager.getMnemonicsLength(),
    });
    return this._passwordManager.saveWalletData(walletData);
  }

  async exportAllWallets(password: string) {
    if (!password) throw Error("Incorrect password");
    // Industry-standard gate: re-enter wallet password before exporting keys
    // (MetaMask-style), even when the vault is already unlocked. Passwordless
    // wallets skip vault verify — the entered password only encrypts the file.
    const vaultEncrypted = await this._passwordManager.isEncrypted();
    if (vaultEncrypted) {
      const passwordIsCorrect = await this._passwordManager.verifyPassword(
        password,
        true,
      );
      if (!passwordIsCorrect) throw Error("Incorrect password");
    }

    // Backup format version 2: adds shieldReceiveAddresses per wallet.
    // Shielded addresses carry r0/r1 secrets that are generated client-side at
    // creation time and mirrored in WASM state — they are NOT re-derivable
    // from the mnemonic alone, so they must be included verbatim here.
    // The entire JSON blob is protected by the user's password (same key used
    // to ethers-encrypt the private key).
    const wallets = await Promise.all(
      this._wallets.map(async (w) => {
        const pk = await w.wallet.signer?.getPrivateKeyHex?.();
        if (!pk)
          throw Error(`can not get private key from wallet: ${w.address}`);
        const wallet = new ethers.Wallet(pk);
        const encrypted = await wallet.encrypt(password);
        const json = JSON.parse(encrypted);
        if (w.name) {
          json.name = w.name;
        }
        if (w.mnInd !== undefined && w.mnInd >= 0) {
          // json.mnInd = w.mnInd;
        }
        json.signType = w.signType;
        // Include the full shield-address list (with r0/r1) so that a
        // round-trip export → import preserves all private receive addresses.
        json.shieldReceiveAddresses = w.shieldReceiveAddresses ?? [];
        json.psyBackupVersion = 2;
        return json;
      }),
    );
    return wallets;
  }

  async addPassword(password: string) {
    const walletData: IStorageWalletData = {
      networkKey: this._networkKey,
      activeWalletAddress: this._currentWallet?.address,
      wallets: await Promise.all(
        this._wallets.map((w) =>
          storeWalletFromWidgeWallet(w, this._networkKey),
        ),
      ),
    };

    await this._passwordManager.setPassword(password, walletData);
    await this.refreshPsyState();
  }

  async changePassword({
    oldPassword,
    newPassword,
  }: {
    oldPassword: string;
    newPassword?: string;
  }) {
    return this._passwordManager.changePassword({ oldPassword, newPassword });
  }

  async getMnemonic(password: string, mnInd: number) {
    return this._passwordManager.getMnemonic(password, mnInd);
  }

  async genPrivateKey(mnInd: number) {
    return this._passwordManager.getPrivateKeyFromMnemonic(mnInd);
  }

  async newRandomWalletFailed(mnInd: number) {
    return this._passwordManager.newRandomWalletFailed(mnInd);
  }

  // operations
  async getBalance(address: string, contractId: Felt, checkpointId?: Felt) {
    const userId = this._wallets.find((w) => w.address === address)?.userId;
    if (userId === undefined) {
      throw Error("Wallet Not Found");
    }
    return this._providerReadQueue.run(async () => {
      if (BigInt(contractId) >= 5n) {
        const leaf =
          await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(
            contractId,
          );
        const pin = ftPinForContractLeaf(leaf);
        if (pin) {
          const balance =
            await this._provider.realmEdgeRpcProvider.getUserContractStateTreeLeafHash(
              checkpointId ?? this._checkpointId,
              userId,
              contractId,
              0,
            );
          return ftBalanceFromLeaf(balance, pin.profile);
        }
      }
      return fetchUserBalance(
        this._provider,
        checkpointId ?? this._checkpointId,
        userId,
        contractId,
      );
    });
  }

  async getUserId(address: string) {
    // Prefer an already-resolved id for a wallet we own. `userId` is the
    // validated on-chain id captured at registration/restore via tryGetUserId,
    // so it's authoritative — including a legitimate user 0. Only `< 0` (the
    // pending sentinel) or undefined means "not resolved yet" and needs a fetch.
    const cached = this._wallets.find((w) => w.address === address)?.userId;
    if (cached !== undefined && Number(cached) >= 0) {
      return cached;
    }

    // Cache miss / unresolved: resolve through the retrying lookup, NOT a single
    // bare RPC. A transient coordinator hiccup must never surface as a bogus `0`
    // — `0` is simultaneously a real account and the provider's unset/sentinel
    // value (current_user_id defaults to 0, realm 0 == coordinator), so a `0`
    // leaked from a failed lookup is indistinguishable from real user 0 and is
    // what made every account occasionally flash to Psy-00000000. tryGetUserId
    // retries and returns -1 when it genuinely can't resolve; we surface that as
    // an error so callers retry instead of treating it as user 0.
    const resolved = await this._providerReadQueue.run(() =>
      tryGetUserId(this._provider, address, 3),
    );
    if (Number(resolved) < 0) {
      throw new Error(
        `could not resolve userId for ${address} (transient lookup failure or unregistered account)`,
      );
    }
    return resolved;
  }

  /**
   * Self-heal a wallet whose stored userId no longer matches the chain.
   *
   * After a devnet reset (or any chain that re-registers users), the wallet
   * keeps its cached `userId`, but that id no longer resolves to this key on
   * the new chain — every send/claim then fails "not registered". This does a
   * cheap on-chain lookup for the wallet's public key and, when the stored id
   * is stale, rebuilds the wallet from its private key with `storedUserId`
   * cleared so `widgetWalletFromPrivateKey` re-resolves it: it ADOPTS a
   * different valid id if the key is already registered, or RE-REGISTERS the
   * key if the chain no longer knows it.
   *
   * Safe by construction: healthy wallets cost one extra getUserId read and
   * return early; the rebuild's tryGetUserId finds an existing id before it
   * would ever register, so a transient RPC miss can't mint a duplicate; and
   * the live wallet is swapped out only after the rebuild succeeds AND the id
   * actually changed.
   */
  private async reconcileWalletIdentity(address: string): Promise<void> {
    if (this._disposed) return;
    const wallet = this._wallets.find((w) => w.address === address);
    // Only reconcile wallets that believe they are registered — one with no
    // stored userId still flows through the normal registration path.
    if (!wallet || wallet.userId == null || Number(wallet.userId) < 0) return;
    if (this._identityHealInFlight.has(address)) return;
    // Don't race a user-initiated add/register on the shared prover.
    if (this._addWalletInFlight) return;
    this._identityHealInFlight.add(address);
    try {
      // Raw on-chain lookup (bypasses the stored userId so we can detect a
      // stale one). tryGetUserId retries and returns -1 when it genuinely
      // can't resolve — never a bogus 0 — so a transient miss doesn't look
      // like a real user 0.
      let chainUserId = -1;
      try {
        chainUserId = Number(
          await this._providerReadQueue.run(() =>
            tryGetUserId(this._provider, address, 3),
          ),
        );
      } catch {
        chainUserId = -1;
      }
      if (this._disposed) return;
      if (chainUserId >= 0 && chainUserId === Number(wallet.userId)) {
        return; // stored id still valid on chain — nothing to heal
      }

      const privateKey = await wallet.wallet.signer.getPrivateKeyHex?.();
      if (!privateKey) {
        console.warn(
          "[psy-wallet][core] cannot self-heal identity: private key unavailable",
          { address },
        );
        return;
      }

      console.info(
        "[psy-wallet][core] stored userId is stale; reconciling on-chain identity",
        { address, storedUserId: wallet.userId, chainUserId },
      );

      // Serialize against user-initiated adds and pause the warm-up loop while
      // the (possibly re-registering) rebuild runs on the shared prover.
      if (this._addWalletInFlight) return;
      this._addWalletInFlight = true;
      let healed: IPsyWidgetWallet | undefined;
      try {
        await this._waitForProver("reconcileWalletIdentity");
        if (this._disposed) return;
        healed = await widgetWalletFromPrivateKey(
          this._provider,
          privateKey,
          wallet.signType,
          wallet.fingerprint,
          wallet.mnInd,
          wallet.name,
          wallet.sdkKeyCircuitParams,
          () => this._disposed,
          "restore",
          undefined, // clear stored userId -> force fresh on-chain resolution
          undefined,
          undefined,
          this._networkKey,
        );
      } finally {
        this._addWalletInFlight = false;
      }
      if (this._disposed || !healed) return;

      // The rebuild found/registered the same id after all (e.g. the read was a
      // transient miss) — leave the live wallet untouched, no state churn.
      if (Number(healed.userId) === Number(wallet.userId)) return;

      // Rotate the shield receive identity. The userId genuinely changed, so
      // EVERY stored receive address — owner = Poseidon(oldUserId, 1337, r0,
      // r1) — is now cryptographically unclaimable by the healed identity and
      // must never be advertised again. KEEP the old addresses so their
      // incoming notes remain resolvable, but stamp each with its owner userId;
      // then guarantee at least one CURRENT-identity address exists.
      const healedWallet = healed;
      const preserved = this.backfillOwnerUserId(
        wallet.userId,
        wallet.shieldReceiveAddresses ?? [],
      );
      healedWallet.shieldReceiveAddresses = preserved;
      const hasCurrentAddress = hasCurrentIdentityAddress(
        healedWallet.userId,
        preserved,
      );
      if (!hasCurrentAddress) {
        try {
          const fresh = await this.deriveShieldReceiveAddressForWallet(
            healedWallet,
            "Private receive 1",
          );
          healedWallet.shieldReceiveAddresses = [...preserved, fresh];
        } catch (e) {
          console.warn(
            "[psy-wallet][core] could not derive a current-identity receive address after identity rotation; Receive screen may be empty until one is created",
            e,
          );
        }
      }

      void clearWalletSnapshotCache(this._chainKey, wallet.userId);
      // Swap the healed wallet in, keeping list order stable.
      const wasCurrent = this._currentWallet?.address === address;
      this.wallets = this._wallets.map((w) =>
        w.address === address ? healed! : w,
      );
      if (wasCurrent) {
        this._provider.realmEdgeRpcProvider.setUserId(healed.userId);
        this.currentWallet = healed;
      }
      await this.saveWallets();
      console.info("[psy-wallet][core] identity reconciled", {
        address,
        previousUserId: wallet.userId,
        newUserId: healed.userId,
      });
      if (wasCurrent) {
        void this.dispatchCachedWalletSnapshot(address);
        void this.buildCurrentWalletSnapshot(false).catch(() => undefined);
      }
    } finally {
      this._identityHealInFlight.delete(address);
    }
  }

  private async ensureLocalWalletUser(wallet: IPsyWidgetWallet) {
    const existing = this._localWalletUserReady.get(wallet.address);
    if (existing) {
      return existing;
    }

    const ready = (async () => {
      const signer = wallet.wallet.signer;
      const privateKey = await signer.getPrivateKeyHex?.();
      if (!privateKey) {
        throw Error(`can not get private key from wallet: ${wallet.address}`);
      }
      await signer.addUser(privateKey, wallet.signType, wallet.fingerprint);
    })().catch((error) => {
      this._localWalletUserReady.delete(wallet.address);
      throw error;
    });

    this._localWalletUserReady.set(wallet.address, ready);
    return ready;
  }

  private warmUpLocalWalletUsers() {
    const wallets = [
      ...(this._currentWallet ? [this._currentWallet] : []),
      ...this._wallets.filter(
        (w) => w.address !== this._currentWallet?.address,
      ),
    ];
    // 1s, not 0: this fires right after loadWallets, and _waitForProver now
    // lazily STARTS the deferred WASM circuit build. At 0ms it would race —
    // and lose against — the popup's first state paint (cached snapshot
    // dispatch), re-blocking the cold-start UI behind the build. By 1s the
    // post-paint kick in background/main.ts has already started the build,
    // so this just queues behind it; 1s is immaterial next to the build's
    // tens of seconds.
    setTimeout(() => {
      void (async () => {
        for (const wallet of wallets) {
          if (this._disposed) return;
          if (this._addWalletInFlight) return;
          try {
            await this._waitForProver("warmUpLocalWalletUsers");
            if (this._disposed || this._addWalletInFlight) return;
            await this.ensureLocalWalletUser(wallet);
          } catch (error) {
            console.warn("[psy-wallet][core] local wallet warmup failed", {
              error,
            });
          }
        }
      })();
    }, 1000);
  }

  private refreshWalletUserInfoCacheInBackground() {
    const addresses = [
      ...(this._currentWallet?.address ? [this._currentWallet.address] : []),
      ...this._wallets
        .map((wallet) => wallet.address)
        .filter((address) => address !== this._currentWallet?.address),
    ];

    setTimeout(() => {
      void (async () => {
        let changed = false;
        for (const address of addresses) {
          if (this._disposed) return;
          const wallet = this._wallets.find((w) => w.address === address);
          if (!wallet) continue;
          try {
            const refreshed = await refreshWidgetWallet(wallet);
            if (this._disposed) return;
            const index = this._wallets.findIndex((w) => w.address === address);
            if (index < 0) continue;
            const latest = this._wallets[index];
            const hasChanged =
              String(refreshed.balance) !== String(latest.balance) ||
              String(refreshed.nonce) !== String(latest.nonce) ||
              String(refreshed.userId) !== String(latest.userId) ||
              String(refreshed.l2NetworkMagic) !==
                String(latest.l2NetworkMagic);
            if (!hasChanged) continue;
            const merged = {
              ...refreshed,
              name: latest.name,
              mnInd: latest.mnInd,
              signType: latest.signType,
              fingerprint: latest.fingerprint,
              sdkKeyCircuitParams: latest.sdkKeyCircuitParams,
              shieldReceiveAddresses: latest.shieldReceiveAddresses ?? [],
            };
            const nextWallets = [...this._wallets];
            nextWallets[index] = merged;
            this.wallets = nextWallets;
            if (this._currentWallet?.address === address) {
              this.currentWallet = merged;
            }
            changed = true;
          } catch (error) {
            console.warn("[psy-wallet][core] cached user info refresh failed", {
              error,
            });
          }
        }
        if (changed && !this._disposed) {
          await this.saveWallets().catch((error) => {
            console.warn(
              "[psy-wallet][core] failed to persist refreshed user info cache",
              error,
            );
          });
        }
      })();
    }, 0);
  }

  async getClaimRewardsCallArgs(_jobInfos: string): Promise<ContractCallArgs[]> {
    throw new Error("getClaimRewardsCallArgs is unsupported by the selected SDK");
  }

  async getClaimAmount(
    checkpointId: Felt,
    contractId: Felt,
    receiveUserId: Felt,
    sentUserId: Felt,
  ) {
    return await this._providerReadQueue.run(async () => {
      if (BigInt(contractId) >= 5n) {
        const pin = ftPinForContractLeaf(await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(BigInt(contractId)));
        if (pin) {
          const counter = (owner: Felt, peer: Felt, claimed: boolean) => readFtCounter(pin, BigInt(peer), claimed, (slot) =>
            this._provider.realmEdgeRpcProvider.getRpcProviderByUserId(owner).getUserContractStateTreeLeafHash(checkpointId, owner, contractId, slot));
          const sent = await counter(sentUserId, receiveUserId, false);
          const claimed = await counter(receiveUserId, sentUserId, true);
          if (claimed > sent) throw new Error("FT claimed counter exceeds sent counter");
          return sent - claimed;
        }
      }
      return getClaimAmount(this._provider.realmEdgeRpcProvider, checkpointId, contractId, receiveUserId, sentUserId);
    });
  }

  /** Raw cumulative `total_sent[recipient]` from the SENDER's ledger — the
   *  transfer modal's first-touch fee probe (a fresh sender→recipient pair
   *  burns extra IMT-first-touch DA slots; see lib/fee.ts). Read-only, one
   *  slot fetch, no wallet/prover state touched. */
  async getSenderTotalSent(
    checkpointId: Felt,
    contractId: Felt,
    senderUserId: Felt,
    recipientUserId: Felt,
  ) {
    return await this._providerReadQueue.run(async () => {
      if (BigInt(contractId) >= 5n) {
        const pin = ftPinForContractLeaf(await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(BigInt(contractId)));
        if (pin) return readFtCounter(pin, BigInt(recipientUserId), false, (slot) =>
          this._provider.realmEdgeRpcProvider.getRpcProviderByUserId(senderUserId).getUserContractStateTreeLeafHash(checkpointId, senderUserId, contractId, slot));
      }
      return getSenderTotalSent(this._provider.realmEdgeRpcProvider, checkpointId, contractId, senderUserId, recipientUserId);
    });
  }

  // ── Psy faucet (server-side operator signing via faucet-server) ─────────
  //
  // Extension pages cannot reliably load Cloudflare Turnstile under MV3 CSP.
  // The wallet therefore opens the hosted app verification page, stores a
  // short-lived nonce locally, and only accepts the token back from that origin.
  // Faucet-server verifies the token and submits the faucet tx through the
  // same Turnstile-gated `psy_claim_faucet` method the web app uses.
  private async faucetRpc<T>(
    method: string,
    params: unknown[] = [],
  ): Promise<T> {
    const url = (
      this._config as typeof this._config & { faucet_rpc_url?: string[] }
    )?.faucet_rpc_url?.[0];
    if (!url) throw new Error("faucet_rpc_url is not configured");
    const startedAt = Date.now();
    faucetLog("faucet-server rpc start", {
      method,
      url: faucetRpcUrlLabel(url),
      params: sanitizeFaucetRpcParams(params),
    });
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
      });
      faucetLog("faucet-server rpc response", {
        method,
        status: res.status,
        ok: res.ok,
        elapsedMs: Date.now() - startedAt,
      });
      if (!res.ok) {
        throw new Error(
          `faucet-server RPC ${method} failed: HTTP ${res.status}`,
        );
      }
      const json = await res.json();
      if (json.error) {
        faucetWarn("faucet-server rpc json error", {
          method,
          elapsedMs: Date.now() - startedAt,
          error: json.error,
        });
        throw new Error(
          `faucet-server RPC ${method} error: ${
            json.error.message ?? JSON.stringify(json.error)
          }`,
        );
      }
      faucetLog("faucet-server rpc success", {
        method,
        elapsedMs: Date.now() - startedAt,
      });
      return json.result as T;
    } catch (error) {
      faucetWarn("faucet-server rpc failed", {
        method,
        elapsedMs: Date.now() - startedAt,
        error,
      });
      throw error;
    }
  }

  async getPsyFaucetConfig(): Promise<{
    enabled: boolean;
    faucetContractId: number;
    faucetMethodName: string;
    amount: bigint;
    windowCheckpoints: number;
    operatorUserIds: bigint[];
    turnstileRequired: boolean;
  }> {
    faucetLog("config load start");
    try {
      const raw = await this.faucetRpc<{
        enabled: boolean;
        faucet_contract_id: number;
        faucet_method_name: string;
        amount: string;
        window_checkpoints: number;
        operator_user_ids: number[];
        turnstile_required: boolean;
      }>("psy_get_psy_faucet_config");
      const config = {
        enabled: Boolean(raw.enabled),
        faucetContractId: Number(raw.faucet_contract_id ?? 0),
        faucetMethodName: raw.faucet_method_name ?? "faucet",
        amount: BigInt(raw.amount ?? "0"),
        windowCheckpoints: Number(raw.window_checkpoints ?? 0),
        operatorUserIds: Array.isArray(raw.operator_user_ids)
          ? raw.operator_user_ids.map((id) => BigInt(id))
          : [],
        turnstileRequired: Boolean(raw.turnstile_required),
      };
      faucetLog("config load success", {
        enabled: config.enabled,
        faucetContractId: config.faucetContractId,
        faucetMethodName: config.faucetMethodName,
        amount: String(config.amount),
        windowCheckpoints: config.windowCheckpoints,
        operatorUserIds: config.operatorUserIds.map(String),
        turnstileRequired: config.turnstileRequired,
      });
      return config;
    } catch (error) {
      faucetWarn("config load failed", { error });
      throw error;
    }
  }

  private async ensureFaucetWindowOpen(recipientUserId: Felt): Promise<void> {
    const marker = await loadFaucetCooldownMarker(
      this._chainKey,
      recipientUserId,
    );
    if (isFaucetCooldownActive(marker, this._checkpointId)) {
      // Tag the error as LOCAL so the claim catch-blocks never treat it as a
      // server "already claimed" verdict and re-write the marker. Without the
      // tag, every retry during a cooldown re-marked at the LIVE checkpoint,
      // extending the lockout a full window forward each tap — a stale or
      // mistaken marker became self-perpetuating and blocked users (including
      // freshly registered ones) the server would happily have granted.
      const err = new Error(FAUCET_WINDOW_ALREADY_USED_MESSAGE) as Error & {
        psyLocalFaucetCooldown?: boolean;
      };
      err.psyLocalFaucetCooldown = true;
      throw err;
    }
  }

  private async markFaucetWindowConsumed(
    recipientUserId: Felt,
    params: {
      checkpointId?: number;
      windowId?: number;
      windowCheckpoints?: number;
    },
  ): Promise<void> {
    // Never EXTEND an already-active cooldown. The error path re-marks with
    // the live checkpoint (no server window), so without this guard a retry
    // during a cooldown pushed nextEligible a full window forward each time.
    // The earliest recorded expiry always wins; marking is only additive when
    // there is no active marker at all.
    const existing = await loadFaucetCooldownMarker(
      this._chainKey,
      recipientUserId,
    );
    if (isFaucetCooldownActive(existing, this._checkpointId)) return;
    await markFaucetWindowUsed(this._chainKey, recipientUserId, {
      checkpointId:
        params.checkpointId && params.checkpointId > 0
          ? params.checkpointId
          : this._checkpointId,
      windowId: params.windowId,
      windowCheckpoints: params.windowCheckpoints,
    });
  }

  async beginPsyFaucetVerification(recipientUserId: Felt): Promise<{
    verificationUrl: string;
    state: string;
    expiresAt: number;
  }> {
    const wallet = this._currentWallet;
    faucetLog("begin verification start", {
      recipientUserId: String(recipientUserId),
      currentWalletAddress: wallet?.address,
      currentWalletUserId:
        wallet?.userId === undefined ? undefined : String(wallet.userId),
    });
    if (!wallet?.address || wallet.userId === undefined) {
      throw new Error("Wallet Not Found");
    }
    if (BigInt(wallet.userId) !== BigInt(recipientUserId)) {
      throw new Error("Faucet recipient does not match the active wallet");
    }

    const state = randomFaucetState();
    const origin = hostedFaucetOrigin();
    const now = Date.now();
    const pending: PendingFaucetVerification = {
      state,
      address: wallet.address,
      userId: String(recipientUserId),
      origin,
      createdAt: now,
      expiresAt: now + FAUCET_VERIFICATION_TTL_MS,
    };
    await this.savePendingFaucetVerification(pending);

    const result = {
      verificationUrl: hostedFaucetVerifyUrl({
        state,
        userId: recipientUserId,
      }),
      state,
      expiresAt: pending.expiresAt,
    };
    faucetLog("begin verification success", {
      state: faucetStateShort(state),
      origin,
      expiresAt: pending.expiresAt,
      verificationUrl: result.verificationUrl,
    });
    return result;
  }

  async completePsyFaucetTurnstile(
    input: CompleteFaucetTurnstileInput,
    origin?: string,
  ): Promise<FaucetCompletionResult> {
    const state = String(input?.state ?? "").trim();
    const token = String(input?.turnstile_token ?? "").trim();
    const recipientUserId = BigInt(input?.recipient_user_id ?? "");
    faucetLog("complete turnstile start", {
      state: faucetStateShort(state),
      origin,
      recipientUserId: String(recipientUserId),
      tokenLength: token.length,
    });
    if (!state || !token) throw new Error("Missing faucet verification token");

    const completionKey = `${state}:${recipientUserId}`;
    const existing = this._faucetCompletionPromises.get(completionKey);
    if (existing) {
      faucetLog("complete turnstile join in-flight", {
        state: faucetStateShort(state),
        recipientUserId: String(recipientUserId),
        origin,
      });
      return existing;
    }

    const completion = this.completePsyFaucetTurnstileOnce(
      state,
      token,
      recipientUserId,
      origin,
    );
    this._faucetCompletionPromises.set(completionKey, completion);
    try {
      return await completion;
    } finally {
      this._faucetCompletionPromises.delete(completionKey);
      faucetLog("complete turnstile in-flight cleared", {
        state: faucetStateShort(state),
        recipientUserId: String(recipientUserId),
      });
    }
  }

  private async completePsyFaucetTurnstileOnce(
    state: string,
    token: string,
    recipientUserId: bigint,
    origin?: string,
  ): Promise<FaucetCompletionResult> {
    const pending = await this.getPendingFaucetVerification(state);
    if (!pending)
      throw new Error("Faucet verification expired or was already used");
    if (origin !== pending.origin) {
      throw new Error("Faucet verification origin mismatch");
    }
    if (BigInt(pending.userId) !== recipientUserId) {
      throw new Error("Faucet verification recipient mismatch");
    }
    if (
      this._currentWallet &&
      (this._currentWallet.address !== pending.address ||
        BigInt(this._currentWallet.userId) !== recipientUserId)
    ) {
      throw new Error("Active wallet changed during faucet verification");
    }
    faucetLog("complete turnstile pending matched", {
      state: faucetStateShort(state),
      address: pending.address,
      userId: pending.userId,
      hasCachedClaimResult: Boolean(pending.claimResult),
    });

    const raw =
      pending.claimResult ??
      (await this.faucetRpc<FaucetClaimResult>("psy_claim_faucet", [
        {
          recipient_user_id: Number(String(recipientUserId)),
          turnstile_token: token,
          turnstile_state: state,
        },
      ]));
    const operatorUserId = BigInt(raw.operator_user_id);
    if (!pending.claimResult) {
      await this.savePendingFaucetVerification({
        ...pending,
        claimResult: raw,
      });
      faucetLog("complete turnstile claim result cached", {
        state: faucetStateShort(state),
        recipientUserId: String(recipientUserId),
        operatorUserId: String(operatorUserId),
        txHash: raw.tx_hash,
      });
    }
    faucetLog("complete turnstile claim submitted", {
      state: faucetStateShort(state),
      recipientUserId: String(recipientUserId),
      operatorUserId: String(operatorUserId),
      txHash: raw.tx_hash,
      amount: raw.amount,
      checkpointId: raw.checkpoint_id,
      windowId: raw.window_id,
      alreadySubmitted: Boolean(raw.already_submitted),
      fromCache: Boolean(pending.claimResult),
    });
    await this.waitForFaucetClaimableForResponse(
      recipientUserId,
      operatorUserId,
      Boolean(raw.already_submitted),
    );
    faucetLog("complete turnstile claimable ready", {
      state: faucetStateShort(state),
      recipientUserId: String(recipientUserId),
      operatorUserId: String(operatorUserId),
    });
    await this.refreshWalletForFreshClaim(recipientUserId);
    await this.waitForFaucetRollupClaimable(operatorUserId);
    faucetLog("complete turnstile wallet refreshed", {
      state: faucetStateShort(state),
      recipientUserId: String(recipientUserId),
    });
    return {
      address: pending.address,
      operator_user_id: Number(operatorUserId.toString()),
      tx_hash: raw.tx_hash,
      amount: raw.amount,
      checkpoint_id: Number(raw.checkpoint_id),
      window_id: Number(raw.window_id),
      already_submitted: Boolean(raw.already_submitted),
    };
  }

  async claimPsyFaucetWithTurnstile(
    recipientUserId: Felt,
    state: string,
    turnstileToken: string,
  ): Promise<{
    operatorUserId: bigint;
    txHash: string;
    amount: bigint;
    alreadySubmitted: boolean;
    // Checkpoint/window the faucet grant was recorded against, surfaced so
    // the popup can persist a local cooldown marker and show "available
    // again at checkpoint X" UP FRONT instead of an after-the-fact error.
    claimCheckpointId: number;
    claimWindowId: number;
  }> {
    faucetLog("claim with turnstile start", {
      recipientUserId: String(recipientUserId),
      state: faucetStateShort(state),
      tokenLength: turnstileToken.length,
    });
    try {
      await this.ensureFaucetWindowOpen(recipientUserId);
      const raw = await this.completePsyFaucetTurnstile(
        {
          state,
          recipient_user_id: String(recipientUserId),
          turnstile_token: turnstileToken,
        },
        hostedFaucetOrigin(),
      );
      const result = {
        operatorUserId: BigInt(raw.operator_user_id),
        txHash: raw.tx_hash,
        amount: BigInt(raw.amount),
        alreadySubmitted: Boolean(raw.already_submitted),
        claimCheckpointId: Number(raw.checkpoint_id ?? 0),
        claimWindowId: Number(raw.window_id ?? 0),
      };
      await this.markFaucetWindowConsumed(recipientUserId, {
        checkpointId: result.claimCheckpointId,
        windowId: result.claimWindowId,
      });
      faucetLog("claim with turnstile success", {
        recipientUserId: String(recipientUserId),
        state: faucetStateShort(state),
        operatorUserId: String(result.operatorUserId),
        txHash: result.txHash,
        amount: String(result.amount),
        alreadySubmitted: result.alreadySubmitted,
      });
      return result;
    } catch (error) {
      if (isFaucetWindowAlreadyUsedError(error)) {
        await this.markFaucetWindowConsumed(recipientUserId, {});
      }
      faucetWarn("claim with turnstile failed", {
        recipientUserId: String(recipientUserId),
        state: faucetStateShort(state),
        error,
      });
      throw error;
    }
  }

  // Asks faucet-server to submit the faucet transfer, then waits until the
  // resulting pending transfer is claimable on-chain. The UI refreshes
  // claimables after this; the user's later claim goes through the normal
  // Claim page flow.
  async claimPsyFaucetWallet(recipientUserId: Felt): Promise<{
    operatorUserId: bigint;
    txHash: string;
    amount: bigint;
    alreadySubmitted: boolean;
    // See claimPsyFaucetWithTurnstile — lets the popup persist the cooldown.
    claimCheckpointId: number;
    claimWindowId: number;
  }> {
    faucetLog("claim wallet start", {
      recipientUserId: String(recipientUserId),
    });
    try {
      const config = await this.getPsyFaucetConfig();
      faucetLog("claim wallet config ready", {
        recipientUserId: String(recipientUserId),
        enabled: config.enabled,
        turnstileRequired: config.turnstileRequired,
        amount: String(config.amount),
      });
      if (config.turnstileRequired) {
        throw new Error("Turnstile verification is required");
      }
      await this.ensureFaucetWindowOpen(recipientUserId);
      const raw = await this.faucetRpc<{
        tx_hash: string;
        operator_user_id: number;
        amount: string;
        checkpoint_id: number;
        window_id: number;
        already_submitted: boolean;
      }>("psy_claim_faucet", [
        {
          recipient_user_id: Number(String(recipientUserId)),
          turnstile_token: null,
        },
      ]);
      const operatorUserId = BigInt(raw.operator_user_id);
      const result = {
        operatorUserId,
        txHash: raw.tx_hash,
        amount: BigInt(raw.amount),
        alreadySubmitted: Boolean(raw.already_submitted),
        claimCheckpointId: Number(raw.checkpoint_id ?? 0),
        claimWindowId: Number(raw.window_id ?? 0),
      };
      faucetLog("claim wallet submitted", {
        recipientUserId: String(recipientUserId),
        operatorUserId: String(operatorUserId),
        txHash: raw.tx_hash,
        amount: raw.amount,
        checkpointId: raw.checkpoint_id,
        windowId: raw.window_id,
        alreadySubmitted: Boolean(raw.already_submitted),
      });
      await this.markFaucetWindowConsumed(recipientUserId, {
        checkpointId: result.claimCheckpointId,
        windowId: result.claimWindowId,
        windowCheckpoints: config.windowCheckpoints,
      });
      // The faucet tx is submitted but may not be in a checkpoint yet; the user's
      // simple_claim prover fails ("no pending claim") if we race ahead, so wait
      // for the operator→recipient transfer to become claimable first.
      await this.waitForFaucetClaimableForResponse(
        BigInt(recipientUserId),
        operatorUserId,
        Boolean(raw.already_submitted),
      );
      faucetLog("claim wallet claimable ready", {
        recipientUserId: String(recipientUserId),
        operatorUserId: String(operatorUserId),
      });
      await this.refreshWalletForFreshClaim(BigInt(recipientUserId));
      await this.waitForFaucetRollupClaimable(operatorUserId);
      faucetLog("claim wallet success", {
        recipientUserId: String(recipientUserId),
        operatorUserId: String(result.operatorUserId),
        txHash: result.txHash,
        amount: String(result.amount),
        alreadySubmitted: result.alreadySubmitted,
      });
      return result;
    } catch (error) {
      if (isFaucetWindowAlreadyUsedError(error)) {
        await this.markFaucetWindowConsumed(recipientUserId, {});
      }
      faucetWarn("claim wallet failed", {
        recipientUserId: String(recipientUserId),
        error,
      });
      throw error;
    }
  }

  /** Keep the faucet wait animation active until the services-backed wallet
   * snapshot contains the operator's public claimable. No durable expectation:
   * a timeout simply allows the next normal rollup to self-heal the UI. */
  private async waitForFaucetRollupClaimable(
    operatorUserId: bigint,
    timeoutMs = 30_000,
    intervalMs = 2_000,
  ): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    do {
      await this.buildCurrentWalletSnapshot(true);
      const found = this._lastWalletSnapshot?.claimableItems?.some(
        (item) =>
          item.kind === "public" &&
          item.senderUserId === String(operatorUserId) &&
          item.amount !== "0",
      );
      if (found) return;
      if (Date.now() >= deadline) return;
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
    } while (!this._disposed);
  }

  private async loadPendingFaucetVerifications(): Promise<
    PendingFaucetVerification[]
  > {
    const now = Date.now();
    pendingFaucetVerifications = pendingFaucetVerifications
      .filter((item) => {
        return (
          item &&
          typeof item.state === "string" &&
          typeof item.address === "string" &&
          typeof item.userId === "string" &&
          typeof item.origin === "string" &&
          typeof item.expiresAt === "number" &&
          item.expiresAt > now
        );
      })
      .slice(-20);
    return [...pendingFaucetVerifications];
  }

  private async savePendingFaucetVerification(
    pending: PendingFaucetVerification,
  ): Promise<void> {
    const items = (await this.loadPendingFaucetVerifications()).filter(
      (item) => item.state !== pending.state,
    );
    items.push(pending);
    pendingFaucetVerifications = items.slice(-20);
  }

  private async getPendingFaucetVerification(
    state: string,
  ): Promise<PendingFaucetVerification | null> {
    const items = await this.loadPendingFaucetVerifications();
    return items.find((item) => item.state === state) ?? null;
  }

  private async waitForFaucetClaimable(
    recipientUserId: bigint,
    operatorUserId: bigint,
    timeoutMs = 240_000,
    intervalMs = 2_000,
  ): Promise<void> {
    const PSY_TOKEN_CONTRACT_ID = BigInt(this._nativeContractId);
    const deadline = Date.now() + timeoutMs;
    const startedAt = Date.now();
    let attempt = 0;
    faucetLog("wait claimable start", {
      recipientUserId: String(recipientUserId),
      operatorUserId: String(operatorUserId),
      timeoutMs,
      intervalMs,
    });
    while (Date.now() < deadline) {
      attempt += 1;
      if (this._disposed) throw new Error("wallet disposed");
      const checkpointId = await this._providerReadQueue.run(() =>
        fetchBlockNumber(this._provider),
      );
      try {
        const amount = await this.getClaimAmount(
          BigInt(checkpointId) as unknown as Felt,
          PSY_TOKEN_CONTRACT_ID as unknown as Felt,
          recipientUserId as unknown as Felt,
          operatorUserId as unknown as Felt,
        );
        if (BigInt(amount) > 0n) {
          faucetLog("wait claimable success", {
            recipientUserId: String(recipientUserId),
            operatorUserId: String(operatorUserId),
            checkpointId,
            amount: String(amount),
            attempt,
            elapsedMs: Date.now() - startedAt,
          });
          return;
        }
        if (attempt === 1 || attempt % 5 === 0) {
          faucetLog("wait claimable pending", {
            recipientUserId: String(recipientUserId),
            operatorUserId: String(operatorUserId),
            checkpointId,
            amount: String(amount),
            attempt,
            elapsedMs: Date.now() - startedAt,
          });
        }
      } catch (error) {
        if (attempt === 1 || attempt % 5 === 0) {
          faucetWarn("wait claimable transient error", {
            recipientUserId: String(recipientUserId),
            operatorUserId: String(operatorUserId),
            checkpointId,
            attempt,
            elapsedMs: Date.now() - startedAt,
            error,
          });
        }
        // Transient (chain state not yet at this checkpoint) — keep polling.
      }
      await new Promise((rsv) => setTimeout(rsv, intervalMs));
    }
    faucetWarn("wait claimable timed out", {
      recipientUserId: String(recipientUserId),
      operatorUserId: String(operatorUserId),
      attempts: attempt,
      elapsedMs: Date.now() - startedAt,
      timeoutMs,
    });
    throw new Error(
      "timed out waiting for the faucet transfer to land on-chain",
    );
  }

  private async waitForFaucetClaimableForResponse(
    recipientUserId: bigint,
    operatorUserId: bigint,
    alreadySubmitted: boolean,
  ): Promise<void> {
    faucetLog("wait claimable for response start", {
      recipientUserId: String(recipientUserId),
      operatorUserId: String(operatorUserId),
      alreadySubmitted,
    });
    try {
      await this.waitForFaucetClaimable(
        recipientUserId,
        operatorUserId,
        alreadySubmitted ? FAUCET_ALREADY_SUBMITTED_WAIT_MS : undefined,
      );
      faucetLog("wait claimable for response success", {
        recipientUserId: String(recipientUserId),
        operatorUserId: String(operatorUserId),
        alreadySubmitted,
      });
    } catch (error) {
      faucetWarn("wait claimable for response failed", {
        recipientUserId: String(recipientUserId),
        operatorUserId: String(operatorUserId),
        alreadySubmitted,
        error,
      });
      if (alreadySubmitted) {
        throw new Error(FAUCET_WINDOW_ALREADY_USED_MESSAGE);
      }
      throw error;
    }
  }

  private async refreshWalletForFreshClaim(
    recipientUserId: bigint,
    attempts = 3,
  ): Promise<void> {
    const wallet = this._currentWallet;
    if (!wallet) throw new Error("Wallet Not Found");
    if (BigInt(wallet.userId) !== recipientUserId) {
      throw new Error("Active wallet changed before faucet claim");
    }

    let lastError: unknown;
    faucetLog("refresh wallet for fresh claim start", {
      recipientUserId: String(recipientUserId),
      attempts,
      address: wallet.address,
    });
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        faucetLog("refresh wallet attempt start", {
          recipientUserId: String(recipientUserId),
          attempt: attempt + 1,
        });
        await wallet.wallet.refresh();
        await this.updateCheckpointId();
        await this.refreshPsyState();
        faucetLog("refresh wallet attempt success", {
          recipientUserId: String(recipientUserId),
          attempt: attempt + 1,
          checkpointId: this.checkpointId,
        });
        return;
      } catch (error) {
        lastError = error;
        faucetWarn("refresh wallet attempt failed", {
          recipientUserId: String(recipientUserId),
          attempt: attempt + 1,
          error,
        });
        if (attempt + 1 < attempts) {
          await new Promise((resolve) => setTimeout(resolve, 1_000));
        }
      }
    }

    throw lastError instanceof Error
      ? lastError
      : new Error("failed to refresh wallet state before faucet claim");
  }

  // Extension-internal only. Not a web RPC approval or financial capability.
  // No native adapter can be supplied by the dApp. Unavailable native checks
  // retain the exact capsule as unverified and close every broadcast path.
  private marketPreparation() {
    if (this._marketPreparation) return this._marketPreparation;
    const options: Parameters<typeof createPrepareOnlyMarketService>[0] = {
      store: extStorage,
      bundle: marketPreparationBundle,
      provider: this._provider,
      parse: (text) => PsyJSON.parse(text),
      stringify: (value) => PsyJSON.stringify(value),
      prepareTrace: async (record, context) => {
        if (
          this._disposed ||
          this.isWalletLocked() ||
          this._currentWallet?.address !== context.account
        )
          throw Error("Selected unlocked ordinary wallet required");
        const wallet = this._wallets.find((w) => w.address === context.account);
        if (
          !wallet ||
          wallet.signType !== SignType.ZKSign ||
          Number(wallet.userId) !== context.userId
        )
          throw Error(
            "Market preparation requires the approved ordinary signing identity",
          );
        await this.marketPreparation().assertNetwork(this._config);
        await this._waitForProver("market prepare-only");
        await this.ensureWalletUserInWasm(wallet);
        await wallet.wallet.refresh();
        const generate = wallet.wallet.generateTxTrace?.bind(wallet.wallet);
        if (!generate) throw Error("Proof-only trace API unavailable");
        return generate(
          context.account,
          record.plan.calls as ContractCallArgs[],
        );
      },
    };
    const installed = installedMarketOptions(marketPreparationBundle);
    if (installed) {
      this._marketExecution = createMarketWalletService({...options, ...installed,
        confirmBroadcast: terms => this.confirmPreparedMarket(terms)});
      return (this._marketPreparation = this._marketExecution);
    }
    return (this._marketPreparation = createPrepareOnlyMarketService(options));
  }

  private async confirmPreparedMarket(input: unknown) {
    const {terms} = await marketConfirmation(input);
    const assertCurrent = async () => {
      const current = await this.marketPreparationContext(terms.context.account, terms.context.origin);
      if (Object.entries(current).some(([key, value]) => terms.context[key as keyof PreparationContext] !== value))
        throw Error("Wallet identity changed during exact market approval");
    };
    await assertCurrent();
    const result = await approveManager.confirmPreparedMarket(terms);
    await assertCurrent();
    return result;
  }

  private marketExecution(): MarketWalletService {
    this.marketPreparation();
    if (!this._marketExecution)
      throw Error("Reviewed instance-specific native release is not installed; market writes remain closed");
    return this._marketExecution;
  }

  getMarketWriteCapabilities() {
    return {...this.marketPreparation().capabilities(),
      registryHashes: [marketPreparationBundle.registryHash, marketPreparationBundle.amm.registryHash],
      chainRootAt1: marketPreparationBundle.registry.network.chainRootAt1,
      enabledMarketIds: [...marketPreparationBundle.registry.markets, ...marketPreparationBundle.amm.registry.markets]
        .filter(m => m.kind !== "nftmarket" && !("quarantined" in m && m.quarantined === true)).map(m => m.marketId),
      nftWrite: false, liveAcceptanceComplete: false};
  }

  private async marketPreparationContext(
    address: string,
    origin: string,
  ): Promise<PreparationContext> {
    if (
      this._disposed ||
      this.isWalletLocked() ||
      this._currentWallet?.address !== address
    )
      throw Error("Selected unlocked wallet required");
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet || wallet.signType !== SignType.ZKSign || !wallet.fingerprint)
      throw Error("Pinned ordinary signing fingerprint unavailable");
    await this.marketPreparation().assertNetwork(this._config);
    return this.marketPreparation().contextFor({
      origin,
      account: address,
      userId: Number(wallet.userId),
      fingerprint: wallet.fingerprint,
      chainKey: this._chainKey,
    });
  }

  async prepareMarketTransaction(
    address: string,
    origin: string,
    record: PreparationRecord,
  ) {
    if (!this.getMarketWriteCapabilities().enabledMarketIds.includes(record.plan.marketId))
      throw Error("Market is quarantined or its native intent postcondition remains closed");
    const context = await this.marketPreparationContext(address, origin);
    // This is the same FIFO barrier as ordinary wallet writes. Nonce witnesses
    // are generated inside it; prepared intents also gate later legacy jobs.
    return txQueue.runExclusive(async () => {
      await txQueue.assertReadyForMarket(address);
      // Legacy cancellation or a failed UI row cannot prove rejection. Until
      // the native original-receipt adapter is accepted, preserve and refuse
      // every previously proved/submitted trace for this account.
      const legacy = await traceStore.list(this._chainKey);
      if (
        legacy.some(
          (trace) => trace.address === address && trace.status !== "generated",
        )
      )
        throw Error(
          "Legacy trace history requires original-receipt reconciliation before market preparation",
        );
      return this.marketPreparation().prepare(context, record);
    });
  }

  async listMarketPreparations(address: string, origin: string) {
    return this.marketPreparation().list(
      await this.marketPreparationContext(address, origin),
    );
  }

  async cancelMarketPreparation(
    address: string,
    origin: string,
    intentId: string,
  ) {
    const context = await this.marketPreparationContext(address, origin);
    return txQueue.runExclusive(() =>
      this.marketPreparation().cancelPreparation(context, intentId),
    );
  }

  async verifyMarketPreparation(address: string, origin: string, intentId: string) {
    const context = await this.marketPreparationContext(address, origin);
    return txQueue.runExclusive(async () => {
      await txQueue.assertReadyForMarket(address);
      return this.marketExecution().verify(context, intentId);
    });
  }

  async broadcastMarketPreparation(address: string, origin: string, intentId: string, preparedHash: string) {
    const context = await this.marketPreparationContext(address, origin);
    return txQueue.runExclusive(async () => {
      await txQueue.assertReadyForMarket(address);
      return this.marketExecution().broadcast(context, intentId, preparedHash);
    });
  }

  async reconcileMarketPreparation(address: string, origin: string, intentId: string) {
    const context = await this.marketPreparationContext(address, origin);
    return txQueue.runExclusive(() => this.marketExecution().reconcile(context, intentId));
  }

  async enqueueTx<K extends TxQueueJobKind>(
    kind: K,
    address: string,
    payload: TxQueuePayloadFor<K>,
    opts?: TxQueueEnqueueOptions,
  ): Promise<string> {
    await this.marketPreparation().assertNoPending(address, this._chainKey);
    return txQueue.enqueue(kind, address, payload, opts);
  }

  async awaitTx(queueId: string): Promise<unknown> {
    return txQueue.awaitTx(queueId);
  }

  async cancelTx(queueId: string) {
    return txQueue.cancel(queueId);
  }

  async retryTx(queueId: string) {
    return txQueue.retry(queueId);
  }

  async execContractCall(
    address: string,
    args: ContractCallArgs | ContractCallArgs[],
  ): Promise<SdkTxResult> {
    const queueId = await this.enqueueTx("contract_call", address, args);
    return (await this.awaitTx(queueId)) as SdkTxResult;
  }

  private async executeQueuedContractCall(
    address: string,
    args: ContractCallArgs | ContractCallArgs[],
    queueId?: string,
    onTraceStep?: (step: string) => void,
    previewTxHash?: string,
  ): Promise<SdkTxResult> {
    await this._waitForProver("execContractCall");
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) throw Error("Wallet Not Found");
    if (Array.isArray(args) && !args.length) throw Error("Empty args");

    await this.updateCheckpointId();
    if (containsSimpleClaimCall(args)) {
      await wallet.wallet.refresh();
      await this.updateCheckpointId();
    }

    const txs = queueId
      ? []
      : transactionManager.genTxFromContractCall(
          address,
          args,
          this.checkpointId,
          await this._fetchOnChainNonce(wallet.userId),
        );
    const groupId = queueId ?? txs[0]?.groupId;
    transactionManager.setGroupPhase(groupId, "queued");
    try {
      const gets = await Promise.all(
        txs
          .filter((tx) => tx.name === "Claim")
          .map(async (tx) => {
            tx.value = await this.getClaimAmount(
              tx.checkpointId,
              tx.args?.contract_id!,
              wallet.userId,
              tx.args?.inputs[0]!,
            );
          }),
      );
      if (gets.length) transactionManager.refreshTxState();
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      await transactionManager.txPendingFinished(false, message, groupId);
      throw error;
    }

    const generateTxTrace = wallet.wallet.generateTxTrace?.bind(wallet.wallet);
    const executeOnce = async (
      callArgs: ContractCallArgs | ContractCallArgs[],
      usePreviewTxHash?: string,
    ): Promise<SdkTxResult> => {
      if (!generateTxTrace) {
        throw new Error(
          "Cannot submit transaction: generateTxTrace API unavailable",
        );
      }
      if (!usePreviewTxHash) {
        return this.runTraceTwoStep(
          address,
          "contract_call",
          queueId,
          () => generateTxTrace(address, callArgs),
          onTraceStep,
        );
      }

      const calls = Array.isArray(callArgs) ? callArgs : [callArgs];
      const itemsHash = hashClaimBatchItems(
        calls.map((data) => ({ type: "public" as const, data })),
      );
      const memoryRecord = this._previewTraceRecords.get(usePreviewTxHash);
      this._previewTraceRecords.delete(usePreviewTxHash);
      // The hydrated envelope lives only in memory. If it is gone the
      // durable preview is still `generated`, so one-shot removal cleans it
      // and we fail closed WITHOUT invoking CAS — never repin a durable
      // preview to proving before confirming the matching memory record.
      if (!memoryRecord) {
        await traceStore.removeGeneratedPreview(
          this._chainKey,
          address,
          usePreviewTxHash,
        );
        throw this.exactPreviewInvalidated();
      }
      const durableIdentity = await traceStore.consumeGeneratedPreview(
        this._chainKey,
        usePreviewTxHash,
        {
          address,
          networkKey: this._networkKey,
          kind: "contract_call",
          itemsHash,
          queueId: queueId ?? groupId!,
        },
      );
      if (!durableIdentity) {
        // CAS missed: the durable record is still `generated`, so one-shot
        // removal applies and no proving record is left behind.
        await traceStore.removeGeneratedPreview(
          this._chainKey,
          address,
          usePreviewTxHash,
        );
        throw this.exactPreviewInvalidated();
      }
      memoryRecord.queueId = queueId ?? groupId!;
      memoryRecord.status = "proving";
      this.cancelPreviewTraceTimer(memoryRecord.txHash);
      try {
        return await this.proveTraceRecordBySteps(wallet, memoryRecord, false);
      } catch (error) {
        // CAS already repinned the record to proving; removeGeneratedPreview
        // would no-op (it only drops `generated` records) and orphan it, so
        // drop the proving record unconditionally instead.
        await traceStore.remove(memoryRecord.chainKey, memoryRecord.txHash);
        throw error;
      }
    };

    return this._enqueueTxSubmit(async () => {
      transactionManager.setGroupPhase(groupId, "proving");
      const confirmSubmittedResult = async (result: SdkTxResult) => {
        transactionManager.setGroupPhase(groupId, "confirming");
        if (queueId) return result;
        await this.waitForSubmittedNonceAdvance(
          address,
          wallet.userId,
          txs[0]?.senderNonce,
          {
            kind: "contract_call",
            groupId,
            queueId,
            txHash: txHashFromSdkResult(result),
          },
        );
        return result;
      };
      try {
        const result = await confirmSubmittedResult(
          await executeOnce(args, previewTxHash),
        );
        if (queueId) return result;
        await transactionManager.txPendingFinished(true, result, groupId);
        return result;
      } catch (error) {
        if (await this.hasPrivateFtSubmissionIntent(wallet, queueId))
          throw error;
        if (previewTxHash) {
          const exactError = this.exactPreviewInvalidated();
          if (queueId) throw exactError;
          await transactionManager.txPendingFinished(
            false,
            exactError.message,
            groupId,
          );
          throw exactError;
        }

        let currentError: unknown = error;
        const firstMessage =
          currentError instanceof Error
            ? currentError.message
            : String(currentError);
        if (isTransientProveError(firstMessage)) {
          await new Promise((resolve) => setTimeout(resolve, 2500));
          try {
            const result = await confirmSubmittedResult(
              await executeOnce(args),
            );
            if (queueId) return result;
            await transactionManager.txPendingFinished(true, result, groupId);
            return result;
          } catch (retryError) {
            currentError = retryError;
          }
        }
        if (isStateRefreshRetryError(currentError)) {
          try {
            await wallet.wallet.refresh();
            transactionManager.refreshTxState();
            const result = await confirmSubmittedResult(
              await executeOnce(args),
            );
            if (queueId) return result;
            await transactionManager.txPendingFinished(true, result, groupId);
            return result;
          } catch (retryError) {
            if (queueId) throw retryError;
            const message =
              retryError instanceof Error
                ? retryError.message
                : String(retryError);
            await transactionManager.txPendingFinished(false, message, groupId);
            throw retryError;
          }
        }

        if (queueId) throw currentError;
        const message =
          currentError instanceof Error
            ? currentError.message
            : String(currentError);
        await transactionManager.txPendingFinished(false, message, groupId);
        throw currentError;
      }
    });
  }

  // Durable-queue worker entry point: tx_queue owns Activity/pending-hold
  // projection; this function only executes the already queued claim batch.
  // The durable queueId is forwarded so the persisted trace is keyed to the
  // entry that recovery looks up.
  private async executeQueuedClaimBatch(
    address: string,
    claims: ClaimBatchItem[],
    queueId?: string,
    onTraceStep?: (step: string) => void,
    previewTxHash?: string,
    exactFoldExecution = false,
  ): Promise<SdkTxResult> {
    // Pass the durable tx-queue id so the persisted trace is keyed to the
    // entry that recovery looks up (entry.queueId), not the per-run groupId.
    return (await this.execClaimBatch(
      address,
      claims,
      onTraceStep || previewTxHash || exactFoldExecution
        ? {
            ...(onTraceStep ? { onTraceStep } : {}),
            ...(previewTxHash ? { previewTxHash } : {}),
            ...(exactFoldExecution
              ? { exactFoldExecution: true as const }
              : {}),
          }
        : undefined,
      queueId,
    )) as SdkTxResult;
  }

  private async inputsForClaimsOrThrow(
    address: string,
    claims: ClaimBatchItem[] | undefined,
    supplied?: TxInput[],
  ): Promise<TxInput[] | undefined> {
    let inputs = mergeInputs(
      ...(claims ?? []).map(inputsForClaimItem),
      supplied,
    );
    const wallet = this._wallets.find((w) => w.address === address);

    for (const item of claims ?? []) {
      if (item.type !== "public") continue;
      const data = item.data as ContractCallArgs;
      if (!isPublicTokenCall(data, "claim")) continue;

      const senderUserId = data.inputs?.[0];
      const input = publicClaimInput({
        contractId: String(data.contract_id ?? "0"),
        senderUserId: String(senderUserId ?? ""),
      });
      const existing = inputs.find((candidate) => candidate.key === input.key);
      if (existing?.amount && BigInt(existing.amount) > 0n) continue;

      if (wallet) {
        try {
          const amount = await this.getClaimAmount(
            this.checkpointId,
            data.contract_id,
            wallet.userId,
            senderUserId,
          );
          if (BigInt(amount) > 0n) {
            inputs = mergeInputs(inputs, [
              { ...input, amount: String(amount) },
            ]);
            continue;
          }
        } catch {
          // Fail below. A claim without its real input amount would create a
          // +0 Activity row and no incoming hold.
        }
      }

      throw new Error(
        `Unable to resolve public claim input ${input.key}. Refresh claimables and retry.`,
      );
    }

    return inputs.length > 0 ? inputs : undefined;
  }
  /** Materialize every execution-affecting claim field before trace generation. */
  private async prepareClaimBatchItems(
    address: string,
    wallet: IPsyWidgetWallet,
    sourceClaims: ClaimBatchItem[],
    exactFoldExecution = false,
  ): Promise<ClaimBatchItem[]> {
    let claims = structuredClone(sourceClaims);
    const pins = new Map<string, Awaited<ReturnType<typeof ftPinForContractLeaf>>>();
    for (let index = 0; index < claims.length; index++) {
      const item = claims[index];
      if (item.type !== "public" || !["simple_transfer", "simple_claim"].includes(item.data.method_name)) continue;
      const contractId = BigInt(item.data.contract_id);
      if (contractId < 5n) continue;
      const key = String(contractId);
      if (!pins.has(key)) pins.set(key, ftPinForContractLeaf(await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(contractId)));
      claims[index] = adaptPublicFtCall(item, pins.get(key) ?? null);
    }
    for (const claim of claims) {
      if (claim.type === "private_transfer") {
        normalizePrivateTransferNoteProof(
          claim.data.claim as unknown as Record<string, unknown>,
        );
      }
    }
    const identity = await resolvePrivateClaimReceiveIdentities({
      claims,
      userId: wallet.userId,
      resolveSecrets: async (shieldAddress) => {
        await this.ensureShieldReceiveAddress(address, shieldAddress);
        return this.getShieldReceiveAddressSecrets(address, shieldAddress);
      },
      listReceiveSecrets: async () =>
        (wallet.shieldReceiveAddresses ?? []).map((entry) => ({
          r0: entry.r0,
          r1: entry.r1,
        })),
    });
    if (identity.excluded.length > 0) {
      console.warn(
        "[execClaimBatch] excluded private-note claims without a matching receive identity",
        identity.excluded,
      );
      const reasons = identity.excluded.map((item) => item.reason).join("; ");
      if (exactFoldExecution) {
        throw new Error(
          `Exact reviewed claim batch could not materialize every item: ${reasons}`,
        );
      }
      if (identity.claims.length === 0) throw new Error(reasons);
      const shortfall = await assessClaimBatchAffordability({
        claims: identity.claims,
        balanceOf: async (contractId) =>
          BigInt(await this.getBalance(address, BigInt(contractId))),
        publicClaimAmount: async (contractId, senderUserId) => {
          try {
            return BigInt(
              await this.getClaimAmount(
                this.checkpointId,
                BigInt(contractId),
                wallet.userId,
                BigInt(senderUserId),
              ),
            );
          } catch {
            return null;
          }
        },
      }).catch(() => null);
      if (shortfall) {
        throw new Error(
          `Cannot fund this send after excluding ${identity.excluded.length} unclaimable item(s): ` +
            `balance ${shortfall.balance} + remaining claimable ${shortfall.incoming} < spend ${shortfall.spend} ` +
            `on contract ${shortfall.contractId} (short ${shortfall.shortfall}). ${reasons}`,
        );
      }
    }
    claims = identity.claims;

    for (const claim of claims) {
      if (claim.type !== "claim_shield_deposit") continue;
      const raw = claim.data as Extract<
        ClaimBatchItem,
        { type: "claim_shield_deposit" }
      >["data"] & { shield_start_index?: unknown; shield_address?: string };
      if (!raw.shield_address) continue;
      const startIdxRaw = raw.shield_start_index;
      const startIdx =
        startIdxRaw != null && startIdxRaw !== ""
          ? Number(startIdxRaw)
          : undefined;
      await this.ensureShieldReceiveAddress(
        address,
        raw.shield_address,
        Number.isFinite(startIdx) ? startIdx : undefined,
      );
      const normalizedShieldAddress = normalizeShieldAddress(
        raw.shield_address,
      );
      const { r0, r1 } = this.getShieldReceiveAddressSecrets(
        address,
        raw.shield_address,
      );
      if (normalizedShieldAddress) raw.shield_address = normalizedShieldAddress;
      raw.random0 = String(r0);
      raw.random1 = String(r1);
    }
    return claims;
  }

  private exactPreviewInvalidated(): Error {
    return new Error(
      "The reviewed transaction preview is no longer available or no longer matches this plan. Re-preview and confirm again.",
    );
  }

  private consumePreparedPreviewClaims(
    address: string,
    txHash: string,
    queuedClaims: ClaimBatchItem[],
  ): { claims: ClaimBatchItem[]; queuedItemsHash: string } | undefined {
    const plan = this._preparedPreviewClaims.get(txHash);
    this._preparedPreviewClaims.delete(txHash);
    const now = Date.now();
    const queuedItemsHash = hashClaimBatchItems(queuedClaims);
    if (
      !plan ||
      plan.address !== address ||
      now < plan.createdAt ||
      now - plan.createdAt > PREVIEW_TRACE_TTL_MS ||
      plan.queuedItemsHash !== queuedItemsHash
    ) {
      return undefined;
    }
    return { claims: plan.claims, queuedItemsHash };
  }

  private async proveExactPreviewClaimBatch(
    wallet: IPsyWidgetWallet,
    address: string,
    txHash: string,
    queueId: string,
    items: ClaimBatchItem[],
  ): Promise<SdkTxResult> {
    const prepared = this.consumePreparedPreviewClaims(address, txHash, items);
    const memoryRecord = this._previewTraceRecords.get(txHash);
    this._previewTraceRecords.delete(txHash);
    // Fail closed WITHOUT invoking CAS when the in-memory plan or hydrated
    // envelope is gone. The durable preview is still `generated` at this
    // point, so one-shot removal cleans it; CAS must never repin a durable
    // preview to proving before the matching memory material is confirmed.
    if (!prepared || !memoryRecord) {
      await traceStore.removeGeneratedPreview(this._chainKey, address, txHash);
      throw this.exactPreviewInvalidated();
    }
    const durableIdentity = await traceStore.consumeGeneratedPreview(
      this._chainKey,
      txHash,
      {
        address,
        networkKey: this._networkKey,
        kind: "claim_batch",
        itemsHash: prepared.queuedItemsHash,
        queueId,
      },
    );
    if (!durableIdentity) {
      // CAS missed: the durable record is still `generated`, so one-shot
      // removal applies and no proving record is left behind.
      await traceStore.removeGeneratedPreview(this._chainKey, address, txHash);
      throw this.exactPreviewInvalidated();
    }
    memoryRecord.queueId = queueId;
    memoryRecord.status = "proving";
    this.cancelPreviewTraceTimer(memoryRecord.txHash);
    try {
      return await this.proveTraceRecordBySteps(wallet, memoryRecord, false);
    } catch (error) {
      // CAS already repinned the record to proving; removeGeneratedPreview
      // would no-op (it only drops `generated` records) and orphan it, so
      // drop the proving record unconditionally instead.
      await traceStore.remove(memoryRecord.chainKey, memoryRecord.txHash);
      throw error;
    }
  }

  async execClaimBatch(
    address: string,
    claims: ClaimBatchItem[],
    // Internal (startSendBatch) milestone hook — fires once this batch's
    // Activity rows + balance hold are persisted, i.e. the send now
    // SURVIVES popup/UI death. Popup-facing messages never pass this.
    hooks?: {
      onPendingRows?: (groupId: string | undefined) => void;
      onTraceStep?: (step: string) => void;
      inputs?: TxInput[];
      feeCoverItemCount?: number;
      previewTxHash?: string;
      exactFoldExecution?: true;
    },
    // Durable tx-queue id for trace persistence/recovery. Falls back to the
    // per-run groupId when called outside the queue (popup send-batch).
    traceQueueId?: string,
  ) {
    if (!traceQueueId) {
      await this.updateCheckpointId();
      const previewPlan = hooks?.previewTxHash
        ? this._preparedPreviewClaims.get(hooks.previewTxHash)
        : undefined;
      if (hooks?.previewTxHash && !previewPlan) {
        throw this.exactPreviewInvalidated();
      }
      const queuedClaims = previewPlan?.queuedClaims ?? claims;
      const inputs = await this.inputsForClaimsOrThrow(
        address,
        queuedClaims,
        previewPlan
          ? mergeInputs(hooks?.inputs, previewPlan.feeCoverInputs)
          : hooks?.inputs,
      );
      const queueId = await this.enqueueTx(
        "claim_batch",
        address,
        queuedClaims,
        {
          inputs,
          feeCoverItemCount:
            previewPlan?.feeCoverItemCount ?? hooks?.feeCoverItemCount,
          previewTxHash: hooks?.previewTxHash,
          exactFoldExecution: hooks?.exactFoldExecution,
        },
      );
      try {
        hooks?.onPendingRows?.(queueId);
      } catch {
        // a milestone observer must never break the submission itself
      }
      return (await this.awaitTx(queueId)) as SdkTxResult;
    }

    await this._waitForProver("execClaimBatch");
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw Error("Wallet Not Found");
    }
    if (!claims.length) {
      throw Error("Empty claims");
    }
    if (!hooks?.previewTxHash) {
      claims = await this.prepareClaimBatchItems(
        address,
        wallet,
        claims,
        hooks?.exactFoldExecution === true,
      );
    }

    const stringifyLogValue = (value: unknown): string | undefined => {
      if (value === undefined || value === null) return undefined;
      return typeof value === "bigint" ? value.toString() : String(value);
    };
    const summarizeClaimBatchItem = (item: ClaimBatchItem, index: number) => {
      if (item.type === "public") {
        const data = item.data as ContractCallArgs;
        return {
          index,
          type: item.type,
          methodName: data.method_name,
          contractId: stringifyLogValue(data.contract_id),
          inputsCount: Array.isArray(data.inputs) ? data.inputs.length : 0,
          amount: stringifyLogValue(data.inputs?.[1]),
        };
      }
      if (item.type === "private_transfer") {
        const data = item.data as Extract<
          ClaimBatchItem,
          { type: "private_transfer" }
        >["data"];
        const claim = data.claim;
        return {
          index,
          type: item.type,
          contractId: stringifyLogValue(data.contract_id),
          amount: stringifyLogValue(claim?.amount),
          checkpointId: stringifyLogValue(claim?.checkpoint_id),
          noteRootSlot: stringifyLogValue(claim?.note_root_slot),
          userTreeRoot: claim?.user_tree_root,
          nullifier: claim?.nullifier,
          hasNoteProofBincode: Boolean(claim?.note_proof_bincode_b64),
          hasNoteProofBytes: Boolean(
            Array.isArray(claim?.note_proof) && claim.note_proof.length > 0,
          ),
          hasNoteProofFingerprint: Boolean(claim?.note_proof_fingerprint),
          hasNoteVerifierData: Boolean(claim?.note_verifier_data),
        };
      }
      const data = item.data as Extract<
        ClaimBatchItem,
        { type: "claim_shield_deposit" }
      >["data"];
      return {
        index,
        type: item.type,
        contractId: stringifyLogValue(data.contract_id),
        sourceChainIndex: stringifyLogValue(data.source_chain_index),
        depositIndex: stringifyLogValue(data.deposit_index),
      };
    };
    const classifyClaimBatchError = (message: string) => {
      const lower = message.toLowerCase();
      return {
        registerContractCircuits: lower.includes(
          "register contract circuits error",
        ),
        emptyJsonResponse:
          lower.includes("eof while parsing") ||
          lower.includes("failed to parse json response"),
        responseBodyDecode:
          lower.includes("failed to read response body") ||
          lower.includes("error decoding response body"),
        serverError: lower.includes("servererror"),
        rpcError: lower.includes("rpcerror") || lower.includes("rpc call"),
      };
    };
    console.info("[execClaimBatch] start", {
      address,
      checkpointId: this.checkpointId,
      claimCount: claims.length,
      items: claims.map(summarizeClaimBatchItem),
      proveProxyUrl: this._config?.prove_proxy_url?.[0],
      coordinatorUrl: this._config?.coordinator_configs?.[0]?.rpc_url?.[0],
      realmUrl: this._config?.realm_configs?.[0]?.rpc_url?.[0],
    });

    const exactFoldExecution = hooks?.exactFoldExecution === true;
    // Proactively make sure the prover actually holds this wallet's signing
    // key BEFORE we try to generate/prove the trace. The offscreen WASM can be
    // re-created after boot (idle eviction / network switch) and come back
    // EMPTY while the per-signer cache still reads "loaded", so the first
    // claim after a prover restart fails with "public key X not found in
    // wallet". Re-importing here (idempotent) covers that up front; the
    // reactive retry in the prove loop is the backstop for a mid-flight prover
    // restart. Best-effort: never block the claim on this.
    try {
      await this.ensureWalletKeyInWasm(wallet);
    } catch (error) {
      console.warn("[execClaimBatch] proactive wallet-key load failed", error);
    }

    await this.updateCheckpointId();

    const groupId = traceQueueId;

    // Stale-claim auto-retry. The chain rejects a batch when ANY individual
    // item refers to state that's already been consumed — a `simple_claim`
    // from a sender with no remaining unclaimed amount, or a `claim_deposit`
    // whose shield-deposit leaf was already claimed in a previous tx. The
    // wallet's UI flow (transfer-modal.tsx :700-734) handles this for
    // `simple_claim` by parsing the `item_index=N` hint from the error,
    // dropping that item, and retrying. The dApp-facing UPS path needs the
    // same auto-recovery — without it the bridge sees a hard failure and
    // the user is told their funds are stuck when actually a single
    // already-claimed item is poisoning an otherwise-fine batch.
    //
    // Errors we recover from by dropping the named item:
    //   • "no tokens to claim from this sender" — public simple_claim
    //   • "shield claim already used"           — claim_deposit replay
    //   • "nullifier already claimed"           — private_transfer replay
    //   • "proof tree root mismatch"            — private note proof is for an
    //                                             older checkpoint (note tree
    //                                             root has moved on)
    //
    // We do NOT drop the transfer item itself (transfer is the one item
    // we MUST keep); if a transfer item's index is named, surface the
    // failure as-is. Bounded by claims.length so a pathological error
    // doesn't loop.
    const STALE_ITEM_PATTERNS = [
      "no tokens to claim from this sender",
      "shield claim already used",
      "nullifier already claimed",
      "proof tree root mismatch",
    ];
    const isStaleItemError = (msg: string): boolean =>
      STALE_ITEM_PATTERNS.some((p) => msg.toLowerCase().includes(p));

    // The WASM prover lost this wallet's signing key (offscreen/provider
    // re-init after boot — see ensureWalletKeyInWasm). One re-import + retry.
    const isMissingUserKeyError = (msg: string): boolean =>
      msg.toLowerCase().includes("not found in wallet");
    let userKeyRehydrated = false;

    // Transient prove-proxy failure — see module-level isTransientProveError.
    let transientRetryUsed = false;
    const parseItemIndex = (msg: string): number => {
      const m = msg.match(/item_index=(\d+)/);
      return m ? Number(m[1]) : -1;
    };
    const isTransferItem = (item: ClaimBatchItem): boolean => {
      if (item.type !== "public") return false;
      const data = item.data as { method_name?: string };
      // private_transfer: a fused private SEND riding the claim batch as a
      // generic public item (executePrivateTransfer's preClaimItems path).
      // withdraw: the bridge folds pending claims into a withdrawal's batch;
      // the withdrawal is the user's intent, never droppable collateral.
      // Like simple_transfer these must never be auto-dropped as stale.
      return (
        isPublicTokenCall(item.data, "transfer") ||
        data?.method_name === "private_transfer" ||
        data?.method_name === "withdraw"
      );
    };
    const isPrivateTransferItem = (item: ClaimBatchItem): boolean =>
      Boolean(
        (item as { data?: { claim?: Record<string, unknown> } }).data?.claim,
      );

    // Serialize the prove+submit phase (including its retry/drop loop) on
    // the same FIFO as execContractCall — concurrent UPS submissions would
    // otherwise build against the same chain snapshot and race each other.
    // Rows are already pending above, so a queued batch stays visible.
    // Decoupled trace flow for batch claims: same generate→persist→prove path
    // as contract calls, reusing the shared resumable prover.
    const generateBatchClaimTxTrace =
      wallet.wallet.generateBatchClaimTxTrace?.bind(wallet.wallet);
    const selectClaimBatchMethod = () => {
      const canUseStepTrace = Boolean(generateBatchClaimTxTrace);
      return {
        canUseStepTrace,
        method: canUseStepTrace
          ? "trace.generate+proveStep"
          : "blocked:generateBatchClaimTxTrace unavailable",
      };
    };
    return this._enqueueTxSubmit(async () => {
      transactionManager.setGroupPhase(groupId, "proving");
      let activeClaims = claims;
      const maxDropAttempts = claims.length;
      const maxLoopAttempts = Math.max(12, claims.length * 2 + 6);
      let dropAttempts = 0;
      let loopAttempts = 0;
      const confirmSubmittedResult = async (
        result: SdkTxResult,
        label: string,
      ) => {
        transactionManager.setGroupPhase(groupId, "confirming");
        if (traceQueueId) return result;
        const confirmedNonce = await this.waitForSubmittedNonceAdvance(
          address,
          wallet.userId,
          undefined,
          {
            kind: label,
            groupId,
            queueId: traceQueueId ?? groupId,
            txHash: txHashFromSdkResult(result),
          },
        );
        if (confirmedNonce === undefined) {
          console.warn(
            "[psy-wallet][tx] submitted claim batch confirmation unavailable after submit; not marking failed",
            {
              kind: label,
              groupId,
              queueId: traceQueueId ?? groupId,
              txHash: txHashFromSdkResult(result),
            },
          );
        }
        return result;
      };
      const runClaimBatch = async (
        label: string,
        items: ClaimBatchItem[],
        usePreviewTxHash?: string,
      ): Promise<SdkTxResult> => {
        const { canUseStepTrace, method } = selectClaimBatchMethod();
        console.warn("[execClaimBatch] run", {
          label,
          groupId,
          checkpointId: this.checkpointId,
          itemCount: items.length,
          items: items.map(summarizeClaimBatchItem),
          method,
          hasPreview: Boolean(usePreviewTxHash),
        });
        if (usePreviewTxHash) {
          if (!canUseStepTrace || !generateBatchClaimTxTrace) {
            throw this.exactPreviewInvalidated();
          }
          return this.proveExactPreviewClaimBatch(
            wallet,
            address,
            usePreviewTxHash,
            traceQueueId ?? groupId!,
            items,
          );
        }
        if (canUseStepTrace && generateBatchClaimTxTrace) {
          return this.runTraceTwoStep(
            address,
            "claim_batch",
            traceQueueId ?? groupId,
            () => generateBatchClaimTxTrace(address, items),
            hooks?.onTraceStep,
          );
        }
        console.warn("[tx-trace] submit-blocked", {
          kind: "claim_batch",
          address,
          queueId: traceQueueId ?? groupId,
          itemCount: items.length,
          blocked: true,
          reason: "generateBatchClaimTxTrace API unavailable",
        });
        throw new Error(
          "Cannot submit claim batch: generateBatchClaimTxTrace API unavailable",
        );
      };
      while (loopAttempts < maxLoopAttempts) {
        loopAttempts += 1;
        try {
          const result = await confirmSubmittedResult(
            await runClaimBatch(
              "trace_claim_batch",
              activeClaims,
              hooks?.previewTxHash,
            ),
            "claim_batch",
          );
          if (traceQueueId) {
            return result;
          }
          await transactionManager.txPendingFinished(true, result, groupId);
          return result;
        } catch (e: any) {
          const message = e instanceof Error ? e.message : String(e);
          if (isProofDeserializeError(e)) {
            const friendly = toFriendlyProofError(e);
            if (traceQueueId) throw friendly;
            await transactionManager.txPendingFinished(
              false,
              friendly.message,
              groupId,
            );
            throw friendly;
          }
          if (hooks?.previewTxHash) {
            if (traceQueueId) throw e;
            await transactionManager.txPendingFinished(false, message, groupId);
            throw this.exactPreviewInvalidated();
          }
          const batchContractIds = [
            ...new Set(
              activeClaims.flatMap((claim) => {
                const data = claim.data as {
                  contract_id?: unknown;
                  l2_token_contract_id?: unknown;
                };
                return [data.contract_id, data.l2_token_contract_id]
                  .map(stringifyLogValue)
                  .filter((value): value is string => value !== undefined);
              }),
            ),
          ];
          const classification = classifyClaimBatchError(message);
          console.warn("[execClaimBatch] failed", {
            groupId,
            checkpointId: this.checkpointId,
            itemCount: activeClaims.length,
            batchContractIds,
            items: activeClaims.map(summarizeClaimBatchItem),
            classification,
            method: selectClaimBatchMethod().method,
            proveProxyUrl: this._config?.prove_proxy_url?.[0],
            coordinatorUrl:
              this._config?.coordinator_configs?.[0]?.rpc_url?.[0],
            realmUrl: this._config?.realm_configs?.[0]?.rpc_url?.[0],
            message,
            stack: e instanceof Error ? e.stack : undefined,
          });
          if (message.toLowerCase().includes("proof tree root mismatch")) {
            const privateNotes: any[] = activeClaims
              .map((item, index) => {
                if (item.type !== "private_transfer") return null;
                const data = item.data as {
                  contract_id?: unknown;
                  claim?: PrivateTransferClaimRaw;
                };
                const claim = data.claim;
                return {
                  index,
                  contractId: stringifyLogValue(data.contract_id),
                  checkpointId: stringifyLogValue(claim?.checkpoint_id),
                  noteRootSlot: stringifyLogValue(claim?.note_root_slot),
                  userTreeRoot: claim?.user_tree_root,
                  nullifier: claim?.nullifier,
                  amount: stringifyLogValue(claim?.amount),
                  hasNoteProofBincode: Boolean(claim?.note_proof_bincode_b64),
                  hasNoteProofBytes: Boolean(
                    Array.isArray(claim?.note_proof) &&
                      claim.note_proof.length > 0,
                  ),
                  hasNoteProofFingerprint: Boolean(
                    claim?.note_proof_fingerprint,
                  ),
                  hasNoteVerifierData: Boolean(claim?.note_verifier_data),
                };
              })
              .filter(Boolean);
            console.error(
              "[execClaimBatch] proof tree root mismatch diagnostics",
              {
                checkpointId: this.checkpointId,
                privateNotes,
              },
            );
          }
          // Smoking-gun callout: the prove-proxy got an empty body while
          // registering circuits — i.e. its upstream get_contract_code RPC
          // returned nothing for one of batchContractIds. Cross-reference these
          // ids against what's deployed on the node the proxy talks to.
          if (
            classification.registerContractCircuits ||
            classification.emptyJsonResponse
          ) {
            console.error(
              "[execClaimBatch] register-contract-circuits EOF — upstream node returned empty get_contract_code",
              {
                groupId,
                batchContractIds,
                proveProxyUrl: this._config?.prove_proxy_url?.[0],
                coordinatorUrl:
                  this._config?.coordinator_configs?.[0]?.rpc_url?.[0],
                realmUrl: this._config?.realm_configs?.[0]?.rpc_url?.[0],
              },
            );
          }

          if (isStateRefreshRetryError(e)) {
            try {
              await wallet.wallet.refresh();
              transactionManager.refreshTxState();
              const retryResult = await runClaimBatch(
                "retry_trace_claim_batch",
                activeClaims,
              );
              await confirmSubmittedResult(retryResult, "claim_batch");
              if (traceQueueId) return retryResult;
              await transactionManager.txPendingFinished(
                true,
                retryResult,
                groupId,
              );
              return retryResult;
            } catch (retryError: any) {
              const retryMsg =
                retryError instanceof Error
                  ? retryError.message
                  : String(retryError);
              if (!isStaleItemError(retryMsg) || exactFoldExecution) {
                if (traceQueueId) throw retryError;
                await transactionManager.txPendingFinished(
                  false,
                  retryError.message || PsyJSON.stringify(retryError),
                  groupId,
                );
                throw retryError;
              }
              // Legacy batches re-enter the loop with the fresh stale-item
              // error so best-effort recovery can drop the named item.
              e = retryError;
            }
          }

          // Lost-key recovery — the prover doesn't have this wallet's key
          // (the offscreen/provider WASM was re-initialised since boot). Re-
          // import it into the live WASM, bypassing the stale per-signer
          // add_user cache, then retry the same batch. One attempt: if it
          // recurs the key genuinely can't be loaded and we should surface it.
          if (isMissingUserKeyError(message) && !userKeyRehydrated) {
            userKeyRehydrated = true;
            console.warn(
              "[execClaimBatch] prover is missing the wallet key; re-importing and retrying",
              { address, reason: message.slice(0, 160) },
            );
            try {
              await this.ensureWalletKeyInWasm(wallet);
            } catch (rehydrateError) {
              console.warn(
                "[execClaimBatch] wallet-key re-import failed",
                rehydrateError,
              );
            }
            continue;
          }

          // Transient prove-proxy recovery — single retry on parse failure.
          // No item drop; the request is identical, the proxy just needs a
          // breath. Cap at one retry so we don't pile load on the proxy.
          if (isTransientProveError(message) && !transientRetryUsed) {
            transientRetryUsed = true;
            console.warn(
              "[execClaimBatch] prove-proxy returned non-JSON; retrying once",
              {
                groupId,
                classification,
                reason: message,
              },
            );
            await new Promise((resolve) => setTimeout(resolve, 2_500));
            continue;
          }

          // Stale-item recovery — drop the named item and retry the rest.
          if (
            !exactFoldExecution &&
            isStaleItemError(message) &&
            dropAttempts < maxDropAttempts
          ) {
            const staleIndex = parseItemIndex(message);
            if (
              Number.isInteger(staleIndex) &&
              staleIndex >= 0 &&
              staleIndex < activeClaims.length &&
              !isTransferItem(activeClaims[staleIndex])
            ) {
              const staleItem = activeClaims[staleIndex];
              if (
                message.toLowerCase().includes("proof tree root mismatch") &&
                isPrivateTransferItem(staleItem)
              ) {
                console.error(
                  "[execClaimBatch] proof tree root mismatch on private_transfer; not auto-dropping",
                  {
                    staleIndex,
                    item: summarizeClaimBatchItem(staleItem, staleIndex),
                    reason: message,
                    activeClaims: activeClaims.map((claim, index) =>
                      summarizeClaimBatchItem(claim, index),
                    ),
                  },
                );
                if (traceQueueId) throw e;
                await transactionManager.txPendingFinished(
                  false,
                  message,
                  groupId,
                );
                throw e;
              }
              console.warn("[execClaimBatch] dropping already-consumed item", {
                staleIndex,
                type: staleItem.type,
                reason: message.slice(0, 160),
              });
              activeClaims = activeClaims.filter(
                (_, index) => index !== staleIndex,
              );
              dropAttempts += 1;
              // If we just dropped the LAST claim and the only remaining
              // item is the transfer-with-no-claim, the user effectively
              // wanted "just transfer this amount from slot balance" — the
              // chain will either accept (if slot covers) or reject with a
              // clean balance error on the next iteration.
              if (activeClaims.length === 0) {
                // Resolve our rows before throwing — this throw escapes the
                // catch below, and an unresolved group stays "executing" in
                // Activity forever.
                const allConsumed = new Error(
                  "Every claim item was already consumed — nothing left to submit.",
                );
                if (traceQueueId) throw allConsumed;
                await transactionManager.txPendingFinished(
                  false,
                  allConsumed.message,
                  groupId,
                );
                throw allConsumed;
              }
              continue;
            }
          }

          if (traceQueueId) throw e;
          await transactionManager.txPendingFinished(
            false,
            e.message || PsyJSON.stringify(e),
            groupId,
          );
          throw e;
        }
      }
      const exhausted = new Error(
        "Claim batch recovery budget exhausted before submission.",
      );
      if (traceQueueId) throw exhausted;
      await transactionManager.txPendingFinished(
        false,
        exhausted.message,
        groupId,
      );
      throw exhausted;
    });
  }

  async execContractCallWithoutProof(
    address: string,
    args: ContractCallArgs | ContractCallArgs[],
  ): Promise<SdkTxResult> {
    console.warn("[tx-trace] compatibility:without-proof-routed-to-trace", {
      kind: "contract_call",
      address,
      reason: "execContractCallWithoutProof compatibility entry was requested",
    });
    return this.execContractCall(address, args);
  }

  async execClaimBatchWithoutProof(
    address: string,
    claims: ClaimBatchItem[],
  ): Promise<SdkTxResult> {
    console.warn("[tx-trace] compatibility:without-proof-routed-to-trace", {
      kind: "claim_batch",
      address,
      itemCount: claims.length,
      reason: "execClaimBatchWithoutProof compatibility entry was requested",
    });
    return this.execClaimBatch(address, claims);
  }

  /**
   * Public private-transfer entry point. It only persists a tx_queue entry and
   * waits for the queue worker result; the worker calls
   * runPrivateTransferQueueEntry to do the actual proof/submit/Nostr work.
   */
  async executePrivateTransfer(
    address: string,
    req: {
      contract_id: string;
      recipient_shield_address: string;
      recipient_nostr_pubkey: string;
      amount: string;
      sender_label?: string;
      token_symbol?: string;
      decimals?: number;
    },
    preClaimItems?: ClaimBatchItem[],
    previewTxHash?: string,
  ): Promise<PrivateTransferResult> {
    const previewPlan = previewTxHash
      ? this._preparedPreviewClaims.get(previewTxHash)
      : undefined;
    if (previewTxHash && preClaimItems?.length && !previewPlan) {
      throw this.exactPreviewInvalidated();
    }
    const queuedPreClaims = previewPlan
      ? previewPlan.queuedClaims.slice(0, -1)
      : preClaimItems;
    const inputs = await this.inputsForClaimsOrThrow(address, queuedPreClaims);
    const queueId = await this.enqueueTx(
      "private_transfer",
      address,
      { request: req, preClaimItems: queuedPreClaims },
      { inputs, previewTxHash },
    );
    return (await this.awaitTx(queueId)) as PrivateTransferResult;
  }

  private async runPrivateTransferQueueEntry(
    address: string,
    req: {
      contract_id: string;
      recipient_shield_address: string;
      recipient_nostr_pubkey: string;
      amount: string;
      sender_label?: string;
      token_symbol?: string;
      decimals?: number;
    },
    preClaimItems?: ClaimBatchItem[],
    queueId?: string,
    hooks?: {
      onStep?: (step: string) => void;
      onBackupSaveFailed?: () => void;
    },
    previewTxHash?: string,
  ): Promise<{
    success: boolean;
    txHash: string | null;
    noteProofRaw: string | null;
    nostrDelivered: boolean;
    error: string | null;
    backupPayload?: string | null;
    preClaimTxHash?: string | null;
  }> {
    let previewNote:
      | {
          noteSecretHash: [bigint, bigint, bigint, bigint];
          nullifierSecret: [bigint, bigint, bigint, bigint];
          secondaryNoteSecretHash?: FtWords;
          secondaryNullifierSecret?: FtWords;
        }
      | undefined;
    if (previewTxHash) {
      const candidate = this._privatePreviewNotes.get(previewTxHash);
      this._privatePreviewNotes.delete(previewTxHash);
      this.cancelPreviewTraceTimer(previewTxHash);
      const now = Date.now();
      if (
        candidate?.address === address &&
        now >= candidate.createdAt &&
        now - candidate.createdAt <= PREVIEW_TRACE_TTL_MS
      ) {
        previewNote = {
          noteSecretHash: candidate.noteSecretHash,
          nullifierSecret: candidate.nullifierSecret,
          secondaryNoteSecretHash: candidate.secondaryNoteSecretHash,
          secondaryNullifierSecret: candidate.secondaryNullifierSecret,
        };
      }
    }
    if (previewTxHash && !previewNote) {
      await traceStore.removeGeneratedPreview(
        this._chainKey,
        address,
        previewTxHash,
      );
      this._previewTraceRecords.delete(previewTxHash);
      throw this.exactPreviewInvalidated();
    }
    await this._waitForProver("executePrivateTransfer");
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) throw new Error("Wallet Not Found");
    await this.updateCheckpointId();
    const relay = nostrRelay(this._config);
    const ftPin =
      BigInt(req.contract_id) >= 5n
        ? ftPinForContractLeaf(
            await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(
              BigInt(req.contract_id),
            ),
          )
        : null;
    if (BigInt(req.contract_id) >= 5n && !ftPin)
      throw new Error(
        "Unsupported private FT code/layout; no transfer submitted",
      );
    if (ftPin && queueId) this._privateFtQueueIds.add(queueId);
    try {
      return await executePrivateTransferLib(
        (addr, args) =>
          this.executeQueuedContractCall(
            addr,
            args,
            queueId,
            hooks?.onStep,
            previewNote ? previewTxHash : undefined,
          ),
        {
          senderAddress: address,
          queueId,
          senderUserId: wallet.userId,
          chainKey: this._chainKey,
          senderLabel: req.sender_label ?? wallet.name,
          recipientShield: req.recipient_shield_address,
          recipientNpub: req.recipient_nostr_pubkey,
          amount: BigInt(req.amount),
          contractId: BigInt(req.contract_id),
          checkpointId: this.checkpointId,
          tokenSymbol: req.token_symbol ?? "PSY",
          decimals: req.decimals ?? 9,
          nostrRelay: relay,
          preClaimItems: preClaimItems?.length ? preClaimItems : undefined,
          onStep: hooks?.onStep,
          onBackupSaveFailed: hooks?.onBackupSaveFailed,
          noteSecretHash: previewNote?.noteSecretHash,
          nullifierSecret: previewNote?.nullifierSecret,
          ftPin: ftPin ?? undefined,
          secondaryNoteSecretHash: previewNote?.secondaryNoteSecretHash,
          secondaryNullifierSecret: previewNote?.secondaryNullifierSecret,
        },
        {
          assertFtPacketVerifierReady: () => {
            if (typeof (this._provider.prover as PrivateFtPacketProver).verifyPrivateFtPacket !== "function") {
              throw new Error("FT packet verifier unavailable in the selected SDK; no transfer submitted");
            }
          },
          execClaimBatch: (addr, items) =>
            this.executeQueuedClaimBatch(
              addr,
              items as ClaimBatchItem[],
              queueId,
              hooks?.onStep,
              previewNote ? previewTxHash : undefined,
            ),
          getBalance: (addr, cid) => this.getBalance(addr, cid),
          getCheckpointId: async () => {
            await this.updateCheckpointId();
            return this.checkpointId;
          },
          provePrivateNoteInclusion: async (args) =>
            runWalletWasmServerMethod(
              "core_prove_private_note_inclusion_json",
              "prove_private_note_inclusion_json",
              [
                args.address,
                args.ownerJson,
                args.amount,
                args.noteSecretHashJson,
                args.nullifierSecretJson,
                args.contractId,
                args.noteRootSlot,
                args.checkpointId,
                args.endUserLeafHash,
              ],
            ),
          prepareNostrGiftWrap: async (args) => {
            const scope = this.privateTransferBackupScope(wallet);
            const backup = (await listTransferBackups(scope)).find(
              (item) => item.noteCommitment === args.noteCommitment,
            );
            if (ftPin) {
              if (!backup) throw new Error("Missing FT recovery backup");
              const verify = (this._provider.prover as PrivateFtPacketProver)
                .verifyPrivateFtPacket;
              if (!verify) throw new Error(
                "Private FT packet verification is unsupported by the selected SDK",
              );
              const checked = await verify.call(
                this._provider.prover,
                ftPin.profile,
                args.noteProofRaw,
                ftPin.codeRoot,
                ftPin.layoutRoot,
              );
              if (
                !checked.verified ||
                checked.amount !== args.amount ||
                checked.contractId !== args.contractId
              )
                throw new Error("FT outgoing packet did not verify");
              if (!backup.signedNostrEvents?.length)
                await updateTransferBackupRequired(scope, backup.id, {
                  signedNostrEvents: buildSignedFtEvents(
                    args.noteProofRaw,
                    args.receiverNpub,
                  ),
                });
              return;
            }
            if (backup?.signedNostrEvents?.length === 2) return;
            const signedEvents = buildPrivateTransferSignedEvents({
              receiverNpub: args.receiverNpub,
              recipientShieldLimbs: args.recipientShieldLimbs,
              amount: args.amount,
              contractId: args.contractId,
              txHash: args.txHash,
              noteCommitment: args.noteCommitment,
              noteProofRaw: args.noteProofRaw,
              nullifierSecret: args.nullifierSecret,
              noteSecret: args.noteSecret,
            }).events;
            if (backup) {
              await updateTransferBackupRequired(scope, backup.id, {
                signedNostrEvents: signedEvents,
              });
            }
          },
          sendNostrGiftWrap: async (args) => {
            const scope = this.privateTransferBackupScope(wallet);
            const backup = (await listTransferBackups(scope)).find(
              (item) => item.noteCommitment === args.noteCommitment,
            );
            if (ftPin) {
              if (!backup?.signedNostrEvents?.length)
                throw new Error("FT finalized delivery was not persisted");
              await publishSignedEvents(backup.signedNostrEvents, relay, 1);
              return;
            }
            const signedEvents =
              backup?.signedNostrEvents?.length === 2
                ? backup.signedNostrEvents
                : buildPrivateTransferSignedEvents({
                    receiverNpub: args.receiverNpub,
                    recipientShieldLimbs: args.recipientShieldLimbs,
                    amount: args.amount,
                    contractId: args.contractId,
                    txHash: args.txHash,
                    noteCommitment: args.noteCommitment,
                    noteProofRaw: args.noteProofRaw,
                    nullifierSecret: args.nullifierSecret,
                    noteSecret: args.noteSecret,
                  }).events;
            if (backup && !backup.signedNostrEvents?.length) {
              await updateTransferBackup(scope, backup.id, {
                signedNostrEvents: signedEvents,
              });
            }
            await publishPrivateTransfer(
              {
                receiverNpub: args.receiverNpub,
                recipientShieldLimbs: args.recipientShieldLimbs,
                amount: args.amount,
                contractId: args.contractId,
                txHash: args.txHash,
                noteCommitment: args.noteCommitment,
                noteProofRaw: args.noteProofRaw,
                nullifierSecret: args.nullifierSecret,
                noteSecret: args.noteSecret,
              },
              relay,
              signedEvents,
            );
          },
        },
      );
    } finally {
      if (queueId) this._privateFtQueueIds.delete(queueId);
      if (previewTxHash) {
        await traceStore.removeGeneratedPreview(
          this._chainKey,
          address,
          previewTxHash,
        );
      }
    }
  }

  /**
   * Popup-facing private transfer: runs the WHOLE orchestration (chain
   * commit → inclusion proof → Nostr delivery) HERE in the service worker
   * and narrates progress through `privateTransferStatus` state dispatches.
   * Previously the popup modal ran lib/executePrivateTransfer itself, so
   * closing the popup mid-flight killed the JS — the chain commit might
   * land but the proof was never built and the Nostr note never sent,
   * leaving the recipient unpaid until manual recovery. The popup now only
   * WATCHES; its lifetime no longer matters.
   *
   * Residual risk: MV3 can still evict the service worker itself. The
   * background keeps a 20s keep-alive interval (src/lib/keep-alive.ts) and
   * the in-flight runtime message pins it during the long proof, but
   * eviction is not impossible — the Step-0 pre-commit backup plus the
   * resume path remain the safety net.
   *
   * Always RESOLVES with the terminal status (never rejects): the popup
   * may be gone by completion, and the dispatched status is the source of
   * truth anyway.
   */
  async startPrivateTransfer(
    address: string,
    req: {
      contract_id: string;
      recipient_shield_address: string;
      recipient_nostr_pubkey: string;
      amount: string;
      sender_label?: string;
      token_symbol?: string;
      decimals?: number;
    },
    preClaimItems?: ClaimBatchItem[],
    runId?: string,
    previewTxHash?: string,
  ): Promise<IPrivateTransferStatus> {
    const status: IPrivateTransferStatus = {
      runId:
        runId || `ptr_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      address,
      phase: "running",
      steps: [],
      backupSaveFailed: false,
      startedAt: Date.now(),
    };
    this._privateTransferStatus = status;
    // The run's recoverable artifacts (pre-commit backup, then the
    // committed-but-undelivered note) outlive any single SW incarnation,
    // but the code that finishes them only executes when a worker WAKES.
    // Arm the recovery alarm for the whole run — it covers the windows the
    // Activity rows don't: before rows exist and after they resolve but
    // before the note proof/Nostr delivery completed.
    armPendingRecoveryAlarm();
    const dispatch = () => {
      psyStateDispatch({ privateTransferStatus: status }).catch(() => {});
    };
    dispatch();
    try {
      const inputs = await this.inputsForClaimsOrThrow(address, preClaimItems);
      const queueId = await this.enqueueTx(
        "private_transfer",
        address,
        {
          runId: status.runId,
          request: req,
          preClaimItems,
        },
        { inputs, previewTxHash },
      );
      const res = (await this.awaitTx(queueId)) as {
        success: boolean;
        outcome:
          | "delivered"
          | "committed_incomplete"
          | "submission_unknown"
          | "send_not_committed";
        postCommitFailureStage:
          | "missing_inclusion_identity"
          | "proof_build"
          | "recipient_event"
          | "relay_publish"
          | null;
        txHash: string | null;
        noteProofRaw: string | null;
        nostrDelivered: boolean;
        error: string | null;
        backupPayload?: string | null;
        preClaimTxHash?: string | null;
      };
      status.phase = res.success ? "success" : res.txHash ? "warning" : "error";
      status.result = {
        outcome: res.outcome,
        postCommitFailureStage: res.postCommitFailureStage,
        success: res.success,
        txHash: res.txHash,
        preClaimTxHash: res.preClaimTxHash ?? null,
        nostrDelivered: res.nostrDelivered,
        error: res.error,
        backupPayload: res.backupPayload ?? null,
      };
    } catch (e: any) {
      status.phase = "error";
      status.result = {
        success: false,
        outcome: "send_not_committed",
        postCommitFailureStage: null,
        txHash: null,
        preClaimTxHash: null,
        nostrDelivered: false,
        error: e?.message || String(e),
        backupPayload: null,
      };
    }
    this._privateTransferStatus = status;
    dispatch();
    return status;
  }

  /**
   * Popup-facing PUBLIC send / claim batch: runs the WHOLE submission —
   * exec (prove+submit with the stale-item auto-drop inside execClaimBatch),
   * and the transfer-only fallback — HERE
   * in the service worker, narrating progress through `sendBatchStatus`
   * state dispatches. Previously the popup modal owned exec + retry +
   * complete(): closing the popup during its prepare window silently
   * dropped the send (no Activity row, nothing submitted), and closing it
   * mid-flight lost fallback handling. The popup now only WATCHES
   * (SendBatchProcessingModal); its lifetime no longer matters once this
   * method has been invoked.
   *
   * Always RESOLVES with the terminal status (never rejects): the popup
   * may be gone by completion, and the dispatched status is the source of
   * truth anyway.
   */
  /**
   * UPS fee-cover fusion: a batch is rejected at the END CAP when the
   * sender's PSY (contract 0) slot can't cover the network fee — even
   * though the user may have PSY sitting CLAIMABLE. Claims credit the slot
   * before the end-cap fee debit within the same UPS, so fusing a PSY
   * simple_claim in FRONT of the batch makes "claim USDT with zero PSY in
   * the slot but 1,000 PSY claimable" just work — one proof, one fee, no
   * separate claim-PSY-first ceremony (same fusion idea as d1cda7c).
   *
   * Conservative by design: skipped when the fee is unknown, when the
   * batch already credits PSY (its own claim/mint covers the debit), when
   * the slot covers the estimate, or when no PSY public claimable is known
   * locally. Best-effort — any error returns the batch unchanged.
   */
  private async _prependFeeCoverClaims(
    wallet: IPsyWidgetWallet,
    claims: ClaimBatchItem[],
  ): Promise<{
    claims: ClaimBatchItem[];
    inputs: TxInput[];
    feeCoverItemCount: number;
  }> {
    const unchanged = { claims, inputs: [], feeCoverItemCount: 0 };
    try {
      if (!this._fee || !claims.length) return unchanged;
      // Fee estimate: guta + da × (≈2 modified slots per item + 2 for the
      // end cap). Slightly over-estimating only means claiming a bit more
      // of the user's own PSY — never a wrong debit.
      const estimate =
        this._fee.amount +
        (this._fee.daFee ?? 0n) * BigInt(2 * claims.length + 2);
      const isNativeContract = (raw: unknown) =>
        String(raw ?? "") === this._nativeContractId ||
        String(raw ?? "") === "";
      const creditsNative = claims.some((c) => {
        if (c.type === "public") {
          const d = c.data as { contract_id?: unknown; method_name?: string };
          return (
            isNativeContract(d.contract_id) &&
            (isPublicTokenCall(d, "claim") ||
              d.method_name === "simple_mint")
          );
        }
        const d = c.data as {
          contract_id?: unknown;
          l2_token_contract_id?: unknown;
        };
        return isNativeContract(d.contract_id ?? d.l2_token_contract_id);
      });
      if (creditsNative) return unchanged;
      const balance = BigInt(
        String(
          (await this.getBalance(
            wallet.address,
            BigInt(this._nativeContractId),
          )) ?? "0",
        ),
      );
      if (balance >= estimate) return unchanged;
      // Slot can't cover the fee — look for PSY public claimables in the
      // latest snapshot (filtered against the locally-claimed registry so
      // we never re-claim a pair a previous batch already swept).
      const apiServicesUrl = firstConfigUrl(
        (this._config as { api_services_url?: unknown })?.api_services_url,
      );
      if (!apiServicesUrl) return unchanged;
      const rollup = await this.readClaimableRollup(
        wallet,
        this.checkpointId,
        apiServicesUrl,
      );
      const psyItems = rollup.publicItems.filter(
        (i) => String(i.contractId) === this._nativeContractId && i.amount > 0n,
      );
      if (!psyItems.length) return unchanged;
      let deficit = estimate - balance;
      const chosen: typeof psyItems = [];
      for (const item of psyItems) {
        if (deficit <= 0n) break;
        chosen.push(item);
        deficit -= item.amount;
      }
      // Even when the claimables don't FULLY cover the estimate, claiming
      // what exists strictly improves the batch's odds (the estimate is an
      // upper bound; the chain charges actual slots).
      const prependItems: ClaimBatchItem[] = chosen.map((item) => ({
        type: "public",
        data: {
          contract_id: BigInt(this._nativeContractId),
          method_name: publicTokenMethod(this._nativeContractId, "claim"),
          inputs: [BigInt(item.senderUserId)],
        },
      }));
      return {
        claims: [...prependItems, ...claims],
        inputs: chosen.map((item) =>
          publicClaimInput({
            contractId: item.contractId,
            senderUserId: item.senderUserId,
            amount: item.amount,
          }),
        ),
        feeCoverItemCount: prependItems.length,
      };
    } catch (e) {
      console.warn("[startSendBatch] fee-cover fusion skipped", e);
      return unchanged;
    }
  }

  async startSendBatch(
    address: string,
    claims: ClaimBatchItem[],
    opts?: {
      runId?: string;
      kind?: ISendBatchStatus["kind"];
      inputs?: TxInput[];
      /** Retry the lone transfer when a claims+transfer batch fails —
       *  parity with the popup's old "try without claiming first" path. */
      transferFallback?: boolean;
      previewTxHash?: string;
    },
  ): Promise<ISendBatchStatus> {
    const status: ISendBatchStatus = {
      runId:
        opts?.runId ||
        `sb_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
      address,
      kind: opts?.kind ?? "send",
      phase: "running",
      steps: [],
      startedAt: Date.now(),
    };
    this._sendBatchStatus = status;
    const dispatch = () => {
      psyStateDispatch({ sendBatchStatus: status }).catch(() => {});
    };
    const pushStep = (key: ISendBatchStatus["steps"][number]["key"]) => {
      status.steps = [...status.steps, { key, at: Date.now() }];
      dispatch();
    };
    dispatch();

    const isTransferItem = (item: ClaimBatchItem): boolean =>
      item.type === "public" &&
      (isPublicTokenCall(item.data, "transfer") || ["private_transfer", "withdraw"].includes(
        (item.data as { method_name?: string })?.method_name ?? "",
      ));
    const onPendingRows = (groupId: string | undefined) => {
      status.groupId = groupId;
      pushStep("submitted");
    };

    try {
      // UPS fee-cover fusion (see _prependFeeCoverClaims): when the PSY
      // slot can't pay the network fee but PSY sits claimable, claim it in
      // the SAME UPS, in front — the credit lands before the end-cap debit.
      let activeClaims = claims;
      let inputs = [...(opts?.inputs ?? [])];
      let feeCoverItemCount = 0;
      const senderWallet = this._wallets.find((w) => w.address === address);
      if (senderWallet) {
        const fused = await this._prependFeeCoverClaims(senderWallet, claims);
        activeClaims = fused.claims;
        inputs = mergeInputs(inputs, fused.inputs);
        feeCoverItemCount = fused.feeCoverItemCount;
      }

      let execResult: unknown;
      try {
        execResult = await this.execClaimBatch(address, activeClaims, {
          onPendingRows,
          inputs,
          feeCoverItemCount,
          previewTxHash: opts?.previewTxHash,
        });
      } catch (e) {
        if (opts?.previewTxHash) throw e;
        // Transfer-only fallback: a poisoned claim item shouldn't strand
        // the user's actual send if their slot balance can cover it.
        const transferOnly = opts?.transferFallback
          ? claims.find(isTransferItem)
          : undefined;
        const hasClaimItems = activeClaims.some((c) => !isTransferItem(c));
        if (!transferOnly || !hasClaimItems) throw e;
        console.warn(
          "[startSendBatch] claim batch failed — retrying transfer only",
          { reason: (e as Error)?.message?.slice(0, 160) },
        );
        status.fallbackUsed = true;
        dispatch();
        execResult = await this.execClaimBatch(address, [transferOnly], {
          onPendingRows,
          inputs,
        });
      }
      pushStep("confirmed");
      // Recompute the unified snapshot so balances/claimables update even
      // when no popup is alive to ask for it.
      void this.refreshWalletSnapshot(false).catch(() => undefined);

      const txHash =
        typeof execResult === "string"
          ? execResult
          : ((execResult as { result?: string })?.result ?? null);
      status.phase = "success";
      status.result = { success: true, txHash, error: null };
    } catch (e) {
      status.phase = "error";
      status.result = {
        success: false,
        txHash: null,
        error: (e as Error)?.message || String(e),
      };
    }
    dispatch();
    return status;
  }

  /** Generate a Review-time public/fused send trace without proving, queuing,
   * creating Activity rows, or touching pending holds. */
  async previewSendTrace(
    address: string,
    items: ClaimBatchItem[],
  ): Promise<{
    txHash: string;
    feeBase: string;
    slotsModified: number;
    expiresAt: number;
  } | null> {
    const generation = this._previewGeneration;
    const wallet = this._wallets.find(
      (candidate) => candidate.address === address,
    );
    const generate = wallet?.wallet.generateBatchClaimTxTrace?.bind(
      wallet.wallet,
    );
    if (
      !wallet ||
      !generate ||
      !this.previewGenerationIsCurrent(generation, address, wallet)
    ) {
      return null;
    }
    let previewTxHash: string | undefined;
    try {
      // Reserve the durable queue's full chain-state operation lock. Its
      // transaction entry acquires this before async prepare, so preview
      // generation cannot slip between queue selection and executor startup.
      return await txQueue.runExclusive(async () => {
        await this.marketPreparation().assertNoPending(address, this._chainKey);
        if (!this.previewGenerationIsCurrent(generation, address, wallet)) {
          return null;
        }
        const fused = await this._prependFeeCoverClaims(wallet, items);
        const preparedClaims = await this.prepareClaimBatchItems(
          address,
          wallet,
          fused.claims,
        );
        const envelope = await generate(address, preparedClaims);
        const previewResult = this.traceResultToSdkTxResult(
          envelope.tx_hash,
          envelope,
        ) as { end_cap_data?: { stats?: { slots_modified?: unknown } } };
        const rawSlots = previewResult.end_cap_data?.stats?.slots_modified;
        const slots =
          typeof rawSlots === "number"
            ? rawSlots
            : this.extractSlotsModified(
                this.parseTracePayloadForResult(envelope.trace?.payload),
              );
        if (
          slots == null ||
          !this.previewGenerationIsCurrent(generation, address, wallet)
        ) {
          return null;
        }
        const now = Date.now();
        const queuedItemsHash = hashClaimBatchItems(fused.claims);
        const memoryRecord: TraceRecord = {
          txHash: envelope.tx_hash,
          sigHash: envelope.sig_hash,
          queueId: `preview:${envelope.tx_hash}`,
          address,
          chainKey: this._chainKey,
          networkKey: this._networkKey,
          kind: "claim_batch",
          itemsHash: queuedItemsHash,
          envelope,
          status: "generated",
          createdAt: now,
          updatedAt: now,
        };
        previewTxHash = envelope.tx_hash;
        this._previewTraceRecords.set(previewTxHash, memoryRecord);
        await traceStore.save(memoryRecord.chainKey, {
          ...memoryRecord,
          envelope: undefined,
        });
        if (!this.previewGenerationIsCurrent(generation, address, wallet)) {
          await this.discardPreviewTrace(address, previewTxHash);
          return null;
        }
        this._preparedPreviewClaims.set(previewTxHash, {
          address,
          createdAt: now,
          sourceItemsHash: hashClaimBatchItems(items),
          queuedItemsHash,
          queuedClaims: fused.claims,
          claims: preparedClaims,
          feeCoverInputs: fused.inputs,
          feeCoverItemCount: fused.feeCoverItemCount,
        });
        this.schedulePreviewTraceExpiry(address, previewTxHash);
        return {
          txHash: previewTxHash,
          feeBase: computeFee(
            this._fee?.amount ?? 0n,
            this._fee?.daFee ?? 0n,
            slots,
          ).toString(),
          slotsModified: slots,
          expiresAt: now + PREVIEW_TRACE_TTL_MS,
        };
      });
    } catch {
      if (previewTxHash) {
        await this.discardPreviewTrace(address, previewTxHash).catch(
          () => undefined,
        );
      }
      return null;
    }
  }

  /** Generate a private Review trace while retaining secrets and the hydrated
   * envelope only in this unlocked core's memory. */
  async previewPrivateTransferTrace(
    address: string,
    opts: {
      recipientShield: string;
      amount: bigint;
      contractId: bigint;
      preClaimItems?: ClaimBatchItem[];
    },
  ): Promise<{
    txHash: string;
    feeBase: string;
    slotsModified: number;
    expiresAt: number;
  } | null> {
    const generation = this._previewGeneration;
    const wallet = this._wallets.find(
      (candidate) => candidate.address === address,
    );
    if (
      !wallet ||
      !this.previewGenerationIsCurrent(generation, address, wallet)
    ) {
      return null;
    }
    const ftPin =
      BigInt(opts.contractId) >= 5n
        ? ftPinForContractLeaf(
            await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(
              BigInt(opts.contractId),
            ),
          )
        : null;
    if (BigInt(opts.contractId) >= 5n && !ftPin) return null;
    const built = buildPrivateTransferCall({
      recipientShield: opts.recipientShield,
      amount: BigInt(opts.amount),
      contractId: BigInt(opts.contractId),
      ftPin: ftPin ?? undefined,
    });
    if (!built) return null;
    const preClaims = opts.preClaimItems?.length
      ? opts.preClaimItems
      : undefined;
    const queuedItems: ClaimBatchItem[] = [
      ...(preClaims ?? []),
      { type: "public", data: built.call },
    ];
    const kind: TxQueueJobKind = preClaims ? "claim_batch" : "contract_call";
    const generateCall = wallet.wallet.generateTxTrace?.bind(wallet.wallet);
    const generateBatch = wallet.wallet.generateBatchClaimTxTrace?.bind(
      wallet.wallet,
    );
    if (
      (kind === "claim_batch" && !generateBatch) ||
      (!preClaims && !generateCall)
    ) {
      return null;
    }
    let previewTxHash: string | undefined;
    try {
      // Use the durable queue's complete prepare/execute lock, not only the
      // core's prove/submit FIFO, so queued work owns state before prepare.
      return await txQueue.runExclusive(async () => {
        await this.marketPreparation().assertNoPending(address, this._chainKey);
        if (!this.previewGenerationIsCurrent(generation, address, wallet)) {
          return null;
        }
        const preparedItems = preClaims
          ? await this.prepareClaimBatchItems(address, wallet, queuedItems)
          : queuedItems;
        const envelope = preClaims
          ? await generateBatch!(address, preparedItems)
          : await generateCall!(address, built.call);
        const previewResult = this.traceResultToSdkTxResult(
          envelope.tx_hash,
          envelope,
        ) as { end_cap_data?: { stats?: { slots_modified?: unknown } } };
        const rawSlots = previewResult.end_cap_data?.stats?.slots_modified;
        const slots =
          typeof rawSlots === "number"
            ? rawSlots
            : this.extractSlotsModified(
                this.parseTracePayloadForResult(envelope.trace?.payload),
              );
        if (
          slots == null ||
          !this.previewGenerationIsCurrent(generation, address, wallet)
        ) {
          return null;
        }
        const now = Date.now();
        const queuedItemsHash = hashClaimBatchItems(queuedItems);
        const memoryRecord: TraceRecord = {
          txHash: envelope.tx_hash,
          sigHash: envelope.sig_hash,
          queueId: `preview:${envelope.tx_hash}`,
          address,
          chainKey: this._chainKey,
          networkKey: this._networkKey,
          kind,
          itemsHash: queuedItemsHash,
          envelope,
          status: "generated",
          createdAt: now,
          updatedAt: now,
        };
        previewTxHash = envelope.tx_hash;
        this._previewTraceRecords.set(previewTxHash, memoryRecord);
        await traceStore.save(memoryRecord.chainKey, {
          ...memoryRecord,
          envelope: undefined,
        });
        if (!this.previewGenerationIsCurrent(generation, address, wallet)) {
          await this.discardPreviewTrace(address, previewTxHash);
          return null;
        }
        for (const [txHash, note] of this._privatePreviewNotes) {
          if (
            note.address === address ||
            now - note.createdAt > PREVIEW_TRACE_TTL_MS
          ) {
            void this.discardPreviewTrace(note.address, txHash);
          }
        }
        this._privatePreviewNotes.set(previewTxHash, {
          address,
          createdAt: now,
          noteSecretHash: built.noteSecretHash,
          nullifierSecret: built.nullifierSecret,
          secondaryNoteSecretHash: built.ftNotes?.[1].noteSecret,
          secondaryNullifierSecret: built.ftNotes?.[1].nullifierSecret,
        });
        if (preClaims) {
          this._preparedPreviewClaims.set(previewTxHash, {
            address,
            createdAt: now,
            sourceItemsHash: queuedItemsHash,
            queuedItemsHash,
            queuedClaims: queuedItems,
            claims: preparedItems,
            feeCoverInputs: [],
            feeCoverItemCount: 0,
          });
        }
        this.schedulePreviewTraceExpiry(address, previewTxHash);
        return {
          txHash: previewTxHash,
          feeBase: computeFee(
            this._fee?.amount ?? 0n,
            this._fee?.daFee ?? 0n,
            slots,
          ).toString(),
          slotsModified: slots,
          expiresAt: now + PREVIEW_TRACE_TTL_MS,
        };
      });
    } catch {
      if (previewTxHash) {
        await this.discardPreviewTrace(address, previewTxHash).catch(
          () => undefined,
        );
      }
      return null;
    }
  }

  async discardPreviewTrace(address: string, txHash: string): Promise<void> {
    this.cancelPreviewTraceTimer(txHash);
    if (this._privatePreviewNotes.get(txHash)?.address === address) {
      this._privatePreviewNotes.delete(txHash);
    }
    if (this._preparedPreviewClaims.get(txHash)?.address === address) {
      this._preparedPreviewClaims.delete(txHash);
    }
    if (this._previewTraceRecords.get(txHash)?.address === address) {
      this._previewTraceRecords.delete(txHash);
    }
    await traceStore.removeGeneratedPreview(this._chainKey, address, txHash);
  }

  /**
   * Recovery sweep for private transfers that died AFTER the chain commit:
   * backups that are committed on-chain (txHash set, not preCommit) but
   * whose proof was never built (`pendingProof`) or whose note was never
   * delivered (`nostrDelivered: false`). Runs on wallet load and on every
   * popup open (refreshPsyState), so a transfer interrupted by popup/SW
   * death finishes by itself the next time the wallet wakes up.
   * The prove call is transaction-pinned: it passes the immutable pre-submit
   * checkpoint plus the submitted transaction's end_user_leaf_hash, so the
   * SDK identifies this note's exact inclusion checkpoint. A "set twice with
   * different values" prover failure is no longer a deterministic permanent
   * verdict — a later sweep (fresh worker lifetime) retries the row; we just
   * log a non-transient failure and skip it for the rest of this lifetime.
   */
  async resumePendingPrivateTransfers(): Promise<void> {
    if (this._disposed || this._resumePrivateTransfersRunning) return;
    // A live run is already driving its own proof+delivery — don't race it.
    if (this._privateTransferStatus?.phase === "running") return;
    // Skip rows younger than this: a run from a previous SW incarnation may
    // still be in flight right after a restart, and proving the same note
    // twice wastes minutes of CPU (delivery itself is idempotent).
    const RESUME_MIN_AGE_MS = 5 * 60_000;
    this._resumePrivateTransfersRunning = true;
    try {
      for (const wallet of this._wallets) {
        const backupScope = this.privateTransferBackupScope(wallet);
        const backups = await listTransferBackups(backupScope).catch(
          () => [] as TransferBackup[],
        );
        for (const b of backups) {
          if (this._disposed) return;
          // FT submission intents carry the exact endcap BEFORE submission.
          // Probing that historical identity is read-only and never re-sends.
          if (
            !b.txHash ||
            (b.preCommit &&
              !(b.ftPin && b.submissionIntent && b.endUserLeafHash))
          )
            continue;
          const needsProof = !!b.pendingProof || !b.payload;
          const needsDelivery = !b.nostrDelivered;
          if (!needsProof && !needsDelivery) continue;
          // No persisted permanent-verdict skip here: transaction-pinned
          // checkpoint validation (end_user_leaf_hash + the immutable
          // pre-submit checkpoint) removed the premise that a "set twice
          // with different values" prover failure is deterministic, so a
          // flagged row is re-proven like any other pending row. The
          // once-per-SW-lifetime guard below still caps re-burns within a
          // single worker.
          const attemptKey = `${wallet.address}:${b.id}`;
          if (this._resumeAttemptedBackupKeys.has(attemptKey)) continue;
          if (Date.now() - b.createdAt < RESUME_MIN_AGE_MS) continue;
          this._resumeAttemptedBackupKeys.add(attemptKey);
          try {
            await this._resumeOneTransferBackup(wallet, b);
            console.info("[private-transfer][resume] recovered backup", {
              id: b.id,
              txHash: b.txHash?.slice(0, 12),
            });
          } catch (e) {
            const msg = (e as Error)?.message || String(e);
            if (
              /prover not ready/i.test(msg) ||
              isTransientNostrRelayError(e)
            ) {
              // Cold prover and transient relay-publish failures (open/OK
              // timeouts, mid-batch closes) are recoverable in this worker.
              // The finalized events remain stored, so a later sweep retries
              // the same ids over a fresh relay socket without re-signing.
              this._resumeAttemptedBackupKeys.delete(attemptKey);
              console.info(
                "[private-transfer][resume] transient failure, deferring",
                { id: b.id },
              );
            } else {
              // Includes the plonky2 "set twice with different values"
              // signature: with transaction-pinned checkpoint validation the
              // pre-submit checkpoint + end_user_leaf_hash target the note's
              // actual inclusion checkpoint, so this is no longer treated as
              // a deterministic permanent verdict. Log and let a later sweep
              // (fresh worker lifetime) retry — never persist a block flag.
              console.warn("[private-transfer][resume] attempt failed", {
                id: b.id,
                error: msg.slice(0, 200),
              });
            }
          }
        }
      }
    } finally {
      this._resumePrivateTransfersRunning = false;
    }
  }

  /**
   * One recovery sweep, driven by the pending-recovery chrome.alarm (see
   * background/pending-recovery-alarm.ts). The alarm's real work happens
   * implicitly — waking a dead worker runs the boot path, whose loadWallets
   * already reconciles restored rows and resumes incomplete transfers. This
   * method (called from main.ts's onAlarm) re-runs the resume sweep on a
   * live worker and answers ONE question: does recovery work remain, i.e.
   * should the alarm stay armed?
   *
   * Deliberately disarms (returns false) when:
   *   - wallets aren't loaded (password-locked after a restart): nothing CAN
   *     be recovered until the user unlocks via the popup, and the popup-open
   *     boot runs these same sweeps — a minute-ly wake would just burn cycles;
   *   - the only incomplete backups are unrecoverable automatically (no
   *     recovery secrets / no recipient npub) or older than the recovery
   *     window: those are the Saved-backups UI's job, and re-proving a
   *     deterministically-blocked backup every minute would waste minutes of
   *     WASM CPU per fire.
   */
  /**
   * Popup-open recovery kick for a WEDGED "proving" tx-queue entry.
   *
   * A full-balance send holds the whole balance via a pendingOut hold, so the
   * headline correctly reads 0 (the amber "Held" chip narrates it) WHILE the
   * spend is genuinely in flight. If the worker was evicted mid-proof the
   * entry is left orphaned in "proving" and its hold never lifts on its own —
   * the funds never left, but the headline keeps showing 0. recovery is the
   * ONLY authority that can safely resolve this: it re-checks the chain (and
   * resumes a persisted proof trace if one exists — the funds MAY still leave,
   * so the hold must NOT be dropped speculatively), and only marks the entry
   * failed + releases the hold when it confirms nothing was submitted.
   *
   * The boot path already fires this once (ctor) and the 1-min recovery alarm
   * re-fires it for a closed popup; a WARM reopen (SW alive, boot long past)
   * had no trigger, leaving a ≤60s wrong-0 window until the next alarm. Firing
   * here on every popup open bounds that window to recovery latency instead.
   * Fire-and-forget: recovery re-dispatches holds via refreshPendingRows when
   * it terminalizes an entry, so the headline self-heals; blocking the popup
   * paint on it would hang the UI behind a multi-second chain poll. Skips the
   * entry drive() is actively proving (recoverInterruptedProving's own
   * activeQueueId guard), so a legitimately in-flight send is never disturbed.
   */
  recoverInterruptedProvingOnOpen(): void {
    if (this._disposed) return;
    void txQueue.recoverInterruptedProving().catch(() => undefined);
  }

  async sweepPendingRecovery(): Promise<boolean> {
    if (this._disposed) return false;
    if (!this._wallets.length) return false;
    await this.resumePendingPrivateTransfers().catch(() => undefined);
    // Re-poll the durable tx-queue's "submitting" entries: a send that landed
    // but wasn't confirmed in drive()'s window would otherwise sit "confirming"
    // until a full worker cold boot, which the 6s checkpoint interval prevents
    // by keeping the worker alive. recoverInterruptedProving is a no-op when
    // nothing is submitting/proving and dedupes overlapping runs.
    await txQueue.recoverInterruptedProving().catch(() => undefined);
    // Pending Activity rows: either genuinely in flight on THIS worker (keep
    // the alarm as the safety net for its death) or owed a boot reconcile.
    if (transactionManager.txPending.length) return true;
    if (this._privateTransferStatus?.phase === "running") return true;
    const RECOVERY_WINDOW_MS = 30 * 60_000;
    for (const wallet of this._wallets) {
      const backups = await listTransferBackups(
        this.privateTransferBackupScope(wallet),
      ).catch(() => [] as TransferBackup[]);
      for (const b of backups) {
        if (
          !b.txHash ||
          (b.preCommit && !(b.ftPin && b.submissionIntent && b.endUserLeafHash))
        )
          continue;
        if (Date.now() - b.createdAt >= RECOVERY_WINDOW_MS) continue;
        const needsProof = !!b.pendingProof || !b.payload;
        const needsDelivery = !b.nostrDelivered;
        if (!needsProof && !needsDelivery) continue;
        if (needsProof && !b.noteCommitment) continue;
        if (needsProof && (!b.checkpointBefore || !b.endUserLeafHash)) continue;
        if (!needsProof && needsDelivery && !b.recipientNpub) continue;
        return true;
      }
    }
    return false;
  }

  /** Finish ONE committed-but-incomplete transfer backup: rebuild the note
   *  proof from the persisted secrets if needed, then deliver over Nostr. */
  async retryPrivateTransferBackup(address: string, id: string): Promise<void> {
    if (this._disposed || this._passwordManager.needPassword)
      throw new Error("Unlock the wallet before recovering a transfer");
    if (
      this._privateTransferStatus?.phase === "running" ||
      this._resumePrivateTransfersRunning
    )
      throw new Error("Another private transfer or recovery is running");
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) throw new Error("Wallet Not Found");
    this._resumePrivateTransfersRunning = true;
    try {
      const backup = (
        await listTransferBackups(this.privateTransferBackupScope(wallet))
      ).find((b) => b.id === id);
      if (!backup) throw new Error("Transfer backup not found for this wallet");
      await this._resumeOneTransferBackup(wallet, backup);
    } finally {
      this._resumePrivateTransfersRunning = false;
    }
  }

  private async _resumeOneTransferBackup(
    wallet: IPsyWidgetWallet,
    b: TransferBackup,
  ): Promise<void> {
    const backupScope = this.privateTransferBackupScope(wallet);
    if (b.ftPin) {
      const pin = ftPinForContractLeaf(
        await this._provider.coordinatorEdgeRpcProvider.getContractLeafData(
          BigInt(b.contractId),
        ),
      );
      if (
        !pin ||
        pin.profile !== b.ftPin.profile ||
        pin.codeRoot !== b.ftPin.codeRoot ||
        pin.layoutRoot !== b.ftPin.layoutRoot
      )
        throw new Error("FT backup no longer matches authenticated contract");
      if (!b.checkpointBefore || !b.endUserLeafHash || !b.txHash)
        throw new Error(
          "FT recovery needs the original transaction identity; never resend",
        );
      let payload = b.payload;
      let raw: string;
      if (!payload || b.pendingProof) {
        const low = await findNoteSecret(backupScope, b.noteCommitment ?? "");
        const high = await findNoteSecret(
          backupScope,
          b.secondaryNoteCommitment ?? "",
        );
        if (!low || !high)
          throw new Error("FT recovery note secrets unavailable");
        await this._waitForProver("resumePrivateFtTransfer");
        const toWords = (values: string[]) => values.map(BigInt) as FtWords;
        raw = await proveFtOutgoing({
          address: wallet.address,
          owner: shieldAddressToU64x4(b.recipientShield).map(BigInt) as FtWords,
          amount: BigInt(b.amount),
          contractId: BigInt(b.contractId),
          pin,
          notes: [low, high].map((note) => ({
            noteSecret: toWords(note.noteSecret),
            nullifierSecret: toWords(note.nullifierSecret),
          })) as [
            { noteSecret: FtWords; nullifierSecret: FtWords },
            { noteSecret: FtWords; nullifierSecret: FtWords },
          ],
          checkpointBefore: b.checkpointBefore,
          endUserLeafHash: b.endUserLeafHash,
          prove: (args) =>
            runWalletWasmServerMethod<string>(
              "resume FT note proof",
              "prove_private_note_inclusion_json",
              [
                args.address,
                args.ownerJson,
                args.amount,
                args.noteSecretHashJson,
                args.nullifierSecretJson,
                args.contractId,
                args.noteRootSlot,
                args.checkpointId,
                args.endUserLeafHash,
              ],
            ),
        });
        payload = buildNostrPayload({
          recipientShield: b.recipientShield,
          amount: BigInt(b.amount),
          contractId: BigInt(b.contractId),
          tokenSymbol: b.tokenSymbol,
          decimals: b.decimals,
          txHash: b.txHash,
          noteProofRaw: raw,
          ftPin: pin,
        });
        await updateTransferBackupRequired(backupScope, b.id, {
          payload,
          pendingProof: false,
          preCommit: false,
        });
      } else {
        raw = ftRawPacket(PsyJSON.parse(payload).noteProofRaw);
      }
      if (!b.nostrDelivered) {
        if (!b.recipientNpub) return;
        const verify = (this._provider.prover as PrivateFtPacketProver)
          .verifyPrivateFtPacket;
        if (!verify) throw new Error(
          "Private FT packet verification is unsupported by the selected SDK",
        );
        const checked = await verify.call(
          this._provider.prover,
          pin.profile,
          raw,
          pin.codeRoot,
          pin.layoutRoot,
        );
        if (
          !checked.verified ||
          checked.amount !== b.amount ||
          checked.contractId !== b.contractId
        )
          throw new Error("Recovered FT packet identity differs");
        const events = b.signedNostrEvents?.length
          ? b.signedNostrEvents
          : buildSignedFtEvents(raw, b.recipientNpub);
        await updateTransferBackupRequired(backupScope, b.id, {
          signedNostrEvents: events,
        });
        await publishSignedEvents(events, nostrRelay(this._config), 1);
        await updateTransferBackupRequired(backupScope, b.id, {
          nostrDelivered: true,
        });
      }
      return;
    }
    let payload = b.payload;
    let secret = await migrateLegacyNoteSecret(backupScope, b);
    let noteProofRaw: string | undefined;
    const shieldLimbs = shieldAddressToU64x4(b.recipientShield);
    if (shieldLimbs.length !== 4) return;
    if (!payload || b.pendingProof) {
      if (!secret) {
        console.warn(
          "[private-transfer-resume] missing note secret for backup",
          {
            backupId: b.id,
            noteCommitment: b.noteCommitment ?? null,
          },
        );
        return;
      }
      // Transaction-pinned recovery requires BOTH the immutable pre-submit
      // checkpoint and the submitted transaction's end_user_leaf_hash. A
      // committed backup missing either predates transaction-pinned recovery
      // and cannot be reproven — reject with a clear error rather than
      // substituting "0"/the tx hash/a current checkpoint (none pin to this
      // note's actual inclusion checkpoint).
      if (!b.checkpointBefore || !b.endUserLeafHash) {
        throw new Error(
          "Cannot retry proof for this backup: it predates transaction-pinned " +
            "recovery and is missing its pre-submit checkpoint or " +
            "end_user_leaf_hash. Re-send the transfer or recover from a " +
            "backup made after the wallet update.",
        );
      }
      await this._waitForProver("resumePrivateTransferBackup");
      noteProofRaw = await runWalletWasmServerMethod<string>(
        "resume prove_private_note_inclusion_json",
        "prove_private_note_inclusion_json",
        [
          wallet.address,
          PsyJSON.stringify(shieldLimbs),
          b.amount,
          PsyJSON.stringify(secret.noteSecret),
          PsyJSON.stringify(secret.nullifierSecret),
          b.contractId,
          (b.noteRootSlot ?? DEFAULT_NOTE_ROOT_SLOT.toString()).toString(),
          b.checkpointBefore,
          b.endUserLeafHash,
        ],
      );
      if (!noteProofRaw || noteProofRaw.length < 100) {
        throw new Error("resume proof RPC returned empty/invalid output");
      }
      payload = buildNostrPayload({
        recipientShield: b.recipientShield,
        amount: BigInt(b.amount),
        contractId: BigInt(b.contractId),
        tokenSymbol: b.tokenSymbol,
        decimals: b.decimals,
        txHash: b.txHash ?? "",
        noteProofRaw,
      });
      await updateTransferBackup(backupScope, b.id, {
        payload,
        pendingProof: false,
      });
    } else {
      try {
        const parsed = PsyJSON.parse(payload) as { noteProofRaw?: unknown };
        noteProofRaw =
          typeof parsed.noteProofRaw === "string"
            ? parsed.noteProofRaw
            : parsed.noteProofRaw && typeof parsed.noteProofRaw === "object"
              ? PsyJSON.stringify(parsed.noteProofRaw)
              : undefined;
      } catch {
        noteProofRaw = undefined;
      }
    }
    if (!b.nostrDelivered) {
      // Without the recipient's npub we can't deliver — the row stays
      // "Needs manual delivery" and the payload is downloadable.
      if (!b.recipientNpub) return;
      if (!secret || !b.noteCommitment || !noteProofRaw) return;
      const relay = nostrRelay(this._config);
      const signedEvents =
        b.signedNostrEvents?.length === 2
          ? b.signedNostrEvents
          : buildPrivateTransferSignedEvents({
              receiverNpub: b.recipientNpub,
              recipientShieldLimbs: shieldLimbs as [
                string,
                string,
                string,
                string,
              ],
              amount: b.amount,
              contractId: b.contractId,
              txHash: b.txHash ?? "",
              noteCommitment: b.noteCommitment,
              noteProofRaw,
              nullifierSecret: secret.nullifierSecret,
              noteSecret: secret.noteSecret,
            }).events;
      if (!b.signedNostrEvents?.length) {
        await updateTransferBackup(backupScope, b.id, {
          signedNostrEvents: signedEvents,
        });
      }
      try {
        await publishPrivateTransfer(
          {
            receiverNpub: b.recipientNpub,
            recipientShieldLimbs: shieldLimbs as [
              string,
              string,
              string,
              string,
            ],
            amount: b.amount,
            contractId: b.contractId,
            txHash: b.txHash ?? "",
            noteCommitment: b.noteCommitment,
            noteProofRaw,
            nullifierSecret: secret.nullifierSecret,
            noteSecret: secret.noteSecret,
          },
          relay,
          signedEvents,
        );
      } catch (error) {
        console.warn("[private-transfer] backup redelivery failed", {
          relay,
          backupId: b.id,
          error,
        });
        throw error;
      }
      await updateTransferBackup(backupScope, b.id, {
        nostrDelivered: true,
      });
    }
  }

  async deployContract(
    address: string,
    circuitDefs: DPNFunctionCircuitDefinition[],
    abi?: unknown,
    metadata?: Record<string, unknown>,
    servicesUrl?: string,
  ) {
    void metadata;
    void servicesUrl;
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw Error("Wallet Not Found");
    }
    if (!Array.isArray(circuitDefs) || circuitDefs.length === 0) {
      throw new Error("No circuit definitions supplied for deploy");
    }
    if (
      typeof wallet.userId !== "bigint" &&
      (typeof wallet.userId !== "number" || !Number.isSafeInteger(wallet.userId))
    ) {
      throw new Error("Contract deployer must be a numeric u64 user ID");
    }
    const deployer = validateDeployerUserId(BigInt(wallet.userId));
    if (abi == null) {
      throw new Error("Contract ABI is required for layout-aware deployment");
    }
    const deployTimeout = async <T>(
      label: string,
      promise: Promise<T>,
      timeoutMs: number,
      onTimeout?: () => void,
    ): Promise<T> => {
      let timer: ReturnType<typeof setTimeout> | undefined;
      try {
        return await Promise.race([
          promise,
          new Promise<never>((_, reject) => {
            timer = setTimeout(() => {
              onTimeout?.();
              reject(
                new Error(
                  `Deploy timed out while ${label}; reload the wallet extension and try again.`,
                ),
              );
            }, timeoutMs);
          }),
        ]);
      } finally {
        if (timer) clearTimeout(timer);
      }
    };

    console.warn("[deploy-contract] wait-prover:start", {
      address,
      userId: String(wallet.userId),
      circuitCount: circuitDefs.length,
    });
    await deployTimeout(
      "waiting for the local prover",
      this._waitForProver("deployContract"),
      90_000,
    );
    console.warn("[deploy-contract] wait-prover:done", {
      address,
      userId: String(wallet.userId),
      circuitCount: circuitDefs.length,
    });
    await wallet.wallet.refresh();
    console.warn("[deploy-contract] submit:start", {
      address,
      userId: String(wallet.userId),
      circuitCount: circuitDefs.length,
    });
    const registeredUserId = await deployTimeout(
      "checking the registered deployment owner",
      this._provider.coordinatorEdgeRpcProvider.getUserId(wallet.address),
      30_000,
    );
    if (
      !Number.isSafeInteger(registeredUserId) ||
      BigInt(registeredUserId) !== deployer
    ) {
      throw new Error("Contract deployer differs from the registered wallet owner");
    }
    const deployCmd = await deployTimeout(
      "building the deploy command",
      this._provider.prover.getDeployContractCmd(
        deployer,
        circuitDefs,
        abi,
      ),
      30 * 60_000,
    );
    console.warn("[deploy-contract] command:done", {
      address,
      userId: String(wallet.userId),
      circuitCount: circuitDefs.length,
    });
    const submitController = new AbortController();
    const txHash = await deployTimeout(
      "submitting the deployment",
      this._provider.coordinatorEdgeRpcProvider.deployContract(
        deployCmd,
        submitController.signal,
      ),
      30_000,
      () => submitController.abort(),
    );
    console.warn("[deploy-contract] submit:done", {
      address,
      userId: String(wallet.userId),
      txHash,
    });
    return txHash;
  }

  async simulateContractCall(
    address: string,
    args: ContractCallArgs | ContractCallArgs[],
  ): Promise<SimulatedTxJson> {
    await this._waitForProver("simulateContractCall");
    const wallet = this._wallets.find((entry) => entry.address === address);
    if (!wallet) throw new Error("Wallet Not Found");
    if (Array.isArray(args) && args.length === 0) {
      throw new Error("No contract calls supplied");
    }

    await this.ensureWalletKeyInWasm(wallet);
    await wallet.wallet.refresh();
    const callData: ContractCallData = {
      contract_calls: Array.isArray(args) ? args : [args],
      software_defined_call: { inputs: [] },
    };
    return this._provider.prover.simulateContractCall(address, callData);
  }

  async getPrivateKey(address: string) {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw Error("Wallet Not Found");
    }
    return wallet.wallet.signer.getPrivateKeyHex?.();
  }

  async decryptNostrSecretsEvent(
    address: string,
    shieldAddress: string,
    eventJson: unknown,
  ): Promise<string | null> {
    const wallet = this._wallets.find((w) => w.address === address);
    if (!wallet) {
      throw Error("Wallet Not Found");
    }
    const target = normalizeShieldAddress(String(shieldAddress ?? ""));
    if (!target) {
      throw new Error("Invalid shield address");
    }
    const receive = (wallet.shieldReceiveAddresses ?? []).find(
      (entry) => normalizeShieldAddress(entry.shieldAddress) === target,
    );
    if (!receive) {
      throw new Error("Shield receive address not found");
    }
    const event =
      typeof eventJson === "string"
        ? (PsyJSON.parse(eventJson) as NostrEvent)
        : (eventJson as NostrEvent);
    if (
      !event ||
      typeof event !== "object" ||
      typeof event.content !== "string" ||
      typeof event.pubkey !== "string"
    ) {
      throw new Error("Invalid Nostr event");
    }
    const privateKeyHex = await this.getWalletPrivateKey(wallet);
    const receiverSk = await derivePrivacyNostrSecretKey(
      privateKeyHex,
      receive.r0,
      receive.r1,
    );
    try {
      const wrapConvKey = nip44.v2.utils.getConversationKey(
        receiverSk,
        event.pubkey,
      );
      const seal = JSON.parse(
        nip44.v2.decrypt(event.content, wrapConvKey),
      ) as NostrEvent;
      if (
        !seal ||
        typeof seal.content !== "string" ||
        typeof seal.pubkey !== "string"
      ) {
        throw new Error("Invalid Nostr seal");
      }
      const sealConvKey = nip44.v2.utils.getConversationKey(
        receiverSk,
        seal.pubkey,
      );
      return nip44.v2.decrypt(seal.content, sealConvKey);
    } catch (error) {
      if (event.content.trimStart().startsWith("{")) {
        return event.content;
      }
      throw error;
    }
  }

  async addWalletFromMnemonic(
    mn: string,
    signType: SignType,
    fingerprint?: string,
    walletName?: string,
    sdkKeyCircuitParams?: ISdkKeyCircuitParams,
  ) {
    const mnInd = this._passwordManager.getMnemonicsLength();
    const privateKey = this._passwordManager.importPrivateKeyFromMnemonic(mn);
    try {
      return await this.addWalletFromPrivateKey(
        privateKey,
        signType,
        fingerprint,
        mnInd,
        true,
        walletName,
        sdkKeyCircuitParams,
      );
    } catch (error) {
      // importPrivateKeyFromMnemonic already PUSHED the mnemonic; if adding the
      // wallet fails (e.g. "Account Exists" on a re-import that slipped the
      // dedup), roll the mnemonic back so it doesn't leak a phantom seed slot
      // (which would render an empty/duplicate "Seed Phrase" group).
      await this._passwordManager.newRandomWalletFailed(mnInd);
      throw error;
    }
  }
}
