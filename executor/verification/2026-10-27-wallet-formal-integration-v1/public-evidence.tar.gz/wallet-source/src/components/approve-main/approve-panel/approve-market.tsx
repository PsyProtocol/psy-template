import bundle from "@/market-preparation/bundle.json";
import { useEffect, useState } from "react";
import type { ApprovePreparedMarketMsg } from "@/types";
import { usePsyStateSelector } from "@/hooks/use-psy-state";
import { sendApproveResult } from "@/message";
import { MarketLimitRows } from "@/market-native/LimitRows";
import { marketConfirmation } from "@/market-native/confirmation";
import {
  ApproveShell,
  ApproveHero,
  ApproveOriginCard,
  ApproveAccountCard,
  DetailDisclosure,
} from "../approve-ui";
import { Icons } from "@/components/ui/icons";

export default function ApproveMarket({
  msg,
}: {
  msg: ApprovePreparedMarketMsg;
}) {
  const [account, terms, expected] = msg.params;
  const { wallets } = usePsyStateSelector("wallets");
  const wallet = wallets.find((w) => w.address === account);
  const [valid, setValid] = useState(false);
  const [limits, setLimits] = useState<Array<{ label: string; value: string }>>(
    [],
  );
  useEffect(() => {
    let live = true;
    void marketConfirmation(terms)
      .then((v) => {
        if (live) {
          setValid(
            v.approvalSha256 === expected && account === terms.context.account,
          );
          setLimits(v.limits);
        }
      })
      .catch(() => {
        if (live) setValid(false);
      });
    return () => {
      live = false;
    };
  }, [account, terms, expected]);
  const deny = () => {
    void sendApproveResult(
      msg.id,
      null,
      "User rejected exact market transaction",
    ).finally(window.close);
  };
  const allow = async () => {
    const checked = await marketConfirmation(terms);
    if (
      !valid ||
      !wallet ||
      !acceptedMarket ||
      checked.approvalSha256 !== expected
    )
      throw Error("Exact market approval changed");
    await sendApproveResult(
      msg.id,
      { approved: true, approvalSha256: expected },
      null,
    );
    window.close();
  };
  const plan = terms.review.plan;
  const reviewed = [bundle, bundle.amm].find(
    (b) => b.registryHash === plan.registryHash,
  );
  const market = reviewed?.registry.markets.find(
    (m) => m.marketId === plan.marketId,
  );
  const acceptedMarket = Boolean(
    market &&
      market.kind !== "nftmarket" &&
      !("quarantined" in market && market.quarantined === true),
  );
  return (
    <ApproveShell
      onCancel={deny}
      onConfirm={allow}
      confirmDisabled={!valid || !wallet || !acceptedMarket}
      cancelLabel="Reject"
      confirmLabel="Approve exact transaction"
      footerNote="Approval permits one exact send after fresh checks. Confirmation and asset claim are separate steps."
    >
      <ApproveHero
        icon={<Icons.security className="h-7 w-7" />}
        eyebrow="Verified market plan"
        title="Approve market transaction"
        subtitle="Review the account, limits and exact request before broadcast."
      />
      <ApproveOriginCard origin={terms.context.origin} />
      {wallet && (
        <ApproveAccountCard
          address={wallet.address}
          name={wallet.name}
          userId={wallet.userId}
        />
      )}
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-2 rounded-2xl border border-borderGray p-4 text-sm">
        <dt>Action</dt>
        <dd className="break-all">{plan.kind}</dd>
        <dt>Network</dt>
        <dd>{plan.network.name}</dd>
        <dt>Market</dt>
        <dd>{plan.marketId}</dd>
        <dt>Recipient</dt>
        <dd>{plan.recipientId}</dd>
        <dt>Nonce</dt>
        <dd>{plan.walletNonce}</dd>
        <dt>Actual network fee</dt>
        <dd>{terms.actualFee} PSY base units</dd>
        <dt>Fee limit</dt>
        <dd>{terms.maxNetworkFee} PSY base units</dd>
        <dt>Valid through</dt>
        <dd>Checkpoint {terms.validUntilCheckpoint}</dd>
      </dl>
      <div className="rounded-2xl border border-borderGray p-4 text-sm">
        {!acceptedMarket && (
          <p role="alert">
            No active reviewed market identity matches this confirmation.
          </p>
        )}
        {market && (
          <p className="mb-2">
            Market assets:{" "}
            {market.assets
              .map((a) => `contract ${a.contractId} (${a.decimals} decimals)`)
              .join(" / ")}
          </p>
        )}
        <p className="font-medium">Maximum asset debits (base units)</p>
        {plan.debits.map((d, i) => (
          <p className="break-all" key={`${d.contractId}:${i}`}>
            Contract {d.contractId}: {d.amount}
          </p>
        ))}
        <MarketLimitRows rows={limits} />
      </div>
      <p className="text-sm text-black2">
        A submitted order is not a completed trade. Outputs remain pending until
        settlement and claim.
      </p>
      <DetailDisclosure summary="Exact approved plan and ordered calls">
        <pre className="max-h-72 overflow-auto whitespace-pre-wrap break-all text-xs">
          {JSON.stringify(
            { request: terms.review.request, plan, calls: terms.fullCalls },
            null,
            2,
          )}
        </pre>
      </DetailDisclosure>
      <DetailDisclosure summary="Transaction identity">
        <pre className="whitespace-pre-wrap break-all text-xs">
          {JSON.stringify(
            {
              requestSha256: terms.requestSha256,
              preparedHash: terms.preparedHash,
              approvalSha256: expected,
              chainRootAt1: plan.network.chainRootAt1,
            },
            null,
            2,
          )}
        </pre>
      </DetailDisclosure>
    </ApproveShell>
  );
}
