import {
  type ClaimBatchItem,
  PsyJSON,
  PsyWasmWebProverProvider,
} from "@psy-protocol/psy-sdk";
import type { PsyNetworkConfig } from "@psy-protocol/psy-sdk/config";
import { nip19, getPublicKey as nostrGetPublicKey } from "nostr-tools";
import browser from "webextension-polyfill";
import {marketActions,routeMarketRequest} from "./market-router";
import accountsApproved from "@/background/accounts-approved";
import approveManager from "@/background/approve-manager";
import { AUTO_LOCK_ALARM } from "@/background/auto-lock-alarm";
import { initWasm } from "@/background/init-wasm";
import {
  clearPendingRecoveryAlarm,
  PENDING_RECOVERY_ALARM,
} from "@/background/pending-recovery-alarm";
import {
  assertApprovedAccountForOrigin,
  assertTrustedExtensionSender,
  assertWalletUnlocked,
  isTrustedExtensionSender,
  senderOrigin,
} from "@/background/security-gates";
import {
  getActiveNetwork,
  loadConfig,
  saveConfig,
  setActiveNetwork,
} from "@/config";
import type { NetworkType } from "@/env.ts";
import { getWalletBuildInfo } from "@/build-info";
import {
  loadChainIdentityRecord,
  observeChainIdentity,
  saveChainIdentityRecord,
} from "@/lib/chainIdentity";
import { preCheckNetwork } from "@/lib/data.ts";
import storage from "@/lib/extStorage";
import { hostedFaucetOrigin } from "@/lib/faucet";
import {
  externalProofParamsToPrivateTransferClaimRaw,
  shieldDepositParamsToClaimBatchItem,
} from "@/lib/claimables";
import { derivePrivacyNostrSecretKey } from "@/lib/shield-address";
import { txHashFromSdkResult } from "@/lib/transaction";
import { getOriginFromUrl } from "@/lib/utils";
import {
  closeOffscreenWasmDocument,
  invalidateOffscreenWasmRequests,
  OFFSCREEN_WASM_ENABLED,
  runWalletWasmServerCall,
  runWalletWasmServerMethod,
} from "@/lib/wallet";
import { setWasmExclusiveGate } from "@/lib/wasm-exclusive";
import type { PsyInternalRequest } from "@/types";
import {
  actions,
  approveActions,
  PSY_INTERNAL_REQUEST_ACTION,
  psyStateDispatch,
} from "../message";
import connectionManager from "./connection-manager";
import PsyWalletExtCore, {
  allowMethods,
  type IPsyState,
} from "./psy-wallet-ext-core";

async function deriveNostrSk(
  privKeyHex: string,
  random0: string,
  random1: string,
): Promise<Uint8Array> {
  return derivePrivacyNostrSecretKey(privKeyHex, random0, random1);
}

const CONNECT_TIMEOUT = 10000;

// A passing prove-proxy check is cached in session storage so repeated prover
// starts skip the up-to-10s RPC round-trip. Keep this out of reloadCore: normal
// wallet boot/read-only usage must not depend on prove_proxy_url. A FAILED
// check is never cached — the next proof attempt retries.
const NETWORK_OK_CACHE_KEY = "psy_network_ok_cache";
const NETWORK_OK_TTL_MS = 60_000;

let connecting = false;
let psyWalletCore: PsyWalletExtCore | null = null;
let initStatus: IPsyState["initStatus"] = "initializing";
let initError: string | undefined;
let wasmInitPromise: Promise<void> | null = null;
let wasmInitKey: string | null = null;
let wasmInitGeneration = 0;
// Deferred WASM init: reloadCore records WHAT to init here instead of
// starting it inline. The Plonky2 circuit build runs in long synchronous
// chunks that block the service-worker thread for tens of seconds, so
// starting it before the popup's first state round-trip kept users staring
// at the "Connect to Wallet"/"Initialize Wallet" splash for the whole
// build. The init is started either by kickWasmInitSoon() (shortly after
// the first state paint) or lazily by waitForWasm() when a proving action
// actually needs it — whichever comes first.
let pendingWasmInit: { config: PsyNetworkConfig; networkKey: string } | null =
  null;
// True once a deferred WASM init ATTEMPT failed (prove-proxy reachability,
// compile, or circuit-build error). Without it the popup's "Preparing prover…"
// pill would spin forever after a failed init; with it the pill flips to
// "Prover unavailable" with a Retry (retryInit) affordance. Boolean rather than
// an optional string because psyStateDispatch JSON-serializes state and
// undefined fields are dropped — a cleared error could never overwrite a stale
// one.
let proverFailed = false;
// Offscreen-proving readiness. The WASM server lives in the offscreen worker,
// NOT this service worker, so PsyWasmWebProverProvider.wasmServer is always
// undefined here under offscreen mode — we can't read readiness off it. Track
// it explicitly: set true when initWasm() resolves, false on failure/teardown.
let offscreenProverReady = false;

interface RuntimeNetworkIdentity {
  networkKey: string;
  chainKey: string;
  previousChainKey?: string;
}

async function resolveRuntimeNetworkKey(
  network: NetworkType,
  config: PsyNetworkConfig,
): Promise<RuntimeNetworkIdentity> {
  const stored = await loadChainIdentityRecord(network).catch(() => undefined);
  const observation = await observeChainIdentity(config, stored?.root);

  if (!observation) {
    if (stored) {
      return {
        networkKey: `${network}:${stored.root}`,
        chainKey: stored.root,
      };
    }
    throw new Error(
      `Cannot establish the active ${network} chain: configured RPC endpoints did not return a valid checkpoint-1 root. Check your connection and Network Settings, then try again.`,
    );
  }

  if (!stored || stored.root === observation.root) {
    await saveChainIdentityRecord(network, {
      root: observation.root,
      updatedAt: observation.observedAt,
    }).catch(() => {});
  }
  return {
    networkKey: `${network}:${observation.root}`,
    chainKey: observation.root,
    ...(stored && stored.root !== observation.root
      ? { previousChainKey: stored.root }
      : {}),
  };
}

function replacePsyWalletCore(core: PsyWalletExtCore) {
  psyWalletCore?.dispose();
  psyWalletCore = core;
}

async function disposePsyWalletCore() {
  psyWalletCore?.dispose();
  psyWalletCore = null;
  wasmInitGeneration += 1;
  wasmInitPromise = null;
  wasmInitKey = null;
  pendingWasmInit = null;
  // Network switch: tear down the prior network's prover. With the offscreen
  // document that means closing it; otherwise reset the in-SW singleton
  // wasmServer (the SDK ignores a new config once initialized, so leaving it
  // bound would keep proving against the previous realm/chain).
  offscreenProverReady = false;
  if (OFFSCREEN_WASM_ENABLED) {
    invalidateOffscreenWasmRequests();
    await closeOffscreenWasmDocument();
  } else {
    (
      PsyWasmWebProverProvider as unknown as { wasmServer?: unknown }
    ).wasmServer = undefined;
  }
}

function decodeParams(raw: any): any {
  if (raw == null) return [];
  if (typeof raw === "string") return PsyJSON.parse(raw || "[]");
  return raw;
}

function isFaucetVerificationPage(url?: string): boolean {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return (
      parsed.origin === hostedFaucetOrigin() &&
      (parsed.pathname === "/wallet/faucet-verify" ||
        parsed.pathname === "/wallet-faucet-verify")
    );
  } catch {
    return false;
  }
}

// Live readback for state dispatches — a variable would drift across the
// dispose/reload paths that reset wasmServer. Under OFFSCREEN_WASM_ENABLED the
// in-SW wasmServer stays unset (proving runs in the offscreen document), so
// this reflects only the legacy in-SW path; offscreen readiness is signalled
// by startWasmInit's explicit proverReady dispatch.
const isProverReady = () =>
  OFFSCREEN_WASM_ENABLED
    ? offscreenProverReady
    : !!(PsyWasmWebProverProvider as unknown as { wasmServer?: unknown })
        .wasmServer;

function firstProveProxyUrl(config: PsyNetworkConfig): string {
  return (config.prove_proxy_url ?? []).find((u) => !!u?.trim())?.trim() ?? "";
}

async function ensureProveProxyReachableForProver(
  config: PsyNetworkConfig,
  networkKey: string,
): Promise<void> {
  const proveUrl = firstProveProxyUrl(config);
  if (!proveUrl) {
    throw new Error("Prove Proxy URL is not configured");
  }

  const preCheckStart = Date.now();
  try {
    const cached = (await storage.sessionGet(NETWORK_OK_CACHE_KEY)) as
      | { url?: string; networkKey?: string; ts?: number }
      | undefined;
    if (
      cached?.url === proveUrl &&
      cached?.networkKey === networkKey &&
      typeof cached.ts === "number" &&
      Date.now() - cached.ts < NETWORK_OK_TTL_MS
    ) {
      console.info(
        `[psy-wallet][prover] prove proxy check skipped (cached ${Date.now() - cached.ts}ms ago)`,
      );
      return;
    }
  } catch {
    // Cache read is best-effort; fall through to the live check.
  }

  try {
    await preCheckNetwork(config, CONNECT_TIMEOUT);
    console.info(
      `[psy-wallet][prover] prove proxy check passed in ${Date.now() - preCheckStart}ms`,
    );
    void storage
      .sessionSet(NETWORK_OK_CACHE_KEY, {
        url: proveUrl,
        networkKey,
        ts: Date.now(),
      })
      .catch(() => {});
  } catch (e) {
    // Non-destructive: prove_proxy_url only enters storage via an explicit
    // Settings save, so a dead URL is the user's deliberate choice. Report the
    // failure and let prover init surface it (proverFailed / retry pill) — do
    // NOT swap to the bundled default or clear the stored override. Tying a
    // reachability read to a config write is what caused the "saved then
    // reverted" bug (any unreachable override was silently healed to default).
    void storage.sessionRemove(NETWORK_OK_CACHE_KEY).catch(() => {});
    console.warn(
      `[psy-wallet][prover] prove proxy check failed after ${Date.now() - preCheckStart}ms:`,
      e,
    );
    throw e;
  }
}

function startWasmInit(config: PsyNetworkConfig, networkKey: string) {
  if (wasmInitPromise && wasmInitKey === networkKey) {
    return wasmInitPromise;
  }
  wasmInitKey = networkKey;
  const generation = (wasmInitGeneration += 1);
  proverFailed = false;
  initError = undefined;
  wasmInitPromise = ensureProveProxyReachableForProver(config, networkKey)
    .then(() => {
      if (wasmInitGeneration !== generation || wasmInitKey !== networkKey) {
        return;
      }
      return initWasm(config);
    })
    .then(() => {
      if (wasmInitGeneration !== generation || wasmInitKey !== networkKey) {
        return;
      }
      // Tell open popups the prover is warm so the "Preparing prover…"
      // pill can clear without another refresh round-trip. Latch offscreen
      // readiness so later isProverReady()-based dispatches keep it cleared.
      offscreenProverReady = true;
      void psyStateDispatch({ proverReady: true, proverFailed: false });
    })
    .catch((e) => {
      console.warn(
        "[psy-wallet][boot] WASM init failed, continuing without it:",
        e,
      );
      if (wasmInitGeneration !== generation || wasmInitKey !== networkKey) {
        return;
      }
      // Flip the popup's warming pill to its failed/retry variant.
      offscreenProverReady = false;
      proverFailed = true;
      initError = e?.message || String(e);
      pendingWasmInit = { config, networkKey };
      void psyStateDispatch({
        initError,
        proverReady: false,
        proverFailed: true,
      });
    })
    .finally(() => {
      if (wasmInitGeneration === generation && wasmInitKey === networkKey) {
        wasmInitPromise = null;
      }
    });
  return wasmInitPromise;
}

// Starts the deferred init recorded by reloadCore, if any. Idempotent:
// pendingWasmInit is consumed on first call and startWasmInit dedupes by
// network key, so the kick timer and a racing waitForWasm can both call
// this safely.
function startPendingWasmInit(): Promise<void> {
  if (
    (PsyWasmWebProverProvider as unknown as { wasmServer?: unknown }).wasmServer
  )
    return Promise.resolve();
  if (wasmInitPromise) return wasmInitPromise;
  const pending = pendingWasmInit;
  if (!pending) return Promise.resolve();
  pendingWasmInit = null;
  console.info("[psy-wallet][boot] starting deferred WASM circuit init");
  return startWasmInit(pending.config, pending.networkKey);
}

// Schedule the deferred WASM init slightly after the current dispatch
// settles. The delay exists to let the popup's first refreshPsyState
// round-trip (state dispatch + cached-snapshot paint) land before the
// thread-blocking circuit build starts; 150ms is invisible next to the
// build's tens of seconds. Callers invoke this right after they finish
// dispatching post-reload state.
function kickWasmInitSoon() {
  if (!pendingWasmInit) return;
  setTimeout(() => {
    void startPendingWasmInit();
  }, 150);
}

// Warm-SW fast paint: re-dispatch the core's last snapshot immediately (no
// recompute, no scan). Cold boot does not use a separate last-active pointer;
// the storage layout keeps only `psy_wallet_snapshot:{chainKey}:{userId}`.
async function dispatchBootPaint(): Promise<void> {
  try {
    if (psyWalletCore) {
      psyWalletCore.repaintLastWalletSnapshot();
    }
  } catch {
    // Best-effort paint; the authoritative refresh below still runs.
  }
}

async function waitForWasm(action: string) {
  // A proving action is the hard requirement for WASM — if the deferred
  // init hasn't been kicked yet, start it now instead of waiting for the
  // post-paint timer.
  const init = startPendingWasmInit();
  await init;
  if (wasmInitPromise) {
    await wasmInitPromise;
  }
  try {
    if (OFFSCREEN_WASM_ENABLED) {
      await runWalletWasmServerMethod("wait_for_wasm", "ping", [action]);
    } else {
      await runWalletWasmServerCall("wait_for_wasm", () => undefined);
    }
  } catch {
    const detail =
      proverFailed && initError
        ? initError
        : initStatus === "network_failed"
          ? "A configured RPC endpoint is unreachable — check the network URLs in Settings."
          : "Wait for initialization to complete or reload the wallet.";
    throw new Error(
      `[${action}] prover not ready (initStatus=${initStatus}). ${detail}`,
    );
  }
}

// Every WasmRpcServer-touching operation in the SW now rides ONE exclusive
// FIFO (lib/wasm-exclusive.ts): wasm-bindgen async methods hold a &mut
// borrow of the server for their future's whole lifetime, so any concurrent
// entry throws "recursive use of an object … unsafe aliasing in rust"
// (QA F-1: the restored wallet's lazy stored add_user vs. the first send).
// The queue gates each slot on the same waitForWasm as the proving actions,
// so it also lazily starts the deferred circuit init.
setWasmExclusiveGate(waitForWasm);

const reloadCore = async (config?: PsyNetworkConfig, network?: NetworkType) => {
  while (connecting) {
    await new Promise((rsv) => setTimeout(rsv, 100));
  }
  connecting = true;
  try {
    initStatus = "initializing";
    initError = undefined;
    // A fresh reload gets a fresh prover attempt — clear the failed flag so
    // retryInit's dispatches don't carry a stale failure into the popup.
    proverFailed = false;
    let activeNetwork: NetworkType;
    let runtimeIdentity: RuntimeNetworkIdentity;
    try {
      activeNetwork = network ?? (await getActiveNetwork());
      if (!config) config = await loadConfig(activeNetwork);
      runtimeIdentity = await resolveRuntimeNetworkKey(activeNetwork, config);
    } catch (error) {
      initStatus = "network_failed";
      initError =
        error instanceof Error
          ? error.message
          : String(error || "Network identity resolution failed");
      pendingWasmInit = null;
      await psyStateDispatch({
        initStatus,
        initError,
        proverReady: false,
        proverFailed,
      });
      throw error;
    }
    // Do NOT start initWasm inline here. Even `void startWasmInit(...)`
    // blocked cold boot: initWasm's synchronous prefix (initWasmSync's
    // WebAssembly compile of the ~22MB binary) runs before its first
    // await, and the WasmRpcServer circuit build then monopolizes the
    // microtask queue — so reloadCore's return, the wallet restore, and
    // the popup's first state paint all waited behind the full circuit
    // build. Record the deferred init instead; it is kicked shortly after
    // the first paint (kickWasmInitSoon) or lazily by the first proving
    // action (waitForWasm). Every proving path already gates on it.
    pendingWasmInit = { config, networkKey: runtimeIdentity.networkKey };
    initStatus = "ready";
    const core = new PsyWalletExtCore(
      config,
      activeNetwork,
      runtimeIdentity.networkKey,
      false,
      waitForWasm,
      runtimeIdentity.previousChainKey,
    );
    return core;
  } finally {
    connecting = false;
  }
};

// Track the in-flight cold-boot reload so the refreshPsyState handler
// (below) can await it instead of replying with the stale "initializing"
// state and stranding the popup on the "Connecting to Psy" splash.
//
// Background: MV3 evicts the service worker after ~30s idle. A shield
// claim's WASM proof keeps the SW busy for 30-60s, then it idles, then
// Chrome kills it. On the next popup open the SW respawns cold —
// psyWalletCore is null, initStatus is "initializing", and reloadCore()
// is kicked off here. The popup mounts at almost the same time and
// fires psy_internal_request("refreshPsyState"); WITHOUT this promise
// to await, the handler short-circuits, returns "initializing", and the
// popup gets stranded on the splash even after reloadCore finishes —
// because the late line-below dispatch may have raced the popup's
// listener registration and been lost, and the popup's next
// refreshPsyState (if any) would just see "initializing" again until
// something else triggers a fresh dispatch.
//
// Setting and clearing this in the .finally() means a SECOND cold boot
// (subsequent SW evictions) also gets a fresh awaitable promise.
let initialLoadPromise: Promise<void> | null = null;
const coldBootStart = Date.now();
initialLoadPromise = reloadCore()
  .then(async (core) => {
    const reloadCoreDone = Date.now();
    replacePsyWalletCore(core);
    await core.whenReady();
    const whenReadyDone = Date.now();
    console.info(
      `[psy-wallet][boot] cold boot: reloadCore ${reloadCoreDone - coldBootStart}ms, ` +
        `whenReady (wallet restore) ${whenReadyDone - reloadCoreDone}ms`,
    );
    psyStateDispatch({
      initStatus,
      initError,
      proverReady: isProverReady(),
      proverFailed,
    });
    return core.refreshPsyState().then(() => {
      console.info(
        `[psy-wallet][boot] cold boot: first refreshPsyState dispatched at +${Date.now() - coldBootStart}ms`,
      );
    });
  })
  .catch((e) => {
    console.warn("[psy-wallet][boot] core load error:", e);
    // Don't rethrow — awaiters should proceed with whatever state reloadCore
    // left behind.
  })
  .finally(() => {
    connecting = false;
    initialLoadPromise = null;
    // First state paint is done (or failed) — warm the prover now.
    kickWasmInitSoon();
  });

// Pending-recovery alarm (background/pending-recovery-alarm.ts). The fire
// itself is most of the cure: it wakes a DEAD worker, and this module's
// top-level reloadCore → loadWallets already reconciles restored pending
// rows and resumes committed-but-undelivered private transfers. The handler
// then runs one explicit sweep (covers the alarm firing on a LIVE worker,
// where no boot happened) and disarms the alarm once nothing recoverable
// remains — without this, an interrupted transfer stayed "Pending" and its
// recipient unpaid until the user happened to reopen the popup, because
// NOTHING else ever woke the worker.
browser.alarms?.onAlarm.addListener((alarm) => {
  // Auto-lock alarm (background/auto-lock-alarm.ts): the MV3-correct backstop
  // for the in-memory idle timer. Its fire WAKES a suspended/evicted worker;
  // the core then locks the wallet if the idle window has elapsed (the popup
  // shows the unlock screen), or re-arms if activity refreshed the window.
  if (alarm.name === AUTO_LOCK_ALARM) {
    void (async () => {
      try {
        // Let a cold boot's restoreSession (which itself locks on expiry) settle
        // before we enforce, so we don't race the wallet restore.
        if (initialLoadPromise) await initialLoadPromise;
        const core = psyWalletCore;
        if (!core) return;
        await core.enforceAutoLock();
      } catch (e) {
        console.warn("[psy-wallet][auto-lock-alarm] enforce failed", e);
      }
    })();
    return;
  }

  if (alarm.name !== PENDING_RECOVERY_ALARM) return;
  void (async () => {
    try {
      // Cold wake: the boot reload kicked off above is in flight — let the
      // wallet restore (and its reconcile/resume sweeps) finish first.
      if (initialLoadPromise) await initialLoadPromise;
      const core = psyWalletCore;
      if (!core) return;
      const workRemains = await core.sweepPendingRecovery();
      if (!workRemains) clearPendingRecoveryAlarm();
    } catch (e) {
      // Keep the alarm armed on errors — a failed sweep is exactly the case
      // the next fire should retry.
      console.warn("[psy-wallet][recovery-alarm] sweep failed", e);
    }
  })();
});

browser.runtime.onConnect.addListener((port) => {
  const origin = getOriginFromUrl(port.sender?.url || "");
  if (port.name !== "@crx/client" && port.sender?.tab?.id && origin) {
    connectionManager.addConnection(port.sender.tab.id, origin, port);
  }
});

browser.runtime.onMessage.addListener(
  async (msg: any, sender: browser.Runtime.MessageSender) => {
    if (!msg.isPsy) return;

    // B1: only extension pages / SW — content-script relays carry the tab's
    // https origin even though sender.id is the extension id.
    const fromTrustedExtension = isTrustedExtensionSender(sender);
    const origin = senderOrigin(sender);

    if (actions.includes(msg.action)) {
      const { id, action, params } = msg;
      if (!id) {
        return { error: "Missing request id" };
      }

      if (!psyWalletCore) {
        replacePsyWalletCore(await reloadCore());
        kickWasmInitSoon();
      }
      // Upstream's approve payload reads from a local `core` binding;
      // guaranteed non-null by the reload guard above.
      const core = psyWalletCore!;
      // Wait for the wallet restore before dispatching: on a cold MV3 service
      // worker _wallets/_currentWallet are not populated yet, so psy_accounts
      // returned [] and shield handlers threw a transient "Wallet not found".
      // The boot/reload paths already await this; resolves instantly once
      // ready (it just awaits the stored initial-load promise).
      await core.whenReady();

      if (approveActions.includes(action)) {
        return await approveManager.receiveApproveMsg(msg, {
          sender,
          currentWallet: core._currentWallet?.address,
          core,
          walletSnapshot: core.getApproveWalletSnapshot(),
        });
      } else {
        const parsedParams = decodeParams(params);
        const ok = (result: unknown) => ({
          id,
          result: PsyJSON.stringify(result),
          error: null,
        });
        const fail = (error: any, prefix = "") => ({
          id,
          result: null,
          error: `${prefix}${error?.message || String(error)}`,
        });
        type ActionHandler = () => Promise<{
          id: any;
          result: any;
          error: any;
        }>;
        if (marketActions.includes(action as typeof marketActions[number])) {
          try { return ok(await routeMarketRequest(core, action, parsedParams, origin)); }
          catch (error) { return fail(error); }
        }
        const handlers: Record<string, ActionHandler> = {
          async psy_accounts() {
            const currentWallet = core._currentWallet?.address;

            return ok(
              origin
                ? accountsApproved.getAccountsForOrigin(origin, currentWallet)
                : [],
            );
          },
          async psy_getPermissions() {
            return ok(
              origin
                ? accountsApproved.getApprovedAccountsForOrigin(origin)
                : [],
            );
          },
          async psy_getNetworkConfig() {
            return ok(await loadConfig());
          },
          async psy_getWalletBuildInfo() {
            return ok(getWalletBuildInfo());
          },
          async psy_listShieldReceiveAddresses() {
            const [address] = parsedParams;
            // Origin-approval still gates this (an unapproved site can't read
            // your addresses). But NOT wallet-unlock: shield RECEIVE addresses
            // are public, shareable-by-design data held in plaintext on the
            // wallet object, and `lock()` only locks the password manager — it
            // never clears `_wallets`. Gating reads on unlock (added in the
            // B1/B5/B6 hardening) broke approved dapps like the bridge the
            // moment the wallet auto-locked mid-session, with no secret
            // actually at risk. Sensitive RPCs (keys, signing, userId) keep the
            // unlock gate.
            assertApprovedAccountForOrigin(origin, address);
            return ok(await core.listShieldReceiveAddresses(address));
          },
          async psy_resolveShieldReceiveAddress() {
            // Forward-derive a shield receive address the account OWNS and
            // return its public record (incl. per-address nostrNpub). Used by
            // the bridge deposit-backup worker when its cached list misses an
            // on-demand-derived, never-materialized address. Ownership is
            // enforced inside core.resolveShieldReceiveAddress (via
            // ensureShieldReceiveAddress) — a foreign address throws rather
            // than resolving. Unlike psy_listShieldReceiveAddresses, this
            // DERIVES from the wallet private key, so it needs the unlock gate
            // (same as psy_getUserId / psy_getNostrNpub).
            const [address, shieldAddress, startIndexRaw, r0Raw, r1Raw] =
              parsedParams;
            assertApprovedAccountForOrigin(origin, address);
            assertWalletUnlocked(core.isWalletLocked());
            const startIndex =
              startIndexRaw != null && startIndexRaw !== ""
                ? Number(startIndexRaw)
                : undefined;
            // A shield deposit carries its own r0/r1 on the note; when present,
            // core derives the npub directly (ownership re-verified) instead of
            // forward-deriving the receive sequence, which never reaches a
            // deposit address.
            const r0 =
              r0Raw != null && r0Raw !== "" ? String(r0Raw) : undefined;
            const r1 =
              r1Raw != null && r1Raw !== "" ? String(r1Raw) : undefined;
            return ok(
              await core.resolveShieldReceiveAddress(
                address,
                shieldAddress,
                startIndex,
                r0,
                r1,
              ),
            );
          },
          async psy_getUserId() {
            const [address] = parsedParams;
            assertApprovedAccountForOrigin(origin, address);
            assertWalletUnlocked(core.isWalletLocked());
            return ok(await core.getUserId(address));
          },
          async psy_simulateContractCall() {
            const [address, args] = parsedParams;
            assertApprovedAccountForOrigin(origin, address);
            assertWalletUnlocked(core.isWalletLocked());
            return ok(await core.simulateContractCall(address, args));
          },
          async psy_listClaimables() {
            // Read-only claimables summary for an approved dApp. Reveals
            // amounts + counts (which the approved origin already renders as
            // balances) but NO claim secrets — the response is built through
            // an explicit field allowlist in core.listClaimablesForDapp
            // (kind/id/contractId/amount only; no noteProofRaw, no
            // nullifier_secret, no r0/r1). This is the bridge's replacement
            // for the removed local Nostr drain: psy-services discovers the
            // claimables, and the dApp only learns totals.
            const [address] = parsedParams;
            assertApprovedAccountForOrigin(origin, address);
            assertWalletUnlocked(core.isWalletLocked());
            return ok(await core.listClaimablesForDapp(address));
          },
          async psy_decryptNostrContent() {
            const [addressRaw, shieldAddressesRaw, eventsRaw] = parsedParams;
            const address = String(addressRaw ?? "");
            assertApprovedAccountForOrigin(origin, address);
            assertWalletUnlocked(core.isWalletLocked());

            const parseMaybeJson = (value: unknown): unknown => {
              if (typeof value !== "string") return value;
              try {
                return PsyJSON.parse(value);
              } catch {
                return value;
              }
            };
            const shieldInput = parseMaybeJson(shieldAddressesRaw);
            const eventInput = parseMaybeJson(eventsRaw);
            const shieldAddresses = (
              Array.isArray(shieldInput) ? shieldInput : [shieldInput]
            )
              .map((entry) => {
                if (typeof entry === "string") return entry;
                if (entry && typeof entry === "object") {
                  const record = entry as Record<string, unknown>;
                  return String(
                    record.shieldAddress ??
                      record.shield_address ??
                      record.address ??
                      "",
                  );
                }
                return "";
              })
              .filter((value) => value.length > 0);
            const events = Array.isArray(eventInput)
              ? eventInput
              : [eventInput];
            const decrypted: Array<{
              plaintext: string;
              shieldAddress: string;
              id: string;
              senderPubkey?: string;
              created_at?: number;
            }> = [];
            let lastError: unknown = null;
            for (const event of events) {
              const eventRecord =
                event && typeof event === "object"
                  ? (event as Record<string, unknown>)
                  : {};
              for (const shieldAddress of shieldAddresses) {
                try {
                  const plaintext = await core.decryptNostrSecretsEvent(
                    address,
                    shieldAddress,
                    event,
                  );
                  if (plaintext) {
                    decrypted.push({
                      plaintext,
                      shieldAddress,
                      id:
                        typeof eventRecord.id === "string"
                          ? eventRecord.id
                          : "",
                      senderPubkey:
                        typeof eventRecord.pubkey === "string"
                          ? eventRecord.pubkey
                          : undefined,
                      created_at:
                        typeof eventRecord.created_at === "number"
                          ? eventRecord.created_at
                          : undefined,
                    });
                    break;
                  }
                } catch (error) {
                  lastError = error;
                }
              }
            }
            if (decrypted.length > 0) return ok(decrypted);
            throw new Error(
              `Unable to decrypt Nostr content${
                lastError
                  ? `: ${lastError instanceof Error ? lastError.message : String(lastError)}`
                  : ""
              }`,
            );
          },
          async psy_getNostrNpub() {
            // Loads the wallet private key to derive the Nostr key — wallet-
            // internal, never a dApp capability. Extension pages only.
            assertTrustedExtensionSender(sender);
            assertWalletUnlocked(core.isWalletLocked());
            const [address, random0, random1] = parsedParams;
            const privKeyHex = await core.getPrivateKey(address);
            if (!privKeyHex) throw new Error("Failed to load private key");
            const sk = await deriveNostrSk(privKeyHex, random0, random1);
            const npub = nip19.npubEncode(nostrGetPublicKey(sk));
            return ok(npub);
          },
          async psy_getClaimRewardsCallArgs() {
            const [jobInfos] = parsedParams;
            const result = await core.getClaimRewardsCallArgs(jobInfos);
            return ok(result);
          },
          async psy_completeFaucetTurnstile() {
            const origin =
              (sender as any).origin ||
              (sender.url && getOriginFromUrl(sender.url));
            const [input] = parsedParams;
            return ok(await core.completePsyFaucetTurnstile(input, origin));
          },
          async psy_closeFaucetVerificationTab() {
            const tabId = sender.tab?.id;
            if (!tabId || !isFaucetVerificationPage(sender.url)) {
              throw new Error("Not a faucet verification tab");
            }

            void browser.tabs.remove(tabId).catch((error) => {
              console.warn(
                "[psy-wallet][faucet] failed to close verification tab:",
                error,
              );
            });
            return ok(true);
          },
          async psy_addExternalProof() {
            const [address, noteProofRaw] = parsedParams;
            const noteProof =
              noteProofRaw instanceof Uint8Array
                ? noteProofRaw
                : Uint8Array.from(Object.values(noteProofRaw ?? {}));
            await waitForWasm("psy_addExternalProof");
            const resultJson = await runWalletWasmServerMethod<string>(
              "main_add_external_proof_json",
              "add_external_proof_json",
              [address, noteProof],
            );
            return { id, result: resultJson, error: null };
          },
          async psy_claimWithExternalProof() {
            const [
              address,
              noteProofRaw,
              nullifierJson,
              ownerJson,
              amount,
              userTreeRootJson,
              checkpointId,
              noteRootSlot,
              contractId,
              shieldAddress,
              noteProofFingerprintJson,
              noteVerifierDataJson,
            ] = parsedParams;
            const noteProof =
              noteProofRaw instanceof Uint8Array
                ? noteProofRaw
                : Uint8Array.from(Object.values(noteProofRaw ?? {}));
            // Route through the unified claim-batch surface so the prover emits
            // TraceStep::ExternalProof before the private_claim contract call.
            const claim = externalProofParamsToPrivateTransferClaimRaw({
              noteProof,
              nullifierJson,
              ownerJson,
              amount,
              userTreeRootJson,
              checkpointId,
              noteRootSlot,
              shieldAddress,
              noteProofFingerprintJson,
              noteVerifierDataJson,
              tokenContractId: contractId,
            });
            const item: ClaimBatchItem = {
              type: "private_transfer",
              data: { contract_id: String(contractId), claim },
            };
            const result = await core.execClaimBatch(address, [item]);
            return ok(txHashFromSdkResult(result) ?? "");
          },
          async psy_claimShieldDeposit() {
            const [
              address,
              tokenAddressU32x8Json,
              l2TokenContractIdJson,
              amountU32x8Json,
              sourceChainIndex,
              depositIndex,
              depositRootJson,
              nullifierHashJson,
              noteCommitmentJson,
              depositProofBincodeB64,
              shieldAddress,
              contractId,
              depositProofFingerprintJson,
              shieldStartIndex,
            ] = parsedParams;
            const item = shieldDepositParamsToClaimBatchItem({
              tokenAddressU32x8Json,
              l2TokenContractIdJson,
              amountU32x8Json,
              sourceChainIndex,
              depositIndex,
              depositRootJson,
              nullifierHashJson,
              noteCommitmentJson,
              depositProofBincodeB64,
              shieldAddress,
              contractId,
              depositProofFingerprintJson,
            });
            const startIdx =
              shieldStartIndex != null && shieldStartIndex !== ""
                ? Number(shieldStartIndex)
                : undefined;
            if (Number.isFinite(startIdx)) {
              (
                item.data as { shield_start_index?: string }
              ).shield_start_index = String(startIdx);
            }
            const result = await core.execClaimBatch(address, [item]);
            return ok(txHashFromSdkResult(result) ?? "");
          },
          async psy_provePrivateNoteInclusion() {
            const [
              address,
              ownerJson,
              amount,
              noteSecretHashJson,
              nullifierSecretJson,
              contractId,
              noteRootSlot,
              checkpointId,
              // Submitted transaction's end_user_leaf_hash — the identity the
              // SDK pins note-inclusion to. NOT the content hash; the wallet
              // fails closed upstream if absent, so it should always be present.
              endUserLeafHash,
            ] = parsedParams;
            await waitForWasm("psy_provePrivateNoteInclusion");
            const resultJson = await runWalletWasmServerMethod<string>(
              "main_prove_private_note_inclusion_json",
              "prove_private_note_inclusion_json",
              [
                address,
                ownerJson,
                String(amount),
                noteSecretHashJson,
                nullifierSecretJson,
                String(contractId),
                String(noteRootSlot),
                String(checkpointId),
                String(endUserLeafHash),
              ],
            );
            return { id, result: resultJson, error: null };
          },
          async psy_proveDepositInclusion() {
            const [
              shieldAddressJson,
              nullifierJson,
              noteSecretHashJson,
              tokenAddressU32x8Json,
              l2TokenContractIdJson,
              amountU32x8Json,
              sourceChainIndex,
              depositIndex,
              depositRootJson,
              depositSiblingsJson,
            ] = parsedParams;
            await waitForWasm("psy_proveDepositInclusion");
            const resultJson = await runWalletWasmServerMethod<string>(
              "main_prove_deposit_inclusion_json",
              "prove_deposit_inclusion_json",
              [
                shieldAddressJson,
                nullifierJson,
                noteSecretHashJson,
                tokenAddressU32x8Json,
                l2TokenContractIdJson,
                amountU32x8Json,
                String(sourceChainIndex),
                String(depositIndex),
                depositRootJson,
                depositSiblingsJson,
              ],
            );
            return { id, result: resultJson, error: null };
          },
        };
        const prefixMap: Record<string, string> = {
          psy_claimWithExternalProof: "[wallet-bg-external-proof] ",
          psy_claimShieldDeposit: "[wallet-bg-shield] ",
          psy_resolveShieldReceiveAddress: "[wallet-bg-shield-resolve] ",
          psy_provePrivateNoteInclusion: "[wallet-bg-note-proof] ",
          psy_proveDepositInclusion: "[wallet-bg-shield-proof] ",
        };
        const handler = handlers[action];
        if (!handler)
          return { id, result: null, error: `Unsupported action: ${action}` };
        try {
          return await handler();
        } catch (error: any) {
          return fail(error, prefixMap[action] || "");
        }
      }
    }

    // SECURITY GATE for the internal popup<->background channels below.
    // `approval-result` resolves a pending approval, and `psy_internal_request`
    // dynamically dispatches ANY `allowMethods` core method — getMnemonic /
    // getPrivateKey / exportAllWallets / removeWallet / lock / changePassword /
    // addWalletFromMnemonic. Any website could otherwise drive these via the
    // all-pages content-script relay → seed/key exfiltration and takeover. Gate
    // on trusted extension sender (B1).
    if (msg.action === "approval-result") {
      if (!fromTrustedExtension) return { status: "forbidden" };
      await approveManager.handleApproveMsg(msg, psyWalletCore!);
      return { status: "result received" };
    }

    if (msg.action === PSY_INTERNAL_REQUEST_ACTION) {
      if (!fromTrustedExtension) {
        return { __psyInternalError: "Forbidden" };
      }
      const { type, params } = msg as PsyInternalRequest;
      if (type === "reload") {
        const p = decodeParams(params);
        const payload = p[0];
        const networkFromPayload = payload?.network as NetworkType | undefined;
        const configFromPayload = (payload?.config ??
          payload) as PsyNetworkConfig;
        const effectiveNetwork =
          networkFromPayload ?? (await getActiveNetwork());
        await disposePsyWalletCore();
        await setActiveNetwork(effectiveNetwork);
        await saveConfig(configFromPayload, effectiveNetwork);
        // Re-read the just-saved config through loadConfig instead of running
        // the RAW form payload as the live config: loadConfig is where every
        // defense lives (defaults merge, guta/da fee floors, prove_proxy_url
        // fallback, empty coordinator/realm array fallback). Passing the raw
        // payload bypassed all of them until the NEXT full reload - a partial
        // save could run fee math with missing fields or an empty realm list.
        const effectiveConfig = await loadConfig(effectiveNetwork);
        // disposePsyWalletCore() already ran above (handles wasmServer reset).
        const newCore = await reloadCore(effectiveConfig, effectiveNetwork);
        // Update psyWalletCore BEFORE dispatching state and calling refreshPsyState
        replacePsyWalletCore(newCore);
        await newCore.whenReady();
        await psyStateDispatch({
          initStatus,
          initError,
          proverReady: isProverReady(),
          proverFailed,
        });
        try {
          await newCore.refreshPsyState();
        } catch (e) {
          console.warn(
            "[psy-wallet][reload] refreshPsyState failed in reload handler:",
            e,
          );
        }
        await psyStateDispatch({
          initStatus,
          initError,
          proverReady: isProverReady(),
          proverFailed,
        });
        kickWasmInitSoon();
        return;
      }
      if (type === "getConfig") {
        // Resolve against the RUNNING network, not getActiveNetwork() storage
        // — the two can drift (storage said localhost while the core ran on
        // sepolia, so getConfig() handed back the wrong network's config).
        const config = await loadConfig(psyWalletCore?.runningNetwork);
        psyWalletCore?.touchAutoLock();
        return PsyJSON.stringify(config);
      }
      if (type === "retryInit") {
        // Mutation-free re-init: the same flow as "reload" but WITHOUT
        // setActiveNetwork/saveConfig. Retrying after a transient network
        // failure must never write config — routing retry through the
        // settings-save path baked default-merged values (incl.
        // prove_proxy_url) into storage on fresh profiles, masking future
        // default updates. reloadCore() re-reads the saved config and
        // active network itself.
        //
        // Clear the rejected attempt before doing any teardown/network work.
        // `undefined` is omitted by PsyJSON, so use null to overwrite the
        // popup's stale error and publish an actual retryable/loading state.
        initStatus = "initializing";
        initError = undefined;
        proverFailed = false;
        await psyStateDispatch({
          initStatus,
          initError: null,
          proverReady: false,
          proverFailed,
        });

        try {
          await disposePsyWalletCore();
          const newCore = await reloadCore();
          replacePsyWalletCore(newCore);
          // Match normal reload/open ordering: do not publish `ready` or an
          // empty replacement core until its wallet restore has settled.
          await newCore.whenReady();
          await psyStateDispatch({
            initStatus,
            initError,
            proverReady: isProverReady(),
            proverFailed,
          });
          try {
            await newCore.refreshPsyState();
          } catch (e) {
            console.warn(
              "[psy-wallet][retryInit] refreshPsyState failed in retryInit handler:",
              e,
            );
          }
          await psyStateDispatch({
            initStatus,
            initError,
            proverReady: isProverReady(),
            proverFailed,
          });
          kickWasmInitSoon();
          return;
        } catch (error) {
          // reloadCore publishes network identity failures itself. This also
          // covers teardown/config/restore failures so every rejected retry
          // releases the loading UI into the latest actionable error state.
          initStatus = "network_failed";
          initError =
            error instanceof Error
              ? error.message
              : String(error || "Wallet initialization failed");
          await psyStateDispatch({
            initStatus,
            initError,
            proverReady: false,
            proverFailed,
          });
          return { __psyInternalError: initError };
        }
      }
      if (type === "refreshPsyState") {
        // Instant cached paint FIRST — before awaiting any restore. Guarantees
        // the reopened popup gets home numbers the moment its message lands,
        // even while a cold boot or an in-flight scan is still running. The
        // authoritative dispatch below (post-restore) refines it.
        await dispatchBootPaint();
        // Phase 1: dispatch route-critical state from the core if it exists
        // (reloadCore created it, but whenReady/loadWallets may still be
        // running). This lets AuthChecker route to #main/#welcome immediately
        // instead of waiting for the full wallet restore to complete.
        if (psyWalletCore) {
          await psyStateDispatch({
            initStatus,
            initError,
            proverReady: isProverReady(),
            proverFailed,
          });
          await psyWalletCore.dispatchRouteCriticalState();
        }
        if (initialLoadPromise) {
          try {
            await initialLoadPromise;
          } catch {
            // The initializer catches and logs its own error; continue below
            // so the popup still receives the best state available.
          }
        }
        if (!psyWalletCore) {
          // Cold-boot path. Don't reply instantly with the stale
          // "initializing" state — that's what stranded the popup on
          // the "Connecting to Psy" splash after a claim (see the
          // comment around initialLoadPromise at module init). The in-flight
          // cold-boot reload was already awaited above (the outer
          // initialLoadPromise block, which .finally-nulls it), so re-checking
          // it here would be dead — fall through to the dispatch below.
          if (!psyWalletCore) {
            // initialLoadPromise resolved but the reload failed hard
            // enough that no core was set. Dispatch whatever we have
            // — the popup's Initializing component will keep showing the splash
            // if initStatus is still "initializing" (a truly stuck SW; the
            // auth.tsx 60s fallback then opens Network Settings as last resort).
            await psyStateDispatch({
              initStatus,
              initError,
              proverReady: isProverReady(),
              proverFailed,
            });
            approveManager.refreshApproveState();
            return;
          }
        }
        if (psyWalletCore) {
          await psyWalletCore
            .reconcileLiveChainKey("popup-open")
            .catch(() => undefined);
        }
        await psyWalletCore.refreshPsyState();
        psyWalletCore.touchAutoLock();
        // Popup opened: kick recovery for any WEDGED "proving" tx-queue entry
        // whose hold is still pinning the headline to 0 over funds that never
        // actually left (worker evicted mid-proof). The boot path fires this on
        // a cold start and the 1-min alarm covers a closed popup, but a WARM
        // reopen had no trigger — this bounds that wrong-0 window to recovery
        // latency instead of the alarm cadence. Fire-and-forget: recovery
        // re-dispatches holds when it terminalizes an orphaned entry, and it
        // skips the send drive() is actively proving.
        psyWalletCore.recoverInterruptedProvingOnOpen();
        await psyStateDispatch({
          initStatus,
          initError,
          proverReady: isProverReady(),
          proverFailed,
        });
        return;
      }
      // The approve dispatch in ApproveManager happens before the popup
      // window is created, so on a cold popup mount the listener registers
      // too late and the message is lost — AuthChecker then routes to
      // /welcome (the "registration page" users were complaining about).
      // The popup re-requests the current approve state via this action
      // once its listener is live.
      if (type === "refreshApproveState") {
        approveManager.refreshApproveState();
        return;
      }
      // Expected failures (wrong unlock password, "Account Exists", …) must
      // NOT be re-thrown out of this listener. Chrome ships a native
      // promise-aware `browser` namespace now, so webextension-polyfill
      // defers to it — and Chrome's native handling of a rejected listener
      // promise records an "Uncaught Error: <msg>" entry in the
      // chrome://extensions error console AND surfaces it to the sender as
      // runtime.lastError with that same mangled prefix. Returning a small
      // error envelope keeps the rejection a normal, clean-messaged reply;
      // psyInternalRequest (message.ts) converts it back into a rejected
      // promise for the caller.
      if (!allowMethods.includes(type)) {
        return { __psyInternalError: "Method Not Allowed" };
      }

      if (!psyWalletCore) {
        replacePsyWalletCore(await reloadCore());
        kickWasmInitSoon();
      }

      // Local non-null binding for the dynamic dispatch below. Upstream's
      // 6b7a5b6 renamed the call target from `psyWalletCore[type]` to
      // `core[type]` but only THEIR tree had a `core` binding in scope —
      // after the shield merge this threw `ReferenceError: core is not
      // defined` at RUNTIME for every allowMethods call (wallet creation,
      // balances, sends — all dead), silently, because the `@ts-expect-error`
      // that was meant for the string-index expression also suppressed
      // TS2304 for the missing name.
      const core = psyWalletCore!;
      // Same cold-SW gate the dApp branch got in 355b231: on a fresh service
      // worker the wallet restore has not populated _wallets/_currentWallet
      // yet, so popup internal requests (balances, wallet list, sends) raced
      // it and threw transient Wallet-not-found right after MV3 eviction.
      // Idempotent - resolves instantly once the initial load is done.
      await core.whenReady();
      const p = decodeParams(params);
      try {
        // @ts-expect-error
        const result = await core[type](...p);
        if (type !== "lock") core.touchAutoLock();
        if (result !== undefined) {
          return PsyJSON.stringify(result);
        }
      } catch (error: any) {
        return {
          __psyInternalError:
            error?.message || String(error) || "Internal request failed",
        };
      }
    }
  },
);
