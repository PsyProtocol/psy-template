// Explicit isolated QA stages. No unknown mutation is ever automatically retried.
import assert from'node:assert/strict';import{createHash}from'node:crypto';import{existsSync,mkdirSync,readFileSync}from'node:fs';import{join,dirname,basename}from'node:path';
import{read,save,ordinary,confirmUps,run}from'../../batching/admission/liveSupport.mjs';import{LiveMarket}from'../../batching/admission/liveMarket.mjs';
import{publicState}from'../publicState.mjs';import{loadOptions}from'../config.mjs';import{createPublicWalletAdapter}from'../publicWalletAdapter.mjs';import{ExecutionJournal}from'../journal.mjs';import{execFile}from'node:child_process';import{promisify}from'node:util';
import{hostname,platform,arch,cpus,loadavg}from'node:os';
import{fileURLToPath}from'node:url';
import{latestBroadcastOutcome}from'./attemptOutcome.mjs';
import{ordinaryEvidenceDirectory}from'./ordinaryEvidence.mjs';
import{selectedCliTask}from'./cliExecution.mjs';
import{saveObservation}from'../observations.mjs';
import{assetCohort}from'./cohortScope.mjs';
import{optionalCalibration}from'./optionalCalibration.mjs';
import{completedColdCalibration}from'./completedCalibration.mjs';
import{parseLosslessJson}from'../../amm/u124/client.mjs';
export const pause=ms=>new Promise(r=>setTimeout(r,ms));
export function cohort(base,original){
 assert.ok(!existsSync(join(base,'public/ABANDONED-DEPLOYMENT-v1.json')),'retired QA case cannot run financial acceptance');
 const releaseFile=process.env.PSY_CANDIDATE_RELEASE_FILE??'candidate-release.json';assert.match(releaseFile,/^candidate-release(?:-v[1-9][0-9]*)?\.json$/);
 const releasePath=join(base,'public',releaseFile),release=existsSync(releasePath)?read(releasePath):null;if(process.env.PSY_CANDIDATE_RELEASE_FILE)assert.ok(release,'explicit frozen release manifest missing');
 if(release){assert.equal(release.version,1);assert.match(release.toolchainFile,/^candidate-toolchain-v[1-9][0-9]*\.json$/);assert.equal(createHash('sha256').update(readFileSync(join(base,'public',release.toolchainFile))).digest('hex'),release.toolchainSha256,'frozen toolchain manifest changed');}
 const tools=read(join(base,'public',release?release.toolchainFile:'candidate-toolchain.json'));
 for(const [path,digest]of [[tools.compactBinary,tools.compactBinarySha256],[tools.ordinaryBinary,tools.ordinaryBinarySha256],[tools.compiler,tools.compilerSha256]])assert.equal(createHash('sha256').update(readFileSync(path)).digest('hex'),digest,'reviewed test binary changed');
 const binary=tools.compactBinary,ordinaryBinary=tools.ordinaryBinary,config=join(base,'public/rpc.json'),env={PSY_MARKET_TESTNET_PROFILE:'staging-bundled-regtest-20261020-v1',RAYON_NUM_THREADS:'2'};
 const actorHome=existsSync(join(base,'public/qa-actors-source.json'))?read(join(base,'public/qa-actors-source.json')).directory:base;
 const actors={bob:{id:860352,secret:join(original,'.secrets/bob-bundled-profile-v1.json')},trader:{id:876736,secret:join(original,'.secrets/trader.json')},sponsor:{id:1384640,secret:join(original,'.secrets/sponsor-bundled-profile-v1.json')},...Object.fromEntries(['charlie','dave'].map(n=>[n,{id:read(join(actorHome,'public',n+'-registration-v1.json')).userId,secret:join(actorHome,'.secrets',n+'.json')}]))};
 const markets=['amm','orderbook','bondingcurve','nftmarket'].map(kind=>{const build=join(base,'markets-v1',kind),registration=read(join(build,'live-registration.json'));return new LiveMarket({base,config,build,registration,policy:read(join(build,'bound/policy.json')),contracts:registration.contracts,ordinaryBinary,compactBinary:binary,env,actors});});
 const extraFile=join(base,'public/additional-cohort-users-v1.json'),extra=existsSync(extraFile)?read(extraFile):{version:1,users:[]};assert.deepEqual(Object.keys(extra).sort(),['users','version']);assert.equal(extra.version,1);const assetSpec=assetCohort({actors:Object.values(actors).map(a=>a.id),marketVaults:markets.map(m=>m.vault),legacyVaults:markets.map(m=>read(join(original,'markets-v1',m.kind,'live-registration.json')).vaultId),extraUsers:extra.users});
 const by=Object.fromEntries(markets.map(m=>[m.kind,m])),bindings=new Map(markets.flatMap(m=>m.contracts).map(b=>[b.contract.contractId,b]));
 const user=async(actor,name,calls)=>{const out=ordinaryEvidenceDirectory(base,name,actors[actor].id);if(out!==join(base,'attempts',name))return out;if(existsSync(join(out,'preflight.json'))){if(!existsSync(join(out,'included.json')))await confirmUps(config,out);return out;}assert.ok(!existsSync(join(base,'public',name+'.json')),'partial unsigned input requires inspected new attempt');return ordinary({base,config,binary:ordinaryBinary,secret:actors[actor].secret,name,calls,bindings,env});};
 // Per-user AMM order nonces strictly increase. A renewed LP intake opens a
 // second order, so every later Bob AMM order shifts by one.
 const bobLpNonce=existsSync(join(base,'public/liquidity-retry-ready-v1.json'))?2n:1n;
 return{base,original,releaseFile,assetSpec,bobLpNonce,binary,binarySha256:tools.compactBinarySha256,ordinaryBinary,config,env,actors,markets,by,bindings,user,token:read(join(by.amm.build,'token-a.json')).abi,nft:read(join(by.nftmarket.build,'nft.json')).abi};
}
export async function formal(h,m,tag,plan,{benchmark=false,benchmarkKinds=['batch_commit','batch_settle'],expiry=96,mode='resident',runtimeSuffix='',contendOnMaintenance=null,performanceMetrics=false,bulkFallbackRemainingCheckpoints,recoveryPayers=[]}={}){
 assert.ok(Array.isArray(recoveryPayers)&&recoveryPayers.every(id=>Number.isSafeInteger(id)&&id>0&&id<16777216&&id!==m.vault&&Object.values(h.actors).some(a=>a.id===id)),'explicit owned recovery payer scope');
 const dir=join(h.base,'public',tag+'-'+m.kind+'-executor');if(!existsSync(dir)){mkdirSync(dir);for(const[n,v]of Object.entries({abi:m.abi,config:m.driverConfig,policy:m.policy,dependencies:m.contracts,plan}))save(join(dir,n+'.json'),v);}
 const reg=m.registration,asset=id=>{const b=m.contracts.find(b=>b.contract.contractId===id).contract;const source=join(m.build,id===m.driverConfig.nftId?'nft.json':id===m.driverConfig.assetB?'token-b.json':'token-a.json'),abi=read(source).abi,abiPath=join(dir,'asset-'+id+'-abi.json');assert.ok(abi?.contract,'compiled asset must contain its raw ABI');if(!existsSync(abiPath))save(abiPath,abi);else assert.deepEqual(read(abiPath),abi,'frozen raw asset ABI changed');return{contractId:id,codeRoot:b.codeRoot,layoutRoot:b.layoutRoot,abi:abiPath};};
 const options={kind:m.kind,...(performanceMetrics?{performanceMetrics:true}:{}),...(bulkFallbackRemainingCheckpoints===undefined?{}:{bulkFallbackRemainingCheckpoints}),profile:'batch-admission-compact-v1',...(reg.admissionMode?{admissionMode:reg.admissionMode}:{}),network:'sepolia',testnetProfile:h.env.PSY_MARKET_TESTNET_PROFILE,contractId:m.id,vaultId:m.vault,fingerprint:reg.fingerprint,publicKeyHash:reg.publicKeyHash,codeRoot:reg.contracts.find(b=>b.contract.contractId===m.id).contract.codeRoot,layoutRoot:reg.contracts.find(b=>b.contract.contractId===m.id).contract.layoutRoot,wallet:h.binary,walletSha256:h.binarySha256,rpcConfig:h.config,abi:join(dir,'abi.json'),driverConfig:join(dir,'config.json'),policy:join(dir,'policy.json'),dependencyBindings:join(dir,'dependencies.json'),admissionPlan:join(dir,'plan.json'),runtimeDirectory:join(h.base,'runtime'+runtimeSuffix),batchSponsorId:h.actors.sponsor.id,activationPayerId:h.activationPayers?.[m.kind]??h.actors[m.kind==='nftmarket'?'trader':'bob'].id,automaticInitialize:true,batchExpiryCheckpoints:expiry,batchMemberLimit:4,proverThreads:2,proverMode:mode,...(h.proverMemoryMode?{proverMemoryMode:h.proverMemoryMode}:{}),...(h.fixedVerifierMode?{fixedVerifierMode:h.fixedVerifierMode}:{}),users:[...new Set([...Object.values(h.actors).filter(a=>a.id!==h.actors.sponsor.id).map(a=>a.id),...recoveryPayers])].sort((a,b)=>a-b),...(m.kind==='nftmarket'?{paymentToken:asset(m.driverConfig.tokenId),collection:asset(m.driverConfig.nftId)}:{assetA:asset(m.driverConfig.assetA),assetB:asset(m.driverConfig.assetB)})};
 const path=join(dir,'executor.json');if(!existsSync(path))save(path,options);else assert.deepEqual(read(path),options,'frozen stage options changed');
 const o=await loadOptions(path),adapter=await createPublicWalletAdapter(o,{runDriver:promisify(execFile),...(h.residentScope?{residentScope:h.residentScope}:{})}),journal=new ExecutionJournal({directory:o.runtimeDirectory,network:o.network,vaultId:o.vaultId,fingerprint:o.fingerprint});
 const metricsPath=(task,proof)=>proof?.submissionDirectory?join(h.base,'public',tag+'-'+m.kind+'-submit-metrics-'+createHash('sha256').update(JSON.stringify(task)).digest('hex')+'-'+basename(proof.submissionDirectory)+'.json'):null;
 const submit=adapter.submit;adapter.submit=async(task,proof)=>{const startedAt=new Date().toISOString(),before=performance.now();const result=await submit(task,proof);save(metricsPath(task,proof),{startedAt,finishedAt:new Date().toISOString(),processWallMilliseconds:Math.round(performance.now()-before),scope:'saved-proof verification, fresh state/dependency RPC checks, and HTTP acknowledgement; excludes signing/proving and confirmation; not a pure transport latency',reproved:result.reproved,submissionDirectory:result.submissionDirectory,error:result.error??null});return result;};
 const prove=adapter.prove;
 if(contendOnMaintenance)adapter.prove=async task=>{
  if(task.maintenanceOperation===contendOnMaintenance||(contendOnMaintenance==='admit_entry'&&task.maintenanceOperation==='admit_entries_4')){
   const output=join(h.base,'public',tag+'-'+m.kind+'-same-journal-contender.json');
   if(!existsSync(output)){
    const taskPath=join(h.base,'public',tag+'-'+m.kind+'-contender-task.json');save(taskPath,task);
    await run(process.execPath,[fileURLToPath(new URL('./candidateContender.mjs',import.meta.url)),path,taskPath,output],join(h.base,tag+'-'+m.kind+'-same-journal-contender.log'),h.env);
   }
  }
  return prove(task);
 };
 const prepareSubmission=adapter.prepareSubmission;
 if(benchmark)adapter.prepareSubmission=async(task,p)=>{
  if(!benchmarkKinds.includes(task.kind))return prepareSubmission(task,p);
  const warm=parseLosslessJson(readFileSync(join(p.preparedDirectory,'preflight.json'),'utf8'));
  const source=dirname(p.preparedDirectory),out=join(h.base,'attempts',tag+'-'+m.kind+'-'+task.kind+'-cold-comparison');
  // Calibration is read-only measurement. A failed cold run is preserved and
  // reported as missing; it never blocks or replaces the warm submission.
  const comparisonPath=join(out,'comparison.json'),completed=completedColdCalibration(comparisonPath,p),failurePath=join(out,'failure.json'),t=completed??await optionalCalibration({existingFailure:existsSync(failurePath)?read(failurePath):null,
   run:()=>run(h.binary,['preflight',o.policy,h.config,join(source,'calls.json'),join(source,'guard.json'),out],join(h.base,tag+'-'+m.kind+'-'+task.kind+'-cold-comparison.log'),{...h.env,PSY_MARKET_BENCH_SOURCE_CHECKPOINT:warm.core.checkpoint_id.toString()}),
   readFailure:async()=>existsSync(failurePath)?read(failurePath):null,
   onUnavailable:async failure=>{const marker=out+'-unavailable.json';if(!existsSync(marker))save(marker,{checkedAt:new Date().toISOString(),market:m.kind,task:task.kind,failure,warmDirectory:p.preparedDirectory,comparisonAvailable:false});}});
  if(t===null)return prepareSubmission(task,p);
  const cold=parseLosslessJson(readFileSync(join(out,'preflight.json'),'utf8'));assert.equal(warm.benchmarkSourceCheckpoint,null);assert.equal(cold.benchmarkSourceCheckpoint,warm.core.checkpoint_id);assert.equal(cold.core.checkpoint_id,warm.core.checkpoint_id);
  for(const x of [warm,cold]){assert.equal(x.fullUpsVerified,true);assert.equal(x.exactStackAndSessionVerified,true);}assert.equal(warm.core.state_transition.start_user_leaf_hash,cold.core.state_transition.start_user_leaf_hash);assert.equal(warm.core.new_user_leaf.user_state_tree_root,cold.core.new_user_leaf.user_state_tree_root);assert.deepEqual(warm.core.new_user_leaf,cold.core.new_user_leaf);assert.deepEqual(warm.core,cold.core,'same authenticated-source full public core');assert.equal(warm.core.state_transition.end_user_leaf_hash,cold.core.state_transition.end_user_leaf_hash);assert.equal(warm.core.new_user_leaf.nonce,cold.core.new_user_leaf.nonce);assert.equal(warm.fee,cold.fee);assert.equal(warm.actualCalls,cold.actualCalls);assert.equal(warm.callsSha256,cold.callsSha256);
  if(!completed)saveObservation(out+'/comparison.json',{scope:'single same-host sequential warm then cold full UPS pair; same request, authenticated source checkpoint, own anchor, nonce, fee and end state; cold source-calibration proof is read-only and never submitted',order:['warm','cold'],host:hostname(),platform:platform(),arch:arch(),logicalCpus:cpus().length,loadAverageAfterPair:loadavg(),rayonThreads:2,binarySha256:o.walletSha256,market:m.kind,task:task.kind,warmDirectory:p.preparedDirectory,coldDirectory:out,coldProcessTiming:t,warmTimingsMs:warm.timingsMilliseconds,coldTimingsMs:cold.timingsMilliseconds,calls:warm.actualCalls,fee:warm.fee,startLeaf:warm.core.state_transition.start_user_leaf_hash,endStateRoot:warm.core.new_user_leaf.user_state_tree_root,warmCheckpoint:warm.core.checkpoint_id,coldCheckpoint:cold.core.checkpoint_id,chainTps:null,preparedManifestSha256:p.manifestSha256});return prepareSubmission(task,p);
 };
 const step=async(label,expected,{cliOnce=false}={})=>{
  const output=join(h.base,'public',label+'-formal-result.json');if(existsSync(output))return read(output);
  await journal.reconcile(adapter.reconcile);assert.equal((await journal.unresolved()).length,0,'unknown prior broadcast; stop');
  const taskPath=join(h.base,'public',label+'-formal-task.json');let task;if(existsSync(taskPath))task=read(taskPath);else{const scan=await adapter.scan();assert.ok(scan.action,'no formal action: '+JSON.stringify(scan,(_k,v)=>typeof v==='bigint'?v.toString():v));task=scan.action;assert.ok(expected(task),'unexpected stage action');save(taskPath,task);}
  const cliEvidence=join(h.base,'public',label+'-production-cli-execution.json');
  if(existsSync(cliEvidence)){const prior=read(cliEvidence);assert.deepEqual(prior.reviewedTask,task,'reviewed CLI task changed');task=prior.actualTask;assert.ok(expected(task));cliOnce=false;}
  const before=performance.now();let result;
  if(cliOnce){
   assert.ok(!benchmark||task.kind==='batch_maintenance','paired commit/settlement calibration must use its measured adapter');
   const prior=await journal.records(),log=join(h.base,label+'-production-cli-once.log');
   assert.ok(!existsSync(log),'preserve prior CLI attempt and reconcile before explicit restart');
   const cliStartedAt=new Date().toISOString(),cliStart=performance.now();let timing,cliProcessError=null;
   try{timing=await run(process.execPath,[fileURLToPath(new URL('../run.mjs',import.meta.url)),path,'once','--expected-task',taskPath],log,h.env);}
   catch(error){cliProcessError=error.message;timing={startedAt:cliStartedAt,finishedAt:new Date().toISOString(),wallMilliseconds:Math.round(performance.now()-cliStart),scope:'nonzero CLI child exit; durable task/intent must still pass identity checks and exact receipt reconciliation; not success'};}

   const selected=selectedCliTask((await journal.records()).slice(prior.length),task);
   save(cliEvidence,{checkedAt:new Date().toISOString(),entrypoint:'executor/run.mjs once',config:path,log,timing,cliProcessError,reviewedTask:task,actualTask:selected.task,taskId:selected.taskId,scope:'real production CLI process; fresh scan may advance local send window, complete calls and all other task fields must match'});
   task=selected.task;result={taskId:selected.taskId};
  }else result=await journal.execute({task,...adapter});
  for(let i=0;i<120;i++){
   await journal.reconcile(adapter.reconcile);const records=await journal.records(),outcome=latestBroadcastOutcome(records,result.taskId);if(outcome?.status==='resolved-by-confirmed-conflict')throw Error('original task is terminal: resolved by confirmed nonce conflict; do not re-execute or wait for its old receipt');if(outcome?.status==='not-submitted')throw Error('explicit pre-broadcast rejection: '+outcome.reason+'; inspect evidence before explicitly resuming; reuse requires unchanged proof, anchor and send window');const included=outcome?.status==='included'?outcome:null;
   if(included){const mp=metricsPath(task,records.findLast(r=>r.taskId===result.taskId&&r.status==='broadcast-intent')?.proof);const report={checkedAt:new Date().toISOString(),taskId:result.taskId,task,result:included.result,wallMilliseconds:Math.round(performance.now()-before),executionStatus:result.status??(cliOnce?'production-cli-once':null),wallMillisecondsScope:result.status==='already-included'?'receipt observation of already included task only; excludes earlier proof/send/recovery work':'this successful parent attempt only; cached proof or earlier failed attempts may be outside this interval; includes deliberately repeated cold calibration when enabled',submitMetricsFile:mp&&existsSync(mp)?mp:null};save(output,report);console.log(report.checkedAt,m.kind,label,'included',included.result.checkpoint);return report;}
   await pause(10000);
  }
  throw Error('formal broadcast remains unresolved; preserve intent and stop');
 };
 return{options:o,adapter,journal,step,warm:()=>adapter.warm(),close:()=>adapter.close?.()};
}
