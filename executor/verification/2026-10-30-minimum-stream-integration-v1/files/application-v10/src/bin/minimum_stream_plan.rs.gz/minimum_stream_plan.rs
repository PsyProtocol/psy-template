//! Public minimum-frontier planning for new v11 instances only. No signing, RPC
//! or broadcast command; a pinned history root is not a finality certificate.
use anyhow::{ensure, Result};
use plonky2::field::{goldilocks_field::GoldilocksField as F, types::PrimeField64};
use plonky2::hash::poseidon::PoseidonHash as H;
use psy_client_common::data::qhashout::QHashOut as Q;
use psy_client_data::qdata::checkpoint::PsyCheckpointLeaf;
use psy_crypto::hash::{merkle::core::MerkleProofCore, traits::qhashable::QFieldHashable};
use psy_template_u124_markets::{
    checkpoint_stream::Member,
    final_state_coverage::{verify_snapshot, Snapshot},
    random_minimum,
    source_review::review,
    stream_policy, stream_source,
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    fs,
    io::{Read, Write},
    path::Path,
};
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Draw {
    checkpoint: PsyCheckpointLeaf<F>,
    path: MerkleProofCore<Q<F>>,
}
fn bytes(path: &str, limit: u64) -> Result<Vec<u8>> {
    let mut b = vec![];
    fs::File::open(path)?.take(limit + 1).read_to_end(&mut b)?;
    ensure!(b.len() as u64 <= limit, "bounded planner input");
    Ok(b)
}
fn sha(b: &[u8]) -> String {
    format!("{:x}", Sha256::digest(b))
}
fn save(p: &Path, v: &impl Serialize) -> Result<()> {
    let mut f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(p)?;
    f.write_all(&serde_json::to_vec_pretty(v)?)?;
    f.write_all(b"\n")?;
    f.sync_all()?;
    fs::File::open(p.parent().unwrap())?.sync_all()?;
    Ok(())
}
fn main() -> Result<()> {
    let a = std::env::args().collect::<Vec<_>>();
    ensure!(
        a.len() == 7,
        "REVIEW SNAPSHOT PINNED_HISTORY_ROOT DRAW_OPENING POLICY FRESH_OUT"
    );
    let (r, _, rb) = review(Path::new(&a[1]))?;
    ensure!(r.kind <= 2, "random ordering is AMM/Curve only");
    let sb = bytes(&a[2], 64 * 1024 * 1024)?;
    let s: Snapshot = serde_json::from_slice(&sb)?;
    let history: Q<F> = a[3].parse()?;
    ensure!(
        history.to_string() == a[3],
        "canonical independently pinned history root"
    );
    let db = bytes(&a[4], 65536)?;
    let draw: Draw = serde_json::from_slice(&db)?;
    let pb = bytes(&a[5], 4 * 1024 * 1024)?;
    let policy: Value = serde_json::from_slice(&pb)?;
    stream_policy::validate(&policy, &r)?;
    ensure!(
        policy["version"] == 11
            && s.fields[7] == s.fields[6] + policy["source_window_checkpoints"].as_u64().unwrap(),
        "reviewed random profile and exact window"
    );
    let covered = verify_snapshot(&r, &s, history)?;
    ensure!(
        draw.path.index == s.fields[6] + 1
            && draw.path.root == history
            && draw.path.value == draw.checkpoint.qfhash::<H>()
            && draw.path.siblings.len() == 32
            && draw.path.verify::<H>(),
        "one authenticated future draw under the same pinned history"
    );
    let source = stream_source::prepare(&r, &s, history)?;
    let scope = &source[0].scope;
    let original = stream_source::priority(&r, &s, history)?;
    let seed = draw
        .checkpoint
        .stats
        .random_seed
        .0
        .elements
        .map(|n| n.to_canonical_u64());
    ensure!(
        !original.members.is_empty(),
        "eligible admission sample required"
    );
    let steps = random_minimum::prepare(scope, &original, seed)?;
    let count = original.members.len();
    let mut pages = vec![];
    for group in [&steps[..count], &steps[count..]] {
        for rows in group.chunks(4) {
            let p = random_minimum::Page {
                seed,
                refund_only: false,
                current: rows[0].before.clone(),
                rows: rows.to_vec(),
            };
            p.after(scope)?;
            pages.push(p);
        }
    }
    let ordered = steps[count..]
        .iter()
        .map(|r| stream_source::PriorityMember {
            index: r.append.index,
            member: Member {
                owner: r.node.owner,
                nonce: r.node.nonce,
                terms: r.node.terms,
            },
        })
        .collect();
    let queue = stream_source::PriorityTree::from_committed(scope, ordered)?;
    ensure!(
        steps.last().unwrap().after.queue == queue.root(),
        "exact complete minimum extraction root"
    );
    let out = Path::new(&a[6]);
    fs::create_dir(out)?;
    save(&out.join("source-pages.json"), &source)?;
    save(&out.join("minimum-pages.json"), &pages)?;
    save(&out.join("queue.json"), &queue.members)?;
    save(
        &out.join("plan.json"),
        &json!({"schema":1,"profile":"source-covered-producer-minimum-stream-v1","reviewSha256":sha(&rb),"snapshotSha256":sha(&sb),"drawSha256":sha(&db),"policySha256":sha(&pb),"historyRoot":history,"scope":scope,"sourceCheckpoint":scope[6],"drawCheckpoint":scope[6]+1,"expiry":scope[7],"accounts":covered.accounts,"earliestEligibleDeadline":covered.earliest_eligible_deadline,"recoveryMembers":covered.recovery_members.len(),"members":queue.members.len(),"sourcePages":source.len(),"minimumBuildPages":count.div_ceil(4),"minimumExtractionPages":count.div_ceil(4),"minimumPages":pages.len(),"noReset":true,"feeOwner":policy["fee_owner"],"seed":seed,"sourceSetRoot":original.root(),"orderedRoot":queue.root(),"authenticatedSeedRelativeToHistory":true,"finalityVerified":false,"causalSealBeforeReleaseAuthenticated":false,"producerInfluence":true,"qualifiedRandomness":false,"fullUpsVerified":false,"canSign":false,"canBroadcast":false}),
    )?;
    Ok(())
}
