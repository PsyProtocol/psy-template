from pathlib import Path
import os,subprocess,json,time,signal
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','SEAL_ORDER_INPUT':str(b.parent/'market-seal-inclusion-20261028-v1/component-proof-v1'),'SEAL_ORDER_OTHER_CASE':str(b.parent/'market-random-order-20261028-v1'),'SEAL_ORDER_OUT':str(b/'proof-v1')})
cmd=['cargo','+nightly-2025-09-20','test','--release','--locked','--offline','--manifest-path',str(b/'application-v1/Cargo.toml'),'--test','seal_order','linked_seal_and_order_proof','--','--exact','--ignored','--nocapture']
start=time.monotonic();samples=[];stopped=None
with (b/'public/proof-v1.log').open('x')as log:
 p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=[list(map(int,x.split()))for x in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()];owned={p.pid}
  for _ in range(8):
   more=owned|{pid for pid,parent,rss in rows if parent in owned}
   if more==owned:break
   owned=more
  rss=sum(rss for pid,parent,rss in rows if pid in owned);samples.append({'elapsedSeconds':time.monotonic()-start,'familyRssKiB':rss})
  if time.monotonic()-start>300 or rss>4096*1024:
   stopped='declared time/memory ceiling';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(1)
result={'exitCode':p.returncode,'seconds':time.monotonic()-start,'stopReason':stopped,'samples':samples,'rssScope':'launch-to-exit 1Hz sampled process family, shared pages may duplicate, not physical peak','financialOperations':0,'command':cmd}
with (b/'public/proof-result-v1.json').open('x')as out:json.dump(result,out,indent=2);out.write('\n')
print(result['exitCode'],result['seconds'],flush=True)
