from pathlib import Path
import json,hashlib
c=Path(__file__).resolve().parent;root=c/'full-ups-v3';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
normal=['sealed-grant','open','sealed-source-0','sealed-source-1',*[f'sealed-minimum-{i}'for i in range(4)],'sealed-settle-0','sealed-settle-1']
for market in ['amm','bondingcurve']:
 report=read(root/(market+'-REPORT.json'));assert report['fullUpsVerified'] and not report['broadcast']and not report['ordinaryWalletUps']and not report['qualifiedRandomness']
 labels=normal+(['sealed-unseeded-expire','sealed-unseeded-refund-0','sealed-unseeded-refund-1']if market=='amm'else[])
 infos={};totalfee=0;fill=0;refund=0;key=None
 for label in labels:
  d=root/(market+'-'+label);v=read(d/'verification.json');p=read(d/'plan.json');pub=read(d/'public-session.json');request=read(d/'request.json');core=request['user_ec_input']['core'];calls=pub['actualCalls']
  assert v['fullUpsVerified']and v['fixedVerifier']and not v['broadcast']
  assert len(pub['stack'])==40 and len(calls)==v['calls']==int(pub['txCount'])
  assert v['fee']==1000000000+1000*v['slots']==int(core['stats']['guta_fees_collected'])+int(core['stats']['da_fees_collected'])
  assert calls[-2]['method_name']=='account_executor_fee'and calls[-2]['inputs']==[v['fee'],*p['registered_key']]
  assert calls[-1]['method_name']=='burn'and calls[-1]['inputs']==[v['fee']]
  assert pub['session']['checkpoint_tree_root']==read(d/'source.json')['history']['checkpoint_path']['root']
  if key is None:key=v['keyFingerprint']
  assert v['keyFingerprint']==key==pub['keyFingerprint']
  if label.startswith('sealed-minimum-'):
   seal=p['accepted_seal'];assert seal['snapshot']['fields'][6]==report['acceptedSeal'];assert report['source']<report['acceptedSeal']<report['draw']==report['source']+32
   assert seal['snapshot']['history']['checkpoint_path']['root']==pub['session']['checkpoint_tree_root']
   assert len(calls[0]['inputs'])==10 and calls[0]['inputs'][4]==report['draw']and calls[0]['inputs'][9]==report['acceptedSeal']
   assert calls[0]['inputs'][5:9]==p['minimum']['seed']==[51,62,73,84]
   assert len(p['minimum']['rows'])==[4,1,4,1][int(label.rsplit('-',1)[1])]
   if label=='sealed-minimum-0':assert set(['missing-seal-opening','draw-index-is-not-prior-seal','seal-wrong-chain','seal-inconsistent-root-metadata','seal-coherent-foreign-history','seal-wrong-epoch'])<=set(v['keyAttackRejections'])
  if label.startswith('sealed-settle-'):
   assert not p.get('accepted_seal');assert p['minimum']['seed']==[51,62,73,84]
   for call in calls:
    if call['contract_id']==1000:
     fill+=call['method_name']in ['swap_0','settle_limit_buy'];refund+=call['method_name']in ['refund_funding','batch_refund_swap_0','batch_refund_curve_buy']
  totalfee+=v['fee'];infos[label]=v
  rows.append({'market':market,'label':label,'keyFingerprint':key,**{k:v[k]for k in ['calls','logicalSlots','slots','fee','storedStartLeaf','endLeaf','seconds','keySeconds','endcapAndAuditSeconds','keyAttackRejections']},'requestSha256':sha(d/'request.json'),'keyProofSha256':sha(d/'key-proof.bin')})
 for branch in [normal]+([normal[:4]+labels[-3:]]if market=='amm'else[]):
  for before,after in zip(branch,branch[1:]):assert infos[before]['endLeaf']==infos[after]['storedStartLeaf'],(market,before,after)
 assert fill==3 and refund==2
 assert all(int(r['claimed'])>=0 for r in report['ordinaryClaims'])and len(report['ordinaryClaims'])==15
 for r in report['ordinaryClaims']:
  if 'balanceDelta'in r:assert int(r['balanceDelta'])==int(r['claimed'])
 reportsummary={'market':market,'syntheticFills':fill,'normalRefunds':refund,'members':5,'sourceAccounts':8,'source':report['source'],'seal':report['acceptedSeal'],'draw':report['draw'],'fullUps':len(labels),'aggregateSyntheticFeesAcrossBranchesBaseUnits':str(totalfee),'ordinaryClaimCheckRows':15,'nonzeroOrdinaryVmClaims':sum(int(r['claimed'])>0 for r in report['ordinaryClaims']),'networkClaims':0,'keyFingerprint':key}
 with(c/('public/'+market+'-RESULT-v1.json')).open('x')as f:json.dump(reportsummary,f,indent=2);f.write('\n')
with(c/'public/SEALED-AUDIT-v1.json').open('x')as f:json.dump({'scope':'structural audit; exact native end-cap/key verification was performed by the recorded test binary, not this script','completeSyntheticUps':23,'syntheticFills':6,'networkTransactions':0,'ordinaryWalletSignedClaims':0,'actualNetworkFeesBaseUnits':'0','rows':rows},f,indent=2);f.write('\n')
print(json.dumps({'completeSyntheticUps':len(rows),'networkTransactions':0}))
