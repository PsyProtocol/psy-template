from pathlib import Path
import json,hashlib,gzip
case=Path(__file__).resolve().parent
repo=case.parent.parent/'psy-template-security-20261016'
out=repo/'executor/verification/2026-10-29-diagram-producer-recovery-v1'
out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
records=[]
def add(src,name):
 raw=src.read_bytes()
 text=raw.decode()
 for a,b in [(str(case.parent),'<evidence-root>'),(str(Path.home()),'<home>')]:text=text.replace(a,b)
 public=text.encode();packed=gzip.compress(public,mtime=0)
 dst=out/'files'/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('xb') as f:f.write(packed)
 records.append({'file':str(dst.relative_to(out)),'sha256':sha(public),'originalSha256':sha(raw),'gzipSha256':sha(packed),'bytes':len(public),'gzipBytes':len(packed),'pathRedacted':public!=raw})
for f in sorted((case/'public').rglob('*')):
 if f.is_file():add(f,'run/public/'+str(f.relative_to(case/'public')))
for f in sorted(case.glob('*manifest.json')):add(f,'run/'+f.name)
for label in ['application-baseline-v1','application-candidate-v1']:
 for name in ['Cargo.toml','Cargo.lock','APPLICATION.json']:add(case/label/name,'run/'+label+'/'+name)
for name in ['run.py','native_cases.py','package_public.py']:add(case/name,'reproduction/'+name)
add(repo/'batching/dependencies/mainnet-beta-20261027/manifest.json','dependencies/manifest.json')
summary=json.loads((case/'public/SUMMARY.json').read_text())
with (out/'SUMMARY.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
index={'schema':1,'applicationBase':summary['applicationBase'],'sourceSha256':json.loads((case/'public/SOURCE-PINS.json').read_text()),'files':records,'binariesUploaded':False,'newProofsGenerated':0,'financialOperations':0,'priorCompleteUpsEvidence':'../2026-10-28-previous-checkpoint-v1/README.md'}
with (out/'index.json').open('x') as f:json.dump(index,f,indent=2);f.write('\n')
for r in records:
 p=(out/r['file']).read_bytes();raw=gzip.decompress(p)
 assert sha(p)==r['gzipSha256'] and sha(raw)==r['sha256']
 # These are public policy/rank projections and timing logs, not wallet state.
 if r['file'].endswith('.json.gz'):
  def scan(v):
   if isinstance(v,dict):
    assert not(set(v)&{'private_key','privateKey','mnemonic','password','state_reader_results','signingWitness','secret_key','secretKey'})
    for val in v.values():scan(val)
   elif isinstance(v,list):
    for val in v:scan(val)
  scan(json.loads(raw))
audit={'files':len(records),'gzipBytes':sum(r['gzipBytes'] for r in records),'allDigestsVerified':True,'publicProjectionKeyScanPassed':True,'financialOperations':0}
with (out/'PUBLISHED-AUDIT.json').open('x') as f:json.dump(audit,f,indent=2);f.write('\n')
print(json.dumps(audit))
