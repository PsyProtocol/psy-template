import json,pathlib,subprocess,hashlib,time,datetime
C=pathlib.Path(__file__).resolve().parent
previous=C.parent/'runtime-resource-acquisition-20261030-v1'
s=json.loads((previous/'public/l1-state-manager-observation.json').read_bytes())
url='https://rpc-eth-stg.psy-protocol.xyz'
def call(label,method,params):
 req={'jsonrpc':'2.0','id':1,'method':method,'params':params}
 rp=C/'quarantine'/f'{label}.request.json'
 with rp.open('x')as f:json.dump(req,f)
 rp.chmod(0o600);out=C/'quarantine'/f'{label}.body';assert not out.exists()
 start=time.monotonic();p=subprocess.run(['curl','--silent','--show-error','--max-time','40','--max-filesize','2097152','--proto','=https','-H','Content-Type: application/json','--data-binary','@'+str(rp),'-o',str(out),'-w','%{http_code}',url],capture_output=True,text=True)
 raw=out.read_bytes()if out.exists()else b''
 if out.exists():out.chmod(0o600)
 r={'schema':1,'url':url,'request':req,'httpStatus':p.stdout,'curlExit':p.returncode,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'elapsedSeconds':time.monotonic()-start,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalityVerified':False,'canBroadcast':False}
 with(C/'public'/f'{label}-transport.json').open('x')as f:json.dump(r,f,indent=2);f.write('\n')
 print(json.dumps(r),flush=True)
 if p.returncode or p.stdout!='200':raise RuntimeError('read failed; no retry')
 v=json.loads(raw)
 if v.get('id')!=1 or v.get('jsonrpc')!='2.0' or 'result'not in v or 'error'in v:
  with(C/'public'/f'{label}-error.json').open('x')as f:json.dump({'schema':1,'error':v.get('error'),'finalityVerified':False},f,indent=2);f.write('\n')
  raise RuntimeError('RPC rejected; no retry')
 return v['result']


from concurrent.futures import ThreadPoolExecutor
plan=json.loads((C/'public/PAIRED_CAPTURE_PLAN.json').read_bytes())
block=call('paired-header','eth_getBlockByNumber',['latest',False])
assert isinstance(block,dict) and len(block.get('hash',''))==66
fixed={'blockHash':block['hash'],'requireCanonical':True}
keys=['hash','parentHash','sha3Uncles','miner','stateRoot','transactionsRoot','receiptsRoot','logsBloom','difficulty','number','gasLimit','gasUsed','timestamp','extraData','mixHash','nonce','baseFeePerGas','withdrawalsRoot','blobGasUsed','excessBlobGas','parentBeaconBlockRoot','requestsHash','blockAccessListHash','slotNumber']
with(C/'public/paired-header-projection.json').open('x')as f:json.dump({'schema':1,'header':{k:block[k]for k in keys}},f,indent=2);f.write('\n')
def capture(account):
 role=account['role'];proof=call('paired-'+role+'-proof','eth_getProof',[account['address'],account['slots'],fixed])
 statement={'schema':1,'kind':'prospective-execution-state-statement-v1','chainId':11155111,'address':account['address'],'blockHash':block['hash'],'blockNumber':block['number'],'stateRoot':block['stateRoot'],'slots':account['slots'],'originalAnchorReplaced':False,'headerConsensusVerified':False,'canBroadcast':False}
 source='prospective-proxy-code'if role=='proxy'else'prospective-implementation-code'
 code=json.loads((C/'quarantine'/f'{source}.body').read_bytes())['result']
 for suffix,obj in [('statement',statement),('proof',{'schema':1,'proof':{k:proof[k]for k in ['address','accountProof','balance','codeHash','nonce','storageHash','storageProof']}}),('code',{'schema':1,'address':account['address'],'blockHash':block['hash'],'code':code})]:
  with(C/'public'/f'paired-{role}-{suffix}.json').open('x')as f:json.dump(obj,f,indent=2);f.write('\n')
 return role
with ThreadPoolExecutor(max_workers=2)as pool:roles=list(pool.map(capture,plan['accounts']))
print('Paired proof capture completed:',roles,flush=True)
