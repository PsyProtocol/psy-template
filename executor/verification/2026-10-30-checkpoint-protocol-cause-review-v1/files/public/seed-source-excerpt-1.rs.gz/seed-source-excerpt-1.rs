        }

        let random_seed_guta = get_temp_guta_rand_seed::<N::QHash>();

        // Write trailing metadata to backup file so reader can verify length.
        // Format: magic(4) + start_root(32) + [items...] + random_seed(32)
        self.new_coordinator_guta_file
            .write_all(&random_seed_guta.into_owned_32bytes())
            .await?;
        self.config
            .file_system
