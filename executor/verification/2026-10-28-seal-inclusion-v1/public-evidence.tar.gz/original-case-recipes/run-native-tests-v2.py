from pathlib import Path
import os,subprocess,json,time,signal
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';env=dict(os.environ);env.update({'PATH':'/opt/homebrew/Cellar/go/1.26.0/libexec/bin:'+env['PATH'],'GOROOT':'/opt/homebrew/Cellar/go/1.26.0/libexec','PSY_NETWORK':'testnet','PSY_CONFIG_PATH':str(s/'source/psy-sdk/psy-genesis/config.json'),'PSY_MARKET_TESTNET_PROFILE':'mainnet-beta-20261027-v1','CARGO_TARGET_DIR':str(s/'target'),'CARGO_BUILD_JOBS':'2','RAYON_NUM_THREADS':'2','SEAL_INCLUSION_OUT':str(b/'component-proof-v1')})
cmd=['cargo','+nightly-2025-09-20','test','--release','--locked','--offline','--manifest-path',str(b/'application-v2/Cargo.toml'),'--test','seal_inclusion','--','--nocapture']
start=time.monotonic();samples=[];stopped=None
with (b/'public/native-tests-v2.log').open('x')as f:
 p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=[list(map(int,x.split()))for x in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines()];owned={p.pid}
  for _ in range(8):
   more=owned|{pid for pid,parent,rss in rows if parent in owned}
   if more==owned:break
   owned=more
  rss=sum(rss for pid,parent,rss in rows if pid in owned);samples.append({'elapsedSeconds':time.monotonic()-start,'familyRssKiB':rss})
  if time.monotonic()-start>300 or rss>4096*1024:
   stopped='declared time/memory ceiling';os.killpg(p.pid,signal.SIGTERM);p.wait();break
  time.sleep(1)
result={'exitCode':p.returncode,'seconds':time.monotonic()-start,'stopReason':stopped,'samples':samples,'rssScope':'full launch-to-exit sampled process family, shared pages may duplicate, not physical peak','financialOperations':0}
with (b/'public/native-tests-result-v2.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(result['exitCode'],result['seconds'],flush=True)
