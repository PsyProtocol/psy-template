import test from'node:test';import assert from'node:assert/strict';
import{createIntent,createRegistry,planIntent,units}from'./intent.mjs';
import{MAX_AMOUNT}from'../token/wide/arithmetic.mjs';
const root='a'.repeat(64),other='b'.repeat(64),sdk='c'.repeat(64);
const dep=id=>({contractId:id,codeRoot:root,layoutRoot:root,functionTreeRoot:root,stateTreeHeight:31n,layoutFieldCount:71n,layoutSlotCount:1000n});
export function fixture(){
 const market=(id,vault,assets)=>({kind:'amm',marketId:id,vaultId:vault,fingerprint:root,publicKeyHash:other,dependencies:[0n,id,...assets.map(a=>a.id)].map(dep),assets});
 const registry=createRegistry({domainHash:root,sdkManifestHash:sdk,markets:[market(100n,200n,[{id:10n,decimals:18},{id:11n,decimals:6}]),market(101n,201n,[{id:11n,decimals:6},{id:12n,decimals:9}])]});
 const terms={version:1,domainHash:root,sdkManifestHash:sdk,registryHash:registry.hash,owner:50n,nonce:1n,receiver:50n,expiresAtCheckpoint:200n,maxNativeFees:50_000_000_000n,input:{id:10n,decimals:18,amount:100n},output:{id:12n,decimals:9,amount:1n},markets:[100n,101n],execution:{controllerId:102n,vaultId:202n,fingerprint:root,publicKeyHash:other,codeRoot:root,layoutRoot:root,functionTreeRoot:root,stateTreeHeight:31n,layoutFieldCount:20n,layoutSlotCount:100n}};
 const intent=createIntent(terms),snapshots=[{marketId:100n,vaultId:200n,checkpoint:100n,stateRoot:root,reserveA:1000n,reserveB:1000n},{marketId:101n,vaultId:201n,checkpoint:100n,stateRoot:root,reserveA:1000n,reserveB:1000n}];
 return{terms,intent,registry,snapshots,checkpoint:100n};
}
test('canonical intent binds the whole scope and keeps advisory quotes non-authorizing',()=>{const f=fixture(),p=planIntent(f);assert.equal(p.atomic,false);assert.equal(p.sourceAuthenticated,false);assert.equal(p.steps[1].input,p.steps[0].output);assert.ok(Object.isFrozen(f.intent.terms.input));for(const change of [{nonce:2n},{domainHash:other},{sdkManifestHash:other},{maxNativeFees:1n},{expiresAtCheckpoint:201n},{input:{...f.terms.input,amount:101n}}])assert.notEqual(createIntent({...f.terms,...change}).id,f.intent.id);});
test('wrong receiver, ambiguous fields, unsafe numbers and nonce overflow fail closed',()=>{const f=fixture();for(const change of [{receiver:51n},{nonce:0n},{nonce:1n<<62n},{owner:50},{version:2},{seed:'x'},{output:{...f.terms.output,collection:1n}}])assert.throws(()=>createIntent({...f.terms,...change}));});
test('decimal parsing is exact for differing verified precision',()=>{assert.equal(units('1.000000000000000017',18),(10n**18n)+17n);assert.equal(units('1.000001',6),1_000_001n);assert.equal(units('12',0),12n);for(const [s,d]of[['1e3',18],['01',18],['-1',6],['1.1',0],['1.0000001',6],['1',19]])assert.throws(()=>units(s,d));assert.equal(units(MAX_AMOUNT.toString(),0),MAX_AMOUNT);assert.throws(()=>units((MAX_AMOUNT+1n).toString(),0));});
test('route, registry, assets, decimals, domain and expiry substitutions reject',()=>{const f=fixture();for(const change of [{checkpoint:200n},{intent:{...f.intent,id:other}},{registry:{...f.registry,hash:other}},{snapshots:[{...f.snapshots[0],vaultId:202n},f.snapshots[1]]},{snapshots:[{...f.snapshots[0],checkpoint:99n},f.snapshots[1]]}])assert.throws(()=>planIntent({...f,...change}));for(const change of [{domainHash:other},{sdkManifestHash:other},{input:{...f.terms.input,decimals:9}},{output:{...f.terms.output,id:10n}},{output:{...f.terms.output,amount:MAX_AMOUNT}}])assert.throws(()=>planIntent({...f,intent:createIntent({...f.terms,...change})}));});
test('registry commits code/layout/function/key/vault plus complete dependencies',()=>{const f=fixture();for(const field of ['fingerprint','publicKeyHash']){const r=structuredClone(f.registry.value);r.markets[0][field]='d'.repeat(64);assert.notEqual(createRegistry(r).hash,f.registry.hash);}for(const field of ['codeRoot','layoutRoot','functionTreeRoot']){const r=structuredClone(f.registry.value);r.markets[0].dependencies[0][field]='d'.repeat(64);assert.notEqual(createRegistry(r).hash,f.registry.hash);}const r=structuredClone(f.registry.value);r.markets[0].dependencies.pop();assert.throws(()=>createRegistry(r),/closure/);});
test('U124 carry and reserve overflow remain checked by base arithmetic',()=>{const f=fixture();const i=createIntent({...f.terms,input:{...f.terms.input,amount:(1n<<62n)+17n}});assert.throws(()=>planIntent({...f,intent:i,snapshots:[{...f.snapshots[0],reserveA:MAX_AMOUNT,reserveB:MAX_AMOUNT},f.snapshots[1]]}),/bounded/);assert.throws(()=>createIntent({...f.terms,input:{...f.terms.input,amount:MAX_AMOUNT+1n}}),/bounded/);});

test('layout slots use the selected SDK packed-word capacity while metadata stays exact',()=>{
 const f=fixture(),r=structuredClone(f.registry.value),nativeSlots=8594128984n;
 for(const m of r.markets){const d=m.dependencies.find(d=>d.contractId===0n);d.stateTreeHeight=32n;d.layoutSlotCount=nativeSlots;d.layoutFieldCount=8n;}
 const accepted=createRegistry(r);assert.notEqual(accepted.hash,f.registry.hash);
 for(const invalid of [-1n,17179869185n,8594128984,9007199254740992]){
  const wrong=structuredClone(r);wrong.markets[0].dependencies[0].layoutSlotCount=invalid;assert.throws(()=>createRegistry(wrong),/bounded/);
 }
 const short=structuredClone(r);short.markets[0].dependencies[0].stateTreeHeight=31n;assert.throws(()=>createRegistry(short),/bounded/);
 const execution={...f.terms.execution,stateTreeHeight:32n,layoutSlotCount:nativeSlots};
 assert.equal(createIntent({...f.terms,execution}).terms.execution.layoutSlotCount,nativeSlots);
 assert.equal(createIntent({...f.terms,execution:{...execution,layoutSlotCount:17179869184n}}).terms.execution.layoutSlotCount,17179869184n);
 for(const bad of [{layoutSlotCount:17179869185n},{layoutSlotCount:8594128984},{stateTreeHeight:31n},{stateTreeHeight:33n},{layoutFieldCount:1n<<32n}])
  assert.throws(()=>createIntent({...f.terms,execution:{...execution,...bad}}),/bounded/);
});
