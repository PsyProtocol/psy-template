import os,sys,time,json,subprocess,signal
from pathlib import Path
case=Path(__file__).resolve().parent
sdk=case.parent/'sdk-mainnet-beta-20261027-v1'
env=os.environ.copy();env.update(PSY_NETWORK='testnet',PSY_CONFIG_PATH=str(sdk/'source/psy-sdk/psy-genesis/config.json'),PSY_MARKET_TESTNET_PROFILE='mainnet-beta-20261027-v1',RAYON_NUM_THREADS='2',BATCH_MINIMAL_GENESIS='1',BATCH_BUILD=str(case.parent/'deterministic-bootstrap-20261031-v1/fixtures-v1'),FUNDED_LIFECYCLE_OUT=str(case/'lifecycle-v1'))
start=time.monotonic();samples=[];reason=None
with (case/'public/lifecycle-v1.log').open('xb') as log:
 p=subprocess.Popen([str(case/'bin/lifecycle-v4'),'fresh_curve_lifecycle_with_ordinary_claim_and_exhausted_fee_recovery','--ignored','--nocapture','--test-threads=1'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (case/'public/ACTIVE-v1.json').write_text(json.dumps({'owner':'root','pid':p.pid,'maximumSeconds':2400,'maximumCompleteUps':12,'financialOperations':0})+'\n')
 while p.poll() is None:
  rows=[tuple(map(int,r.split())) for r in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines() if len(r.split())==3];ids={p.pid}
  while True:
   old=len(ids);ids.update(pid for pid,parent,rss in rows if parent in ids)
   if len(ids)==old:break
  rss=sum(rss for pid,parent,rss in rows if pid in ids);elapsed=time.monotonic()-start;samples.append({'elapsedSeconds':elapsed,'familyRssKiB':rss})
  if elapsed>2400 or rss>10485760:
   reason='deadline' if elapsed>2400 else 'sampled RSS limit';os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(1)
 try:code=p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
report={'exitCode':code,'elapsedSeconds':time.monotonic()-start,'stopReason':reason,'sampledFamilyRssPeakKiB':max([s['familyRssKiB'] for s in samples],default=0),'memoryScope':'one-second process-family RSS sampling, includes shared pages; not physical peak','financialOperations':0,'samples':samples}
(case/'public/CLOSED-v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='samples'}));sys.exit(code if code>=0 else 1)
