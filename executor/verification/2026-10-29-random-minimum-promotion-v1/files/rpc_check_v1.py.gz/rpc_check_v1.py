from pathlib import Path
import json,subprocess,datetime
c=Path(__file__).resolve().parent;d=c/'public/rpc-precheck-v1';d.mkdir();old=c.parent/'random-source-stream-20261029-v1/public/rpc-precheck-v1'
def put(p,a):
 with p.open('x')as f:json.dump(a,f,indent=2);f.write('\n')
put(d/'PLAN.json',{'maxReadOnlyRequests':7,'retries':0,'timeoutPerRequestSeconds':15,'financialOperations':0,'scope':'read-only observations; not an authorization or finality proof'})
rows=[]
for name in ['head-0','head-1','head-2','anchor-0','anchor-1','anchor-2','native']:
 a=json.loads((old/(name+'-request.json')).read_text());assert a['endpoint']in ['https://realm0-stg.psy-protocol.xyz','https://realm1-stg.psy-protocol.xyz','https://coordinator-stg.psy-protocol.xyz'];assert a['request']['method']in ['psy_get_latest_checkpoint_id','psy_get_checkpoint_global_state_roots','psy_get_contract_leaf_data']
 put(d/(name+'-request.json'),a)
 p=subprocess.run(['curl','--silent','--show-error','--connect-timeout','8','--max-time','15','--max-filesize','1048576','--header','content-type: application/json','--data-binary','@-',a['endpoint']],input=json.dumps(a['request']).encode(),capture_output=True,timeout=20)
 with(d/(name+'-response.raw')).open('xb')as f:f.write(p.stdout)
 row={'label':name,'exitCode':p.returncode,'stderr':p.stderr.decode(errors='replace')}
 try:row['response']=json.loads(p.stdout)
 except:row['response']=None
 put(d/(name+'-transport.json'),row);rows.append(row)
valid=lambda r:r['exitCode']==0 and isinstance(r['response'],dict)and'error'not in r['response']and'result'in r['response']
anchors=[r['response']['result']for r in rows if r['label'].startswith('anchor')and valid(r)]
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'successfulReads':sum(valid(r)for r in rows),'heads':{r['label']:r['response']['result']for r in rows if r['label'].startswith('head')and valid(r)},'checkpointOneAgreed':len(anchors)==3 and anchors[0]==anchors[1]==anchors[2],'nativeLeaf':next((r['response']['result']for r in rows if r['label']=='native'and valid(r)),None),'financialOperations':0,'finalityAuthenticated':False,'deploymentEnabled':False}
put(d/'SUMMARY.json',summary);print(summary)
