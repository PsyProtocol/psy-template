from pathlib import Path
import json,urllib.request,time,hashlib,concurrent.futures
b=Path(__file__).resolve().parent;s=b.parent/'sdk-mainnet-beta-20261027-v1';config=s/'source/psy-sdk/psy-genesis/config.json';network=json.loads(config.read_text())['networks']['testnet'];url=network['coordinator_configs'][0]['rpc_url'][0];rows=[]
def call(label,method,params):
 assert method in ['psy_get_latest_checkpoint_id','psy_get_checkpoint_tree_root','psy_get_checkpoint_tree_leaf_hash','psy_get_checkpoint_tree_merkle_proof','psy_get_checkpoint_state_transition_proof']
 body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode();start=time.monotonic();entry={'label':label,'method':method,'params':params,'endpoint':url,'requestSha256':hashlib.sha256(body).hexdigest()}
 with (b/'public'/f'{label}-request.json').open('xb')as f:f.write(body)
 try:
  with urllib.request.urlopen(urllib.request.Request(url,data=body,headers={'Content-Type':'application/json'}),timeout=15)as r:raw=r.read(12000001);assert len(raw)<=12000000,'response limit';entry['httpStatus']=r.status
  with (b/'public'/f'{label}-response.json').open('xb')as f:f.write(raw)
  value=json.loads(raw);assert value.get('jsonrpc')=='2.0'and value.get('id')==1 and 'error'not in value and'result'in value,'RPC error/envelope'
  entry['responseSha256']=hashlib.sha256(raw).hexdigest();entry['ok']=True;return entry,value['result']
 except Exception as e:entry['ok']=False;entry['error']=str(e);return entry,None
 finally:entry['seconds']=time.monotonic()-start
first,cp=call('latest','psy_get_latest_checkpoint_id',[]);rows.append(first)
if isinstance(cp,int)and not isinstance(cp,bool)and 1<=cp<=4294967295:
 jobs=[]
 for label,n in [('genesis',0),('current',cp)]:
  jobs.extend([(label+'-root','psy_get_checkpoint_tree_root',{'checkpoint_id':n}),(label+'-leaf','psy_get_checkpoint_tree_leaf_hash',{'checkpoint_id':n,'leaf_checkpoint_id':n}),(label+'-path','psy_get_checkpoint_tree_merkle_proof',{'checkpoint_id':n,'leaf_checkpoint_id':n}),(label+'-proof','psy_get_checkpoint_state_transition_proof',{'checkpoint_id':n})])
 if cp>1:jobs.append(('previous-proof','psy_get_checkpoint_state_transition_proof',{'checkpoint_id':cp-1}))
 assert len(jobs)+1<=10
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for future in [pool.submit(call,*j)for j in jobs]:
   entry,result=future.result();rows.append(entry);print(entry['label'],entry['ok'],flush=True)
report={'schema':1,'network':'testnet','declaredMagic':network['magic'],'configSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'observedCheckpoint':cp,'calls':rows,'financialOperations':0,'proofsGenerated':0,'finalityVerified':False,'qualifiedSource':False,'randomAuthorization':False}
with (b/'public/RPC-OBSERVATIONS-v1.json').open('x')as out:json.dump(report,out,indent=2);out.write('\n')
print('Saved',len(rows),'bounded public read attempts; no authorization inferred.',flush=True)
