import {mkdir,writeFile} from 'node:fs/promises';
const out=new URL('./observations/native-functions-v2/',import.meta.url);await mkdir(out);
const rows=[];
for(const[name,index]of[['transfer',6],['claim',8],['burn',14]]){
 const request={jsonrpc:'2.0',id:1,method:'psy_get_contract_function_tree_merkle_proof',params:{checkpoint_id:347,contract_id:0,function_id:index}};
 await writeFile(new URL(name+'-request.json',out),JSON.stringify(request)+'\n',{flag:'wx'});
 const response=await fetch('https://coordinator-stg.psy-protocol.xyz',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request),redirect:'error',signal:AbortSignal.timeout(20000)});
 const raw=await response.text();await writeFile(new URL(name+'-response.json',out),raw,{flag:'wx'});const json=JSON.parse(raw);rows.push({name,index,request,httpStatus:response.status,response:json});
 console.log(name,response.status,json.error??Object.keys(json.result??{}));
}
await writeFile(new URL('CAPTURE.json',out),JSON.stringify({at:new Date().toISOString(),financialOperations:0,rows},null,2)+'\n',{flag:'wx'});
