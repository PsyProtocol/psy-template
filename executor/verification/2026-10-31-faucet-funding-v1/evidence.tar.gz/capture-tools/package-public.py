from pathlib import Path
import json,hashlib,tarfile,io,gzip,re
case=Path(__file__).resolve().parent
repo=case.parent.parent/'psy-template-security-20261016'
out=repo/'executor/verification/2026-10-31-faucet-funding-v1'
out.mkdir()
items={}
for directory in ['public','capture-v1','reconcile-v1']:
 for p in sorted((case/directory).rglob('*')):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink()
  assert p.suffix in ['.json','.log']
  b=p.read_bytes();name=p.relative_to(case).as_posix()
  assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|"(?:private_key|privateKey|mnemonic|seedPhrase|password)"\s*:',b),name
  items[name]=b
for name in ['observe-services.mjs','package-public.py']:
 items['capture-tools/'+name]=(case/name).read_bytes()
for name in ['captureNativeBinding.mjs','reconcileFaucetFunding.mjs','reconcileFaucetFunding.test.mjs']:
 items['application/'+name]=(repo/'executor/acceptance'/name).read_bytes()
# The ordinary registry is exactly the previously reviewed public verifier-only
# registry; comparison was completed before publication. No secret witness wire
# data, wallet files, or raw original faucet error is traversed by this packager.
registry=json.loads(items['capture-v1/runtime-client-resources.json'])['result']
old=json.loads((case.parent/'current-chain-activation-20261030-v1/capture-v3/runtime-client-resources.json').read_text())['result']
assert registry==old
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as t:
 for name,b in sorted(items.items()):
  e=tarfile.TarInfo(name);e.size=len(b);e.mode=0o644;e.mtime=0;t.addfile(e,io.BytesIO(b))
packed=gzip.compress(buffer.getvalue(),mtime=0)
with (out/'evidence.tar.gz').open('xb') as f:f.write(packed)
manifest={'schema':1,'scope':'Bounded read-only funding reconciliation; not financial acceptance','archiveSha256':hashlib.sha256(packed).hexdigest(),'members':[{'file':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}for n,b in sorted(items.items())],'financialOperations':0,'originalFaucetOutcome':'unresolved'}
with (out/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
readme='''# Original faucet and current funding evidence — 31 October 2026

Read the [review report](../../../docs/security/FAUCET_FUNDING_CONTINUATION_20261031.md).
This is read-only funding evidence, not deployment, a market UPS, real settlement,
ordinary-wallet arrival, finality or permission to resend the original grant.

- `capture-v1/`: 16 fresh chain/Native/user/verifier reads at checkpoint 22654.
- `reconcile-v1/`: all 203 exact one-attempt configuration/registration/cursor
  requests and responses, transports, original-lock preservation and summary.
- `public/`: predeclared limits, safe original request/error projection, three
  service-index hints, unchanged-resource/source checks, 23-test final log,
  original failed test assertion summary, manual review and zero-fee accounting.
- `application/`: exact acquisition/reconciliation source snapshot.
- `capture-tools/`: original public index acquisition and packaging scripts.
  These retain local acquisition paths; they do not authorize replaying finance.

`manifest.json` binds every member, length, SHA256 and archive SHA256. The prior
raw private proving diagnostic, all wallet secrets/recovery files and binaries
are excluded. Public `private_note_*` registry names describe verifier metadata,
not private keys or secret witnesses. The registry result is identical to the
previously reviewed public payload.

Balance and known pending total are zero. The original request and lock remain
unchanged. There were no new faucet requests, business proofs, new contracts,
registrations, fills or claims. The remaining external delivery is exact
original-request disposition or independent budgeted funding; there is no safe
client-side retry based solely on this inventory.
'''
with (out/'README.md').open('x') as f:f.write(readme)
print(json.dumps({'members':len(items),'archiveBytes':len(packed),'archiveSha256':manifest['archiveSha256']}))
