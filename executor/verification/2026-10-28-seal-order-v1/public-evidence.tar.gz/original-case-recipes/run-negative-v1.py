from pathlib import Path
import copy,hashlib,json,os,subprocess,time
b=Path(__file__).resolve().parent;o=b/'negative-v1';o.mkdir();f=b/'proof-v1';binary=b.parent/'sdk-mainnet-beta-20261027-v1/target/release/verify_seal_order'
original=json.loads((f/'candidate.json').read_text());layout=json.loads((f/'layout.json').read_text());root=json.loads((f/'REPORT.json').read_text())['checkpointRoot'];rows=[];started=time.monotonic();env=dict(os.environ,RAYON_NUM_THREADS='2',PSY_NETWORK='testnet')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(name,statement=None,descriptor=None,checkpoint='105',checkpoint_root=None,proof=None,existing=None):
 assert time.monotonic()-started<120,'total read-only test budget expired'
 case=o/name;case.mkdir();inputs=[]
 for label,value,default in [('candidate',statement,f/'candidate.json'),('layout',descriptor,f/'layout.json'),('proof',proof,f/'linked-proof.bin')]:
  path=default
  if value is not None:
   path=case/(label+('.bin'if label=='proof'else'.json'))
   with path.open('xb')as out:out.write(value if isinstance(value,bytes)else json.dumps(value).encode())
  inputs.append(path)
 report=existing or case/'REPORT.json';before=sha(report)if report.exists()else None
 args=[str(binary),str(inputs[0]),str(inputs[1]),checkpoint_root or root,checkpoint,str(inputs[2]),str(report)]
 start=time.monotonic();p=subprocess.run(args,env=env,capture_output=True,timeout=20)
 with (case/'output.log').open('xb')as out:out.write(p.stdout+p.stderr)
 assert p.returncode!=0,(name,'unexpected acceptance')
 assert sha(report)==before if before else not report.exists(),(name,'report replaced')
 rows.append({'name':name,'exitCode':p.returncode,'seconds':time.monotonic()-start,'arguments':args[1:],'inputs':[{'path':str(path),'sha256':sha(path)}for path in inputs],'existingReportPreserved':bool(before)})
for name,index in [('network',1),('genesis',18),('source',14),('round',9),('epoch',5),('market',3),('vault',4),('code',22),('layout-root',26),('function-root',30),('key-fingerprint',34),('queue-root',42),('batch-root',46),('member-terms',52),('member-nonce',51)]:
 value=copy.deepcopy(original);value['fields'][index]=str(int(value['fields'][index])+1);run(name,statement=value)
value=copy.deepcopy(original);value['seed'][0]='2';run('changed-seed',statement=value)
value=copy.deepcopy(original);value['fields'][52]='00';run('noncanonical-field',statement=value)
value=copy.deepcopy(original);value['verified']=True;run('injected-success',statement=value)
value=copy.deepcopy(original);value['verifierUrl']='https://invalid.example/verifier';run('injected-verifier',statement=value)
value=copy.deepcopy(layout);value['root_slot']=2;run('different-reviewed-slot',descriptor=value)
value=copy.deepcopy(layout);value['fields']+=1;run('different-layout-count',descriptor=value)
run('wrong-checkpoint',checkpoint='106');run('leading-zero-checkpoint',checkpoint='0105');run('wrong-checkpoint-root',checkpoint_root='0'*64);run('noncanonical-root',checkpoint_root=root.upper())
run('child-proof-instead-of-parent',proof=(f/'order-proof.bin').read_bytes())
value=bytearray((f/'linked-proof.bin').read_bytes());value[len(value)//2]^=1;run('corrupt-proof',proof=bytes(value))
run('trailing-proof',proof=(f/'linked-proof.bin').read_bytes()+b'\x00');run('oversize-proof',proof=b' '*2000001);run('oversize-input',statement=b' '*16385);run('existing-report',existing=b/'public/exact-verification-v1.json')
with (b/'public/negative-result-v1.json').open('x')as out:json.dump({'schema':1,'scope':'linked-component parser, endpoint and saved-proof rejection; not qualified beacon, finality or live faults','toolSha256':sha(binary),'cases':rows,'rejected':len(rows),'seconds':time.monotonic()-started,'financialOperations':0,'proofsGenerated':0,'randomAuthorization':False},out,indent=2);out.write('\n')
print('Rejected',len(rows),'read-only saved-proof cases; no new proof or finance.')
