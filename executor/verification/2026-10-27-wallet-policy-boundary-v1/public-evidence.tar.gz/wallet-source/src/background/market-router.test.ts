import { describe, it, expect, vi } from "vitest";
vi.mock("./security-gates", () => ({
  assertApprovedAccountForOrigin: vi.fn((origin, address) => {
    if (origin !== "https://market.example" || address !== "a".repeat(64))
      throw Error("Forbidden");
  }),
  assertWalletUnlocked: (locked: boolean) => {
    if (locked) throw Error("Wallet locked");
  },
}));
import { routeMarketRequest } from "./market-router";
function fixture() {
  let installed = true,
    locked = false;
  const core = {
    isWalletLocked: () => locked,
    getMarketWriteCapabilities: () => ({
      schema: 1 as const,
      financialAuthorization: false as const,
      registryHash: "b".repeat(64),
      requiredSdkManifestSha256: "c".repeat(64),
      boundary: "test only",
      registryHashes: [],
      enabledMarketIds: [1000],
      chainRootAt1: "d".repeat(64),
      nftWrite: false as const,
      liveAcceptanceComplete: false as const,
      prepareOnly: !installed,
      nativeFullCallVerifier: installed,
      broadcast: installed,
    }),
    prepareMarketTransaction: vi.fn(),
    verifyMarketPreparation: vi.fn(),
    broadcastMarketPreparation: vi.fn(),
    reconcileMarketPreparation: vi.fn(),
    listMarketPreparations: vi.fn(),
    cancelMarketPreparation: vi.fn(),
  };
  return {
    core,
    setInstalled: (v: boolean) => {
      installed = v;
    },
    setLocked: (v: boolean) => {
      locked = v;
    },
  };
}
describe("approved-origin exact market router", () => {
  it("uses the browser origin and forwards only exact original identities", async () => {
    const { core } = fixture(),
      account = "a".repeat(64),
      intent = "1".repeat(64),
      prepared = "2".repeat(64);
    await routeMarketRequest(
      core,
      "psy_broadcastMarketPreparation",
      [account, intent, prepared],
      "https://market.example",
    );
    expect(core.broadcastMarketPreparation).toHaveBeenCalledWith(
      account,
      "https://market.example",
      intent,
      prepared,
    );
    await routeMarketRequest(
      core,
      "psy_reconcileMarketPreparation",
      [account, intent],
      "https://market.example",
    );
    expect(core.reconcileMarketPreparation).toHaveBeenCalledWith(
      account,
      "https://market.example",
      intent,
    );
    await expect(
      routeMarketRequest(
        core,
        "psy_broadcastMarketPreparation",
        [account, intent, prepared, { broadcast: () => {} }],
        "https://market.example",
      ),
    ).rejects.toThrow();
    await expect(
      routeMarketRequest(
        core,
        "psy_broadcastMarketPreparation",
        [account, intent, prepared],
        "https://evil.example",
      ),
    ).rejects.toThrow("Forbidden");
    expect(core.broadcastMarketPreparation).toHaveBeenCalledTimes(1);
  });
  it("closes before preparation when locked or resources are missing", async () => {
    const f = fixture(),
      params = ["a".repeat(64), { recordId: "1".repeat(64) }];
    f.setInstalled(false);
    await expect(
      routeMarketRequest(
        f.core,
        "psy_prepareMarketTransaction",
        params,
        "https://market.example",
      ),
    ).rejects.toThrow("not installed");
    f.setInstalled(true);
    f.setLocked(true);
    await expect(
      routeMarketRequest(
        f.core,
        "psy_prepareMarketTransaction",
        params,
        "https://market.example",
      ),
    ).rejects.toThrow("locked");
    expect(f.core.prepareMarketTransaction).not.toHaveBeenCalled();
  });
});
