import{readFile,writeFile,mkdir,cp}from'node:fs/promises';import{spawnSync}from'node:child_process';import assert from'node:assert/strict';
import{generateMinimumStream}from'<application-root>/batching/checkpoint-stream/minimum-generate.mjs';
import{parseLosslessJson}from'<application-root>/amm/u124/client.mjs';
const root='<evidence-root>',old=root+'/random-source-stream-20261029-v1',out=root+'/minimum-stream-integration-20261030-v1/fixtures-v1';await mkdir(out);
const pages=parseLosslessJson(await readFile(old+'/native-planner-v1/prepared/source-pages.json','utf8')),options={empty24:pages[0].before.users.map(String),empty56:pages[0].before.orders.map(String),window:8192};
for(const name of ['native.json','token','nft'])await cp(old+'/fixtures-v4/'+name,out+'/'+name,{recursive:true,errorOnExist:true,force:false});
for(const market of ['amm','bondingcurve']){const c={...JSON.parse(await readFile(old+'/fixtures-v4/'+market+'/config.json','utf8')),feeOwner:600};const d=out+'/'+market;await mkdir(d);await writeFile(d+'/config.json',JSON.stringify(c,null,2)+'\n',{flag:'wx'});await writeFile(d+'/minimum-options.json',JSON.stringify(options,null,2)+'\n',{flag:'wx'});await writeFile(d+'/main.psy.rs',generateMinimumStream(market,c,options),{flag:'wx'});
 const r=spawnSync(old+'/bin-v1/compile_random_stream',[d+'/main.psy.rs',d+'/compiled',String(c.assetA),String(c.assetB)],{encoding:'utf8',maxBuffer:4000000});await writeFile(d+'/compile.log',(r.stdout??'')+(r.stderr??''),{flag:'wx'});assert.equal(r.status,0,market+' minimum candidate compile');}
