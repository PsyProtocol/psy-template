import type { IPsyStateDispatch } from "@/background/psy-wallet-ext-core";
import type {
  ClaimBatchItem,
  ContractCallArgs,
  DPNFunctionCircuitDefinition,
  Felt,
  IPsyCompleteUserInfo,
  IPsyUserWallet,
  SignType,
} from "@psy-protocol/psy-sdk";
import type { PSY_INTERNAL_REQUEST_ACTION } from "@/message";

interface IPsyWidgetWallet extends IPsyCompleteUserInfo {
  wallet: IPsyUserWallet;
  name: string;
  address: string;
  isActive: boolean;
  userId: Felt;
  mnInd: number;
  signType: SignType;
  fingerprint?: string;
  sdkKeyCircuitParams?: ISdkKeyCircuitParams;
  shieldReceiveAddresses?: IShieldReceiveAddress[];
}

interface IWalletInfo {
  name: string;
  address: string;
  userId: string;
  mnInd: number;
  signType: SignType;
  fingerprint?: string;
  sdkKeyCircuitParams?: ISdkKeyCircuitParams;
  shieldReceiveAddresses?: IShieldReceiveAddressPublic[];
}

interface IShieldReceiveAddress {
  shieldAddress: string;
  r0: string;
  r1: string;
  nostrNpub: string;
  nostrDerivationVersion: "psy-privacy-v0";
  shieldStartIndex: number;
  deriveIndex?: number;
  label: string;
  createdAt: string;
  used: boolean;
  /** The userId this address was derived under (owner = Poseidon(userId,1337,
   *  r0,r1)). A devnet reset re-registers the account under a NEW userId, which
   *  cryptographically strands every address derived under the old one — this
   *  tag records the epoch for archival. Optional so cached/backup records
   *  round-trip unchanged; the derivation check (isCurrentIdentityAddress)
   *  stays the source of truth, so a missing/wrong tag can never hide a
   *  genuinely-current address. */
  ownerUserId?: string;
}

type IShieldReceiveAddressPublic = Omit<IShieldReceiveAddress, "r0" | "r1">;

interface IShieldReceiveShare {
  type: "psy_shield_receive";
  version: 1;
  shieldAddress: string;
  nostrNpub: string;
  label?: string;
}

interface IStorageWalletData {
  networkKey?: string;
  wallets: {
    /** Legacy unscoped id, read only for migration when networkKey embeds the same chainKey. */
    userId?: number;
    name: string;
    address: string;
    privateKey: string;
    networkKey?: string;
    signType: SignType;
    fingerprint?: string;
    sdkKeyCircuitParams?: ISdkKeyCircuitParams;
    shieldReceiveAddresses?: IShieldReceiveAddress[];
    cachedUserInfo?: IStorageWalletUserInfoCache;
    mnInd: number;
  }[];
  activeWalletAddress?: string;
}

interface IStorageWalletUserInfoCache {
  networkKey: string;
  networkId: string;
  l2NetworkMagic: string;
  userId: string;
  publicKeyHex: string;
  nonce: string;
  balance: string;
  updatedAt: string;
}

interface ISdkKeyCircuitParams {
  allowedContractIds: number[];
  allowedMethodIds: number[];
  expectedTxCount: number;
}

interface BaseApproveMsg<T extends string> {
  id: string;
  isPsy: boolean;
  action: T;
  params: unknown;
  // The requesting site, threaded onto the msg (NOT into `params`, whose
  // by-position parsing the execution path depends on) so any approval panel
  // can render a "Requested by …" origin card. Absent for the wallet's own
  // internal, no-popup actions. See approve-manager.receiveApproveMsg.
  origin?: string;
  avatar?: string;
  // Wallet-bundled pending claims (psy_execClaimBatch with a
  // `foldPendingClaims` opts param): summary stamped by approve-manager
  // AFTER it prepended the wallet items into `params`, so the approval
  // popup can render an explicit "also claiming N items totalling X" line.
  // Display-only — execution reads the already-rewritten params.
  foldedClaims?: {
    count: number;
    total: string;
    contractId: string;
    /** Per-item display amounts (base units), aligned with the PREPENDED folded
     *  rows — simple_claim args carry only the sender, so without this the
     *  popup row reads "Claim PSY" with no number. */
    itemAmounts?: string[];
  };
}

type hostname = string;
type avatar = string | undefined;

interface ApproveConnectParams {
  origin: hostname;
  avatar?: avatar;
  approvedAccounts: address[];
  currentWallet?: IWalletInfo;
  wallets: IWalletInfo[];
}

interface ApproveConnectMsg
  extends BaseApproveMsg<"psy_requestAccounts" | "psy_requestPermissions"> {
  params: ApproveConnectParams;
}

type address = string;

interface ApproveTransactionMsg extends BaseApproveMsg<"psy_sendTransaction"> {
  params: [address, ContractCallArgs | ContractCallArgs[]];
}

interface ClaimableSnapshotItem {
  kind: "public" | "private-note" | "deposit";
  id: string;
  contractId: number;
  amount: string;
}

interface ClaimablesSnapshotEnvelope {
  complete: boolean;
  snapshotToken: string;
  items: ClaimableSnapshotItem[];
}

interface ExactFoldExpectedItem {
  id: string;
  contractId: string | number;
  amount: string;
}

interface FoldPendingClaimsOptions {
  contractId?: string | number;
  snapshotToken?: string;
  expected?: ExactFoldExpectedItem[];
}

// Unified claim-and-transfer UPS surface. The bridge (and other dapps) pass
// the full mixed batch — public simple_claim / simple_transfer items + any
// private-note or shield-deposit claims that should be bundled into the same
// recursive proof — and the wallet runs them through generateBatchClaimTxTrace
// + prove-step. approve-manager handles the explicit approval path.
interface ApproveExecClaimBatchMsg
  extends BaseApproveMsg<"psy_execClaimBatch"> {
  /** Wallet-authored only after exact token, row, and fold-build validation. */
  exactFoldExecution?: true;
  // Optional third element: dApp opts. Legacy `{ contractId }` asks the wallet
  // for a best-effort fold. Supplying `snapshotToken` + `expected` upgrades the
  // request to the exact contract: background recomputes a complete snapshot
  // at head-of-queue and either prepends exactly those rows or rejects before a
  // popup opens.
  params: [
    address,
    ClaimBatchItem[],
    { foldPendingClaims?: FoldPendingClaimsOptions }?,
  ];
}

// Atomic claim-batch + private send — ONE fused UPS.
//
// `claims` AND the `private_transfer` send are bundled into a single
// claim-batch proof: ClaimBatchItem::Public proves any public contract call
// generically (prove_claim_batch_call(method_name)), so the send rides as a public
// item appended after the claims — same mechanics as public sends'
// [claims…, simple_transfer]. No settle-poll between two transactions.
//
// One approval popup, one dApp call, one on-chain transaction. If the
// fused batch fails, nothing landed (UPS is atomic) and the wallet
// surfaces `{ claimsTxHash: null, sendError, recoveryHint }`; the lib's
// legacy two-stage fallback (shape rejections only) reports a separate
// claims-only hash so "claims confirmed — retry send" is still possible.
interface ApproveExecClaimBatchAndPrivateTransferMsg
  extends BaseApproveMsg<"psy_execClaimBatchAndPrivateTransfer"> {
  params: [
    address,
    ClaimBatchItem[],
    {
      contract_id: string;
      recipient_shield_address: string;
      recipient_nostr_pubkey: string;
      amount: string;
      sender_label?: string;
      token_symbol?: string;
      decimals?: number;
    },
  ];
}

interface ApproveDeployContractMsg
  extends BaseApproveMsg<"psy_deployContract"> {
  params: [
    address,
    DPNFunctionCircuitDefinition[],
    unknown?,
    Record<string, unknown>?,
    string?,
  ];
}

interface ApproveListShieldReceiveAddressesMsg
  extends BaseApproveMsg<"psy_listShieldReceiveAddresses"> {
  params: [address];
}

interface ApproveNostrNpubMsg extends BaseApproveMsg<"psy_getNostrNpub"> {
  params: [address, string, string];
}

interface ApproveAddExternalProofMsg
  extends BaseApproveMsg<"psy_addExternalProof"> {
  params: [address, Uint8Array];
}

interface ApproveProvePrivateNoteInclusionMsg
  extends BaseApproveMsg<"psy_provePrivateNoteInclusion"> {
  params: [
    address,
    string,
    number | string,
    string,
    string,
    number | string,
    number | string,
    number | string,
    // end_user_leaf_hash — submitted transaction's identity (display hex).
    string,
  ];
}

interface ApproveDeriveShieldAddressMsg
  extends BaseApproveMsg<"psy_deriveShieldAddress"> {
  params: [address, string?];
}

interface ApproveShieldDepositMsg
  extends BaseApproveMsg<"psy_claimShieldDeposit"> {
  params: [
    address,
    string, // tokenAddressU32x8Json
    string, // l2TokenContractIdJson
    string, // amountU32x8Json
    number | string, // sourceChainIndex
    number | string, // depositIndex
    string, // depositRootJson
    string, // nullifierHashJson
    string, // noteCommitmentJson
    string, // depositProofBincodeB64
    string, // shieldAddress
    number | string, // contractId
    string?, // depositProofFingerprintJson
    string?, // shieldStartIndex
  ];
}

interface ApproveClaimWithExternalProofMsg
  extends BaseApproveMsg<"psy_claimWithExternalProof"> {
  params: [
    address,
    Uint8Array, // noteProof
    string, // nullifierJson
    string, // ownerJson
    number | string, // amount
    string, // userTreeRootJson
    number | string, // checkpointId
    number | string, // noteRootSlot
    number | string, // contractId
    string, // shieldAddress
    string?, // noteProofFingerprintJson
    string?, // noteVerifierDataJson
  ];
}

interface ApprovePreparedMarketMsg extends BaseApproveMsg<"psy_confirmPreparedMarket"> {
  params: [string, import("../market-native/confirmation").MarketConfirmationTerms, string];
}

type ApproveMsg =
  | ApprovePreparedMarketMsg
  | ApproveConnectMsg
  | ApproveTransactionMsg
  | ApproveExecClaimBatchMsg
  | ApproveExecClaimBatchAndPrivateTransferMsg
  | ApproveDeployContractMsg
  | ApproveListShieldReceiveAddressesMsg
  | ApproveNostrNpubMsg
  | ApproveAddExternalProofMsg
  | ApproveProvePrivateNoteInclusionMsg
  | ApproveDeriveShieldAddressMsg
  | ApproveShieldDepositMsg
  | ApproveClaimWithExternalProofMsg;
// | ApproveClaimRewardsMsg;

interface PsyInternalRequest
  extends BaseApproveMsg<typeof PSY_INTERNAL_REQUEST_ACTION> {
  type: keyof IPsyStateDispatch;
  params: string;
}

export type {
  ClaimableSnapshotItem,
  ClaimablesSnapshotEnvelope,
  ExactFoldExpectedItem,
  FoldPendingClaimsOptions,
  IPsyWidgetWallet,
  IWalletInfo,
  IStorageWalletData,
  IStorageWalletUserInfoCache,
  ISdkKeyCircuitParams,
  IShieldReceiveAddress,
  IShieldReceiveAddressPublic,
  IShieldReceiveShare,
  PsyInternalRequest,
  ApproveTransactionMsg,
  ApprovePreparedMarketMsg,
  ApproveExecClaimBatchMsg,
  ApproveExecClaimBatchAndPrivateTransferMsg,
  ApproveDeployContractMsg,
  ApproveListShieldReceiveAddressesMsg,
  ApproveNostrNpubMsg,
  ApproveAddExternalProofMsg,
  ApproveProvePrivateNoteInclusionMsg,
  ApproveDeriveShieldAddressMsg,
  ApproveShieldDepositMsg,
  ApproveClaimWithExternalProofMsg,
  ApproveConnectMsg,
  ApproveConnectParams,
  ApproveMsg,
};

export enum TxStatus {
  executing,
  complete,
  error,
  queued,
  cancelled,
  proving,
}

/**
 * Live pipeline phase of an in-flight (status `executing`) row, recorded by
 * the background as the group moves through the REAL submission pipeline:
 *   "queued"  — Activity rows are persisted but the prove+submit FIFO is
 *               still busy with an earlier transaction.
 *   "proving" — this group's proof generation is running.
 *   "confirming" — proof submission returned, and the wallet is waiting for
 *                  chain state (user nonce) to reflect inclusion.
 * Absent on settled rows, on rows restored after a service-worker restart
 * (a dead worker can't vouch for what it was doing when it died), and on
 * rows written by older builds — the UI falls back to plain "Pending" in
 * all of those cases.
 */
export type TxPendingPhase = "queued" | "proving" | "confirming";

/** One claimable consumed by a queued transaction. `amount` is stored only
 * when it is not present in the contract-call payload (notably simple_claim). */
export interface TxInput {
  key: string;
  amount?: string;
}

export interface ITransaction {
  status: TxStatus;
  publicKey: string;
  args?: ContractCallArgs;
  start_at?: number;
  checkpointId: Felt;
  end_at?: number;
  from?: string;
  to?: string;
  name: string;
  value?: Felt;
  detail?: any;
  groupId?: string;
  hash?: string;
  /** Sender's ON-CHAIN nonce at submission (decimal string). Recorded so a
   *  service-worker restart can reconcile an interrupted in-flight send:
   *  current chain nonce > senderNonce is evidence the tx landed. */
  senderNonce?: string;
  /** See TxPendingPhase. Display-layer narration only — settlement logic
   *  never reads it. */
  pendingPhase?: TxPendingPhase;
  slotCount?: number;
  queueId?: string;
  cancellable?: boolean;
  chainKey?: string;
  userId?: string;
  /** Claimables consumed by this transaction. This single field drives Claim
   *  list folding and incoming pending amounts. */
  inputs?: TxInput[];
  /** Queue-internal native claim inserted only to fund this batch's fee. */
  isFeeCover?: boolean;
}

export interface IPsyTxState {
  txPending: ITransaction[];
  txHistory: ITransaction[];
}

export type IPsyAccountsApprovedState = {
  record: Record<string, string[]>;
};

export interface IToken {
  id: string;
  name: string;
  symbol: string;
  contractId: string;
  balance: string;
  decimals: number;
}

export interface IPsyTokensState {
  loaded: boolean;
  /** chainKey:userId → { tokenId → confirmed balance (base units) }. Mirrored from
   *  the background-computed wallet snapshot by the bridge in use-tokens. */
  balancesByAddress: Record<string, Record<string, string>>;
  tokens: IToken[];
  addToken: (token: Omit<IToken, "id" | "balance">) => IToken;
  removeToken: (tokenId: string) => void;
  getTokenByContractId: (contractId: string) => IToken | undefined;
  /** Ask the background to recompute the unified wallet snapshot (balance +
   *  claimables). Balances flow back via the snapshot bridge. */
  refreshTokenBalances: (checkpointId?: Felt) => Promise<void>;
}
