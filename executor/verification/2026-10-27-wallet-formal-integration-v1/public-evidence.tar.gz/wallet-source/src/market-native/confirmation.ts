import {
  parseUnits,
  MAX_AMOUNT,
} from "../market-preparation/token/wide/arithmetic.mjs";
import { digest } from "../market-preparation/market-client/protocol.mjs";
import type { PreparationContext } from "../market-preparation/market-client/wallet/prepareService.mjs";
export interface MarketConfirmationTerms {
  schema: 1;
  context: PreparationContext;
  intentId: string;
  recordId: string;
  preparedHash: string;
  requestSha256: string;
  fullCalls: Array<{
    contract_id: string;
    method_name: string;
    inputs: string[];
  }>;
  actualFee: string;
  maxNetworkFee: string;
  validUntilCheckpoint: number;
  review: {
    request: Record<string, unknown>;
    plan: {
      kind: string;
      marketId: number;
      recipientId: number;
      walletNonce: string;
      network: { name: string; chainRootAt1: string };
      debits: Array<{ contractId: number; amount: string }>;
      minimum?: string | null;
      withdrawal?: {
        burned: string;
        minimumA: string;
        minimumB: string;
        [key: string]: unknown;
      } | null;
      effect?: unknown;
      [key: string]: unknown;
    };
  };
}
const hash = /^[0-9a-f]{64}$/;
// Validate only a public projection. Hydrated traces and signing witnesses must
// never cross into the approval window or its runtime message queue.
export async function marketConfirmation(unknownTerms: unknown) {
  const terms = structuredClone(unknownTerms) as MarketConfirmationTerms;
  const keys = [
    "schema",
    "context",
    "intentId",
    "recordId",
    "preparedHash",
    "requestSha256",
    "fullCalls",
    "actualFee",
    "maxNetworkFee",
    "validUntilCheckpoint",
    "review",
  ];
  if (
    !terms ||
    Object.keys(terms).sort().join() !== keys.sort().join() ||
    terms.schema !== 1 ||
    ![
      terms.intentId,
      terms.recordId,
      terms.preparedHash,
      terms.requestSha256,
      terms.context?.account,
    ].every((v) => hash.test(v ?? "")) ||
    !Array.isArray(terms.fullCalls) ||
    terms.fullCalls.length < 1 ||
    terms.fullCalls.length > 40 ||
    !/^[1-9]\d*$/.test(terms.actualFee) ||
    !/^[1-9]\d*$/.test(terms.maxNetworkFee) ||
    BigInt(terms.actualFee) > BigInt(terms.maxNetworkFee) ||
    !Number.isSafeInteger(terms.validUntilCheckpoint) ||
    terms.review?.plan?.recipientId !== terms.context.userId ||
    !Array.isArray(terms.review?.plan?.debits) ||
    typeof terms.review?.plan?.kind !== "string" ||
    !hash.test(terms.review?.plan?.network?.chainRootAt1 ?? "")
  )
    throw Error("Wallet-owned exact market confirmation is incomplete");
  const origin = new URL(terms.context.origin);
  if (
    origin.origin !== terms.context.origin ||
    !["https:", "http:"].includes(origin.protocol)
  )
    throw Error("Exact requesting origin required");
  const limits = marketLimitRows(terms);
  return { terms, limits, approvalSha256: await digest(terms) };
}

export function marketLimitRows(
  terms: MarketConfirmationTerms,
): Array<{ label: string; value: string }> {
  const { request, plan } = terms.review;
  if (request.kind !== plan.kind) throw Error("Reviewed action changed");
  const base = (value: unknown) => {
    if (
      typeof value !== "string" ||
      !/^(0|[1-9]\d*)$/.test(value) ||
      BigInt(value) <= 0n ||
      BigInt(value) > MAX_AMOUNT
    )
      throw Error("Binding U124 base-unit limit required");
    return value + " base units";
  };
  const amount = (value: unknown) => {
    if (
      typeof value !== "string" ||
      parseUnits(value, 18) <= 0n ||
      parseUnits(value, 18) > MAX_AMOUNT
    )
      throw Error("Binding positive token limit required");
    return value + " tokens (18 decimals)";
  };
  if (plan.kind === "swap")
    return [{ label: "Minimum swap output", value: base(plan.minimum) }];
  if (plan.kind === "add")
    return [{ label: "Minimum LP shares", value: base(plan.minimum) }];
  if (plan.kind === "remove") {
    const w = plan.withdrawal;
    if (!w) throw Error("Both withdrawal limits are required");
    return [
      { label: "LP shares to burn", value: base(w.burned) },
      { label: "Minimum asset A output", value: base(w.minimumA) },
      { label: "Minimum asset B output", value: base(w.minimumB) },
    ];
  }
  const t = request.terms as Record<string, unknown> | undefined;
  if (plan.kind === "book-order") {
    if (!t || !["0", "1"].includes(String(t.side)))
      throw Error("Whole-order side and limits required");
    return [
      { label: "Whole-order input", value: amount(t.amount) },
      { label: "Minimum opposite asset output", value: amount(t.minimum) },
      { label: "Partial fills", value: "Not allowed" },
    ];
  }
  if (plan.kind === "curve-buy" || plan.kind === "curve-sell") {
    if (
      !t ||
      typeof t.lots !== "string" ||
      !/^[1-9]\d{0,19}$/.test(t.lots) ||
      BigInt(t.lots) > 18446744069414584320n
    )
      throw Error("Exact Curve lots required");
    return [
      { label: "Curve lots", value: t.lots },
      {
        label:
          plan.kind === "curve-buy"
            ? "Maximum quote spend"
            : "Minimum quote output",
        value: amount(t.quoteLimit),
      },
    ];
  }
  if (
    [
      "admit",
      "cancel",
      "close",
      "release",
      "recover",
      "claim",
      "claim-ft",
      "claim-native",
    ].includes(plan.kind)
  )
    return [
      { label: "Operation", value: plan.kind },
      {
        label: "Settlement and claim",
        value:
          "Original order outcome and actual Outbox balances remain binding; this does not reverse completed trades.",
      },
    ];
  throw Error("This market action has no accepted wallet confirmation policy");
}
