//! Offline comparison of exact checkpoint bytes and frozen SDK verification paths.
//! Diagnostic output never qualifies a key, chain, finality certificate or random source.
use anyhow::{ensure, Context, Result};
use parth_core::protocol::core_types::{QZKProofPublicInputsHasherReader, QZKProofVerifier};
use plonky2::plonk::config::PoseidonGoldilocksConfig as C;
use psy_core::{constants::chain_id::PsyChainNetworkType, job::job_id::ProvingJobCircuitType as Kind};
use psy_plonky2_circuits::zk_verifier::PsyPlonky2ZKVerifier;
use psy_template_u124_markets::checkpoint_evidence::{decode_proof, resource_inventory};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{fs, io::{Read, Write}, time::Instant};

fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn read(path: &str) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    fs::File::open(path)?.take(2_000_001).read_to_end(&mut bytes)?;
    ensure!(bytes.len() <= 2_000_000, "bounded proof input");
    Ok(bytes)
}
fn compare(verifier: &PsyPlonky2ZKVerifier<C, 2>, inputs: &[Result<Vec<u8>>]) -> Result<Vec<Value>> {
    let common = verifier.gcv.common.get_common_circuit_data_ref(Kind::GenerateRollupStateTransitionProof)?;
    let key = &verifier.gcv.library.info_map[&Kind::GenerateRollupStateTransitionProof];
    let mut rows = Vec::new();
    for input in inputs {
        let bytes = input.as_ref().map_err(|error| anyhow::anyhow!("proof read failed: {error:#}"))?;
        let proof = decode_proof(bytes).context("strict proof decode")?;
        let official = PsyPlonky2ZKVerifier::<C, 2>::try_proof_from_slice(bytes).context("SDK proof decode")?;
        let roundtrip = bincode::serialize(&proof)?;
        let official_bytes = bincode::serialize(&official)?;
        let start = Instant::now();
        let result = verifier.verify_zk_proof(Kind::GenerateRollupStateTransitionProof as u32, &official);
        let elapsed = start.elapsed().as_secs_f64();
        let owned = plonky2::plonk::circuit_data::VerifierCircuitData {
            verifier_only: key.verifier_data.to_verifier_data::<C, 2>(), common: common.clone(),
        }.verify(proof.clone());
        rows.push(json!({
            "proofSha256": digest(bytes), "bytes": bytes.len(),
            "strictAndSdkDecodeEqual": roundtrip == official_bytes,
            "strictRoundtripExact": &roundtrip == bytes, "sdkRoundtripExact": &official_bytes == bytes,
            "publicInputs": proof.public_inputs, "fingerprint": key.fingerprint.to_string(),
            "commonSha256": digest(&bincode::serialize(common)?),
            "verifierOnlySha256": digest(&bincode::serialize(&key.verifier_data.to_verifier_data::<C,2>())?),
            "commonDegreeBits": common.degree_bits(),
            "shape": {"publicInputs": proof.public_inputs.len(), "constants": proof.proof.openings.constants.len(),
                "wires": proof.proof.openings.wires.len(), "sigmas": proof.proof.openings.plonk_sigmas.len(),
                "quotients": proof.proof.openings.quotient_polys.len(),
                "friQueryRounds": proof.proof.opening_proof.query_round_proofs.len()},
            "sdkBorrowedVerified": result.is_ok(), "sdkBorrowedSeconds": elapsed,
            "sdkBorrowedError": result.err().map(|e| format!("{e:#}")),
            "applicationOwnedVerified": owned.is_ok(), "applicationOwnedError": owned.err().map(|e| format!("{e:#}"))
        }));
    }
    Ok(rows)
}
fn fixed_resource_control(verifier: &PsyPlonky2ZKVerifier<C, 2>, proof_path: &std::path::Path) -> Result<Value> {
    use plonky2::{field::{goldilocks_field::GoldilocksField as F, types::Field}, hash::{hash_types::HashOut, poseidon::PoseidonHash}, plonk::config::Hasher};
    use psy_client_common::data::qhashout::QHashOut as Q;
    use psy_plonky2_circuits::{coordinator::circuits::checkpoint_state_transition_genesis::QEDCheckpointStateTransitionGenesisCircuit, proof_minifier::pm_core::get_circuit_fingerprint_generic};
    // Every compared key remains the original compiled cache. No resource from
    // a page/RPC/file is installed or tried as an alternative for the real pair.
    let mut kinds=verifier.gcv.library.info_map.keys().copied().collect::<Vec<_>>();
    kinds.sort_by_key(|k|*k as u32);
    let mut inventory=vec![];
    for kind in kinds {
        let info=&verifier.gcv.library.info_map[&kind];
        let vk=info.verifier_data.to_verifier_data::<C,2>();
        let actual=Q(get_circuit_fingerprint_generic(&vk));
        let common=verifier.gcv.common.get_common_circuit_data_ref(kind)?;
        ensure!(actual==info.fingerprint,"cached fingerprint mismatch for {kind:?}");
        ensure!(vk.constants_sigmas_cap.0.len()==1usize<<common.config.fri_config.cap_height,"cached cap/common shape mismatch");
        inventory.push(json!({"kind":kind as u32,"name":format!("{kind:?}"),"fingerprint":actual.to_string(),"fingerprintRecomputed":true,"commonSha256":digest(&bincode::serialize(common)?),"verifierOnlySha256":digest(&bincode::serialize(&vk)?),"commonDegreeBits":common.degree_bits(),"publicInputCount":common.num_public_inputs,"numConstants":common.num_constants,"config":common.config}));
    }
    let kind=Kind::GenesisBlockCheckpointStateTransition;
    let info=&verifier.gcv.library.info_map[&kind];
    let common=verifier.gcv.common.get_common_circuit_data_ref(kind)?;
    let genesis=QEDCheckpointStateTransitionGenesisCircuit::<C,2>::new();
    ensure!(genesis.circuit_data.verifier_only==info.verifier_data.to_verifier_data::<C,2>() && &genesis.circuit_data.common==common && genesis.fingerprint==info.fingerprint,"exact cached/source genesis resources required");
    let mut output=fs::OpenOptions::new().write(true).create_new(true).open(proof_path)?;
    let root=Q(HashOut{elements:[F::ONE;4]});
    let leaf=Q(HashOut{elements:[F::from_canonical_u64(2);4]});
    let start=Instant::now();
    let proof=genesis.prove_base(root,leaf,genesis.fingerprint)?;
    let bytes=bincode::serialize(&proof)?;
    let decoded=decode_proof(&bytes)?;
    ensure!(bincode::serialize(&decoded)?==bytes,"positive control exact encoding");
    genesis.circuit_data.verify(decoded.clone())?;
    verifier.verify_zk_proof(kind as u32,&decoded)?;
    plonky2::plonk::circuit_data::VerifierCircuitData{verifier_only:info.verifier_data.to_verifier_data::<C,2>(),common:common.clone()}.verify(decoded.clone())?;
    let expected=PoseidonHash::two_to_one(PoseidonHash::two_to_one(root.0,leaf.0),genesis.fingerprint.0);
    ensure!(decoded.public_inputs==expected.elements,"synthetic genesis cumulative public inputs");
    let mut altered=decoded.clone();altered.public_inputs[0]+=F::ONE;
    let negative=verifier.verify_zk_proof(kind as u32,&altered);
    ensure!(negative.is_err(),"changed public inputs accepted");
    output.write_all(&bytes)?;output.sync_all()?;
    Ok(json!({"scope":"synthetic genesis control under unchanged cached/source-equal resources; not the chain genesis or a transition acceptance","inventory":inventory,"genesisCachedAndSourceResourcesEqual":true,"genesisNativeVerified":true,"genesisSdkBorrowedVerified":true,"genesisApplicationOwnedVerified":true,"mutatedPublicInputsRejected":true,"mutatedPublicInputsError":negative.err().map(|e|format!("{e:#}")),"proofSha256":digest(&bytes),"proofBytes":bytes.len(),"publicInputs":decoded.public_inputs,"seconds":start.elapsed().as_secs_f64(),"proofsGenerated":1,"realTransitionProofsAccepted":0,"canonicalGenesisVerified":false,"financialOperations":0}))
}
fn parameters(network: PsyChainNetworkType) -> Result<Value> {
    let path = std::env::var("PSY_CONFIG_PATH").context("explicit source configuration required")?;
    let bytes = read(&path)?;
    let config: Value = serde_json::from_slice(&bytes)?;
    let mut sections = Vec::new();
    for name in ["localhost", "testnet", "mainnet"] {
        let section = &config["networks"][name];
        let counts: Vec<Value> = section["realm_configs"].as_array().into_iter().flatten().map(|realm|
            json!({"realmId": realm["id"], "validatorCount": realm["validators"].as_array().map(Vec::len)})).collect();
        sections.push(json!({"name": name, "magic": section["magic"], "validatorCounts": counts}));
    }
    let rotation = match psy_data::config::network_config::load_realm_rotation_config(network) {
        Ok(value) => json!({"available": true, "checkpointsPerEpoch": value.checkpoints_per_epoch, "validatorSubIds": value.validator_sub_ids}),
        Err(error) => json!({"available": false, "error": format!("{error:#}")}),
    };
    Ok(json!({"configSha256": digest(&bytes), "runtimeNetwork": std::env::var("PSY_NETWORK").ok(),
        "sections": sections, "officialRotationParameters": rotation,
        "scope": "source-selected public parameter observation; no configuration rewritten or network identity authenticated"}))
}
fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    ensure!(args.len() == 5 && ["cached", "constructed", "cached-with-control"].contains(&args[1].as_str()),
        "cached|constructed|cached-with-control PREVIOUS_PROOF CURRENT_PROOF FRESH_REPORT");
    psy_template_u124_markets::live_guard::require_compiled_verifier_domain()?;
    // Reserve output before expensive construction; never overwrite original evidence.
    let mut output = fs::OpenOptions::new().write(true).create_new(true).open(&args[4])?;
    let start = Instant::now();
    // Read once: the identities below must describe the same bytes actually verified.
    let inputs: Vec<_> = args[2..4].iter().map(|path| read(path)).collect();
    let network = PsyChainNetworkType::try_from_chain_id(psy_config::PSY_NETWORK_MAGIC)?;
    let result = std::panic::catch_unwind(|| -> Result<_> {
        if args[1] != "constructed" { Ok(PsyPlonky2ZKVerifier::<C,2>::from_cached()) }
            else { PsyPlonky2ZKVerifier::<C,2>::for_network(network).context("official frozen network resource construction") }
    });
    let mut report = match result {
        Ok(Ok(verifier)) => match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| compare(&verifier, &inputs))) {
            Ok(Ok(rows)) => {
                let mut value=json!({"resourcesConstructed": true, "stage": "proofComparison", "proofs": rows});
                if args[1]=="cached-with-control" {
                    let path=std::path::Path::new(&args[4]).with_extension("genesis-control.bin");
                    value["fixedResourceControl"]=match fixed_resource_control(&verifier,&path){Ok(v)=>v,Err(e)=>json!({"error":format!("{e:#}"),"scope":"control failure; no real proof acceptance"})};
                }
                value
            },
            Ok(Err(error)) => json!({"resourcesConstructed": true, "stage": "proofReadDecodeOrComparison", "error": format!("{error:#}")}),
            Err(_) => json!({"resourcesConstructed": true, "stage": "proofComparison", "comparisonPanicked": true}),
        },
        Ok(Err(error)) => json!({"resourcesConstructed": false, "stage": "resourceConstruction", "error": format!("{error:#}")}),
        Err(error) => {
            let text = error.downcast_ref::<String>().cloned().or_else(|| error.downcast_ref::<&str>().map(|s| s.to_string()));
            json!({"resourcesConstructed": false, "stage": "resourceConstruction", "constructionPanicked": true, "error": text})
        }
    };
    report["schema"] = 1.into();
    report["mode"] = args[1].clone().into();
    report["networkMagic"] = psy_config::PSY_NETWORK_MAGIC.to_string().into();
    report["sourceNetworkType"] = format!("{network:?}").into();
    report["elapsedSeconds"] = start.elapsed().as_secs_f64().into();
    match std::panic::catch_unwind(resource_inventory) {
        Ok(Ok(inventory)) => report["cachedResources"] = inventory,
        Ok(Err(error)) => report["cachedResourceError"] = format!("{error:#}").into(),
        Err(_) => report["cachedResourceInventoryPanicked"] = true.into(),
    }
    report["inputIdentities"] = inputs.iter().map(|input| match input {
        Ok(bytes) => json!({"bytes": bytes.len(), "sha256": digest(bytes)}),
        Err(error) => json!({"error": format!("{error:#}")}),
    }).collect::<Vec<_>>().into();
    report["sourceParameters"] = match parameters(network) {
        Ok(value) => value,
        Err(error) => json!({"error": format!("{error:#}")}),
    };
    for field in ["canonicalGenesisVerified", "chainDomainAuthenticated", "finalityVerified", "randomAuthorization", "broadcast"] {
        report[field] = false.into();
    }
    report["proofsGenerated"] = report.pointer("/fixedResourceControl/proofsGenerated").cloned().unwrap_or(json!(0));
    report["fixedResourceControlRequested"] = (args[1]=="cached-with-control").into(); report["financialOperations"] = 0.into();
    let accepted = report["proofs"].as_array().is_some_and(|rows| !rows.is_empty() && rows.iter().all(|r| r["sdkBorrowedVerified"] == true && r["applicationOwnedVerified"] == true && r["strictRoundtripExact"] == true && r["sdkRoundtripExact"] == true));
    report["allProofsMatched"] = accepted.into();
    output.write_all(&serde_json::to_vec_pretty(&report)?)?; output.write_all(b"\n")?; output.sync_all()?;
    ensure!(accepted, "checkpoint compatibility diagnostic did not accept both proofs; report preserved");
    Ok(())
}
