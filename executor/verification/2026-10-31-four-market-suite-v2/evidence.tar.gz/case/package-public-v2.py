from pathlib import Path
import json,hashlib,tarfile,gzip,io,re
p=Path(__file__).resolve().parent;a=Path('/Users/geir/Downloads/QED资料/litepaper/psy-template-security-20261016');out=a/'executor/verification/2026-10-31-four-market-suite-v2';out.mkdir();files={}
def add(path,name):
 assert path.is_file()and not path.is_symlink()and name not in files
 assert not name.startswith('/')and'..'not in Path(name).parts
 assert not any(x in path.parts for x in ['private','drivers','target'])
 data=path.read_bytes();assert not re.search(rb'"(?:privateKey|mnemonic|seedPhrase)"\s*:\s*"|BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY',data),name
 files[name]=data
for directory in ['public','current-v1','current-v2','sources','qa-nft-v1','qa-user-registration-v1','qa-registration-precheck-v1','qa-user-confirmation-v1','registration-funds-audit-v1','suite-tests-v1/suite-v1','suite-tests-v1/bound-v1','registered-target-bound-v1']:
 for source in sorted((p/directory).rglob('*')):
  if source.is_file():add(source,'case/'+str(source.relative_to(p)))
# The other three registered-target artifacts are exact pinned copies of the
# initial suite. Retain their hashes/manifest and omit only duplicate payloads.
for source in sorted((p/'registered-target-suite-v1').rglob('*')):
 if source.is_file()and(source.parent==p/'registered-target-suite-v1' or 'bondingcurve' in source.relative_to(p/'registered-target-suite-v1').parts):add(source,'case/'+str(source.relative_to(p)))
for source in sorted(p.glob('*.mjs')):add(source,'case/'+source.name)
for name in ['run.py','package-public-v1.py','package-public-v2.py','application-v1/APPLICATION.json']:add(p/name,'case/'+name)
sourcePaths=['amm/u124/vm-tests/src/bin/compile_pair_stream_market.rs','batching/checkpoint-stream/build-policy.mjs','batching/checkpoint-stream/pair-artifact.mjs','batching/checkpoint-stream/pair-optimized-build-policy.mjs']
sourcePaths += [str(x.relative_to(a))for x in sorted((a/'batching/market-suite').rglob('*'))if x.is_file()]
for name in sourcePaths:add(a/name,'source/'+name)
# Identity and provenance of the old v9 baseline are public; old proofs are not
# regenerated or copied as if they accepted the new candidate IDs.
reference=p.parent/'pair-triangle-recovery-20261029-v1/fixtures-v2'
old={str(x.relative_to(reference)):hashlib.sha256(x.read_bytes()).hexdigest()for market in ['orderbook','nftmarket']for x in [reference/market/'policy.json',reference/market/'stream-policy.json']}
files['PRESERVED-V9-POLICY-HASHES.json']=(json.dumps({'schema':1,'meaning':'Exact old policy bytes matched in integration tests; not new full UPS or current-ID acceptance','files':old},indent=2)+'\n').encode()
records=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}for name,data in sorted(files.items())]
with(out/'evidence.tar.gz').open('xb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
  with tarfile.open(mode='w',fileobj=gz)as tar:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
archive=(out/'evidence.tar.gz').read_bytes();manifest={'schema':1,'baseCommit':'99a1bc392dca4087384a718d8e4a1e6fb7e1e0bd','sdkCommit':'c92880c8b6e2c8d392f19368bc8801a2584fd427','archiveBytes':len(archive),'archiveSha256':hashlib.sha256(archive).hexdigest(),'priorPackSha256':'688772b33860033ef1b2a49e38fea764cc6beae4c91e20ef2dd47af52af3cf5b','scope':'Four real compiled candidate bytecodes, late-bound policies, cache/identity rejection tests and one exact original QA registration with Merkle evidence; no new live market settlement','exclusions':['Wallet secrets, mnemonics, signing witnesses and executables','Full private/network configuration','Large local tampered-negative copies; test code and result logs are retained','Three byte-identical registered-target candidate duplicates: reconstruct from the preserved initial suite under the manifest hashes'],'members':records}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz','r:gz')as tar:
 assert len(tar.getmembers())==len(records)
 for row in records:
  value=tar.extractfile(row['path']).read();assert len(value)==row['bytes']and hashlib.sha256(value).hexdigest()==row['sha256']
(out/'README.md').write_text('''# Four-market candidate suite and original QA registration

See [the team report](../../../docs/security/FOUR_MARKET_SUITE_20261031.md)
and [the offline entry point](../../../batching/market-suite/README.md).

All four existing deterministic contract sources compile with the frozen SDK.
The complete generated source, ABI/bytecode, audits, policies, pinned inputs,
rejection-test results, source-reuse records and original public QA registration
request/intent/send lock/receipt/URT/checkpoint evidence are in the archive.
QA user 1639168 is included at 25962. The Curve candidate uses its real numeric
recipient; the recipient is not funded or authorized for live graduation.

Asset/collection/market IDs remain provisional. Full current-instance UPS,
fresh-vault bootstrap, real settlement/claim and browser approval are not added
by compilation or test counts. Realm 0 metadata is inconsistent at 25863 and
26033, so no new market/QA B deployment or asset movement was attempted.

Every published member is SHA256-bound and reread after packaging. No wallet
secret, private key, mnemonic, signature witness or executable is included.
Original local failures and artifacts remain unchanged. Negative fixture clones
and three byte-identical cached candidate payloads are omitted, with exact
source/hash/reproduction records preserved.

Reproduce offline into fresh directories using rebuilt frozen compilers and
reviewed local hashes. Do not replay the consumed registration sender. Do not
adopt candidate IDs, host reports or cached artifacts as wallet authorization.
''')
print(json.dumps({'members':len(records),'archiveBytes':len(archive),'archiveSha256':manifest['archiveSha256'],'allMembersVerified':True}))
