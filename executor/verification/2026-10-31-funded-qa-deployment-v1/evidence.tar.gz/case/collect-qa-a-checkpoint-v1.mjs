import{collectDeploymentCheckpoint}from'../../psy-template-security-20261016/executor/acceptance/deploymentCheckpoint.mjs';
import{fileURLToPath}from'node:url';
await collectDeploymentCheckpoint({base:fileURLToPath(new URL('checkpoint-fixture-v1/',import.meta.url)),market:'qa-a',expectedDeployer:223232,out:fileURLToPath(new URL('checkpoint-qa-a-v1/',import.meta.url))});
